<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Inventory Management System</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

<?php include 'header.php';?>

	<?php 
		$user_query = "SELECT * FROM about_shop_own WHERE admin IN ($users_ids)";
			$abt_res = mysqli_query($conn,$user_query);
			$shop_data = mysqli_fetch_assoc($abt_res);
	?>
 
</head>

<script>
 
    $( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#mabout").addClass('active');
	 
});
 
function showdiv1(){
$('#display_shop').hide();
$('#edit_shop').show();
}


function showdiv2(){
$('#display_shop').show();
$('#edit_shop').hide();
}


function add_shop()
{ 		
	//if(! $form.valid()) return false;
	$("#shop_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
		e.preventDefault();
		  document.getElementById("btn2").disabled = true;
	    var myform = document.getElementById("shop_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/update_shop_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				if(data==1){
					alert("Shop Details Updated Successfully..");
				}else{
					alert("Shop Details Not Updated...try again!");
				}
				
				location.reload();
				 
			}
		});
	 
	 }
	 });
}


</script>

<body class="hold-transition skin-blue sidebar-mini">
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
About Shop
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">About Shop</li>
      </ol>
    </section>

    <!-- Main content -->
	 <section id="section1" class="content">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 style="font-size:25px;" class="box-title"><b>Shop Details</b></h3>
            </div><br>
			<div class="box-body">
			
			<div id="display_shop">
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Shop Number</label>
                                </div>
								<div class="col-md-3" id="sid1">
                                      <label><?php echo $shop_data['shop_number']; ?></label>
                                </div>
                                
                            </div>
                        </div>
<!------------------------------------------------ -->				
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Shop Name</label>
                                </div>
								<div class="col-md-3" id="sn1">
                                    <label><?php echo $shop_data['shop_name']; ?></label> 
                                </div>
                                
                            </div>
                        </div>
<!------------------------------------------------ -->			
				<div style="padding-top:10px;" class="row">
                            <div class="form-group">
                                <div class="col-md-2">
                                    <label>Owner name</label>
                                </div>
                                <div class="col-md-3" id="on1">
                                      <label><?php echo $shop_data['owner_name']; ?></label>
                                </div>
								 
                            </div>
				</div>	

<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Mobile No</label>
                                </div>
								<div class="col-md-3" id="mn1">
									<label><?php echo $shop_data['shop_contact']; ?></label>
                                </div>
                                 
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Mail id</label>
                                </div>
								<div class="col-md-3" id="mid1">
                                      <label><?php echo $shop_data['shop_email']; ?></label>
                                </div>
                                 
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> GST No</label>
                                </div>
                                <div class="col-md-3" id="gst1">
									<label><?php echo $shop_data['shop_gstno']; ?></label>
                                </div>
								 
                            </div>
                        </div>
						
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> PAN No</label>
                                </div>
                                <div class="col-md-3" id="gst1">
									<label><?php echo $shop_data['shop_pan']; ?></label>
                                </div>
								 
                            </div>
                        </div>
						
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> VAT No</label>
                                </div>
                                <div class="col-md-3" id="gst1">
									<label><?php echo $shop_data['shop_van']; ?></label>
                                </div>
								 
                            </div>
                        </div>
						
<!------------------------------------------------ -->
					<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Address:</label>
                                </div>
                                <div class="col-md-3" id="add1">
								 
								<label ><?php echo $shop_data['shop_address']; ?> </label>
                                      
                                </div>
								 
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Website:</label>
                                </div>
                                <div class="col-md-3" id="vatid1">
								 <label ><?php echo $shop_data['shop_website']; ?></label>
                                      
                                </div>
								 
                            </div>
                        </div>

<!------------------------------------------------ -->
						<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Terms & Conditions:</label>
                                </div>
                                <div class="col-md-3" id="terms1">
								 <label ><?php echo $shop_data['shop_terms_conditions']; ?></label>
                                      
                                </div>
								 
                            </div>
                        </div>

<!------------------------------------------------ -->

<!------------------------------------------------ -->
						<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Bill Print Mode:</label>
                                </div>
                                <div class="col-md-3" id="terms1">
								 <label ><?php if($shop_data['print_flag']==1){ echo 'Horizontal   (insert A4 half paper in horizontally in printer and )';}else{ echo 'Vertical  (insert A4 half paper in vertically in printer.)';} ?></label>
                                      
                                </div>
								 
                            </div>
                        </div>

<!------------------------------------------------ -->

						<div class="row">
                            <div class="form-group" style="padding-top:20px">
                                <div class="col-md-6">
                                   <button id="btn1"  style="margin-left:155px" onclick="showdiv1()" type="button" class="btn btn-warning">Edit</button>

								   <button style="margin-left:20px" onclick="showdiv2()" type="button" class="btn btn-danger">Cancel</button>
								   </div>
                            </div>
                        </div>

<!-------------------------------------------------- -->			
			</div>

			<div class="box-body" id="edit_shop" style="display:none;">
			
			<form id="shop_form" onsubmit="return add_shop()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
				
				<input type="hidden" class="form-control" value="<?php echo $shop_data['shop_id']; ?>" name="shop_id" id="shop_id">
				
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Shop Number</label>
                                </div>
								
                                <div class="col-md-3" >
                                      <input type="text" class="form-control" value="<?php echo $shop_data['shop_number']; ?>" name="shop_number" id="shop_number">
                                </div>
                            </div>
                        </div>
<!------------------------------------------------ -->				
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Shop Name</label>
                                </div>
								
                                <div class="col-md-3" >
                                      <input type="text" class="form-control" value="<?php echo $shop_data['shop_name']; ?>" name="shop_name" id="shop_name">
                                </div>
                            </div>
                        </div>
<!------------------------------------------------ -->			
				<div style="padding-top:10px;" class="row">
                            <div class="form-group">
                                <div class="col-md-2">
                                    <label>Owner name</label>
                                </div>
                               
								<div class="col-md-3">
                                      <input type="text" class="form-control" value="<?php echo $shop_data['owner_name']; ?>" name="owner_name" id="owner_name">
                                </div>
                            </div>
				</div>	

<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Mobile No</label>
                                </div>
								
                                <div class="col-md-3" >
                                      <input type="number" class="form-control" value="<?php echo $shop_data['shop_contact']; ?>" name="shop_contact" id="shop_contact">
                                </div>
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> Mail id</label>
                                </div>
								
                                <div class="col-md-3" >
                                      <input type="email" class="form-control" value="<?php echo $shop_data['shop_email']; ?>" name="shop_email" id="shop_email">
                                </div>
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> GST No</label>
                                </div>
                               
								<div class="col-md-3" >
                                      <input type="text" class="form-control"  value="<?php echo $shop_data['shop_gstno']; ?>" name="shop_gstno" id="shop_gstno">
                                </div>
                            </div>
                        </div>
						
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> PAN No</label>
                                </div>
                               
								<div class="col-md-3" >
                                      <input type="text" class="form-control"  value="<?php echo $shop_data['shop_pan']; ?>" name="shop_pan" id="shop_pan">
                                </div>
                            </div>
                        </div>
						
<!------------------------------------------------ -->				
				<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label> VAT No</label>
                                </div>
                               
								<div class="col-md-3" >
                                      <input type="text" class="form-control"  value="<?php echo $shop_data['shop_van']; ?>" name="shop_van" id="shop_van">
                                </div>
                            </div>
                        </div>
						
<!------------------------------------------------ -->
					<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Address:</label>
                                </div>
                                
								<div class="col-md-3" >
								<textarea class = "form-control" rows="3" name="shop_address" id="shop_address" placeholder = ""><?php echo $shop_data['shop_address']; ?></textarea>
                                </div>
                            </div>
                        </div>
<!------------------------------------------------ -->
				 <div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Website:</label>
                                </div>
                                
								<div class="col-md-3" >
								
                                 <input type="url"  class="form-control" value="<?php echo $shop_data['shop_website']; ?>" name="shop_website" id="shop_website" >
                                </div>
                            </div>
                        </div>

<!------------------------------------------------ -->
						<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Terms & Conditions:</label>
                                </div>
                              
								<div class="col-md-3" >
								
                                  <textarea class = "form-control" rows="3"  name="shop_terms_conditions" id="shop_terms_conditions" placeholder = ""><?php echo $shop_data['shop_terms_conditions']; ?></textarea>
                                </div>
                            </div>
                        </div>

<!------------------------------------------------ -->
						<div class="row" style="padding-top:10px">
                            <div class="form-group">
                                <div  class="col-md-2">
                                    <label>Bill Print Mode:</label>
                                </div>
                                <div class="col-md-3">
								 <input type="radio" <?php if($shop_data['print_flag']==1) { echo 'checked';} ?>  value="1" name="print_flag" id="print_flag" > Horizontal
								 &nbsp;&nbsp;<input type="radio" <?php if($shop_data['print_flag']==2) { echo 'checked';} ?> value="2" name="print_flag" id="print_flag" > Vertical
                                      
                                </div>
								 
                            </div>
                        </div>

<!------------------------------------------------ -->
<!------------------------------------------------ -->

						<div class="row" align="center">
                            <div class="form-group" style="padding-top:20px">
                                <div class="col-md-6">
                                  
								   <button id="btn2" style="margin-left:20px;"  type="submit" class="btn btn-primary">Save</button>
								   
								   <button style="margin-left:20px" onclick="showdiv2()" type="button" class="btn btn-danger">Cancel</button>
								   </div>
                            </div>
                        </div>
<!-------------------------------------------------- 	
&nbsp
                            <div class="form-group" style="padding-top:20px">
                                <div class="col-md-6">
                                   <button style="margin-left:155px" type="button" class="btn btn-success">Save</button>
                                </div>
                            </div>
                        </div>
<!-------------------------------------------------- -->			
			</form>
			</div>
			  </div>
		

  </div>
  </div>
  </div>
  </section>
    </div>

  <!--add rule pop start-->
  

<?php include 'footer.php';?>

</body>
</html>

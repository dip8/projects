<?php
$hostname_db = "localhost";
$database_db = "data_shop_inventory";
$username_db = "usershopinven";
$password_db = "shop@123"; 
$conn = mysqli_connect($hostname_db, $username_db, $password_db, $database_db) or die(mysqli_error());
mysqli_set_charset($conn,"utf8");
if($conn){
echo 'Ok';
}else{
echo 'Failed';
}
?>

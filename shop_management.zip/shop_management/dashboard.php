<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>
	
	<script>
 
function daily_sale()
{ 		 
	   var myform = document.getElementById("daily_sale_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/date_view.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				$('#report_result').html('');
				$('#report_result').html(data);
				 
			}
		});
	 
	 
} 
 

 
$(function () {
		$('#datetimepicker1').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
		$('#datetimepicker2').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
	document.getElementById('to_date').setAttribute("disabled","disabled");
	 
	 $('#from_date').change(function(){
			 
			$("#to_date").removeAttr("disabled"); 
			
		});
    $('#to_date').change(function(){
			
			 var from_date = $('#from_date').val();
			var to_date = $('#to_date').val();
			 
			 //alert(to_date);
			 if(from_date > to_date)
			 {
			 	alert('Please select From date AND To date correctly..!');
				$('#to_date').val('');
				
			 }
			 
			
           });    
           });    
</script>
<style>

.table-responsive1{
	max-width:100%;
	overflow:auto;
	
}
@media (max-width: 768px) {
  .content-header{
    margin-top:25px;
  }
}
.myheading{
	
	text-align:center;
	font-weight:bold; 
	font-size:20px; 
	margin-top: 0px;"
}
.myclass{
	margin-left:155px;
	margin-bottom:0px;
}
 @media (max-width: 767px){
 .myclass{
	margin-left:60px;
	margin-bottom:0px;
}
 }

</style>


<script>
$(document).ready(function(){
	$('#customer_master').addClass('active');
	$('#dealer_master').addClass('active');

});  
</script>  



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
	<div style="margin-top:20px;margin-bottom:20px;" class="row">

	<div class="col-lg-12">
	<div style="border-right:3px solid #DCDCDC;" class="col-lg-3 col-xs-6 col-sm-6">
	<a id="muser" href="bill.php"><div style="text-align: center;margin-bottom: 5px;" class="icon">
              <i style="font-size:50px;align:center; color: #09d08f;border-radius:50px;background-color:#fff;padding: 5px 19px; border:5px solid #09d08f; " class="fa fa-rupee "></i>
            </div></a>
			<a style="margin-top:0px; color: #888888;" href="bill.php" class="small-box-footer"><h4 class="myheading"><small>Add</small><br>Bill</h4></a>
	</div>
	<div  style="border-right:3px solid #DCDCDC;" class="col-lg-3 col-xs-6 col-sm-6">
	<a href="dealer.php"><div style="text-align: center;margin-bottom: 5px;" class="icon">
              <i style="font-size:50px;align:center; color: #ed673fcf;border-radius:50px;background-color:#fff;padding:0px 10px; border:5px solid #ed673fcf; " class="ion-person-add"></i>
            </div></a>
			<a  style="color: #888888;" href="dealer.php" class="small-box-footer"><h4 class="myheading"><small>Add</small><br>Dealer</h4></a>
	
	</div>
	<!--<div style="border-right:3px solid #DCDCDC;" class="col-lg-2 col-xs-4 col-sm-4">
	<a href="customer.php"><div style="text-align: center;margin-bottom: 5px;" class="icon">
              <i style="font-size:50px;align:center; color: #00c0ef;border-radius:50px;background-color:#fff;padding:0px 10px;; border:5px solid #00c0ef; " class="ion-person-stalker"></i>
            </div></a>
			<a style="color: #888888;" href="customer.php" class="small-box-footer"><h4 class="myheading"><small>Add</small><br>Customer</h4></a>
			
	
	</div>-->
	
	<div class="col-lg-6" style="padding: 0px;">
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-navy">
            <div class="inner">
			<?php 
			//$_SESSION['multi_users_ids'] = $users_ids;
				$cur_today = date("Y-m-d");
				$today = date("Y-m-d");
				$daily_total_query = "SELECT * FROM `daily_recharge` WHERE date='$cur_today' AND added_by IN ($users_ids) ORDER BY daily_recharge_id DESC";
				$daily_total_res = mysqli_query($conn,$daily_total_query);
				if (mysqli_num_rows($daily_total_res) > 0) {
				$daily_total_data = mysqli_fetch_assoc($daily_total_res);
				$recharge_total=$daily_total_data['opening_balance'];
				 }
			 else{ 
				$daily_total_query1 = "SELECT * FROM `daily_recharge` WHERE date<'$cur_today' AND added_by IN ($users_ids) ORDER BY daily_recharge_id DESC";
				$daily_total_res1 = mysqli_query($conn,$daily_total_query1);
				$daily_total_data = mysqli_fetch_assoc($daily_total_res1); 
				$recharge_total=$daily_total_data['closing_balance'];
				} 

				$recharge_total=($recharge_total!='')?(int)$recharge_total:0;
			?>
			
              <h3><?=$recharge_total?></h3>

              <p>Recharge Balance</p>
            </div>
            <div class="icon">
              <i class="ion ion-iphone"></i>
            </div>
            <a href="recharge.php"  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
			<?php
			$cur_today = date("Y-m-d");
			$user_query = "SELECT COUNT(sales_id) AS sales_id FROM sales WHERE sales_date='$cur_today'  AND added_by IN ($users_ids)";
			$ts_res = mysqli_query($conn,$user_query);
			$tss_list = mysqli_fetch_assoc($ts_res);
			
			$total_acc=($tss_list['sales_id']!='')?(int)$tss_list['sales_id']:0;
			?>
              <h3><?=$total_acc?><sup style="font-size: 20px"></sup></h3>

              <p>Today's Sale</p>
            </div>
            <div class="icon">
              <i class="ion ion-battery-charging"></i>
            </div>
            <a href="bill.php" onclick="showdiv('accessories')" class="small-box-footer">More info<i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        </div>
	
	</div>
	</div>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
			<?php
			  $mobque = "SELECT SUM(quantity) AS quantity FROM product WHERE category_id!=2  AND added_by IN ($users_ids) AND status=1";
			$mobres = mysqli_query($conn,$mobque);
			 
			$mob_que = mysqli_fetch_assoc($mobres);
			$total_mobile=($mob_que['quantity']!='')?(int)$mob_que['quantity']:0;
			?>
              <h3><?=$total_mobile?></h3>

              <p>Total Mobiles</p>
            </div>
            <div class="icon">
              <i class="ion ion-iphone"></i>
            </div>
            <a href="#section1" onclick="showdiv('mobile')" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
			<?php
			  $mobaque = "SELECT SUM(quantity) AS quantity FROM product WHERE category_id=2  AND added_by IN ($users_ids) AND status=1";
			$mobares = mysqli_query($conn,$mobaque);
			 
			$moba_que = mysqli_fetch_assoc($mobares);
			$total_acc=($moba_que['quantity']!='')?(int)$moba_que['quantity']:0;
			?>
              <h3><?=$total_acc?><sup style="font-size: 20px"></sup></h3>

              <p>Total Accessories</p>
            </div>
            <div class="icon">
              <i class="ion ion-battery-charging"></i>
            </div>
            <a href="#section2" onclick="showdiv('accessories')" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
			<?php
				$dque = "SELECT COUNT(supplier_id) AS supplier_id FROM supplier WHERE added_by IN ($users_ids)";
				$d_res = mysqli_query($conn,$dque);
			 
				$d_list = mysqli_fetch_assoc($d_res);
			?>
              <h3><?=$d_list['supplier_id']?></h3>

              <p>Total Dealers</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#section3" onclick="showdiv('dealer')" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <?php
				$cque = "SELECT COUNT(customer_id) AS customer_id FROM customer WHERE added_by IN ($users_ids)";
				$c_res = mysqli_query($conn,$cque);
			 
				$c_list = mysqli_fetch_assoc($c_res);
			?>
              <h3><?=$c_list['customer_id']?></h3>

              <p>Total Customers</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-stalker"></i>
            </div>
            <a href="#section4" onclick="showdiv('customer')" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
	
  
  
  <div class="row">
	<h3 style="font-size:25px;text-align:center;" class="box-title"><b>Total Sale & Purchase</b></h3>
	 <div  class="col-md-12">
	 <div style="border:2px solid #f39c12;" class="panel panel-warning">
	 
	  
	  <div class="panel-body" id="customer_edit">
	
	   <form id="daily_sale_form" onsubmit="daily_sale();"  autocomplete="off"  method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
      
     <div class="col-md-10 col-md-push-1">
    
    <div class = "form-group" >
      <label for="price" class="col-sm-3 control-label">From Date:</label>
		
      <div class = "col-sm-6">
	  
	   <div class='input-group date' id='datetimepicker2'>
        <input   type = "text"  class ="form-control" id = "from_date" name="from_date"   placeholder = "Enter From Date" required>
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
   
    
   <div class = "form-group" >
      <label for = "price" class = "col-sm-3 control-label">To Date:</label>
		
      <div class = "col-sm-6">
	  
	   <div class='input-group date' id='datetimepicker1'>
        <input   type = "text"  class ="form-control" id = "to_date" name="to_date"   placeholder = "Enter To Date" required>
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
    
   
</div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">  
			<button type="submit" id="btncustomer" class="btn btn-primary">Search</button>
	
		  <button  type="reset" class="btn btn-danger" onclick="window.location.reload();">Cancel</button>
			</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>

	<div id="report_result">
	<div class="col-lg-6 col-md-6 col-sm-6">
	<div class="panel panel-default">
	  <div class="panel-heading"><strong>Purchases</strong></div>
		<?php
			$purch = "SELECT SUM(p.total_amount) AS total_amount, SUM(p.total_payment) AS total_payment, SUM(p.total_balance) AS total_balance FROM purchase p WHERE added_by IN ($users_ids)";
			$total_purch = mysqli_query($conn,$purch);
			$totalpur_data = mysqli_fetch_assoc($total_purch); 
		?>
		<div class="panel-body" >
			<table class="table table-bordered table-striped ewDbTable"><tbody><tr><th>Total Amount</th><td style="text-align: right;"><?= $totalpur_data['total_amount']; ?></td></tr><tr><th>Total Payment</th><td style="text-align: right;"><?= $totalpur_data['total_payment']; ?></td></tr><tr><th>Total Balance</th><td style="text-align: right;"><?= $totalpur_data['total_balance']; ?></td></tr></tbody></table>  
		</div>
	</div>
	</div>
	<div class="col-lg-6 col-md-6 col-sm-6">
		<div class="panel panel-default">
		  <div class="panel-heading"><strong>Sales</strong></div>
			<?php
				$sale = "SELECT SUM(p.total_amount) AS total_amount, SUM(p.total_payment) AS total_payment, SUM(p.total_balance) AS total_balance, SUM(p.discount_amount) AS discount_amount, SUM(p.gst_amount) AS gst_amount FROM sales p WHERE added_by IN ($users_ids)";
				$total_sale = mysqli_query($conn,$sale);
				$totalsale_data = mysqli_fetch_assoc($total_sale); 
			?>
			<div class="panel-body">
				<table class="table table-bordered table-striped ewDbTable"><tbody><tr><th>Total Amount</th><td style="text-align: right;"><?= $totalsale_data['total_amount']; ?></td></tr><tr><th>Discount Amount</th><td style="text-align: right;"><?= $totalsale_data['discount_amount']; ?></td></tr><tr><th>GST Amount</th><td style="text-align: right;"><?= $totalsale_data['gst_amount']; ?></td></tr><tr><th>Total Payment</th><td style="text-align: right;"><?= $totalsale_data['total_payment']; ?></td></tr><tr><th>Total Balance</th><td style="text-align: right;"><?= $totalsale_data['total_balance']; ?></td></tr></tbody></table>  
			</div>
		</div>
	</div>
	</div>
</div>
	   <section id="section1" class="content" style="display:none;">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 style="font-size:25px;" class="box-title"><b>Total Mobiles</b></h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Company / Brand </th>
                  
                 
				  <th Style="border-right-width:2px;">Purchase Price</th>
				  <th Style="border-right-width:2px;">Sale Price</th>
				  <th Style="border-right-width:2px;">Quantity</th>
                  <!--th Style="border-right-width:2px;">edit</th>
				  <th Style="border-right-width:2px;">Delete</th-->
                </tr>
                </thead><tbody>
				<?php
			  $moblistque = "SELECT * FROM product WHERE category_id!=2 AND added_by IN ($users_ids) ORDER BY product_id DESC";
			$moblistres = mysqli_query($conn,$moblistque);
			 $mob=1;
			while($mob_list = mysqli_fetch_assoc($moblistres))
			{
				  $cmp_id=$mob_list['product_company'];
				$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$cmp_id' ");
						$cmp_row=mysqli_fetch_assoc($rescm);
						 $company_name1=$cmp_row['company_name'];
			?>
                
                <tr <?php if($mob_list['quantity']==0) { ?> style="color:red;" <?php } ?> >
                  <td><?=$mob++?></td>
                  <td><?=$mob_list['product_name']?></td>	
                  <td><?=$company_name1?></td>
                  <td><?=$mob_list['purchase_price']?></td>
                  <td><?=$mob_list['sale_price']?></td>
                  <td><?=$mob_list['quantity']?></td>
                  
                  <!--<td><a href=""><i class="fa fa-pencil"></i></a></td>
                <td  Style="border-right-width:2px;"><a href=""><i class="fa fa-trash"></i></a></td>
                -->
				</tr>
                 
			<?php } ?> 
              </tbody></table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	


	  
	  
    </section>
	
	
      <!-- Main row -->
      
      <!-- /.row (main row) -->
<!--Second section-->
 <section id="section2" class="content" style="display:none">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 style="font-size:25px;" class="box-title"><b>Total Accessories</b></h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example2" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Company / Brand </th>
                 <th Style="border-right-width:2px;">Quantity</th>
				  <th Style="border-right-width:2px;">Purchase Price</th>
				  <th Style="border-right-width:2px;">Sale Price</th>
				   
                   
                </tr>
                </thead><tbody>
                 	<?php
			  $moblistaque = "SELECT * FROM product WHERE category_id=2 AND added_by IN ($users_ids) ORDER BY product_id DESC";
			$moblistares = mysqli_query($conn,$moblistaque);
			 $moba=1;
			while($mob_lista = mysqli_fetch_assoc($moblistares))
			{
				 $cmp_ida=$mob_lista['product_company'];
				$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$cmp_ida'");
						$cmp_row=mysqli_fetch_assoc($rescm);
						$company_name_a=$cmp_row['company_name'];
			?>
                
                <tr <?php if($mob_list['quantity']==0){ ?> style="color:red;" <?php }?>>
                  <td><?=$moba++?></td>
                  <td><?=$mob_lista['product_name']?></td>	
                  <td><?=$company_name_a?></td>
                  <td><?=$mob_lista['quantity']?></td>
                  <td><?=$mob_lista['purchase_price']?></td>
                  <td><?=$mob_lista['sale_price']?></td>
                  
                  
                  <!--<td><a href=""><i class="fa fa-pencil"></i></a></td>
                <td  Style="border-right-width:2px;"><a href=""><i class="fa fa-trash"></i></a></td>
                -->
				</tr>
                
			<?php } ?> 
               </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	


	  
	  
    </section>
	
	
	<!--section Third-->
	 <section id="section3" class="content" style="display:none">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 style="font-size:25px;" class="box-title"><b>Total Dealers</b></h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example3" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Name </th>
                  <th>Company / Brand</th>
				 
                  <th Style="border-right-width:2px;">Email</th>
				  <th Style="border-right-width:2px;">Contact</th>
				  <th Style="border-right-width:2px;">Balance</th>
				  <th Style="border-right-width:2px;">Address</th>
                   
                </tr>
                </thead><tbody>
                 <?php
			  $sup_que = "SELECT * FROM supplier WHERE added_by IN ($users_ids) ORDER BY supplier_id DESC";
			$sup_res = mysqli_query($conn,$sup_que);
			 $sup=1;
			while($sup_list = mysqli_fetch_assoc($sup_res))
			{
				 $brand_a=explode(",",$dealer_data['supplier_for']);
						foreach($brand_a as $val){
						$ressct = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$val'");
						$subcat_row=mysqli_fetch_assoc($ressct);
						$company_name.= $subcat_row['company_name'].", ";
						}
			?>
                
                <tr>
                  <td><?=$sup++?></td>
                  <td><?=$sup_list['supplier_name']?></td>	
                  <td><?=rtrim($company_name,', ')?></td>
                  <td><?=$sup_list['email_id']?></td>
                  <td><?=$sup_list['contact_number']?></td>	
                  <td><?=$sup_list['balance']?></td>	
                  <td><?=$sup_list['supplier_address']?></td>
                   
                  
                  <!--<td><a href=""><i class="fa fa-pencil"></i></a></td>
                <td  Style="border-right-width:2px;"><a href=""><i class="fa fa-trash"></i></a></td>
                -->
				</tr>
                 
			<?php } ?> 
              </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	


	  
	  
    </section>
	
	<!--section fourth-->
	 <section id="section4" class="content" style="display:none">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 style="font-size:25px;" class="box-title"><b>Total Customers</b></h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example4" class="table table-bordered table-striped ">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email </th>
                  <th>Document</th>
              
				  <th Style="border-right-width:2px;">Contact</th>
				  <th Style="border-right-width:2px;">DOB</th>
				  <th Style="border-right-width:2px;">Wedding Date</th>
				  <th Style="border-right-width:2px;">Address</th>
				   
                </tr>
                </thead>
				  <tbody>
                <?php 
				 $user_query = "SELECT * FROM `customer` WHERE added_by IN ($users_ids) ORDER BY customer_id DESC";
			$cust_res = mysqli_query($conn,$user_query);
			$i=0;
			while($cust_data = mysqli_fetch_assoc($cust_res))
					{
						
						$id_proof= $cust_data['id_proof'];
						$user_level= $cust_data['user_level'];
						$status=$cust_data['status'];
						?>
              
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$cust_data['email_id']?></td>
                  <td><?=$cust_data['customer_name']?></td>
				   <td> <img width="30" src="img/customer/<?=$cust_data['id_proof']?>" alt="pic" onerror="this.src='img/no_img.png';" ></td>
                  
                  <td><?=$cust_data['mobile']?></td>
                  <td><?php if($cust_data['date_of_birth']){ echo  $cust_data['date_of_birth'];} else { echo "-";}?></td>
                  <td><?php if($cust_data['wedding_date']){ echo  $cust_data['wedding_date'];} else { echo "-";}?></td>
                    <td Style="border-right-width:2px;" align="center"><?=$cust_data['address']?></td>
				   
				  
				</tr>
                 
               
					<?php } ?>
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
	  
	


	  
	  
    </section>
	
    </section>
    <!-- /.content -->
	

  </div>
 
 
 <?php include 'footer.php';?>
</body>
</html>

-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 20, 2019 at 09:58 PM
-- Server version: 5.6.45-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_shop_inventory_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_shop`
--

CREATE TABLE `about_shop` (
  `shop_id` int(11) NOT NULL,
  `shop_number` varchar(40) NOT NULL,
  `shop_name` varchar(100) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `shop_contact` varchar(20) NOT NULL,
  `shop_email` varchar(100) NOT NULL,
  `shop_address` text NOT NULL,
  `shop_gstno` varchar(50) NOT NULL,
  `shop_website` text NOT NULL,
  `shop_van` varchar(500) NOT NULL,
  `shop_pan` varchar(500) NOT NULL,
  `shop_terms_conditions` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0- own shop/ 1- other shop'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_shop`
--

INSERT INTO `about_shop` (`shop_id`, `shop_number`, `shop_name`, `owner_name`, `shop_contact`, `shop_email`, `shop_address`, `shop_gstno`, `shop_website`, `shop_van`, `shop_pan`, `shop_terms_conditions`, `status`) VALUES
(1, 'ABC2365GHG', 'Swarnalakshya Celluler', 'Swapnil Hunnur', '8087865003', 'swarnalakshya16417@gmail.com', 'Shop no 3, bhairavnath Nagar society.,opp. Telephone exchange, sukhsagar Nagar katraj', 'ABC2365GHG654AB', 'https://www.yeoffer.com/42cc90', '277507890767', 'AACCK6789G', 'You know, being a test pilot isn\'t always the healthiest business in the world.', 1),
(2, '', '', '', '', '', '', '', '', '', '', '', 1),
(3, '001', 'gurukrupa', 'bharati patil', '89076543244657', 'bharatikp10@gmail.com', 'vishwa gym katraj pune', '8900', '', '678090989766', 'cffd56', '', 1),
(4, '', '', '', '', '', '', '', '', '', '', '', 1),
(6, '900', 'test', 'testing', '9089786570', 'bharati@gmail.com', 'ghgfhhghhhj', '789', '', '0000000000', '900', '', 1),
(7, '68346478340', 'harsh enterprises', 'harsh patil', '8989898989', 'harsh@gmail.com', 'harsh comminucation near gold gym viman nagar pune', '98989898', 'http://www.harshcomminucation.com', '67876577874', '89876543567', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactive,1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `status`) VALUES
(1, 'Mobile', 1),
(2, 'Accessories', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ca_payment_transaction`
--

CREATE TABLE `ca_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('sales','purchase') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_payment_transaction`
--

INSERT INTO `ca_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', 'sales', '1', '', 'Cash', 300, 0, 300, '2018-04-06', '2018-03-27', '2018-03-26 22:43:11', '1', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', 'sales', '0', '', 'Cash', 13664, 0, 13664, '2018-04-06', '2018-03-27', '2018-03-27 01:38:11', '1', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', 'sales', '1', '', 'Cash', 8000, 1111, 6889, '2018-06-12', '2018-06-02', '2018-06-02 00:48:24', '1', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', 'sales', '1', '', 'Cash', 8000, 8000, 0, '0000-00-00', '2018-06-18', '2018-06-17 21:33:05', '1', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000005', 'sales', '5', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-06-20', '2018-06-20 01:12:26', '1', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000006', 'sales', '6', '', 'Cash', 15800, 0, 15800, '2018-07-08', '2018-06-28', '2018-06-28 04:26:50', '1', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000007', 'sales', '8', '', 'Cash', 8000, 0, 8000, '2018-08-06', '2018-07-27', '2018-07-27 03:49:18', '1', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000008', 'sales', '8', '', 'Cash', 8000, 0, 8000, '2018-08-06', '2018-07-27', '2018-07-27 03:49:26', '1', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000009', 'sales', '8', '', 'Cash', 12000, 0, 12000, '2018-08-06', '2018-07-27', '2018-07-27 04:39:33', '1', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000010', 'sales', '10', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-08-03', '2018-08-03 10:12:29', '1', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000011', 'sales', '10', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-08-03', '2018-08-03 10:12:35', '1', '0000-00-00 00:00:00', ''),
(12, 'Bill-0000000000012', 'sales', '2', '', 'Cash', 8000, 0, 8000, '2018-08-13', '2018-08-03', '2018-08-03 10:29:21', '1', '0000-00-00 00:00:00', ''),
(13, 'Bill-0000000000013', 'sales', '2', '', 'Cash', 8000, 0, 8000, '2018-08-13', '2018-08-03', '2018-08-03 10:29:39', '1', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000014', 'sales', '11', '', 'Cash', 50000, 0, 50000, '2018-08-27', '2018-08-17', '2018-08-17 00:31:39', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `ca_sales`
--

CREATE TABLE `ca_sales` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(50) NOT NULL,
  `sales_date` datetime NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_sales`
--

INSERT INTO `ca_sales` (`sales_id`, `sales_number`, `sales_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', '2018-03-27 00:00:00', '1', '', 254.24, 0, 300, '', 0, 0, 0, 45.76, '', 300, '2018-03-26 22:43:11', '1', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', '2018-03-27 00:00:00', '0', '', 12200, 0, 13664, '', 2.45901639344, 336, 12, 1464, '', 13664, '2018-03-27 01:38:11', '1', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', '2018-06-02 00:00:00', '1', '', 7142.86, 1111, 6889, '', 0, 0, 12, 857.14, '', 8000, '2018-06-02 00:48:24', '1', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', '2018-06-18 00:00:00', '1', '', 7142.86, 8000, 0, '', 0, 0, 12, 857.14, '', 8000, '2018-06-17 21:33:05', '1', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000005', '2018-06-20 00:00:00', '5', '', 0, 0, 0, '', 0, 0, 5, 0, '', 0, '2018-06-20 01:12:26', '1', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000006', '2018-06-28 00:00:00', '6', '', 14107.14, 0, 15800, '', 1.2658227848101, 200, 12, 1692.86, '', 15800, '2018-06-28 04:26:50', '1', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000007', '2018-07-27 00:00:00', '8', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-07-27 03:49:18', '1', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000008', '2018-07-27 00:00:00', '8', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-07-27 03:49:26', '1', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000009', '2018-07-27 00:00:00', '8', '', 10714.29, 0, 12000, '', 0, 0, 12, 1285.71, '', 12000, '2018-07-27 04:39:33', '1', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000010', '2018-08-03 00:00:00', '10', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-08-03 10:12:29', '1', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000011', '2018-08-03 00:00:00', '10', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-08-03 10:12:35', '1', '0000-00-00 00:00:00', ''),
(12, 'Bill-0000000000012', '2018-08-03 00:00:00', '2', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-08-03 10:29:21', '1', '0000-00-00 00:00:00', ''),
(13, 'Bill-0000000000013', '2018-08-03 00:00:00', '2', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-08-03 10:29:39', '1', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000014', '2018-08-17 00:00:00', '11', '', 44642.86, 0, 50000, '', -100, -50000, 12, 5357.14, '', 50000, '2018-08-17 00:31:39', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `ca_sales_detail`
--

CREATE TABLE `ca_sales_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_sales_detail`
--

INSERT INTO `ca_sales_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Bill-0000000000001', '2', '4', '', 1, 0, 254.24, '18', '45.76', 300),
(2, 'Bill-0000000000002', '1', '2', '', 1, 0, 12200, '12', '1464', 13664),
(3, 'Bill-0000000000003', '1', '7', '', 1, 0, 7142.86, '12', '857.14', 8000),
(4, 'Bill-0000000000004', '1', '6', '', 1, 0, 7142.86, '12', '857.14', 8000),
(5, 'Bill-0000000000005', '1', '11', '', 1, 0, 129, '5', '6', 135),
(6, 'Bill-0000000000006', '1', '10', '', 1, 0, 17857.14, '12', '4285.72', 20000),
(7, 'Bill-0000000000007', '1', '6', '878789098098776', 1, 0, 7142.86, '12', '857.14', 8000),
(8, 'Bill-0000000000008', '1', '6', '878789098098776', 1, 0, 7142.86, '12', '857.14', 8000),
(9, 'Bill-0000000000009', '1', '9', '9088888888887756', 1, 0, 10714.29, '12', '1285.71', 12000),
(10, 'Bill-0000000000010', '', '', '25454', 1, 0, 0, '0', '0', 0),
(11, 'Bill-0000000000011', '', '', '25454', 1, 0, 0, '0', '0', 0),
(12, 'Bill-0000000000012', '1', '6', '355879090524537', 1, 0, 7142.86, '12', '857.14', 8000),
(13, 'Bill-0000000000013', '1', '6', '355879090524537', 1, 0, 7142.86, '12', '857.14', 8000),
(14, 'Bill-0000000000000', '4', '13', '10000000000005', 1, 0, 13152.54, '18', '2367.46', 15520),
(15, 'Bill-0000000000014', '', '', 'Ertfrgteef', 1, 0, 44642.86, '12', '5357.14', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_number` varchar(50) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_number`, `company_name`, `status`) VALUES
(1, '', 'Samsung', 1),
(2, '', 'Nokia', 1),
(3, '', 'Apple', 1),
(4, '', 'Motorola', 1),
(5, '', 'Redmi', 1),
(6, '', 'Vivo', 1),
(7, '', 'Oppo', 1),
(8, '', 'Micromax', 1),
(9, '', 'Lava', 1),
(10, '', 'LYF', 1),
(13, '', 'one+', 1),
(14, '', 'ORAIMO ', 1),
(15, '', 'Sony', 1);

-- --------------------------------------------------------

--
-- Table structure for table `company_supplier`
--

CREATE TABLE `company_supplier` (
  `com_sup_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_supplier`
--

INSERT INTO `company_supplier` (`com_sup_id`, `supplier_id`, `company_id`, `status`) VALUES
(1, 1, 6, 1),
(2, 2, 14, 1),
(3, 3, 6, 1),
(4, 0, 1, 1),
(5, 4, 1, 1),
(6, 5, 2, 1),
(7, 6, 1, 1),
(8, 6, 2, 1),
(9, 6, 3, 1),
(10, 6, 4, 1),
(11, 6, 5, 1),
(12, 6, 6, 1),
(13, 6, 7, 1),
(14, 6, 8, 1),
(15, 6, 9, 1),
(16, 6, 10, 1),
(17, 6, 13, 1),
(18, 6, 14, 1),
(19, 7, 1, 1),
(20, 7, 2, 1),
(21, 7, 3, 1),
(22, 7, 4, 1),
(23, 7, 5, 1),
(24, 7, 6, 1),
(25, 7, 7, 1),
(26, 7, 8, 1),
(27, 7, 9, 1),
(28, 7, 10, 1),
(29, 7, 13, 1),
(30, 7, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_person`
--

CREATE TABLE `contact_person` (
  `contact_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `contact_name` varchar(500) NOT NULL,
  `contact_phone` varchar(500) NOT NULL,
  `contact_email` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0-inactive ,1-active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_person`
--

INSERT INTO `contact_person` (`contact_id`, `supplier_id`, `contact_name`, `contact_phone`, `contact_email`, `status`) VALUES
(1, 1, 'Harsh ', '98000000000', '', 1),
(2, 2, 'Kishor Shinde', '7498512591', '', 1),
(3, 3, 'Harsh', '9800000000', '', 1),
(4, 4, '', '', '', 1),
(5, 1, 'ABC', '', '', 1),
(6, 5, '', '', '', 1),
(7, 2, 'aaa', '', '', 1),
(8, 0, 'a', '999999999999999999999999999999999999999999', '', 1),
(9, 6, '', '', '', 1),
(10, 0, 'a', '99999999999999999999999999999999999999999', '', 1),
(11, 4, 'nikhil patil', '678907654', '', 1),
(12, 1, 'bharati patil', '', '', 1),
(13, 3, 'testing', '', '', 1),
(14, 4, 'bharati patil', '', '', 1),
(15, 5, 'bharati patil', '90768788909', '', 1),
(16, 6, 'vijay patil', '1010101010', '', 1),
(17, 1, 'aa', '', '', 1),
(18, 7, '8787878787', '0', '', 1),
(19, 8, '', '', '', 1),
(20, 7, 'abc', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_number` varchar(50) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email_id` varchar(80) NOT NULL,
  `address` varchar(255) NOT NULL,
  `id_proof` varchar(255) NOT NULL,
  `date_of_birth` datetime NOT NULL,
  `wedding_date` datetime NOT NULL,
  `balance` double(20,0) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactivate / 1-Activate',
  `customer_gst_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_number`, `customer_name`, `mobile`, `email_id`, `address`, `id_proof`, `date_of_birth`, `wedding_date`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `customer_gst_no`) VALUES
(1, 'Cust-00000000001', 'Amar Pardeshi', '8275473337', 'prakash.holam@vigopa.com', 'Pune ', '', '1992-12-05 00:00:00', '1992-12-05 00:00:00', 6926, '2018-03-24 10:38:57', '1', '2018-06-14 06:42:05', '1', 1, ''),
(2, 'Cust-00000000002', 'sagar khomane', '9890150507', '', 'Pune ', '', '1992-07-04 00:00:00', '0000-00-00 00:00:00', 16000, '2018-06-12 04:15:24', '1', '0000-00-00 00:00:00', '', 1, ''),
(3, 'Cust-00000000003', 'santosh aware', '9865326598', '', 'Pune', '', '2010-06-09 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-12 04:25:33', '1', '0000-00-00 00:00:00', '', 1, ''),
(4, 'Cust-00000000004', 'pratibha raut', '7878787887', '', 'Pune', '', '2018-06-15 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-12 04:54:04', '1', '0000-00-00 00:00:00', '', 1, ''),
(5, 'Cust-00000000005', 'anant', '7777777777', 'a@a', 'WHERE 1 \"', 'anant_1528961743.PNG', '2018-06-04 00:00:00', '2018-06-04 00:00:00', 0, '2018-06-14 07:35:43', '', '2018-06-25 12:12:50', '1', 1, 'WHERE 1\";'),
(6, 'Cust-00000000006', 'Ravi', '7875509898', '', 'Vigopa Solutions, 104-Second floor, Sliver point building\r\nSurvey no 20/1/3, Katraj-Kondhawa Road,Katraj', '', '1989-06-06 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-28 11:26:50', '1', '0000-00-00 00:00:00', '', 1, 'AUFF435y33'),
(7, 'Cust-00000000007', 'Vishal gupta', '7042826456', 'vishalbabu1411@gmail.com', 'M-197', '', '1988-11-14 00:00:00', '1988-11-14 00:00:00', 0, '2018-07-27 05:19:17', '1', '0000-00-00 00:00:00', '', 1, 'Bkapb8965d'),
(8, 'Cust-00000000008', 'bharati patil', '9789054328', 'bharatikp10@gmail.com', 'katraj pune', 'bharati patil_1532684567.jpg', '1991-11-10 00:00:00', '1991-11-10 00:00:00', 21074, '2018-07-27 09:42:47', '', '2018-07-27 09:44:08', '1', 1, '101878'),
(9, 'Cust-00000000009', 'suraj surve', '9999999999', '', 'suraj surve shivaji nagar pune', '', '1990-12-21 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-01 12:45:55', '1', '0000-00-00 00:00:00', '', 1, ''),
(10, 'Cust-00000000010', 'sxscxaac', '2322', '', 'sacas', '', '2018-08-03 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-03 17:12:29', '1', '0000-00-00 00:00:00', '', 1, 'dddf'),
(11, 'Cust-00000000011', 'Fhdgjv', '85533467957', '', 'Xhdhhf', '', '2018-08-08 00:00:00', '0000-00-00 00:00:00', 50000, '2018-08-17 07:31:39', '1', '0000-00-00 00:00:00', '', 1, '0'),
(12, 'Cust-00000000012', 'yash patne', '9970275714', 'yashpatne@gmail.com', 'vigopa solution,opp. silver topaz bulding katraj kondhva road pune', '', '2018-08-01 00:00:00', '2018-08-01 00:00:00', 0, '2018-08-21 10:38:28', '1', '0000-00-00 00:00:00', '', 1, '999999');

-- --------------------------------------------------------

--
-- Table structure for table `customer_return`
--

CREATE TABLE `customer_return` (
  `return_id` int(11) NOT NULL,
  `return_number` varchar(200) NOT NULL,
  `return_date` date NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return`
--

INSERT INTO `customer_return` (`return_id`, `return_number`, `return_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', '2018-07-18', '1', '', 0, 0, 6926, '', 0, 0, 0, 0, '', 6926, '2018-07-18 00:49:35', '1', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', '2018-07-27', '8', '', 0, 0, 6926, '', 0, 0, 0, 0, '', 6926, '2018-07-27 03:52:46', '1', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', '2018-08-04', '8', '', 0, 13852, 0, '', 0, 0, 0, 0, '', 13852, '2018-08-04 07:01:30', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_detail`
--

CREATE TABLE `customer_return_detail` (
  `return_d_id` int(11) NOT NULL,
  `return_number` varchar(200) NOT NULL,
  `customer_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return_detail`
--

INSERT INTO `customer_return_detail` (`return_d_id`, `return_number`, `customer_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Return-0000000000001', '1', '6', '', 1, 0, 0, '', '', 6926),
(2, 'Return-0000000000002', '8', '6', '878789098098776', 1, 0, 0, '', '', 6926),
(3, 'Return-0000000000000', '', '', '', 1, 0, 0, '', '', 0),
(4, 'Return-0000000000003', '8', '6', '878789098098776', 1, 0, 0, '', '', 6926),
(5, 'Return-0000000000003', '8', '6', '878789098098776', 1, 0, 0, '', '', 6926);

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_payment_details`
--

CREATE TABLE `customer_return_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_payment_transaction`
--

CREATE TABLE `customer_return_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('return') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return_payment_transaction`
--

INSERT INTO `customer_return_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', 'return', '1', '', 'Credit', 6926, 0, 6926, '2018-07-28', '2018-07-18', '2018-07-18 00:49:35', '1', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', 'return', '8', '', 'Cash', 6926, 0, 6926, '2018-08-06', '2018-07-27', '2018-07-27 03:52:46', '1', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', 'return', '8', '', 'Cash', 13852, 13852, 0, '0000-00-00', '2018-08-04', '2018-08-04 07:01:30', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `daily_recharge`
--

CREATE TABLE `daily_recharge` (
  `daily_recharge_id` int(11) NOT NULL,
  `opening_balance` double DEFAULT '0',
  `purchase_balance` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `sale_balance` double DEFAULT '0',
  `closing_balance` double DEFAULT '0',
  `date` date NOT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_recharge`
--

INSERT INTO `daily_recharge` (`daily_recharge_id`, `opening_balance`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES
(1, 0, 3000, 3000, 0, 3000, '2018-06-11', NULL, NULL, '2018-06-14 14:25:35', NULL, 1),
(2, 3000, 0, 2500, 500, 2500, '2018-06-12', NULL, NULL, '2018-06-14 14:25:35', NULL, 1),
(3, 2500, 2000, 3000, 1500, 3000, '2018-06-14', '1', '1', '2018-06-14 14:30:30', '2018-06-14 00:00:00', 1),
(4, 3000, 500, 3500, 0, 3500, '2018-06-16', '1', '', '2018-06-16 04:37:11', '0000-00-00 00:00:00', 1),
(5, 0, 100, 100, 0, 100, '2018-04-02', '', '', '2018-06-16 09:38:35', '0000-00-00 00:00:00', 1),
(6, 100, 900, 1000, 0, 1000, '2018-06-19', '1', '', '2018-06-19 09:34:14', '0000-00-00 00:00:00', 1),
(7, 1000, -500, 500, 0, 500, '2018-06-25', '1', '', '2018-06-25 12:26:09', '0000-00-00 00:00:00', 1),
(8, 100, 300, 400, 0, 400, '2018-05-30', '1', '', '2018-07-27 11:18:43', '0000-00-00 00:00:00', 1),
(9, 400, 500, 900, 0, 900, '2018-07-31', '1', '', '2018-07-31 09:38:48', '0000-00-00 00:00:00', 1),
(10, 900, 2000, 1400, 1500, 1400, '2018-08-01', '1', '1', '2018-08-01 11:49:25', '2018-08-01 00:00:00', 1),
(11, 1400, 200, 1400, 200, 1400, '2018-08-04', '1', '1', '2018-08-04 13:38:15', '2018-08-04 00:00:00', 1),
(12, 1400, 6500, 5900, 2000, 5900, '2018-09-16', '1', '1', '2018-09-16 10:11:48', '2018-09-16 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exchange`
--

CREATE TABLE `exchange` (
  `exchange_id` int(11) NOT NULL,
  `exchange_number` varchar(50) NOT NULL,
  `from_shop` varchar(20) NOT NULL,
  `to_shop` varchar(20) NOT NULL,
  `amount` double(20,0) NOT NULL,
  `pay_amount` double(20,0) NOT NULL,
  `bal_amount` double(20,0) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1- Actual/ 0- Cutting',
  `exchange_date` date NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `date_updated` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange`
--

INSERT INTO `exchange` (`exchange_id`, `exchange_number`, `from_shop`, `to_shop`, `amount`, `pay_amount`, `bal_amount`, `type`, `exchange_date`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Exch-0000000000001', '', '1', 7219, 0, 7219, 1, '2018-05-04', '2018-05-04 05:26:19', '', '0000-00-00 00:00:00', ''),
(2, 'Exch-0000000000002', '1', '1', 1212, 0, 1212, 1, '2018-07-09', '2018-07-09 03:58:52', '1', '0000-00-00 00:00:00', ''),
(3, 'Exch-0000000000003', '1', '6', 1, 0, 1, 1, '2018-07-27', '2018-07-27 04:03:09', '1', '0000-00-00 00:00:00', ''),
(4, 'Exch-0000000000004', '1', '7', 10, 0, 10, 1, '2018-08-03', '2018-08-03 00:46:12', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `exchange_detail`
--

CREATE TABLE `exchange_detail` (
  `exchange_d_id` int(11) NOT NULL,
  `exchange_number` varchar(50) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(50) NOT NULL,
  `quantity` double(20,0) NOT NULL DEFAULT '0',
  `price` double(20,0) NOT NULL DEFAULT '0',
  `total_amount` double(20,0) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange_detail`
--

INSERT INTO `exchange_detail` (`exchange_d_id`, `exchange_number`, `product_number`, `imei_no`, `quantity`, `price`, `total_amount`) VALUES
(1, 'Exch-0000000000001', '1', '866614030911912', 1, 7219, 7219),
(2, 'Exch-0000000000002', '12', '13', 1, 1212, 1212);

-- --------------------------------------------------------

--
-- Table structure for table `exchange_payment_details`
--

CREATE TABLE `exchange_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_payment_transaction`
--

CREATE TABLE `exchange_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('inward','outward') DEFAULT NULL,
  `shop_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange_payment_transaction`
--

INSERT INTO `exchange_payment_transaction` (`payment_id`, `ref_id`, `type`, `shop_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Exch-0000000000001', 'outward', '1', 'Exchange', 7219, 0, 7219, '2018-05-14', '2018-05-04', '2018-05-04 05:26:19', '', '0000-00-00 00:00:00', ''),
(2, 'Exch-0000000000002', 'outward', '1', 'Exchange', 1212, 0, 1212, '2018-07-19', '2018-07-09', '2018-07-09 03:58:52', '1', '0000-00-00 00:00:00', ''),
(3, 'Exch-0000000000003', 'outward', '6', 'Cash', 1, 0, 1, '2018-08-06', '2018-07-27', '2018-07-27 04:03:09', '1', '0000-00-00 00:00:00', ''),
(4, 'Exch-0000000000004', 'outward', '7', 'Exchange', 10, 0, 10, '2018-08-13', '2018-08-03', '2018-08-03 00:46:12', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `level_tags`
--

CREATE TABLE `level_tags` (
  `tag_id` int(11) NOT NULL,
  `tag_name` varchar(5000) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level_tags`
--

INSERT INTO `level_tags` (`tag_id`, `tag_name`, `status`) VALUES
(1, 'Purchase', 1),
(2, 'Sales', 1),
(3, 'Return', 1),
(4, 'Exchange', 1),
(5, 'Report', 1),
(6, 'CA_outstanding', 1),
(7, 'Notification', 1),
(8, 'Email', 1),
(9, 'User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_imei`
--

CREATE TABLE `mobile_imei` (
  `m_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `imei_no` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0- Cutting/ 1- Actual'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile_imei`
--

INSERT INTO `mobile_imei` (`m_id`, `product_id`, `imei_no`, `status`, `type`) VALUES
(1, 1, '866614030911912', 0, 1),
(2, 2, '867363038707679', 0, 1),
(3, 2, '123456765432', 0, 1),
(4, 6, '355879090524537', 0, 1),
(5, 7, '356821090281881', 0, 1),
(6, 9, '536476686572343', 1, 1),
(7, 10, '43234675743412', 0, 1),
(8, 6, '786847687687643', 1, 1),
(9, 11, '6346345345435', 0, 1),
(10, 12, '13', 0, 1),
(11, 9, '9088888888887756', 0, 1),
(12, 13, '1234567890', 1, 0),
(13, 18, '4656', 1, 1),
(14, 20, '1122112211334', 1, 1),
(15, 20, '1122112211334', 1, 1),
(16, 20, '1122112211334', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `n_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `title` varchar(500) NOT NULL,
  `bdate` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-unread,0-read'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`n_id`, `date`, `id`, `type`, `title`, `bdate`, `status`) VALUES
(1, '2018-06-20', 1, 'stock', 'Vivo Y53', '0000-00-00', 1),
(2, '2018-06-20', 2, 'stock', 'Vivo Y69', '0000-00-00', 1),
(3, '2018-06-20', 7, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(4, '2018-06-20', 11, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(5, '2018-06-20', 1, 'stock', 'Vivo Y53', '0000-00-00', 1),
(6, '2018-06-20', 2, 'stock', 'Vivo Y69', '0000-00-00', 1),
(7, '2018-06-20', 7, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(8, '2018-06-20', 11, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(9, '2018-06-20', 1, 'stock', 'Vivo Y53', '0000-00-00', 1),
(10, '2018-06-20', 2, 'stock', 'Vivo Y69', '0000-00-00', 1),
(11, '2018-06-20', 7, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(12, '2018-06-20', 11, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(13, '2018-06-20', 1, 'stock', 'Vivo Y53', '0000-00-00', 1),
(14, '2018-06-20', 2, 'stock', 'Vivo Y69', '0000-00-00', 1),
(15, '2018-06-20', 7, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1),
(16, '2018-06-20', 11, 'stock', 'VIVO MOBILE Y 71 GOLD', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_transaction`
--

CREATE TABLE `payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(50) DEFAULT NULL,
  `type` enum('sales','purchase') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_transaction`
--

INSERT INTO `payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Purchase-0000000000001', 'purchase', '', '1', 'Cash', 8085, 5000, 3085, '2018-04-03', '2018-03-24', '2018-03-24 12:55:41', '1', '0000-00-00 00:00:00', ''),
(2, 'Purchase-0000000000002', 'purchase', '', '1', 'Cash', 13324, 10000, 3324, '2018-04-05', '2018-03-26', '2018-03-26 06:21:59', '1', '0000-00-00 00:00:00', ''),
(3, 'Purchase-0000000000003', 'purchase', '', '2', 'Cash', 3790, 3000, 3790, '2018-04-05', '2018-03-26', '2018-03-26 07:37:26', '1', '0000-00-00 00:00:00', ''),
(4, 'Purchase-0000000000004', 'purchase', '', '1', 'Cash', 10028, 10028, 0, '0000-00-00', '2018-03-26', '2018-03-26 11:31:54', '', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000001', 'sales', '1', '', 'Cash', 300, 0, 300, '2018-04-06', '2018-03-27', '2018-03-27 05:43:11', '1', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000002', 'sales', '0', '', 'Cash', 13664, 0, 13664, '2018-04-06', '2018-03-27', '2018-03-27 08:38:11', '1', '0000-00-00 00:00:00', ''),
(7, 'Purchase-0000000000005', 'purchase', '', '1', '', 15514.24, 0, 15514.24, '2018-06-03', '2018-05-22', '2018-05-24 11:19:33', '1', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000003', 'sales', '1', '', 'Cash', 8000, 1111, 6889, '2018-06-12', '2018-06-02', '2018-06-02 07:48:24', '1', '0000-00-00 00:00:00', ''),
(9, 'Purchase-0000000000006', 'purchase', '', '2', 'Cash', 800, 395, 0, '0000-00-00', '2018-06-07', '2018-06-07 07:05:40', '1', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000004', 'sales', '1', '', 'Cash', 8000, 8000, 0, '0000-00-00', '2018-06-18', '2018-06-18 04:33:05', '1', '0000-00-00 00:00:00', ''),
(11, 'Purchase-0000000000007', 'purchase', '', '1', 'Cash', 13440, 9821, 0.76, '0000-00-00', '2018-06-18', '2018-06-18 04:36:03', '1', '0000-00-00 00:00:00', ''),
(12, 'Purchase-0000000000008', 'purchase', '', '1', 'Cash', 49280, 39458, 0.24, '2018-06-28', '2018-06-18', '2018-06-18 04:44:31', '1', '0000-00-00 00:00:00', ''),
(13, 'Purchase-0000000000003', 'purchase', '', '2', 'Cash', 3790, 111, 3679, '2018-06-29', '2018-06-19', '2018-06-19 12:54:33', '1', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000005', 'sales', '5', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-06-20', '2018-06-20 08:12:26', '1', '0000-00-00 00:00:00', ''),
(15, 'Bill-0000000000003', 'sales', '1', '', 'Cash', 6889, -99955, 106844, '2018-07-05', '2018-06-25', '2018-06-25 12:34:14', '1', '0000-00-00 00:00:00', ''),
(16, 'Purchase-0000000000009', 'purchase', '', '3', '', 1357, 1457, 0, '0000-00-00', '2018-06-06', '2018-06-26 07:37:23', '', '0000-00-00 00:00:00', ''),
(17, 'Bill-0000000000006', 'sales', '6', '', 'Cash', 15800, 0, 15800, '2018-07-08', '2018-06-28', '2018-06-28 11:26:50', '1', '0000-00-00 00:00:00', ''),
(18, 'Purchase-0000000000010', 'purchase', '', '1', '', 9968, 0, 0, '0000-00-00', '2018-06-27', '2018-07-27 10:33:27', '1', '0000-00-00 00:00:00', ''),
(19, 'Purchase-0000000000011', 'purchase', '', '3', 'Cash', 531, 530, 1, '2018-08-06', '2018-07-27', '2018-07-27 10:36:11', '1', '0000-00-00 00:00:00', ''),
(20, 'Bill-0000000000007', 'sales', '8', '', 'Cash', 8000, 0, 8000, '2018-08-06', '2018-07-27', '2018-07-27 10:49:18', '1', '0000-00-00 00:00:00', ''),
(21, 'Bill-0000000000008', 'sales', '8', '', 'Cash', 8000, 0, 8000, '2018-08-06', '2018-07-27', '2018-07-27 10:49:26', '1', '0000-00-00 00:00:00', ''),
(22, 'Bill-0000000000009', 'sales', '8', '', 'Cash', 12000, 0, 12000, '2018-08-06', '2018-07-27', '2018-07-27 11:39:33', '1', '0000-00-00 00:00:00', ''),
(23, 'Purchase-0000000000012', 'purchase', '', '4', 'Cash', 16520, 0, 16520, '2018-08-06', '2018-07-27', '2018-07-27 12:02:36', '1', '0000-00-00 00:00:00', ''),
(24, 'Purchase-0000000000013', 'purchase', '', '1', 'Cash', 1, 1500, 27991.24, '2018-08-12', '2018-08-02', '2018-08-02 04:46:33', '1', '0000-00-00 00:00:00', ''),
(25, 'Purchase-0000000000014', 'purchase', '', '1', 'Cash', 12444.32, 1244, 11200, '2018-08-17', '2018-08-03', '2018-08-03 06:59:36', '1', '0000-00-00 00:00:00', ''),
(26, 'Bill-0000000000009', 'sales', '8', '', 'Cash', 12000, 10000, 2000, '2018-08-13', '2018-08-03', '2018-08-03 07:18:18', '1', '0000-00-00 00:00:00', ''),
(27, 'Bill-0000000000009', 'sales', '8', '', 'Cash', 2000, 1000, 1000, '2018-08-13', '2018-08-03', '2018-08-03 07:18:53', '1', '0000-00-00 00:00:00', ''),
(28, 'Bill-0000000000010', 'sales', '10', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-08-03', '2018-08-03 17:12:29', '1', '0000-00-00 00:00:00', ''),
(29, 'Bill-0000000000011', 'sales', '10', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-08-03', '2018-08-03 17:12:35', '1', '0000-00-00 00:00:00', ''),
(30, 'Bill-0000000000012', 'sales', '2', '', 'Cash', 8000, 0, 8000, '2018-08-13', '2018-08-03', '2018-08-03 17:29:21', '1', '0000-00-00 00:00:00', ''),
(31, 'Bill-0000000000013', 'sales', '2', '', 'Cash', 8000, 0, 8000, '2018-08-13', '2018-08-03', '2018-08-03 17:29:39', '1', '0000-00-00 00:00:00', ''),
(32, 'Bill-0000000000014', 'sales', '11', '', 'Cash', 50000, 0, 50000, '2018-08-27', '2018-08-17', '2018-08-17 07:31:39', '1', '0000-00-00 00:00:00', ''),
(33, 'Purchase-0000000000015', 'purchase', '', '7', 'Cash', 14539, 14539, 0, '0000-00-00', '2018-08-21', '2018-08-21 10:49:47', '1', '0000-00-00 00:00:00', ''),
(34, 'Purchase-0000000000016', 'purchase', '', '1', 'Cash', 5900, 5900, 0, '0000-00-00', '2018-09-16', '2018-09-16 07:45:10', '1', '0000-00-00 00:00:00', ''),
(35, 'Purchase-0000000000017', 'purchase', '', '1', 'Cash', 5900, 5900, 0, '0000-00-00', '2018-09-16', '2018-09-16 07:45:10', '1', '0000-00-00 00:00:00', ''),
(36, 'Purchase-0000000000018', 'purchase', '', '1', 'Cash', 5900, 5900, 0, '0000-00-00', '2018-09-16', '2018-09-16 07:45:11', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_number` varchar(50) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `unit_of_measurement` varchar(20) NOT NULL,
  `purchase_price` double(20,0) NOT NULL DEFAULT '0',
  `sale_price` double(20,0) NOT NULL DEFAULT '0',
  `imei_no` varchar(500) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `battery_no` varchar(500) NOT NULL,
  `charger_no` varchar(500) NOT NULL,
  `color` varchar(100) NOT NULL,
  `flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-actual,0-cutting',
  `notes` text NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `sub_category_id` varchar(20) NOT NULL,
  `product_company` varchar(5) NOT NULL,
  `min_qty` double(20,0) NOT NULL DEFAULT '0',
  `quantity` double(20,0) NOT NULL DEFAULT '0',
  `gst_percentage` int(11) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_number`, `supplier_number`, `unit_of_measurement`, `purchase_price`, `sale_price`, `imei_no`, `hsn_no`, `battery_no`, `charger_no`, `color`, `flag`, `notes`, `product_name`, `category_id`, `sub_category_id`, `product_company`, `min_qty`, `quantity`, `gst_percentage`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`) VALUES
(1, 'Product-0000000000001', '1', 'PCS', 7219, 8500, '', '8517', '', '', 'Crown Gold', 1, '', 'Vivo Y53', '1', '1', '6', 0, 0, 12, '2018-03-24 12:55:41', '1', '2018-07-27 05:29:15', '1', 1),
(2, 'Product-0000000000002', '1', 'PCS', 11896, 14000, '', '8517', '', '', 'Crown Gold', 1, '', 'Vivo Y69', '1', '1', '6', 0, 0, 12, '2018-03-26 06:21:59', '1', '0000-00-00 00:00:00', '', 1),
(3, 'Product-0000000000003', '2', 'PCS', 254, 500, '', '8517', '', '', '', 1, '', 'Trumpet OET-E33', '2', '3', '14', 0, 5, 18, '2018-03-26 07:37:26', '1', '0000-00-00 00:00:00', '', 1),
(4, 'Product-0000000000004', '2', 'PCS', 135, 300, '', '8518', '', '', '', 1, '', 'E-21', '2', '3', '14', 0, 7, 18, '2018-03-26 07:37:26', '1', '0000-00-00 00:00:00', '', 1),
(5, 'Product-0000000000005', '2', 'PCS', 593, 1000, '', '8518', '', '', '', 1, '', 'WIRELESS  E35S', '2', '3', '14', 0, 1000, 18, '2018-03-26 07:37:26', '1', '2018-06-25 12:23:53', '1', 1),
(6, 'Product-0000000000006', '1', 'PCS', 6926, 8000, '', '8517', '', '', 'Crown Gold', 1, '', 'VIVO MOBILE Y 53 I ', '1', '1', '6', 0, 1, 12, '2018-05-24 11:19:33', '1', '0000-00-00 00:00:00', '', 1),
(7, 'Product-0000000000007', '1', 'PCS', 6926, 8000, '', '8517', '', '', 'Crown Gold', 1, '', 'VIVO MOBILE Y 71 GOLD', '1', '1', '6', 0, 0, 12, '2018-05-24 11:19:33', '1', '0000-00-00 00:00:00', '', 1),
(8, 'Product-0000000000008', '2', 'PCS', 678, 1000, '', '23', '', '', '', 1, '', 'Headphones', '2', '3', '14', 0, -500, 18, '2018-06-07 07:05:40', '1', '2018-06-25 12:10:14', '1', 1),
(9, 'Product-0000000000009', '1', 'PCS', 12000, 12000, '', '432543', '', '', 'Black', 1, '', 'Vivo Y53', '1', '1', '6', 0, 3, 12, '2018-06-18 04:36:03', '1', '2018-07-27 10:33:27', '1', 1),
(10, 'Product-0000000000010', '1', 'PCS', 14000, 16000, '', '32232323', '', '', 'Black', 1, '', 'Vivo Y69', '1', '1', '6', 0, 0, 12, '2018-06-18 04:44:31', '1', '0000-00-00 00:00:00', '', 1),
(11, 'Product-0000000000011', '1', 'PCS', 15000, 17000, '', '767786876', '', '', 'Silver', 1, '', 'VIVO MOBILE Y 71 GOLD', '1', '1', '6', 0, 0, 12, '2018-06-18 04:44:31', '1', '0000-00-00 00:00:00', '', 1),
(12, 'Product-0000000000012', '3', 'PCS', 450, 530, '', '000000777', '', '', '', 1, '', 'vivo', '2', '3', '6', 0, 1, 18, '2018-07-27 10:36:11', '1', '0000-00-00 00:00:00', '', 1),
(13, 'Product-0000000000013', '4', 'PCS', 14000, 15520, '', '456', '', '', 'Gold', 0, '', 'samsung J7', '1', '1', '1', 0, 1, 18, '2018-07-27 12:02:36', '1', '0000-00-00 00:00:00', '', 1),
(14, 'Product-0000000000014', '', 'PCS', 0, 0, '', '', '', '', '', 1, '', 'S8', '1', '1', '1', 0, 0, 12, '2018-07-27 12:09:03', '1', '2018-07-27 12:09:03', '', 1),
(15, 'Product-0000000000015', '', 'PCS', 0, 0, '', '', '', '', '', 1, '', 'galaxy j7', '1', '2', '1', 2, 0, 12, '2018-07-27 12:12:25', '1', '2018-07-27 12:12:25', '', 1),
(16, 'Product-0000000000016', '5', 'PCS', 0, 0, '', '', '', '', '', 1, '', 'nokia 5', '1', '1', '2', 1, 0, 12, '2018-07-27 12:13:28', '1', '2018-07-27 12:14:27', '1', 1),
(17, 'Product-0000000000017', '1', 'PCS', 1, 1500, '', '6767676', '', '', '', 1, '', 'sony', '2', '3', '6', 0, 1, 18, '2018-08-02 04:46:33', '1', '0000-00-00 00:00:00', '', 1),
(18, 'Product-0000000000018', '1', 'PCS', 11111, 2000, '', '7868', '', '', 'Black', 1, '', 'Vivo Y51', '1', '1', '6', 0, 1, 12, '2018-08-03 06:59:36', '1', '0000-00-00 00:00:00', '', 1),
(19, 'Product-0000000000019', '7', 'PCS', 111, 120, '', '32112', '', '', '', 1, '', 'asdsa', '2', '5', '15', 0, 111, 18, '2018-08-21 10:49:47', '1', '0000-00-00 00:00:00', '', 1),
(20, 'Product-0000000000020', '1', 'PCS', 5000, 8000, '', '78', '', '', 'Black', 1, '', 'Vivi802', '1', '1', '6', 0, 3, 18, '2018-09-16 07:45:10', '1', '2018-09-16 07:45:11', '', 1),
(21, 'Product-0000000000021', '', 'PCS', 0, 0, '', '', '', '', '', 1, '', 'Samsun s6', '1', '1', '1', 2, 0, 12, '2018-09-16 09:59:02', '1', '2018-09-16 09:59:02', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchase_id` int(11) NOT NULL,
  `purchase_number` varchar(50) NOT NULL,
  `purchase_date` datetime NOT NULL,
  `supplier_id` varchar(50) NOT NULL,
  `contact_person_id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-tax,0-without_tax',
  `notes` varchar(50) DEFAULT NULL,
  `document` varchar(500) NOT NULL,
  `total_amount` double(20,0) DEFAULT '0',
  `total_payment` double(20,0) DEFAULT '0',
  `total_balance` double(20,0) DEFAULT '0',
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `purchase_number`, `purchase_date`, `supplier_id`, `contact_person_id`, `type`, `notes`, `document`, `total_amount`, `total_payment`, `total_balance`, `added_date`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Purchase-0000000000001', '2018-03-24 00:00:00', '1', 1, 1, NULL, '', 8085, 5000, 3085, '2018-03-24 05:55:41', '1', NULL, NULL),
(2, 'Purchase-0000000000002', '2018-03-26 00:00:00', '1', 1, 1, NULL, '', 13324, 10000, 3324, '2018-03-25 23:21:59', '1', NULL, NULL),
(3, 'Purchase-0000000000003', '2018-03-26 00:00:00', '2', 2, 1, NULL, '', 3790, 3111, 3679, '2018-03-26 00:37:26', '1', NULL, NULL),
(4, 'Purchase-0000000000004', '2018-03-26 00:00:00', '1', 1, 1, NULL, '', 10028, 10028, 0, '2018-03-26 04:31:54', '', NULL, NULL),
(5, 'Purchase-0000000000005', '2018-05-22 00:00:00', '1', 5, 1, NULL, '', 15514, 0, 15514, '2018-05-24 04:19:33', '1', NULL, NULL),
(6, 'Purchase-0000000000006', '2018-06-07 00:00:00', '2', 7, 1, NULL, '', 800, 395, 0, '2018-06-07 00:05:40', '1', NULL, NULL),
(7, 'Purchase-0000000000007', '2018-06-18 00:00:00', '1', 1, 1, NULL, '', 13440, 9821, 1, '2018-06-17 21:36:03', '1', NULL, NULL),
(8, 'Purchase-0000000000008', '2018-06-18 00:00:00', '1', 1, 1, NULL, '', 49280, 39458, 0, '2018-06-17 21:44:31', '1', NULL, NULL),
(9, 'Purchase-0000000000009', '2018-06-06 00:00:00', '3', 3, 1, NULL, '', 1357, 1457, 0, '2018-06-26 00:37:23', '', NULL, NULL),
(10, 'Purchase-0000000000010', '2018-06-27 00:00:00', '1', 12, 1, NULL, '', 9968, 0, 0, '2018-07-27 03:33:27', '1', NULL, NULL),
(11, 'Purchase-0000000000011', '2018-07-27 00:00:00', '3', 13, 1, NULL, '', 531, 530, 1, '2018-07-27 03:36:11', '1', NULL, NULL),
(12, 'Purchase-0000000000012', '2018-07-27 00:00:00', '4', 14, 0, NULL, '', 16520, 0, 16520, '2018-07-27 05:02:36', '1', NULL, NULL),
(13, 'Purchase-0000000000013', '2018-08-02 00:00:00', '1', 1, 1, NULL, '', 1, 1500, 27991, '2018-08-01 21:46:33', '1', NULL, NULL),
(14, 'Purchase-0000000000014', '2018-08-03 00:00:00', '1', 17, 1, NULL, '', 12444, 1244, 11200, '2018-08-02 23:59:36', '1', NULL, NULL),
(15, 'Purchase-0000000000015', '2018-08-21 00:00:00', '7', 20, 1, NULL, '', 14539, 14539, 0, '2018-08-21 03:49:47', '1', NULL, NULL),
(16, 'Purchase-0000000000016', '2018-09-16 00:00:00', '1', 1, 1, NULL, '', 5900, 5900, 0, '2018-09-16 00:45:10', '1', NULL, NULL),
(17, 'Purchase-0000000000017', '2018-09-16 00:00:00', '1', 1, 1, NULL, '', 5900, 5900, 0, '2018-09-16 00:45:10', '1', NULL, NULL),
(18, 'Purchase-0000000000018', '2018-09-16 00:00:00', '1', 1, 1, NULL, '', 5900, 5900, 0, '2018-09-16 00:45:11', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_detail`
--

CREATE TABLE `purchase_detail` (
  `purchase_d_id` int(11) NOT NULL,
  `purchase_number` varchar(50) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(50) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `purchasing_quantity` double(20,0) NOT NULL DEFAULT '0',
  `purchasing_price` double(20,0) NOT NULL DEFAULT '0',
  `selling_price` double(20,0) NOT NULL DEFAULT '0',
  `gst_percentage` int(11) NOT NULL,
  `purchasing_total_amount` double(20,0) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_detail`
--

INSERT INTO `purchase_detail` (`purchase_d_id`, `purchase_number`, `supplier_number`, `product_number`, `imei_no`, `purchasing_quantity`, `purchasing_price`, `selling_price`, `gst_percentage`, `purchasing_total_amount`) VALUES
(1, 'Purchase-0000000000001', '1', '1', '', 1, 8085, 8500, 12, 8085),
(2, 'Purchase-0000000000002', '1', '2', '', 1, 13324, 14000, 12, 13324),
(3, 'Purchase-0000000000003', '2', '3', '', 5, 300, 500, 18, 1500),
(4, 'Purchase-0000000000003', '2', '4', '', 10, 159, 300, 18, 1590),
(5, 'Purchase-0000000000003', '2', '4', '', 1, 0, 300, 18, 0),
(6, 'Purchase-0000000000003', '2', '5', '', 1, 700, 1000, 18, 700),
(7, 'Purchase-0000000000004', '1', '2', '', 1, 10028, 11111, 18, 10028),
(8, 'Purchase-0000000000005', '1', '6', '', 1, 7757, 8000, 12, 7757),
(9, 'Purchase-0000000000005', '1', '7', '', 1, 7757, 8000, 12, 7757),
(10, 'Purchase-0000000000006', '2', '8', '', 1, 800, 1000, 18, 800),
(11, 'Purchase-0000000000007', '1', '9', '', 1, 13440, 120000, 12, 13440),
(12, 'Purchase-0000000000008', '1', '10', '', 1, 15680, 16000, 12, 15680),
(13, 'Purchase-0000000000008', '1', '6', '', 1, 16800, 17000, 12, 16800),
(14, 'Purchase-0000000000008', '1', '11', '', 1, 16800, 17000, 12, 16800),
(15, 'Purchase-0000000000009', '3', '12', '', 1, 1357, 150000, 12, 1357),
(16, 'Purchase-0000000000010', '1', '9', '9088888888887756', 1, 9968, 9950, 12, 9968),
(17, 'Purchase-0000000000011', '3', '12', '', 1, 531, 530, 18, 531),
(18, 'Purchase-0000000000012', '4', '13', '1234567890', 1, 16520, 15520, 18, 16520),
(19, 'Purchase-0000000000013', '1', '17', '', 1, 1, 1500, 18, 1),
(20, 'Purchase-0000000000014', '1', '18', '4656', 1, 12444, 2000, 12, 12444),
(21, 'Purchase-0000000000015', '7', '19', '', 111, 131, 120, 18, 14539),
(22, 'Purchase-0000000000016', '1', '20', '1122112211334', 1, 5900, 8000, 18, 5900),
(23, 'Purchase-0000000000017', '1', '20', '1122112211334', 1, 5900, 8000, 18, 5900),
(24, 'Purchase-0000000000018', '1', '20', '1122112211334', 1, 5900, 8000, 18, 5900);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_sale_recharge`
--

CREATE TABLE `purchase_sale_recharge` (
  `r_purchase_id` int(11) NOT NULL,
  `operator_name` varchar(30) NOT NULL,
  `purchase_balance` double NOT NULL DEFAULT '0',
  `total_balance` double NOT NULL DEFAULT '0',
  `sale_balance` double DEFAULT '0',
  `closing_balance` double NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_sale_recharge`
--

INSERT INTO `purchase_sale_recharge` (`r_purchase_id`, `operator_name`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES
(1, 'Jio', 1000, 1000, 0, 1000, '2018-06-11', NULL, NULL, '2018-06-14 14:24:39', NULL, 1),
(2, 'Idea', 1000, 1000, 0, 1000, '2018-06-11', NULL, NULL, '2018-06-14 14:24:39', NULL, 1),
(3, 'Vodafone', 1000, 1000, 0, 1000, '2018-06-11', NULL, NULL, '2018-06-14 14:24:39', NULL, 1),
(4, 'Jio', 0, 1000, 500, 500, '2018-06-12', NULL, NULL, '2018-06-14 14:24:39', NULL, 1),
(5, 'Idea', 1500, 2500, 0, 2500, '2018-06-14', '1', '', '2018-06-14 14:30:30', '0000-00-00 00:00:00', 1),
(6, 'Idea', 0, 2500, 1500, 1000, '2018-06-14', '1', '', '2018-06-14 14:31:00', '0000-00-00 00:00:00', 1),
(7, 'Idea', 500, 1500, 0, 1500, '2018-06-14', '1', '', '2018-06-14 14:32:53', '0000-00-00 00:00:00', 1),
(8, 'Jio', 500, 1000, 0, 1000, '2018-06-16', '1', '', '2018-06-16 04:37:11', '0000-00-00 00:00:00', 1),
(9, 'Jio', 100, 1100, 0, 1100, '2018-04-02', '', '', '2018-06-16 09:38:35', '0000-00-00 00:00:00', 1),
(10, 'Jio', 900, 2000, 0, 2000, '2018-06-19', '1', '', '2018-06-19 09:34:14', '0000-00-00 00:00:00', 1),
(11, 'Jio', -500, 1500, 0, 1500, '2018-06-25', '1', '', '2018-06-25 12:26:09', '0000-00-00 00:00:00', 1),
(12, 'Jio', 300, 1800, 0, 1800, '2018-05-30', '1', '', '2018-07-27 11:18:43', '0000-00-00 00:00:00', 1),
(13, 'Idea', 500, 2000, 0, 2000, '2018-07-31', '1', '', '2018-07-31 09:38:48', '0000-00-00 00:00:00', 1),
(14, 'Jio', 2000, 3800, 0, 3800, '2018-08-01', '1', '', '2018-08-01 11:49:25', '0000-00-00 00:00:00', 1),
(15, 'Idea', 0, 2000, 1500, 500, '2018-08-01', '1', '', '2018-08-01 11:49:44', '0000-00-00 00:00:00', 1),
(16, 'Jio', 200, 4000, 0, 4000, '2018-08-04', '1', '', '2018-08-04 13:38:15', '0000-00-00 00:00:00', 1),
(17, 'Jio', 0, 4000, 200, 3800, '2018-08-04', '1', '', '2018-08-04 13:40:10', '0000-00-00 00:00:00', 1),
(18, 'Jio', 5000, 8800, 0, 8800, '2018-09-16', '1', '', '2018-09-16 10:11:48', '0000-00-00 00:00:00', 1),
(19, 'Jio', 1500, 2000, 0, 2000, '2018-09-16', '1', '', '2018-09-16 10:12:46', '0000-00-00 00:00:00', 1),
(20, 'Jio', 0, 2000, 2000, 0, '2018-09-16', '1', '', '2018-09-16 10:19:13', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `repair`
--

CREATE TABLE `repair` (
  `repair_id` int(11) NOT NULL,
  `customer_number` varchar(100) DEFAULT NULL,
  `repair_payment_id` varchar(100) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_id` int(11) DEFAULT NULL,
  `product_brand` varchar(20) DEFAULT NULL,
  `product_model` varchar(20) DEFAULT NULL,
  `product_description` text,
  `product_issue` text,
  `due_date` datetime DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:recieved, 2: working, 3:complete, 4:return'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repair`
--

INSERT INTO `repair` (`repair_id`, `customer_number`, `repair_payment_id`, `category_id`, `sub_category_id`, `product_brand`, `product_model`, `product_description`, `product_issue`, `due_date`, `return_date`, `added_by`, `updated_by`, `added_date`, `update_date`, `status`) VALUES
(1, 'Cust-00000000002', '1', 1, 1, 'VIVO', 'VIVO MOBILE Y 53 I ', 'gfgd gfdg fg', 'gfd gfd fd gdf gf', '2018-06-15 00:00:00', '0000-00-00 00:00:00', '1', '', '2018-06-14 22:35:02', '0000-00-00 00:00:00', 1),
(2, 'Cust-00000000002', '5', 1, 1, 'VIVO', 'v9', 'gfgd gfdg fg', 'gfd gfd fd gdf gf', '2018-06-15 00:00:00', '0000-00-00 00:00:00', '1', '1', '2018-06-14 22:36:18', '2018-06-15 00:00:00', 2),
(3, 'Cust-00000000001', '4', 1, 1, 'VIVO', 'V9', 'hfdh dhf g dfg', 'gfd g gf gdg fd', '2018-06-15 00:00:00', '2018-06-15 00:00:00', '1', '', '2018-06-14 22:41:28', '2018-07-20 00:00:00', 1),
(4, 'Cust-00000000000', '4', 1, 2, 'aa', 'a', '', '', '2018-07-08 00:00:00', '0000-00-00 00:00:00', '', '', '2018-06-28 03:35:42', '0000-00-00 00:00:00', 1),
(5, 'Cust-00000000001', '6', 1, 1, 'VIVO', 'VIVO MOBILE Y 53 I ', 'dsfds', 'fdsfds', '2018-06-28 00:00:00', '0000-00-00 00:00:00', '', '', '2018-06-28 06:19:53', '0000-00-00 00:00:00', 1),
(6, 'Cust-00000000002', '6', 1, 1, 'VIVO', 'VIVO MOBILE Y 53 I ', 'asd', 'ads', '2018-06-28 00:00:00', '0000-00-00 00:00:00', '1', '', '2018-06-28 06:21:56', '0000-00-00 00:00:00', 1),
(7, 'Cust-00000000008', '7', 1, 1, 'VIVO', 'vivo v5', 'jhjkhkjjjhkkj', 'hjjjhjhjhjjjjjjjh', '2018-07-27 00:00:00', '0000-00-00 00:00:00', '1', '', '2018-07-27 04:36:52', '0000-00-00 00:00:00', 1),
(8, 'Cust-00000000009', '8', 1, 1, 'suraj sales', '5674386578', 'dcgdhrugudiubu jdfvyovbh', 'not working properly', '2018-08-01 00:00:00', '0000-00-00 00:00:00', '1', '', '2018-08-01 05:45:55', '0000-00-00 00:00:00', 1),
(9, 'Cust-00000000009', '9', 1, 1, 'suraj sales', '5674386578', 'dcgdhrugudiubu jdfvyovbh', 'not working properly', '2018-08-01 00:00:00', '0000-00-00 00:00:00', '1', '', '2018-08-01 05:45:55', '0000-00-00 00:00:00', 1),
(10, 'Cust-00000000009', '10', 1, 1, 'Vivo', 'Vivo Y53', 'f hc ghvb ', 'gb hjv ghgh ', '2018-08-03 00:00:00', '0000-00-00 00:00:00', '1', '1', '2018-08-03 00:52:13', '2018-08-14 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `repair_payment_detail`
--

CREATE TABLE `repair_payment_detail` (
  `repair_payment_id` int(11) NOT NULL,
  `customer_number` varchar(50) DEFAULT NULL,
  `repair_id` varchar(11) NOT NULL,
  `approx_cost` double DEFAULT '0',
  `advance_pay` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `payment_type` varchar(100) DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `cheque_no` varchar(500) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `added_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repair_payment_detail`
--

INSERT INTO `repair_payment_detail` (`repair_payment_id`, `customer_number`, `repair_id`, `approx_cost`, `advance_pay`, `balance`, `total_payment`, `payment_type`, `bank_name`, `cheque_no`, `transaction_date`, `added_date`, `update_date`, `added_by`, `updated_by`) VALUES
(1, 'Cust-00000000001', '3', 600, 100, 500, 600, 'Cash', '', '', '2018-06-14 22:41:28', '2018-06-14 22:41:28', '0000-00-00 00:00:00', '1', ''),
(2, 'Cust-00000000001', '3', 600, 500, 100, 600, 'Cash', '', '', '2018-06-15 05:45:19', '2018-06-15 05:45:19', '0000-00-00 00:00:00', '1', ''),
(3, 'Cust-00000000001', '3', 600, 500, 50, 600, 'Cash', '', '', '2018-06-15 05:56:25', '2018-06-15 05:56:25', '0000-00-00 00:00:00', '1', ''),
(4, 'Cust-00000000001', '3', 600, 600, 0, 600, 'Cash', '', '', '2018-06-15 06:52:07', '2018-06-15 06:52:07', '0000-00-00 00:00:00', '1', ''),
(5, 'Cust-00000000002', '2', 600, 505, 95, 600, 'Cash', '', '', '2018-06-29 00:52:24', '2018-06-29 00:52:24', '0000-00-00 00:00:00', '1', ''),
(6, 'Cust-00000000001', '5', 600, 505, 95, 600, 'Cash', '', '', '2018-07-26 22:04:44', '2018-07-26 22:04:44', '0000-00-00 00:00:00', '1', ''),
(7, 'Cust-00000000008', '7', 8999, 7000, 1999, 8999, 'Cash', '', '', '2018-07-27 04:36:52', '2018-07-27 04:36:52', '0000-00-00 00:00:00', '1', ''),
(8, 'Cust-00000000009', '8', 5000, 1000, 4000, 5000, 'Cash', '', '', '2018-08-01 05:45:55', '2018-08-01 05:45:55', '0000-00-00 00:00:00', '1', ''),
(9, 'Cust-00000000009', '9', 5000, 1000, 4000, 5000, 'Cash', '', '', '2018-08-01 05:45:55', '2018-08-01 05:45:55', '0000-00-00 00:00:00', '1', ''),
(10, 'Cust-00000000009', '10', 3000, 1000, 2000, 3000, 'Cash', '', '', '2018-08-03 00:52:13', '2018-08-03 00:52:13', '0000-00-00 00:00:00', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `return`
--

CREATE TABLE `return` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(200) NOT NULL,
  `sales_date` date NOT NULL,
  `supplier_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return`
--

INSERT INTO `return` (`sales_id`, `sales_number`, `sales_date`, `supplier_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', '2018-03-27', '2', '', 0, 0, 135, '', 0, 0, 0, 0, '', 135, '2018-03-26 22:40:06', '1', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', '2018-03-27', '1', '', 0, 0, 11896, '', 0, 0, 0, 0, '', 11896, '2018-03-26 22:40:37', '1', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', '2018-06-25', '5', '', 0, 0, 9882938, '', 0, 0, 0, 0, '', 9882938, '2018-06-25 05:22:25', '1', '0000-00-00 00:00:00', ''),
(4, 'Return-0000000000004', '2018-08-02', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-08-01 21:52:11', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `return_detail`
--

CREATE TABLE `return_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(200) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return_detail`
--

INSERT INTO `return_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Return-0000000000001', '2', '4', '', 1, 0, 0, '', '', 135),
(2, 'Return-0000000000002', '1', '2', '', 1, 0, 0, '', '', 11896),
(3, 'Return-0000000000000', '2', '8', '', 1000, 0, 0, '', '', 678000),
(4, 'Return-0000000000003', '2', '5', '', 16666, 0, 0, '', '', 9882938),
(5, 'Return-0000000000004', '', '', '', 1, 0, 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `return_payment_details`
--

CREATE TABLE `return_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `return_payment_transaction`
--

CREATE TABLE `return_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('return') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return_payment_transaction`
--

INSERT INTO `return_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', 'return', '', '2', 'Credit', 135, 0, 135, '2018-04-06', '2018-03-27', '2018-03-26 22:40:06', '1', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', 'return', '', '1', 'Credit', 11896, 0, 11896, '2018-04-06', '2018-03-27', '2018-03-26 22:40:37', '1', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', 'return', '', '5', 'Credit', 9882938, 0, 9882938, '2018-07-05', '2018-06-25', '2018-06-25 05:22:25', '1', '0000-00-00 00:00:00', ''),
(4, 'Return-0000000000004', 'return', '', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-08-02', '2018-08-01 21:52:11', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `sales_date` date NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sales_number`, `sales_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', '2018-03-27', '1', '', 254.24, 0, 300, '', 0, 0, 0, 45.76, '', 300, '2018-03-26 22:43:11', '1', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', '2018-03-27', '0', '', 12200, 0, 13664, '', 2.45901639344, 336, 12, 1464, '', 13664, '2018-03-27 01:38:11', '1', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', '2018-06-02', '1', '', 7142.86, -98844, 106844, '', 0, 0, 12, 857.14, '', 8000, '2018-06-02 00:48:24', '1', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', '2018-06-18', '1', '', 7142.86, 8000, 0, '', 0, 0, 12, 857.14, '', 8000, '2018-06-17 21:33:05', '1', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000005', '2018-06-20', '5', '', 0, 0, 0, '', 0, 0, 5, 0, '', 0, '2018-06-20 01:12:26', '1', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000006', '2018-06-28', '6', '', 14107.14, 0, 15800, '', 1.2658227848101, 200, 12, 1692.86, '', 15800, '2018-06-28 04:26:50', '1', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000007', '2018-07-27', '8', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-07-27 03:49:18', '1', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000008', '2018-07-27', '8', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-07-27 03:49:26', '1', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000009', '2018-07-27', '8', '', 10714.29, 11000, 1000, '', 0, 0, 12, 1285.71, '', 12000, '2018-07-27 04:39:33', '1', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000010', '2018-08-03', '10', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-08-03 10:12:29', '1', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000011', '2018-08-03', '10', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-08-03 10:12:35', '1', '0000-00-00 00:00:00', ''),
(12, 'Bill-0000000000012', '2018-08-03', '2', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-08-03 10:29:21', '1', '0000-00-00 00:00:00', ''),
(13, 'Bill-0000000000013', '2018-08-03', '2', '', 7142.86, 0, 8000, '', 0, 0, 12, 857.14, '', 8000, '2018-08-03 10:29:39', '1', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000014', '2018-08-17', '11', '', 44642.86, 0, 50000, '', -100, -50000, 12, 5357.14, '', 50000, '2018-08-17 00:31:39', '1', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `sales_detail`
--

CREATE TABLE `sales_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_detail`
--

INSERT INTO `sales_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Bill-0000000000001', '2', '4', '', 1, 0, 254.24, '18', '45.76', 300),
(2, 'Bill-0000000000002', '1', '2', '', 1, 0, 12200, '12', '1464', 13664),
(3, 'Bill-0000000000003', '1', '7', '', 1, 0, 7142.86, '12', '857.14', 8000),
(4, 'Bill-0000000000004', '1', '6', '', 1, 0, 7142.86, '12', '857.14', 8000),
(5, 'Bill-0000000000005', '1', '11', '', 1, 0, 129, '5', '6', 135),
(6, 'Bill-0000000000006', '1', '10', '', 1, 0, 14107.14, '12', '1692.86', 15800),
(7, 'Bill-0000000000007', '1', '6', '878789098098776', 1, 0, 7142.86, '12', '857.14', 8000),
(8, 'Bill-0000000000008', '1', '6', '878789098098776', 1, 0, 7142.86, '12', '857.14', 8000),
(9, 'Bill-0000000000009', '1', '9', '9088888888887756', 1, 0, 10714.29, '12', '1285.71', 12000),
(10, 'Bill-0000000000010', '', '', '25454', 1, 0, 0, '0', '0', 0),
(11, 'Bill-0000000000011', '', '', '25454', 1, 0, 0, '0', '0', 0),
(12, 'Bill-0000000000012', '1', '6', '355879090524537', 1, 0, 7142.86, '12', '857.14', 8000),
(13, 'Bill-0000000000013', '1', '6', '355879090524537', 1, 0, 7142.86, '12', '857.14', 8000),
(14, 'Bill-0000000000000', '4', '13', '10000000000005', 1, 0, 13152.54, '18', '2367.46', 15520),
(15, 'Bill-0000000000014', '', '', 'Ertfrgteef', 1, 0, 44642.86, '12', '5357.14', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `sim_operator`
--

CREATE TABLE `sim_operator` (
  `operator_id` int(11) NOT NULL,
  `operator_name` varchar(30) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0-Deactive,1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sim_operator`
--

INSERT INTO `sim_operator` (`operator_id`, `operator_name`, `status`) VALUES
(1, 'Jio', 1),
(2, 'Idea', 1),
(3, 'Vodafone', 1),
(4, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` int(10) NOT NULL,
  `sub_category_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `category_id`, `sub_category_name`, `status`) VALUES
(1, 1, 'Smart Phones', 1),
(2, 1, 'Phones', 1),
(3, 2, 'Headphones', 1),
(4, 2, 'ScreenGuard', 1),
(5, 2, 'Battery', 1),
(6, 2, 'Power Banks', 1),
(7, 1, 'Battery', 1),
(8, 6, 'Speaker', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_number` varchar(50) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `supplier_address` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email_id` varchar(70) NOT NULL,
  `note` text NOT NULL,
  `supplier_for` varchar(200) NOT NULL,
  `balance` varchar(25) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactive/ 1-Active',
  `dealer_gst_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_number`, `supplier_name`, `supplier_address`, `contact_person`, `contact_number`, `email_id`, `note`, `supplier_for`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `dealer_gst_no`) VALUES
(1, 'Dealer-00000000001', 'Harsh Communication', 'Office No.-09-10 , Santosh Heights. Apot Opp Apsara Theatre Shankarsheth Road , Gultekadi . Pune-411037', 'Harsh ', '98000000000', 'amarpardeshi28@yahoo.com', '', '6', '0', '2018-03-24 12:21:58', '', '2018-03-26 05:05:45', '1', 1, ''),
(2, 'Dealer-00000000002', 'Kishor Sales', 'S. No. 9/2B, FLAT NO.502. WING B,SHRI VENTATESH LAKE VISTA. PUNE-411046', 'Kishor Shinde', '7498512591', 'kishorshinde13@yahoo.in', '', '1,2,14', '395', '2018-03-26 06:38:35', '1', '2018-07-23 07:17:36', '1', 1, ''),
(3, 'Dealer-00000000003', 'Harsh Communication', 'Pune', 'Harsh', '9800000000', 'md@mayur.com', '', '6', '0', '2018-05-24 10:56:35', '1', '2018-05-24 10:56:35', '', 1, ''),
(4, 'Dealer-00000000004', 'nikhil patil', 'vishwa gym katraj', 'nikhil patil', '8907654567', 'bharati.patil@vigopa.com', '', '1', '0', '2018-07-27 09:48:03', '1', '2018-07-27 10:16:11', '1', 1, '8900'),
(5, 'Dealer-00000000005', 'vijay patil', 'katraj pune 90', 'bharati patil', '78908900000', 'bharatiavni13@gmail.com', '', '2', '0', '2018-07-27 12:08:20', '1', '2018-07-27 12:08:55', '1', 1, '0034'),
(6, 'Dealer-00000000006', 'vijay sales', 'vijay sales shivaji nagar pune', 'vijay patil', '9999999999', 'vijaysales@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14', '0', '2018-08-01 10:23:51', '1', '2018-08-01 10:23:51', '', 1, '123456'),
(7, 'Dealer-00000000007', 'deep enterprises', 'shop no.987 fc road opp. vaishali hotel pune', '8787878787', '8787878787', 'deepenterprises11@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14,15', '0', '2018-08-03 07:32:51', '1', '2018-08-21 10:45:32', '1', 1, '765433'),
(8, 'Dealer-00000000008', '', '', '', '', '', '', '', '0', '2018-08-07 01:06:41', '', '2018-08-07 01:06:41', '', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `unit_of_measurement`
--

CREATE TABLE `unit_of_measurement` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(500) NOT NULL,
  `lname` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `profile_pic` varchar(500) NOT NULL,
  `user_level` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active ,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fname`, `lname`, `email`, `password`, `contact_no`, `profile_pic`, `user_level`, `status`) VALUES
(1, 'Admin', 'Admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '1234567890', '', 3, 1),
(3, 'Amar', 'Pardeshi', 'amar@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '8275473337', '', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

CREATE TABLE `user_level` (
  `u_id` int(11) NOT NULL,
  `level_name` varchar(200) NOT NULL,
  `level_fectures` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`u_id`, `level_name`, `level_fectures`, `status`) VALUES
(2, 'Sub-Admin', '1,2', 1),
(3, 'Admin', '1,2,3,4,5,6,7,8,9', 1),
(4, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `user_id` int(11) NOT NULL,
  `register_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `shop_name` varchar(500) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone_no` varchar(200) NOT NULL,
  `gst_no` varchar(200) NOT NULL,
  `mac_id` varchar(200) NOT NULL,
  `s_key` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `exp_date` date NOT NULL,
  `flag` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`user_id`, `register_date`, `shop_name`, `first_name`, `last_name`, `username`, `password`, `phone_no`, `gst_no`, `mac_id`, `s_key`, `address`, `exp_date`, `flag`, `status`) VALUES
(1, '2018-08-03 19:18:26', 'mobil Shop', 'amar', 'pardeshi', 'admin@gmail.com', '0cc175b9c0f1b6a831c399e269772661', '9800000000', '', '18-A9-05-98-3B-4E', 'a', 'pune', '0000-00-00', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_shop`
--
ALTER TABLE `about_shop`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ca_payment_transaction`
--
ALTER TABLE `ca_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `ca_sales`
--
ALTER TABLE `ca_sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `ca_sales_detail`
--
ALTER TABLE `ca_sales_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `company_supplier`
--
ALTER TABLE `company_supplier`
  ADD PRIMARY KEY (`com_sup_id`);

--
-- Indexes for table `contact_person`
--
ALTER TABLE `contact_person`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_return`
--
ALTER TABLE `customer_return`
  ADD PRIMARY KEY (`return_id`),
  ADD UNIQUE KEY `NoFaktur` (`return_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `customer_return_detail`
--
ALTER TABLE `customer_return_detail`
  ADD PRIMARY KEY (`return_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`return_number`);

--
-- Indexes for table `customer_return_payment_details`
--
ALTER TABLE `customer_return_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `customer_return_payment_transaction`
--
ALTER TABLE `customer_return_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `daily_recharge`
--
ALTER TABLE `daily_recharge`
  ADD PRIMARY KEY (`daily_recharge_id`);

--
-- Indexes for table `exchange`
--
ALTER TABLE `exchange`
  ADD PRIMARY KEY (`exchange_id`);

--
-- Indexes for table `exchange_detail`
--
ALTER TABLE `exchange_detail`
  ADD PRIMARY KEY (`exchange_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`exchange_number`);

--
-- Indexes for table `exchange_payment_details`
--
ALTER TABLE `exchange_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `exchange_payment_transaction`
--
ALTER TABLE `exchange_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `level_tags`
--
ALTER TABLE `level_tags`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indexes for table `mobile_imei`
--
ALTER TABLE `mobile_imei`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `payment_transaction`
--
ALTER TABLE `payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  ADD PRIMARY KEY (`purchase_d_id`);

--
-- Indexes for table `purchase_sale_recharge`
--
ALTER TABLE `purchase_sale_recharge`
  ADD PRIMARY KEY (`r_purchase_id`);

--
-- Indexes for table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`repair_id`);

--
-- Indexes for table `repair_payment_detail`
--
ALTER TABLE `repair_payment_detail`
  ADD PRIMARY KEY (`repair_payment_id`);

--
-- Indexes for table `return`
--
ALTER TABLE `return`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`supplier_id`);

--
-- Indexes for table `return_detail`
--
ALTER TABLE `return_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `return_payment_details`
--
ALTER TABLE `return_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `return_payment_transaction`
--
ALTER TABLE `return_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `sales_detail`
--
ALTER TABLE `sales_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `sim_operator`
--
ALTER TABLE `sim_operator`
  ADD PRIMARY KEY (`operator_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_shop`
--
ALTER TABLE `about_shop`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ca_payment_transaction`
--
ALTER TABLE `ca_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ca_sales`
--
ALTER TABLE `ca_sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ca_sales_detail`
--
ALTER TABLE `ca_sales_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `company_supplier`
--
ALTER TABLE `company_supplier`
  MODIFY `com_sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `contact_person`
--
ALTER TABLE `contact_person`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer_return`
--
ALTER TABLE `customer_return`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer_return_detail`
--
ALTER TABLE `customer_return_detail`
  MODIFY `return_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer_return_payment_details`
--
ALTER TABLE `customer_return_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_return_payment_transaction`
--
ALTER TABLE `customer_return_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `daily_recharge`
--
ALTER TABLE `daily_recharge`
  MODIFY `daily_recharge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `exchange`
--
ALTER TABLE `exchange`
  MODIFY `exchange_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `exchange_detail`
--
ALTER TABLE `exchange_detail`
  MODIFY `exchange_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exchange_payment_details`
--
ALTER TABLE `exchange_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_payment_transaction`
--
ALTER TABLE `exchange_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `level_tags`
--
ALTER TABLE `level_tags`
  MODIFY `tag_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mobile_imei`
--
ALTER TABLE `mobile_imei`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_transaction`
--
ALTER TABLE `payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  MODIFY `purchase_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `purchase_sale_recharge`
--
ALTER TABLE `purchase_sale_recharge`
  MODIFY `r_purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `repair`
--
ALTER TABLE `repair`
  MODIFY `repair_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `repair_payment_detail`
--
ALTER TABLE `repair_payment_detail`
  MODIFY `repair_payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `return`
--
ALTER TABLE `return`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `return_detail`
--
ALTER TABLE `return_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `return_payment_details`
--
ALTER TABLE `return_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `return_payment_transaction`
--
ALTER TABLE `return_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sales_detail`
--
ALTER TABLE `sales_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sim_operator`
--
ALTER TABLE `sim_operator`
  MODIFY `operator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_level`
--
ALTER TABLE `user_level`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

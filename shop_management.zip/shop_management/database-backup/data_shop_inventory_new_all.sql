-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 20, 2019 at 10:03 PM
-- Server version: 5.6.45-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_shop_inventory_new_all`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_shop`
--

CREATE TABLE `about_shop` (
  `shop_id` int(11) NOT NULL,
  `shop_number` varchar(40) NOT NULL,
  `shop_name` varchar(100) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `shop_contact` varchar(20) NOT NULL,
  `shop_email` varchar(100) NOT NULL,
  `shop_address` text NOT NULL,
  `shop_gstno` varchar(50) NOT NULL,
  `shop_website` text NOT NULL,
  `shop_van` varchar(500) NOT NULL,
  `shop_pan` varchar(500) NOT NULL,
  `shop_terms_conditions` text NOT NULL,
  `balance` double NOT NULL,
  `added_by` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0- own shop/ 1- other shop'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_shop`
--

INSERT INTO `about_shop` (`shop_id`, `shop_number`, `shop_name`, `owner_name`, `shop_contact`, `shop_email`, `shop_address`, `shop_gstno`, `shop_website`, `shop_van`, `shop_pan`, `shop_terms_conditions`, `balance`, `added_by`, `status`) VALUES
(1, '122', 'Om Mobile Shopee', 'Yogesh Nair', '9921451181', 'prakash@gmail.com', 'Sant Dhaneshwar Nagar Sr No-45 Pune-411048', 'AD2323SG3', '', '', '', '', 0, 9, 1),
(2, '222', 'Krushana Mobile', 'Krushana S', '9765665666', 'ks@gmail.com', 'Hadpsar', '', '', '', '', '', 0, 9, 1),
(3, '987654', 'deep enterprises', 'harsh patil', '9999999999', 'deepenterprises@gmail.com', 'm.g.road oppo. 360 degree, pune', '999999', 'https://www.deepenterprises.com', '565656', '767686788', '', 0, 2, 1),
(4, 'Test Shop numbe', 'Shop Name  123!@#', 'Piyush Chate', '7030773914', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1\r\n\r\n0TA2', 'Test Shop number 123!@#', '', 'Test Shop number 123!@#', 'Test Shop number 123!@#', '', 0, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `about_shop_own`
--

CREATE TABLE `about_shop_own` (
  `shop_id` int(11) NOT NULL,
  `shop_number` varchar(100) NOT NULL,
  `shop_name` varchar(200) NOT NULL,
  `owner_name` varchar(200) NOT NULL,
  `shop_contact` varchar(20) NOT NULL,
  `shop_email` varchar(100) NOT NULL,
  `shop_address` text NOT NULL,
  `shop_gstno` varchar(50) NOT NULL,
  `shop_website` text NOT NULL,
  `shop_van` varchar(50) NOT NULL,
  `shop_pan` varchar(50) NOT NULL,
  `shop_terms_conditions` longtext NOT NULL,
  `admin` int(11) NOT NULL,
  `print_flag` tinyint(2) NOT NULL COMMENT '1-Horizontal / 2- Vertical',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0- deactive/ 1- activeshop'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_shop_own`
--

INSERT INTO `about_shop_own` (`shop_id`, `shop_number`, `shop_name`, `owner_name`, `shop_contact`, `shop_email`, `shop_address`, `shop_gstno`, `shop_website`, `shop_van`, `shop_pan`, `shop_terms_conditions`, `admin`, `print_flag`, `status`) VALUES
(1, 'ABC2365GHG', 'Swarnalakshya Celluler', 'Swapnil Hunnur', '8087865003', 'swarnalakshya16417@gmail.com', 'Shop no 3, bhairavnath Nagar society.,opp. Telephone exchange, sukhsagar Nagar katraj', 'ABC2365GHG654AB', '277507890767', 'AACCK6789G', 'AACCK6789G', 'You know, being a test pilot isn\'t always the healthiest business in the world.', 4, 1, 1),
(2, '', 'Sai Mobile Shopee', 'Swapnil Pawar', '9623307707', 'swapnilp644@gmail.com', 'Sant Dhaneshwar Nagar Sr No-45 Pune-411048', '', '', '', '', '', 10, 1, 1),
(3, '1234556', 'Om Mobile Shopee', 'Yogesh Nair', '9921451181', 'prakash@gmail.com', 'Sant Dhaneshwar Nagar Sr No-45 Pune-411048', 'AD124DSFF123', '', '', '', 'Testing', 9, 2, 1),
(4, '134567', 'Supriya Mobile Shopee', 'SHUBHAM HANGARGE', '8308383581', 'shangarge499@gmail.com', 'Shop no 1, kamal vihar society, mohan nagar, nr mango tree, dhankawadi, Pune 411043.', '27ACZPH4578D1Z2', '', '', '', '', 11, 1, 1),
(5, '', '', '', '', '', '', '', '', '', '', '', 12, 1, 1),
(6, '1234556', 'Om Mobile Shopee', 'Yogesh Nair', '7875509898', 'yogesh.nair@vigopa.com', '\r\n104-Second floor, Sliver Point building, Katraj-Kondhawa road,\r\nNear Vishwa Gym, Katraj, \r\nPune - 411046.', 'AD124DSFF123', '', '', '', 'Testing', 2, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `area_id` int(11) NOT NULL,
  `area_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0-Deactive,1-Active '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`area_id`, `area_name`, `status`) VALUES
(1, 'Gokulnagar katraj', 1),
(3, 'Ssas', 1),
(4, 'Asas', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactive,1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `status`) VALUES
(1, 'Mobile', 1),
(2, 'Accessories', 1),
(5, 'Category name1', 1),
(6, 'Categoryname2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ca_payment_transaction`
--

CREATE TABLE `ca_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('sales','purchase') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_payment_transaction`
--

INSERT INTO `ca_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', 'sales', '11', '', 'Cash', 60000, 0, 60000, '2018-08-27', '2018-08-17', '2018-08-17 03:05:49', '9', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', 'sales', '19', '', 'Cash', 7000, 7000, 0, '0000-00-00', '2018-08-23', '2018-08-23 10:14:03', '10', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', 'sales', '20', '', 'Cash', 8500, 8500, 0, '0000-00-00', '2018-08-28', '2018-08-28 05:50:13', '2', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', 'sales', '20', '', 'Cash', 8500, 8500, 0, '0000-00-00', '2018-08-28', '2018-08-28 05:51:49', '2', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000000', 'sales', '26', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-12-10', '2018-12-09 23:05:30', '2', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000005', 'sales', '29', '', 'Cash', 1000, 0, 1000, '2018-12-20', '2018-12-10', '2018-12-10 00:23:23', '9', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000006', 'sales', '30', '', 'Cash', 100, 0, 100, '2018-12-20', '2018-12-10', '2018-12-10 00:35:04', '9', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000007', 'sales', '31', '', 'Cash', 100, 0, 100, '2018-12-20', '2018-12-10', '2018-12-10 00:45:44', '9', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000008', 'sales', '32', '', 'Cash', 14, 0, 14, '2018-12-20', '2018-12-10', '2018-12-10 04:02:57', '9', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000009', 'sales', '26', '', 'Cash', 7500, 5000, 2500, '2018-12-21', '2018-12-11', '2018-12-10 23:55:46', '2', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000010', 'sales', '29', '', 'Cash', 16780, 0, 16780, '2018-12-22', '2018-12-12', '2018-12-11 21:45:53', '9', '0000-00-00 00:00:00', ''),
(12, 'Bill-0000000000011', 'sales', '26', '', 'Credit', 1800, 1800, 0, '0000-00-00', '2018-12-13', '2018-12-13 03:03:24', '2', '0000-00-00 00:00:00', ''),
(13, 'Bill-0000000000013', 'sales', '17', '', 'Cash', 10990, 0, 10990, '2019-04-17', '2019-04-07', '2019-04-07 04:06:17', '2', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000014', 'sales', '26', '', 'Cash', 9990, 0, 9990, '2019-11-18', '2019-11-08', '2019-11-07 22:14:17', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `ca_sales`
--

CREATE TABLE `ca_sales` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(50) NOT NULL,
  `sales_date` datetime NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_sales`
--

INSERT INTO `ca_sales` (`sales_id`, `sales_number`, `sales_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', '2018-08-17 00:00:00', '11', '', 53571.43, 0, 60000, '', 0, 0, 12, 6428.57, '', 60000, '2018-08-17 03:05:49', '9', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', '2018-08-23 00:00:00', '19', '', 5932.2, 7000, 0, '', 0, 0, 18, 1067.8, '', 7000, '2018-08-23 10:14:03', '10', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', '2018-08-28 00:00:00', '20', '', 7589.29, 8500, 0, '', 5.8823529411765, 500, 12, 910.71, '', 8500, '2018-08-28 05:50:13', '2', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', '2018-08-28 00:00:00', '20', '', 7589.29, 8500, 0, '', 5.8823529411765, 500, 12, 910.71, '', 8500, '2018-08-28 05:51:49', '2', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000005', '2018-12-10 00:00:00', '29', '', 1000, 0, 1000, '', -100, -1000, 0, 0, '', 1000, '2018-12-10 00:23:23', '9', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000006', '2018-12-10 00:00:00', '30', '', 100, 0, 100, '', -100, -100, 0, 0, '', 100, '2018-12-10 00:35:04', '9', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000007', '2018-12-10 00:00:00', '31', '', 100, 0, 100, '', -100, -100, 0, 0, '', 100, '2018-12-10 00:45:44', '9', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000008', '2018-12-10 00:00:00', '32', '', 14, 0, 14, '', -100, -14, 0, 0, '', 14, '2018-12-10 04:02:57', '9', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000009', '2018-12-11 00:00:00', '26', '', 6696.43, 5000, 2500, '', 0, 0, 12, 803.57, '', 7500, '2018-12-10 23:55:46', '2', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000010', '2018-12-12 00:00:00', '29', '', 14982.14, 0, 16780, '', 0, 0, 12, 1797.86, '', 16780, '2018-12-11 21:45:53', '9', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000011', '2018-12-13 00:00:00', '26', '', 381.36, 1800, 0, '', -75, -1350, 0, 1418.64, '', 1800, '2018-12-13 03:03:24', '2', '0000-00-00 00:00:00', ''),
(12, '', '2019-04-07 00:00:00', '17', '', 9812.5, 0, 10990, '', 0, 0, 12, 1177.5, '', 10990, '2019-04-07 04:06:17', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `ca_sales_detail`
--

CREATE TABLE `ca_sales_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ca_sales_detail`
--

INSERT INTO `ca_sales_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Bill-0000000000001', '4', '4', '35765546556344', 1, 0, 53571.43, '12', '6428.57', 60000),
(2, 'Bill-0000000000002', '8', '6', '1234567890', 1, 0, 5932.2, '18', '1067.8', 7000),
(3, 'Bill-0000000000003', '9', '7', '860569049845434', 1, 0, 7589.29, '12', '910.71', 8500),
(4, 'Bill-0000000000004', '9', '7', '860569049845434', 1, 0, 7589.29, '12', '910.71', 8500),
(5, 'Bill-0000000000000', '', '', 'Test IMEi no 123!@#', 1, 0, 4, '5', '0', 4),
(6, 'Bill-0000000000005', '', '', '1234567890!@#ACZXSD', 1, 0, 1000, '0', '0', 1000),
(7, 'Bill-0000000000006', '', '', 'Test Name123!@#', 1, 0, 100, '0', '0', 100),
(8, 'Bill-0000000000007', '', '', 'Test Name123!@#', 1, 0, 100, '0', '0', 100),
(9, 'Bill-0000000000008', '', '', '1232321', 1, 0, 14, '0', '0', 14),
(10, 'Bill-0000000000009', '6', '9', '00000001', 1, 0, 6696.43, '12', '803.57', 7500),
(11, 'Bill-0000000000010', '14', '15', '73456', 1, 0, 14982.14, '12', '1797.86', 16780),
(12, 'Bill-0000000000011', '7', '16', '', 4, 0, 381.36, '18', '1418.64', 1800),
(13, 'Bill-0000000000013', '5', '1', '869353030845799', 1, 0, 9812.5, '12', '1177.5', 10990),
(14, 'Bill-0000000000014', '5', '2', '869948030482871', 1, 0, 8919.64, '12', '1070.36', 9990);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0-Deactive,1-Active '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`, `status`) VALUES
(1, 'Pune', 1);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_number` varchar(50) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_number`, `company_name`, `status`) VALUES
(1, '', 'Samsung', 1),
(2, '', 'Nokia', 1),
(3, '', 'Apple', 1),
(4, '', 'Motorola', 1),
(5, '', 'Redmi', 1),
(6, '', 'Vivo', 0),
(7, '', 'Oppo', 1),
(8, '', 'Micromax', 1),
(9, '', 'Lava', 1),
(10, '', 'LYF', 1),
(13, '', 'one+', 1),
(14, '', 'ORAIMO ', 1),
(15, '', 'Tork', 1),
(16, '', 'Sony', 1),
(17, '', 'Company2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `company_supplier`
--

CREATE TABLE `company_supplier` (
  `com_sup_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_supplier`
--

INSERT INTO `company_supplier` (`com_sup_id`, `supplier_id`, `company_id`, `status`) VALUES
(1, 1, 6, 1),
(2, 2, 14, 1),
(3, 3, 6, 1),
(4, 0, 1, 1),
(5, 4, 1, 1),
(6, 4, 2, 1),
(7, 4, 3, 1),
(8, 4, 4, 1),
(9, 4, 5, 1),
(10, 4, 6, 1),
(11, 4, 7, 1),
(12, 4, 8, 1),
(13, 4, 9, 1),
(14, 4, 10, 1),
(15, 4, 13, 1),
(16, 4, 14, 1),
(17, 5, 7, 1),
(18, 6, 1, 1),
(19, 6, 2, 1),
(20, 6, 3, 1),
(21, 6, 4, 1),
(22, 6, 5, 1),
(23, 6, 6, 1),
(24, 6, 7, 1),
(25, 6, 8, 1),
(26, 6, 9, 1),
(27, 6, 10, 1),
(28, 6, 13, 1),
(29, 6, 14, 1),
(30, 7, 1, 1),
(31, 7, 2, 1),
(32, 7, 3, 1),
(33, 7, 4, 1),
(34, 7, 5, 1),
(35, 7, 6, 1),
(36, 7, 7, 1),
(37, 7, 8, 1),
(38, 7, 9, 1),
(39, 7, 10, 1),
(40, 7, 13, 1),
(41, 7, 14, 1),
(42, 8, 1, 1),
(43, 8, 2, 1),
(44, 8, 3, 1),
(45, 8, 4, 1),
(46, 8, 5, 1),
(47, 8, 6, 1),
(48, 8, 7, 1),
(49, 8, 8, 1),
(50, 8, 9, 1),
(51, 8, 10, 1),
(52, 8, 13, 1),
(53, 8, 14, 1),
(54, 9, 15, 1),
(55, 10, 1, 1),
(56, 11, 1, 1),
(57, 11, 2, 1),
(58, 11, 3, 1),
(59, 11, 4, 1),
(60, 11, 5, 1),
(61, 11, 6, 1),
(62, 11, 7, 1),
(63, 11, 8, 1),
(64, 11, 9, 1),
(65, 11, 10, 1),
(66, 11, 13, 1),
(67, 11, 14, 1),
(68, 11, 15, 1),
(69, 13, 1, 1),
(70, 13, 2, 1),
(71, 14, 5, 1),
(72, 15, 1, 1),
(73, 15, 2, 1),
(74, 15, 3, 1),
(75, 15, 4, 1),
(76, 15, 5, 1),
(77, 15, 6, 1),
(78, 15, 7, 1),
(79, 15, 8, 1),
(80, 15, 9, 1),
(81, 15, 10, 1),
(82, 15, 13, 1),
(83, 15, 14, 1),
(84, 15, 15, 1),
(85, 17, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_person`
--

CREATE TABLE `contact_person` (
  `contact_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `contact_name` varchar(500) NOT NULL,
  `contact_phone` varchar(500) NOT NULL,
  `contact_email` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0-inactive ,1-active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_person`
--

INSERT INTO `contact_person` (`contact_id`, `supplier_id`, `contact_name`, `contact_phone`, `contact_email`, `status`) VALUES
(1, 1, 'Harsh ', '98000000000', '', 1),
(2, 2, 'Kishor Shinde', '7498512591', '', 1),
(3, 3, 'Vikas', '9800000000', '', 1),
(5, 1, 'Akash', '9959864334', '', 1),
(7, 2, 'Aditya', '9876534655', '', 1),
(8, 4, 'Abc', '8888888888', '', 1),
(9, 5, 'Abc', '9921700077', '', 1),
(10, 6, 'gyviuer', '8888888888', '', 1),
(11, 6, '888888888', '', '', 1),
(12, 7, '8989800000', '8989900000', '', 1),
(13, 8, 'Yogesh', '777869976', '', 1),
(14, 8, 'yogi', '', '', 1),
(15, 9, 'Swapnil', '7875509898', '', 1),
(16, 9, 'Sapnil Pawar', '', '', 1),
(17, 10, 'rehan shikh', '', '', 1),
(18, 11, 'dfsdg', '326542125', '', 1),
(19, 12, 'sagar', '9078675678', '', 1),
(20, 13, 'sagar', '9078675678', '', 1),
(21, 6, 'rajesh', '9090909888', '', 1),
(22, 14, 'Piyush Chate', '1234567891011112', '', 1),
(23, 14, 'rahul ', '123456789112123', '', 1),
(25, 15, 'Piyush Chate', '7030773914', '', 1),
(26, 14, 'rahul ', '1234567890', '', 1),
(27, 14, 'abc', '9675433243', '', 1),
(28, 16, ' 1234567890!@#ACZXSD', '1234567890', '', 1),
(29, 17, ' 1234567890!@#ACZXSD', '1234567890', '', 1),
(30, 14, 'Test Name123!@#', 'Test Name123!@#', '', 1),
(31, 15, '', '', '', 1),
(32, 7, '', '', '', 1),
(33, 5, '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_number` varchar(50) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email_id` varchar(80) NOT NULL,
  `address` varchar(255) NOT NULL,
  `id_proof` varchar(255) NOT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `wedding_date` datetime DEFAULT NULL,
  `balance` double(20,0) NOT NULL DEFAULT '0',
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactivate / 1-Activate',
  `customer_gst_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_number`, `customer_name`, `mobile`, `email_id`, `address`, `id_proof`, `date_of_birth`, `wedding_date`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `customer_gst_no`) VALUES
(1, 'Cust-00000000001', 'Amar Pardeshi', '8275473337', 'prakash.holam@vigopa.com', 'Pune ', '', '1992-12-05 00:00:00', '1992-12-05 00:00:00', 0, '2018-03-24 10:38:57', '1', '2018-06-14 06:42:05', '1', 1, ''),
(2, 'Cust-00000000002', 'sagar khomane', '9890150507', '', 'Pune ', '', '1992-07-04 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-12 04:15:24', '1', '0000-00-00 00:00:00', '', 1, ''),
(3, 'Cust-00000000003', 'santosh aware', '9865326598', '', 'Pune', '', '2010-06-09 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-12 04:25:33', '1', '0000-00-00 00:00:00', '', 1, ''),
(4, 'Cust-00000000004', 'pratibha raut', '7878787887', '', 'Pune', '', '2018-06-15 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-12 04:54:04', '1', '0000-00-00 00:00:00', '', 1, ''),
(5, 'Cust-00000000005', 'anant', '7777777777', 'a@a', 'WHERE 1 \"', 'anant_1528961743.PNG', '2018-06-04 00:00:00', '2018-06-04 00:00:00', 0, '2018-06-14 07:35:43', '', '2018-06-25 12:12:50', '1', 1, 'WHERE 1\";'),
(6, 'Cust-00000000006', 'Ravi', '7875509898', '', 'Vigopa Solutions, 104-Second floor, Sliver point building\r\nSurvey no 20/1/3, Katraj-Kondhawa Road,Katraj', '', '1989-06-06 00:00:00', '0000-00-00 00:00:00', 0, '2018-06-28 11:26:50', '1', '0000-00-00 00:00:00', '', 1, 'AUFF435y33'),
(7, 'Cust-00000000007', 'aa', '9765544334', 'a@gmail.com', 'Pune', '', '2018-06-04 00:00:00', '2018-07-31 00:00:00', 60000, '2018-08-08 13:07:04', '9', '0000-00-00 00:00:00', '', 1, ''),
(8, 'Cust-00000000008', 'bb', '9778665643', 'b@gmail.com', 'pune', '', '2018-07-31 00:00:00', '2018-07-31 00:00:00', 0, '2018-08-08 13:08:34', '9', '0000-00-00 00:00:00', '', 1, ''),
(11, 'Cust-00000000011', 'Akshay Shelke', '9988776655', '', 'Hadpasar, Pune- 28', '', '2007-04-10 00:00:00', '2002-11-14 00:00:00', 60000, '2018-08-17 10:05:49', '9', '2018-08-17 10:07:59', '9', 1, ''),
(12, 'Cust-00000000012', 'Akash', '9765644644', 'akash@gmail.com', 'Katraj, Pune', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-17 10:11:39', '9', '0000-00-00 00:00:00', '', 1, ''),
(13, 'Cust-00000000013', 'Amar', '9786564865', 'prakasholam81@gmail.com', 'Katraj', '', '1993-12-06 00:00:00', '2018-03-29 00:00:00', 0, '2018-08-17 10:14:27', '9', '0000-00-00 00:00:00', '', 1, ''),
(14, 'Cust-00000000014', 'Pratibha Raut', '8977655646', 'pratibha@gmail.com', 'Pune', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-17 10:27:52', '9', '2018-08-17 10:41:15', '9', 1, ''),
(15, 'Cust-00000000015', 'Krushna Pandit', '7387090808', '', 'Kondhwa Budrukh', '', '1988-10-18 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-18 13:23:59', '10', '0000-00-00 00:00:00', '', 1, ''),
(16, 'Cust-00000000016', 'Raju Sahani', '7352623973', '', 'Kakde Nagar Lane-1', '', '1996-03-01 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-18 13:33:15', '10', '0000-00-00 00:00:00', '', 1, ''),
(17, 'Cust-00000000017', 'Amar', '9811111111', 'ama@gmail.com', 'puioi', '', '2018-08-02 00:00:00', '2018-08-03 00:00:00', 10990, '2018-08-21 11:48:08', '2', '0000-00-00 00:00:00', '', 1, ''),
(18, 'Cust-00000000018', 'amar ', '9999999999', '', 'vigopa solution', '', '2018-08-21 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-21 12:07:35', '2', '0000-00-00 00:00:00', '', 1, ''),
(20, 'Cust-00000000020', 'Ramesh', '987654329', '', 'Pune', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-08-28 12:50:13', '2', '0000-00-00 00:00:00', '', 1, ''),
(21, 'Cust-00000000021', 'shubham r hangarge', '8308383337', '', 'dhankawadi pune', '', '2018-09-05 00:00:00', '0000-00-00 00:00:00', 0, '2018-09-12 06:12:30', '11', '0000-00-00 00:00:00', '', 1, ''),
(22, 'Cust-00000000022', 'Amar Pardeshi', '8745546545', '', 'Katraj', '', '2018-09-12 00:00:00', '0000-00-00 00:00:00', 0, '2018-09-12 06:23:49', '9', '0000-00-00 00:00:00', '', 1, ''),
(23, 'Cust-00000000023', 'pratibha', '9856423725', 'abc@gmail.com', 'asdxfesf', '', '1994-07-07 00:00:00', '0000-00-00 00:00:00', 0, '2018-09-12 06:36:36', '9', '2018-09-12 06:36:47', '9', 0, ''),
(24, 'Cust-00000000024', 'SHUBHAM', '8308383581', '', 'DHANKAWADI', '', '2008-01-19 00:00:00', '0000-00-00 00:00:00', 0, '2018-09-12 09:38:10', '11', '0000-00-00 00:00:00', '', 1, ''),
(25, 'Cust-00000000025', '', '', '', '', '', '1970-01-01 00:00:00', '0000-00-00 00:00:00', 0, '2018-10-07 08:33:47', '11', '0000-00-00 00:00:00', '', 1, ''),
(26, 'Cust-00000000026', 'Piyush Chate', '7030773914', '', 'Test Address 1\r\n0TA1', '', '2018-12-04 00:00:00', '0000-00-00 00:00:00', 11490, '2018-12-10 06:05:30', '2', '0000-00-00 00:00:00', '', 1, ' TestGST 123!@#'),
(27, 'Cust-00000000027', 'Piyush Chate', '7030773914', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', 'Piyush Chate_1544425430.odt', '2018-11-28 00:00:00', '2018-11-28 00:00:00', 0, '2018-12-10 07:03:50', '', '0000-00-00 00:00:00', '', 1, '12324'),
(28, 'Cust-00000000028', 'Piyush Chate', '7030773914', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', 'Piyush Chate_1544425523.odt', '2018-12-03 00:00:00', '2018-11-27 00:00:00', 0, '2018-12-10 07:05:23', '', '0000-00-00 00:00:00', '', 1, '12314'),
(29, 'Cust-00000000029', 'Piyush Chate', '7030773914', '', 'Test Address 1\r\n0TA1', '', '2018-11-25 00:00:00', '0000-00-00 00:00:00', 17780, '2018-12-10 07:23:23', '9', '0000-00-00 00:00:00', '', 1, '12324'),
(30, 'Cust-00000000030', 'Test Name123!@#', 'Test Name123!@#', '', 'Test Name123!@#', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 100, '2018-12-10 07:35:04', '9', '0000-00-00 00:00:00', '', 1, 'Test Name123!@#'),
(31, 'Cust-00000000031', 'Piyush Chate', '1234567891', '', 'Test Address 1\r\n0TA1', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 100, '2018-12-10 07:45:44', '9', '0000-00-00 00:00:00', '', 1, ''),
(33, 'Cust-00000000033', 'Piyush Chate', '1234567890', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', 'Piyush Chate_1544442028.odt', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-12-10 11:40:27', '', '0000-00-00 00:00:00', '', 1, 'Test Name123!@#'),
(34, 'Cust-00000000034', 'Piyush Chate', '1231212121', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', 'Piyush Chate_1544442750.odt', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-12-10 11:52:29', '', '0000-00-00 00:00:00', '', 1, ''),
(35, 'Cust-00000000035', 'Piyush Chate', '1234567891', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-12-10 11:53:05', '9', '0000-00-00 00:00:00', '', 1, ''),
(36, 'Cust-00000000036', 'Piyush Chate', '9876543210', 'piyush.chate@vigopa.com', 'Test Address 1\r\n0TA1', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, '2018-12-10 11:53:26', '9', '0000-00-00 00:00:00', '', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_recharge`
--

CREATE TABLE `customer_recharge` (
  `cust_r_id` int(11) NOT NULL,
  `recharge_date` datetime NOT NULL,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact_no` varchar(50) NOT NULL,
  `operator_id` varchar(50) NOT NULL,
  `recharge_amount` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(500) NOT NULL,
  `updated_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(500) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_recharge`
--

INSERT INTO `customer_recharge` (`cust_r_id`, `recharge_date`, `cust_name`, `cust_contact_no`, `operator_id`, `recharge_amount`, `added_date`, `added_by`, `updated_date`, `updated_by`, `status`) VALUES
(1, '2018-12-11 00:00:00', 'shree', '9890897867', 'Vodafone', '50', '2018-12-11 16:02:29', '2', '0000-00-00 00:00:00', '', 1),
(2, '2018-12-11 00:00:00', 'krushna', '8909897867', 'Vodafone', '150', '2018-12-11 16:05:52', '2', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_return`
--

CREATE TABLE `customer_return` (
  `return_id` int(11) NOT NULL,
  `return_number` varchar(200) NOT NULL,
  `return_date` date NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return`
--

INSERT INTO `customer_return` (`return_id`, `return_number`, `return_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', '2018-12-10', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-12-10 05:10:48', '9', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', '2018-12-10', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-12-10 05:13:43', '9', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', '2018-12-10', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-12-10 05:14:29', '9', '0000-00-00 00:00:00', ''),
(4, 'Return-0000000000004', '2018-12-11', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-12-10 22:39:14', '9', '0000-00-00 00:00:00', ''),
(5, 'Return-0000000000005', '2018-12-11', '', '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, '2018-12-10 22:46:59', '9', '0000-00-00 00:00:00', ''),
(6, 'Return-0000000000006', '2018-12-13', '26', '', 0, 0, 4000, '', 0, 0, 0, 0, '', 4000, '2018-12-13 03:10:52', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_detail`
--

CREATE TABLE `customer_return_detail` (
  `return_d_id` int(11) NOT NULL,
  `return_number` varchar(200) NOT NULL,
  `customer_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return_detail`
--

INSERT INTO `customer_return_detail` (`return_d_id`, `return_number`, `customer_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Return-0000000000001', '', '', '', 1, 0, 0, '', '', 0),
(2, 'Return-0000000000002', '', '', '', 1, 0, 0, '', '', 0),
(3, 'Return-0000000000003', '', '', '', 1, 0, 0, '', '', 0),
(4, 'Return-0000000000004', '', '', '', 1, 0, 0, '', '', 0),
(5, 'Return-0000000000005', '', '', '123456789', 1, 0, 0, '', '', 0),
(6, 'Return-0000000000006', '26', '16', '', 4, 0, 0, '', '', 4000);

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_payment_details`
--

CREATE TABLE `customer_return_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_return_payment_transaction`
--

CREATE TABLE `customer_return_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('return') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_return_payment_transaction`
--

INSERT INTO `customer_return_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', 'return', '', '', 'Credit', 0, 0, 0, '0000-00-00', '2018-12-10', '2018-12-10 05:10:48', '9', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', 'return', '', '', 'Credit', 0, 0, 0, '0000-00-00', '2018-12-10', '2018-12-10 05:13:43', '9', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', 'return', '', '', 'Credit', 0, 0, 0, '0000-00-00', '2018-12-10', '2018-12-10 05:14:29', '9', '0000-00-00 00:00:00', ''),
(4, 'Return-0000000000004', 'return', '', '', 'Credit', 0, 0, 0, '0000-00-00', '2018-12-11', '2018-12-10 22:39:14', '9', '0000-00-00 00:00:00', ''),
(5, 'Return-0000000000005', 'return', '', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-12-11', '2018-12-10 22:46:59', '9', '0000-00-00 00:00:00', ''),
(6, 'Return-0000000000006', 'return', '26', '', 'Credit', 4000, 0, 4000, '2018-12-23', '2018-12-13', '2018-12-13 03:10:52', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `daily_recharge`
--

CREATE TABLE `daily_recharge` (
  `daily_recharge_id` int(11) NOT NULL,
  `opening_balance` double DEFAULT '0',
  `purchase_balance` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `sale_balance` double DEFAULT '0',
  `closing_balance` double DEFAULT '0',
  `date` date NOT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_recharge`
--

INSERT INTO `daily_recharge` (`daily_recharge_id`, `opening_balance`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES
(1, 0, 1000, 600, 400, 600, '2018-08-08', '2', '2', '2018-08-08 10:39:25', '2018-08-08 00:00:00', 1),
(2, 600, 3000, 0, 3600, 0, '2018-08-21', '2', '2', '2018-08-21 13:04:48', '2018-08-21 00:00:00', 1),
(3, 0, 4000, 2000, 2000, 2000, '2018-08-23', '10', '10', '2018-08-23 17:21:44', '2018-08-23 00:00:00', 1),
(4, 2000, 0, 0, 2000, 0, '2018-10-19', '10', '', '2018-10-19 14:21:38', '0000-00-00 00:00:00', 1),
(5, 0, 1000, 600, 400, 600, '2018-12-10', '2', '2', '2018-12-10 07:06:51', '2018-12-10 00:00:00', 1),
(6, 600, 3600, 2700, 1500, 2700, '2018-12-11', '2', '2', '2018-12-11 07:23:52', '2018-12-11 00:00:00', 1),
(7, 2700, 11900, 12366, 2234, 12366, '2018-12-13', '9', '9', '2018-12-13 06:39:07', '2018-12-13 00:00:00', 1),
(8, 12366, 30101, -85900, 128367, -85900, '2018-12-14', '9', '9', '2018-12-14 09:21:20', '2018-12-14 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_backup`
--

CREATE TABLE `db_backup` (
  `db_id` int(11) NOT NULL,
  `db_name` text NOT NULL,
  `db_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exchange`
--

CREATE TABLE `exchange` (
  `exchange_id` int(11) NOT NULL,
  `exchange_number` varchar(50) NOT NULL,
  `exchange_type` varchar(100) NOT NULL,
  `from_shop` varchar(20) NOT NULL,
  `to_shop` varchar(20) NOT NULL,
  `amount` double(20,0) NOT NULL,
  `pay_amount` double(20,0) NOT NULL,
  `bal_amount` double(20,0) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '1- Actual/ 0- Cutting',
  `exchange_date` date NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `date_updated` datetime NOT NULL,
  `updated_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_detail`
--

CREATE TABLE `exchange_detail` (
  `exchange_d_id` int(11) NOT NULL,
  `exchange_number` varchar(50) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(50) NOT NULL,
  `quantity` double(20,0) NOT NULL DEFAULT '0',
  `price` double(20,0) NOT NULL DEFAULT '0',
  `total_amount` double(20,0) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange_detail`
--

INSERT INTO `exchange_detail` (`exchange_d_id`, `exchange_number`, `product_number`, `imei_no`, `quantity`, `price`, `total_amount`) VALUES
(1, 'Exch-0000000000000', '13', '45678123', 1, 15000, 15000),
(2, 'Exch-0000000000000', '4', '35765546556345', 1, 50789, 50789),
(3, 'Exch-0000000000000', '14', '354656784545', 1, 13000, 13000),
(4, 'Exch-0000000000000', '15', '12345', 1, 1400, 1400),
(5, 'Exch-0000000000000', '17', '', 2, 250, 500),
(6, 'Exch-0000000000000', '17', '', 3, 531, 1593),
(7, 'Exch-0000000000000', '17', '', 2, 250, 500),
(8, 'Exch-0000000000000', '17', '', 2, 236, 472);

-- --------------------------------------------------------

--
-- Table structure for table `exchange_payment_details`
--

CREATE TABLE `exchange_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_payment_transaction`
--

CREATE TABLE `exchange_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('inward','outward') DEFAULT NULL,
  `shop_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange_payment_transaction`
--

INSERT INTO `exchange_payment_transaction` (`payment_id`, `ref_id`, `type`, `shop_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Exch-0000000000000', 'outward', '4', 'Cheque', 0, 0, 0, '0000-00-00', '2018-12-13', '2018-12-12 22:10:33', '9', '0000-00-00 00:00:00', ''),
(2, 'Exch-0000000000000', 'outward', '4', 'Cash', 0, 1000, 0, '0000-00-00', '2018-12-16', '2018-12-12 22:14:25', '9', '0000-00-00 00:00:00', ''),
(3, 'Exch-0000000000000', 'outward', '4', 'Cash', 15000, 13000, 2000, '2018-12-19', '2018-12-19', '2018-12-12 22:23:14', '9', '0000-00-00 00:00:00', ''),
(4, 'Exch-0000000000000', 'outward', '4', 'Cash', 50789, 0, 50789, '2018-12-23', '2018-12-13', '2018-12-12 22:36:47', '9', '0000-00-00 00:00:00', ''),
(5, 'Exch-0000000000000', 'outward', '4', 'Cash', 13000, 0, 13000, '2018-12-23', '2018-12-13', '2018-12-12 22:38:30', '9', '0000-00-00 00:00:00', ''),
(6, 'Exch-0000000000000', 'outward', '4', 'Cash', 1400, 780, 620, '2018-12-23', '2018-12-13', '2018-12-12 22:43:20', '9', '0000-00-00 00:00:00', ''),
(7, 'Exch-0000000000000', 'outward', '3', 'Exchange', 500, 0, 500, '2018-12-23', '2018-12-13', '2018-12-13 03:15:39', '2', '0000-00-00 00:00:00', ''),
(8, 'Exch-0000000000000', 'inward', '3', 'Exchange', 1593, 0, 1593, '2018-12-23', '2018-12-13', '2018-12-13 03:17:05', '2', '0000-00-00 00:00:00', ''),
(9, 'Exch-0000000000000', 'outward', '3', 'Exchange', 500, 0, 500, '2018-12-23', '2018-12-13', '2018-12-13 03:23:41', '2', '0000-00-00 00:00:00', ''),
(10, 'Exch-0000000000000', 'inward', '3', 'Exchange', 472, 0, 472, '2018-12-23', '2018-12-13', '2018-12-13 03:29:25', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `financer`
--

CREATE TABLE `financer` (
  `financer_id` int(11) NOT NULL,
  `financer_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0-Deactive,1-Active '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `financer`
--

INSERT INTO `financer` (`financer_id`, `financer_name`, `status`) VALUES
(1, 'Home Credit', 1),
(2, 'Bajaj ', 1),
(3, 'TVS ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `level_tags`
--

CREATE TABLE `level_tags` (
  `tag_id` int(11) NOT NULL,
  `tag_name` varchar(5000) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level_tags`
--

INSERT INTO `level_tags` (`tag_id`, `tag_name`, `status`) VALUES
(1, 'Purchase', 1),
(2, 'Sales', 1),
(3, 'Return', 1),
(4, 'Exchange', 1),
(5, 'Report', 1),
(6, 'CA_outstanding', 1),
(7, 'Notification', 1),
(8, 'Email', 1),
(9, 'User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_imei`
--

CREATE TABLE `mobile_imei` (
  `m_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `imei_no` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-deactive',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0- Cutting/ 1- Actual'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile_imei`
--

INSERT INTO `mobile_imei` (`m_id`, `product_id`, `imei_no`, `status`, `type`) VALUES
(1, 1, '869353030845799', 0, 1),
(2, 2, '869948030482871', 0, 1),
(3, 4, '35765546556344', 0, 1),
(4, 4, '35765546556345', 0, 1),
(5, 5, '67578905432', 1, 1),
(6, 6, '1234567890', 0, 1),
(7, 7, '860569045845438', 1, 1),
(8, 7, '860569049845434', 0, 1),
(9, 9, '00000001', 0, 1),
(10, 12, '123456123', 1, 0),
(11, 13, '45678123', 0, 1),
(12, 14, '354656784545', 0, 1),
(13, 15, '73456', 0, 1),
(14, 15, '12345', 0, 1),
(15, 15, '73456', 0, 1),
(16, 15, '12345', 0, 1),
(17, 15, '73456', 0, 1),
(18, 15, '12345', 0, 1),
(19, 19, '10101010', 1, 1),
(20, 1, '123456789', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `n_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `title` varchar(500) NOT NULL,
  `bdate` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-unread,0-read'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`n_id`, `date`, `id`, `type`, `title`, `bdate`, `status`) VALUES
(274, '2019-11-05', 4, 'stock', 'S8', '0000-00-00', 1),
(275, '2019-11-05', 6, 'stock', 'Nokia', '0000-00-00', 1),
(276, '2019-11-05', 7, 'stock', 'Tork', '0000-00-00', 1),
(277, '2019-11-05', 8, 'stock', 'moto e3 power', '0000-00-00', 1),
(278, '2019-11-05', 11, 'stock', 'Note 5 pro', '0000-00-00', 1),
(279, '2019-11-05', 13, 'stock', 'Redmi', '0000-00-00', 1),
(280, '2019-11-05', 14, 'stock', 'note 5 pro', '0000-00-00', 1),
(281, '2019-11-05', 18, 'stock', 'Productname1!@', '0000-00-00', 1),
(282, '2019-11-07', 4, 'stock', 'S8', '0000-00-00', 1),
(283, '2019-11-07', 6, 'stock', 'Nokia', '0000-00-00', 1),
(284, '2019-11-07', 7, 'stock', 'Tork', '0000-00-00', 1),
(285, '2019-11-07', 8, 'stock', 'moto e3 power', '0000-00-00', 1),
(286, '2019-11-07', 11, 'stock', 'Note 5 pro', '0000-00-00', 1),
(287, '2019-11-07', 13, 'stock', 'Redmi', '0000-00-00', 1),
(288, '2019-11-07', 14, 'stock', 'note 5 pro', '0000-00-00', 1),
(289, '2019-11-07', 18, 'stock', 'Productname1!@', '0000-00-00', 1),
(290, '2019-11-15', 2, 'stock', 'A71k', '0000-00-00', 1),
(291, '2019-11-15', 4, 'stock', 'S8', '0000-00-00', 1),
(292, '2019-11-15', 6, 'stock', 'Nokia', '0000-00-00', 1),
(293, '2019-11-15', 7, 'stock', 'Tork', '0000-00-00', 1),
(294, '2019-11-15', 8, 'stock', 'moto e3 power', '0000-00-00', 1),
(295, '2019-11-15', 11, 'stock', 'Note 5 pro', '0000-00-00', 1),
(296, '2019-11-15', 13, 'stock', 'Redmi', '0000-00-00', 1),
(297, '2019-11-15', 14, 'stock', 'note 5 pro', '0000-00-00', 1),
(298, '2019-11-15', 18, 'stock', 'Productname1!@', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`payment_d_id`, `payment_tra_id`, `payment_type`, `bank_name`, `cheque_no`, `finance_type`, `down_payment`, `emi`, `duration`, `payment_date`, `status`) VALUES
(1, 5, 'Cheque', 'SBI', '132425', '', '', '', '', '2018-08-17 00:11:50', 1),
(2, 27, 'Cheque', 'HDFC', '211456', '', '', '', '', '2018-12-11 03:47:39', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_transaction`
--

CREATE TABLE `payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(50) DEFAULT NULL,
  `type` enum('sales','purchase') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_transaction`
--

INSERT INTO `payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Purchase-0000000000001', 'purchase', '', '5', '', 21549.99, 0, 21549.99, '2018-08-18', '2018-08-08', '2018-08-08 10:07:24', '2', '0000-00-00 00:00:00', ''),
(5, 'Purchase-0000000000003', 'purchase', '', '4', 'Cheque', 113767.36, 0, 113767.36, '2018-08-27', '2018-08-17', '2018-08-17 07:11:50', '9', '0000-00-00 00:00:00', ''),
(3, 'Purchase-0000000000002', 'purchase', '', '5', 'Credit', 1100, 1100, 0, '0000-00-00', '2018-08-08', '2018-08-08 10:43:54', '2', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000001', 'sales', '11', '', 'Cash', 60000, 0, 60000, '2018-08-27', '2018-08-17', '2018-08-17 10:05:49', '9', '0000-00-00 00:00:00', ''),
(9, 'Purchase-0000000000004', 'purchase', '', '6', 'Cash', 16800, 0, 16800, '2018-08-31', '2018-08-21', '2018-08-21 11:21:16', '2', '0000-00-00 00:00:00', ''),
(10, 'Purchase-0000000000005', 'purchase', '', '8', '', 5600, 0, 5600, '2018-09-02', '2018-08-23', '2018-08-23 17:10:15', '10', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000002', 'sales', '19', '', 'Cash', 7000, 7000, 0, '0000-00-00', '2018-08-23', '2018-08-23 17:14:03', '10', '0000-00-00 00:00:00', ''),
(12, 'Purchase-0000000000006', 'purchase', '', '9', '', 15680, 0, 15680, '2018-09-07', '2018-08-28', '2018-08-28 12:41:13', '2', '0000-00-00 00:00:00', ''),
(13, 'Purchase-0000000000006', 'purchase', '', '9', 'Cash', 15680, 10000, 5680, '2018-09-07', '2018-08-28', '2018-08-28 12:45:48', '2', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000003', 'sales', '20', '', 'Cash', 8500, 8500, 0, '0000-00-00', '2018-08-28', '2018-08-28 12:50:13', '2', '0000-00-00 00:00:00', ''),
(15, 'Bill-0000000000004', 'sales', '20', '', 'Cash', 8500, 8500, 0, '0000-00-00', '2018-08-28', '2018-08-28 12:51:49', '2', '0000-00-00 00:00:00', ''),
(16, 'Purchase-0000000000005', 'purchase', '', '8', 'Cash', 5600, 5600, 0, '0000-00-00', '2018-09-23', '2018-09-23 09:13:07', '10', '0000-00-00 00:00:00', ''),
(17, 'Bill-0000000000000', 'sales', '26', '', 'Cash', 0, 0, 0, '0000-00-00', '2018-12-10', '2018-12-10 06:05:30', '2', '0000-00-00 00:00:00', ''),
(18, 'Bill-0000000000005', 'sales', '29', '', 'Cash', 1000, 0, 1000, '2018-12-20', '2018-12-10', '2018-12-10 07:23:23', '9', '0000-00-00 00:00:00', ''),
(19, 'Bill-0000000000006', 'sales', '30', '', 'Cash', 100, 0, 100, '2018-12-20', '2018-12-10', '2018-12-10 07:35:04', '9', '0000-00-00 00:00:00', ''),
(20, 'Bill-0000000000007', 'sales', '31', '', 'Cash', 100, 0, 100, '2018-12-20', '2018-12-10', '2018-12-10 07:45:44', '9', '0000-00-00 00:00:00', ''),
(21, 'Bill-0000000000008', 'sales', '32', '', 'Cash', 14, 0, 14, '2018-12-20', '2018-12-10', '2018-12-10 11:02:57', '9', '0000-00-00 00:00:00', ''),
(22, 'Purchase-0000000000007', 'purchase', '', '6', 'Credit', 5040, 4000, 1040, '2018-12-21', '2018-12-11', '2018-12-11 05:53:40', '2', '0000-00-00 00:00:00', ''),
(23, 'Purchase-0000000000008', 'purchase', '', '6', 'Credit', 1770, 1500, 270, '2018-12-25', '2018-12-11', '2018-12-11 05:54:53', '2', '0000-00-00 00:00:00', ''),
(24, 'Bill-0000000000009', 'sales', '26', '', 'Cash', 7500, 5000, 2500, '2018-12-21', '2018-12-11', '2018-12-11 06:55:46', '2', '0000-00-00 00:00:00', ''),
(25, 'Purchase-0000000000009', 'purchase', '', '14', 'Cash', 15750, 0, 15750, '2018-12-21', '2018-12-11', '2018-12-11 07:40:11', '9', '0000-00-00 00:00:00', ''),
(26, 'Purchase-0000000000010', 'purchase', '', '14', 'Cash', 15750, 0, 15750, '2018-12-21', '2018-12-11', '2018-12-11 07:53:57', '9', '0000-00-00 00:00:00', ''),
(27, 'Purchase-0000000000011', 'purchase', '', '14', 'Cheque', 14560, 0, 14560, '2018-12-21', '2018-12-11', '2018-12-11 10:47:39', '9', '0000-00-00 00:00:00', ''),
(28, 'Purchase-0000000000012', 'purchase', '', '14', '', 3136, 0, 3136, '2018-12-21', '2018-12-11', '2018-12-11 12:06:22', '9', '0000-00-00 00:00:00', ''),
(29, 'Purchase-0000000000013', 'purchase', '', '14', '', 3136, 0, 3136, '2018-12-21', '2018-12-11', '2018-12-11 12:06:23', '9', '0000-00-00 00:00:00', ''),
(30, 'Purchase-0000000000014', 'purchase', '', '14', 'Cash', 3136, 0, 3136, '2018-12-21', '2018-12-11', '2018-12-11 12:06:26', '9', '0000-00-00 00:00:00', ''),
(31, 'Bill-0000000000010', 'sales', '29', '', 'Cash', 16780, 0, 16780, '2018-12-22', '2018-12-12', '2018-12-12 04:45:53', '9', '0000-00-00 00:00:00', ''),
(32, 'Purchase-0000000000015', 'purchase', '', '7', 'Credit', 5900, 5680, 0, '0000-00-00', '2018-12-13', '2018-12-13 09:49:07', '2', '0000-00-00 00:00:00', ''),
(33, 'Bill-0000000000011', 'sales', '26', '', 'Credit', 1800, 1800, 0, '0000-00-00', '2018-12-13', '2018-12-13 10:03:24', '2', '0000-00-00 00:00:00', ''),
(34, 'Purchase-0000000000016', 'purchase', '', '5', 'Cash', 2632, 2632, 0, '0000-00-00', '2018-12-22', '2018-12-22 04:32:35', '2', '0000-00-00 00:00:00', ''),
(35, 'Purchase-0000000000017', 'purchase', '', '5', 'Cash', 9621, 9621, 0, '0000-00-00', '2018-12-22', '2018-12-22 04:40:49', '2', '0000-00-00 00:00:00', ''),
(36, 'Bill-0000000000012', 'sales', '17', '', 'Cash', 9440, 9440, 0, '0000-00-00', '2019-04-07', '2019-04-07 11:05:38', '2', '0000-00-00 00:00:00', ''),
(37, 'Bill-0000000000013', 'sales', '17', '', 'Cash', 10990, 0, 10990, '2019-04-17', '2019-04-07', '2019-04-07 11:06:17', '2', '0000-00-00 00:00:00', ''),
(38, 'Bill-0000000000014', 'sales', '26', '', 'Cash', 9990, 0, 9990, '2019-11-18', '2019-11-08', '2019-11-08 05:14:17', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_number` varchar(50) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `unit_of_measurement` varchar(20) NOT NULL,
  `purchase_price` double(20,0) NOT NULL DEFAULT '0',
  `sale_price` double(20,0) NOT NULL DEFAULT '0',
  `imei_no` varchar(500) NOT NULL,
  `hsn_no` varchar(100) NOT NULL,
  `battery_no` varchar(500) NOT NULL,
  `charger_no` varchar(500) NOT NULL,
  `color` varchar(100) NOT NULL,
  `flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-actual,0-cutting',
  `notes` text NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `sub_category_id` varchar(20) NOT NULL,
  `product_company` varchar(5) NOT NULL,
  `min_qty` double(20,0) NOT NULL DEFAULT '0',
  `quantity` double(20,0) NOT NULL DEFAULT '0',
  `gst_percentage` int(11) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_number`, `supplier_number`, `unit_of_measurement`, `purchase_price`, `sale_price`, `imei_no`, `hsn_no`, `battery_no`, `charger_no`, `color`, `flag`, `notes`, `product_name`, `category_id`, `sub_category_id`, `product_company`, `min_qty`, `quantity`, `gst_percentage`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`) VALUES
(1, 'Product-0000000000001', '5', 'PCS', 9621, 10990, '', '85171290', '', '', 'Purple', 1, '', 'A3S', '1', '1', '7', 0, 2, 12, '2018-08-08 10:07:24', '2', '2018-12-22 04:40:49', '', 1),
(2, 'Product-0000000000002', '5', 'PCS', 9790, 9990, '', '85171290', '', '', 'Purple', 1, '', 'A71k', '1', '1', '7', 0, 0, 12, '2018-08-08 10:07:24', '2', '2018-08-08 10:10:14', '2', 1),
(3, 'Product-0000000000003', '5', 'PCS', 110, 150, '', '2222', '', '', '', 1, '', 'A71k screegurad', '2', '4', '7', 0, 8, 0, '2018-08-08 10:43:54', '2', '0000-00-00 00:00:00', '', 1),
(4, 'Product-0000000000004', '4', 'PCS', 50789, 60000, '', '2222', '', '', 'Black', 1, '', 'S8', '1', '1', '1', 0, 0, 12, '2018-08-17 07:11:50', '9', '2018-12-13 11:35:00', '9', 1),
(5, 'Product-0000000000005', '6', 'PCS', 15000, 20000, '', '222', '', '', 'Black', 1, '', 'one+', '1', '1', '13', 0, 1, 12, '2018-08-21 11:21:16', '2', '0000-00-00 00:00:00', '', 1),
(6, 'Product-0000000000006', '8', 'PCS', 5000, 7000, '', '234', '', '', 'Black', 1, '', 'Nokia', '1', '1', '1', 0, 0, 12, '2018-08-23 17:10:15', '10', '0000-00-00 00:00:00', '', 1),
(7, 'Product-0000000000007', '9', 'PCS', 7000, 9000, '', '7689343', '', '', 'silver', 1, '', 'Tork', '1', '1', '15', 0, 0, 12, '2018-08-28 12:41:13', '2', '2018-08-28 12:41:13', '', 1),
(8, 'Product-0000000000008', '0', 'PCS', 8999, 10000, '', '1223', '', '', '', 1, '', 'moto e3 power', '1', '1', '4', 2, 0, 12, '2018-09-12 10:35:19', '9', '0000-00-00 00:00:00', '', 1),
(9, 'Product-0000000000009', '6', 'PCS', 4500, 7500, '', '1234', '', '', 'silver', 1, '', 'M34', '1', '1', '4', 0, 2, 12, '2018-12-11 05:53:40', '2', '2018-12-11 06:35:07', '2', 1),
(10, 'Product-0000000000010', '6', 'PCS', 150, 220, '', '12345', '', '', '', 1, '', 'N Headphone', '2', '6', '2', 0, 4, 18, '2018-12-11 05:54:53', '2', '0000-00-00 00:00:00', '', 1),
(11, 'Product-0000000000011', '11', 'PCS', 2, 11000, '', '0', '', '', 'Rose gold', 1, '', 'Note 5 pro', '1', '1', '5', 1, 0, 5, '2018-12-11 06:39:12', '9', '2018-12-11 06:42:31', '9', 1),
(12, 'Product-0000000000012', '14', 'PCS', 15000, 15750, '', '321', '', '', 'blue', 0, '', 'Samsung ', '1', '1', '5', 0, 1, 5, '2018-12-11 07:40:11', '9', '0000-00-00 00:00:00', '', 1),
(13, 'Product-0000000000013', '14', 'PCS', 15000, 14000, '', '123', '', '', 'Rose gold', 1, '', 'Redmi', '1', '1', '5', 0, 0, 5, '2018-12-11 07:53:57', '9', '0000-00-00 00:00:00', '', 1),
(14, 'Product-0000000000014', '14', 'PCS', 13000, 15000, '', '2222', '', '', 'Black', 1, '', 'note 5 pro', '1', '1', '5', 0, 0, 12, '2018-12-11 10:47:39', '9', '0000-00-00 00:00:00', '', 1),
(15, 'Product-0000000000015', '14', 'PCS', 1400, 16780, '', '12', '', '', 'Black', 1, '', 'Moto G4', '1', '', '', 0, 4, 12, '2018-12-11 12:06:22', '9', '2018-12-13 12:27:03', '9', 1),
(16, 'Product-0000000000016', '7', 'PCS', 250, 450, '', '121234', '', '', '', 1, '', 'vivo power bank 1000', '2', '6', '6', 0, 10, 18, '2018-12-13 09:49:07', '2', '0000-00-00 00:00:00', '', 1),
(17, 'Product-0000000000017', '7', 'PCS', 250, 500, '', '12123456', '', '', '', 1, '', 'vivo battery', '2', '6', '6', 0, 6, 18, '2018-12-13 09:49:07', '2', '0000-00-00 00:00:00', '', 1),
(18, 'Product-0000000000018', '0', 'PCS', 18000, 20000, '', '2', '', '', 'Black!@', 1, '', 'Productname1!@', '6', '', '8', 1, 0, 5, '2018-12-14 07:15:01', '9', '2018-12-14 07:21:32', '9', 0),
(19, 'Product-0000000000019', '5', 'PCS', 2350, 3500, '', '234567', '', '', 'black', 1, '', 'samsang ZX', '1', '1', '7', 0, 1, 12, '2018-12-22 04:32:35', '2', '0000-00-00 00:00:00', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `purchase_id` int(11) NOT NULL,
  `purchase_number` varchar(50) NOT NULL,
  `purchase_date` datetime NOT NULL,
  `supplier_id` varchar(50) NOT NULL,
  `contact_person_id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-tax,0-without_tax',
  `notes` varchar(50) DEFAULT NULL,
  `document` varchar(500) NOT NULL,
  `total_amount` double(20,0) DEFAULT '0',
  `total_payment` double(20,0) DEFAULT '0',
  `total_balance` double(20,0) DEFAULT '0',
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `purchase_number`, `purchase_date`, `supplier_id`, `contact_person_id`, `type`, `notes`, `document`, `total_amount`, `total_payment`, `total_balance`, `added_date`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Purchase-0000000000001', '2018-08-08 00:00:00', '5', 9, 1, NULL, '', 21550, 0, 21550, '2018-08-08 03:07:24', '2', NULL, NULL),
(2, 'Purchase-0000000000002', '2018-08-08 00:00:00', '5', 9, 1, NULL, '', 1100, 1100, 0, '2018-08-08 03:43:54', '2', NULL, NULL),
(3, 'Purchase-0000000000003', '2018-08-17 00:00:00', '4', 8, 1, NULL, '', 113767, 0, 113767, '2018-08-17 00:11:50', '9', NULL, NULL),
(4, 'Purchase-0000000000004', '2018-08-21 00:00:00', '6', 11, 1, NULL, '', 16800, 0, 16800, '2018-08-21 04:21:16', '2', NULL, NULL),
(5, 'Purchase-0000000000005', '2018-08-23 00:00:00', '8', 14, 1, NULL, '', 5600, 5600, 0, '2018-08-23 10:10:15', '10', NULL, NULL),
(6, 'Purchase-0000000000006', '2018-08-28 00:00:00', '9', 16, 1, NULL, '', 15680, 10000, 5680, '2018-08-28 05:41:13', '2', NULL, NULL),
(7, 'Purchase-0000000000007', '2018-12-11 00:00:00', '6', 21, 1, NULL, '', 5040, 4000, 1040, '2018-12-10 22:53:40', '2', NULL, NULL),
(8, 'Purchase-0000000000008', '2018-12-11 00:00:00', '6', 21, 1, NULL, '', 1770, 1500, 270, '2018-12-10 22:54:53', '2', NULL, NULL),
(9, 'Purchase-0000000000009', '2018-12-11 00:00:00', '14', 26, 0, NULL, 'document_1544514011.jpg', 15750, 0, 15750, '2018-12-11 00:40:11', '9', NULL, NULL),
(10, 'Purchase-0000000000010', '2018-12-11 00:00:00', '14', 26, 1, NULL, 'document_1544514838.jpg', 15750, 0, 15750, '2018-12-11 00:53:57', '9', NULL, NULL),
(11, 'Purchase-0000000000011', '2018-12-11 00:00:00', '14', 27, 1, NULL, '', 14560, 0, 14560, '2018-12-11 03:47:39', '9', NULL, NULL),
(12, 'Purchase-0000000000012', '2018-12-11 00:00:00', '14', 30, 1, NULL, '', 3136, 0, 3136, '2018-12-11 05:06:22', '9', NULL, NULL),
(13, 'Purchase-0000000000013', '2018-12-11 00:00:00', '14', 30, 1, NULL, '', 3136, 0, 3136, '2018-12-11 05:06:23', '9', NULL, NULL),
(14, 'Purchase-0000000000014', '2018-12-11 00:00:00', '14', 30, 1, NULL, '', 3136, 0, 3136, '2018-12-11 05:06:26', '9', NULL, NULL),
(15, 'Purchase-0000000000015', '2018-12-13 00:00:00', '7', 32, 1, NULL, '', 5900, 5680, 0, '2018-12-13 02:49:07', '2', NULL, NULL),
(16, 'Purchase-0000000000016', '2018-12-22 00:00:00', '5', 33, 1, NULL, '', 2632, 2632, 0, '2018-12-21 21:32:35', '2', NULL, NULL),
(17, 'Purchase-0000000000017', '2018-12-22 00:00:00', '5', 33, 0, NULL, '', 9621, 9621, 0, '2018-12-21 21:40:49', '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_detail`
--

CREATE TABLE `purchase_detail` (
  `purchase_d_id` int(11) NOT NULL,
  `purchase_number` varchar(50) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(50) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `purchasing_quantity` double(20,0) NOT NULL DEFAULT '0',
  `purchasing_price` double(20,0) NOT NULL DEFAULT '0',
  `selling_price` double(20,0) NOT NULL DEFAULT '0',
  `gst_percentage` int(11) NOT NULL,
  `purchasing_total_amount` double(20,0) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_detail`
--

INSERT INTO `purchase_detail` (`purchase_d_id`, `purchase_number`, `supplier_number`, `product_number`, `imei_no`, `purchasing_quantity`, `purchasing_price`, `selling_price`, `gst_percentage`, `purchasing_total_amount`) VALUES
(1, 'Purchase-0000000000001', '5', '1', '869353030845799', 1, 10775, 10990, 12, 10775),
(2, 'Purchase-0000000000001', '5', '2', '869948030482871', 1, 10775, 10990, 12, 10775),
(3, 'Purchase-0000000000002', '5', '3', '', 10, 110, 150, 0, 1100),
(4, 'Purchase-0000000000003', '4', '4', '35765546556344', 1, 56884, 60000, 12, 56884),
(5, 'Purchase-0000000000003', '4', '4', '35765546556345', 1, 56884, 60000, 12, 56884),
(6, 'Purchase-0000000000004', '6', '5', '67578905432', 1, 16800, 20000, 12, 16800),
(7, 'Purchase-0000000000005', '8', '6', '1234567890', 1, 5600, 7000, 12, 5600),
(8, 'Purchase-0000000000006', '9', '7', '860569045845438', 1, 7840, 9000, 12, 7840),
(9, 'Purchase-0000000000006', '9', '7', '860569049845434', 1, 7840, 9000, 12, 7840),
(10, 'Purchase-0000000000007', '6', '9', '00000001', 1, 5040, 7500, 12, 5040),
(11, 'Purchase-0000000000008', '6', '10', '', 10, 177, 220, 18, 1770),
(12, 'Purchase-0000000000009', '14', '12', '123456123', 1, 15750, 15750, 5, 15750),
(13, 'Purchase-0000000000010', '14', '13', '45678123', 1, 15750, 14000, 5, 15750),
(14, 'Purchase-0000000000011', '14', '14', '354656784545', 1, 14560, 15000, 12, 14560),
(15, 'Purchase-0000000000012', '14', '15', '73456', 1, 1568, 16780, 12, 1568),
(16, 'Purchase-0000000000012', '14', '15', '12345', 1, 1568, 16780, 12, 1568),
(17, 'Purchase-0000000000013', '14', '15', '73456', 1, 1568, 16780, 12, 1568),
(18, 'Purchase-0000000000013', '14', '15', '12345', 1, 1568, 16780, 12, 1568),
(19, 'Purchase-0000000000014', '14', '15', '73456', 1, 1568, 16780, 12, 1568),
(20, 'Purchase-0000000000014', '14', '15', '12345', 1, 1568, 16780, 12, 1568),
(21, 'Purchase-0000000000015', '7', '16', '', 10, 295, 450, 18, 2950),
(22, 'Purchase-0000000000015', '7', '17', '', 10, 295, 500, 18, 2950),
(23, 'Purchase-0000000000016', '5', '19', '10101010', 1, 2632, 3500, 12, 2632),
(24, 'Purchase-0000000000017', '5', '1', '123456789', 1, 9621, 10990, 12, 9621);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_sale_recharge`
--

CREATE TABLE `purchase_sale_recharge` (
  `r_purchase_id` int(11) NOT NULL,
  `operator_name` varchar(30) NOT NULL,
  `purchase_balance` double NOT NULL DEFAULT '0',
  `total_balance` double NOT NULL DEFAULT '0',
  `sale_balance` double DEFAULT '0',
  `closing_balance` double NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_sale_recharge`
--

INSERT INTO `purchase_sale_recharge` (`r_purchase_id`, `operator_name`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES
(1, 'Jio', 1000, 1000, 0, 1000, '2018-08-08', '2', '', '2018-08-08 10:39:25', '0000-00-00 00:00:00', 1),
(2, 'Jio', 0, 1000, 400, 600, '2018-08-08', '2', '', '2018-08-08 10:40:42', '0000-00-00 00:00:00', 1),
(3, 'Airtel', 1000, 1000, 0, 1000, '2018-08-21', '2', '', '2018-08-21 13:04:48', '0000-00-00 00:00:00', 1),
(4, 'Airtel', 0, 1000, 1000, 0, '2018-08-21', '2', '', '2018-08-21 13:06:34', '0000-00-00 00:00:00', 1),
(5, 'Jio', 2000, 2600, 0, 2600, '2018-08-21', '2', '', '2018-08-21 13:15:57', '0000-00-00 00:00:00', 1),
(6, 'Jio', 0, 2600, 2600, 0, '2018-08-21', '2', '', '2018-08-21 13:16:27', '0000-00-00 00:00:00', 1),
(7, 'Idea', 3000, 3000, 0, 3000, '2018-08-23', '10', '', '2018-08-23 17:21:44', '0000-00-00 00:00:00', 1),
(8, 'Idea', 0, 3000, 2000, 1000, '2018-08-23', '10', '', '2018-08-23 17:22:18', '0000-00-00 00:00:00', 1),
(9, 'Idea', 1000, 2000, 0, 2000, '2018-08-23', '10', '', '2018-08-23 17:23:03', '0000-00-00 00:00:00', 1),
(10, 'Idea', 0, 2000, 2000, 0, '2018-10-19', '10', '', '2018-10-19 14:21:38', '0000-00-00 00:00:00', 1),
(11, 'Vodafone', 1000, 1000, 0, 1000, '2018-12-10', '2', '', '2018-12-10 07:06:51', '0000-00-00 00:00:00', 1),
(12, 'Vodafone', 0, 1000, 400, 600, '2018-12-10', '2', '', '2018-12-10 07:08:06', '0000-00-00 00:00:00', 1),
(13, 'Vodafone', 500, 1100, 0, 1100, '2018-12-11', '2', '', '2018-12-11 07:23:52', '0000-00-00 00:00:00', 1),
(14, 'Vodafone', 0, 1100, 100, 1000, '2018-12-11', '2', '', '2018-12-11 07:24:40', '0000-00-00 00:00:00', 1),
(15, 'Vodafone', 0, 1000, 200, 800, '2018-12-11', '2', '', '2018-12-11 07:26:21', '0000-00-00 00:00:00', 1),
(16, 'Idea', 2000, 2000, 0, 2000, '2018-12-11', '2', '', '2018-12-11 10:11:11', '0000-00-00 00:00:00', 1),
(17, 'Idea', 0, 2000, 500, 1500, '2018-12-11', '2', '', '2018-12-11 10:11:54', '0000-00-00 00:00:00', 1),
(18, 'Vodafone', 100, 900, 0, 900, '2018-12-11', '2', '', '2018-12-11 10:44:41', '0000-00-00 00:00:00', 1),
(19, 'Idea', 0, 1500, 300, 1200, '2018-12-11', '2', '', '2018-12-11 10:47:35', '0000-00-00 00:00:00', 1),
(20, 'Uninor', 1000, 1000, 0, 1000, '2018-12-11', '2', '', '2018-12-11 10:49:07', '0000-00-00 00:00:00', 1),
(21, 'Idea', 0, 1200, 400, 800, '2018-12-11', '2', '', '2018-12-11 11:19:47', '0000-00-00 00:00:00', 1),
(22, 'Jio', 900, 900, 0, 900, '2018-12-13', '9', '', '2018-12-13 06:39:07', '0000-00-00 00:00:00', 1),
(23, 'Jio', 10000, 10900, 0, 10900, '2018-12-13', '9', '', '2018-12-13 06:39:59', '0000-00-00 00:00:00', 1),
(24, 'Jio', 0, 10900, 1234, 9666, '2018-12-13', '9', '', '2018-12-13 06:43:37', '0000-00-00 00:00:00', 1),
(25, 'Idea', 0, 0, 1000, -1000, '2018-12-13', '9', '', '2018-12-13 06:44:15', '0000-00-00 00:00:00', 1),
(26, 'Vodafone', 1000, 1900, 0, 1900, '2018-12-13', '9', '', '2018-12-13 06:46:20', '0000-00-00 00:00:00', 1),
(27, 'Jio', 5000, 14666, 0, 14666, '2018-12-14', '9', '', '2018-12-14 09:21:20', '0000-00-00 00:00:00', 1),
(28, 'Jio', 1467, 16133, 0, 16133, '2018-12-14', '9', '', '2018-12-14 09:21:38', '0000-00-00 00:00:00', 1),
(29, 'Jio', 16134, 32267, 0, 32267, '2018-12-14', '9', '', '2018-12-14 09:21:51', '0000-00-00 00:00:00', 1),
(30, 'Vodafone', 7000, 8900, 0, 8900, '2018-12-14', '9', '', '2018-12-14 09:23:05', '0000-00-00 00:00:00', 1),
(31, 'Jio', 0, 32267, 12333, 19934, '2018-12-14', '9', '', '2018-12-14 09:38:35', '0000-00-00 00:00:00', 1),
(32, 'Jio', 0, 19934, 12334, 7600, '2018-12-14', '9', '', '2018-12-14 09:40:06', '0000-00-00 00:00:00', 1),
(33, 'Vodafone', 500, 9400, 0, 9400, '2018-12-14', '9', '', '2018-12-14 11:02:22', '0000-00-00 00:00:00', 1),
(34, 'Jio', 0, 7600, 8000, -400, '2018-12-14', '9', '', '2018-12-14 11:34:22', '0000-00-00 00:00:00', 1),
(35, 'Jio', 0, -400, 400, -800, '2018-12-14', '9', '', '2018-12-14 11:35:35', '0000-00-00 00:00:00', 1),
(36, 'Jio', 0, -800, 800, -1600, '2018-12-14', '9', '', '2018-12-14 11:36:30', '0000-00-00 00:00:00', 1),
(37, 'Vodafone', 0, 9400, 94500, -85100, '2018-12-14', '9', '', '2018-12-14 11:37:53', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `repair`
--

CREATE TABLE `repair` (
  `repair_id` int(11) NOT NULL,
  `customer_number` varchar(100) DEFAULT NULL,
  `repair_payment_id` varchar(100) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `sub_category_id` int(11) DEFAULT NULL,
  `product_brand` varchar(20) DEFAULT NULL,
  `product_model` varchar(20) DEFAULT NULL,
  `product_description` text,
  `product_issue` text,
  `due_date` datetime DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `added_by` varchar(20) DEFAULT NULL,
  `updated_by` varchar(20) DEFAULT NULL,
  `added_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_date` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:recieved, 2: working, 3:complete, 4:return'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repair`
--

INSERT INTO `repair` (`repair_id`, `customer_number`, `repair_payment_id`, `category_id`, `sub_category_id`, `product_brand`, `product_model`, `product_description`, `product_issue`, `due_date`, `return_date`, `added_by`, `updated_by`, `added_date`, `update_date`, `status`) VALUES
(1, 'Cust-00000000001', '2', 1, 1, 'A3S', 'A3S', 'abc', 'Screen damage', '2018-08-08 00:00:00', '0000-00-00 00:00:00', '2', '2', '2018-08-08 03:51:09', '2018-08-08 00:00:00', 2),
(2, 'Cust-00000000015', '3', 1, 1, 'Samsung', '7562', '', 'charging base', '2018-08-19 00:00:00', '0000-00-00 00:00:00', '10', '', '2018-08-18 06:23:59', '0000-00-00 00:00:00', 1),
(3, 'Cust-00000000016', '24', 1, 1, 'Samsung', 'GT-I9060', 'Whaite Colour', 'Charging Base/Battary Canectar', '2018-08-19 00:00:00', '0000-00-00 00:00:00', '10', '10', '2018-08-18 06:33:15', '2018-09-22 00:00:00', 1),
(4, 'Cust-00000000011', '4', 1, 1, 'samsung', 's6', 'samsung s6', 'screen damage', '2018-08-18 00:00:00', '2018-08-18 00:00:00', '9', '9', '2018-08-18 06:42:29', '2018-08-18 00:00:00', 4),
(5, 'Cust-00000000011', '4', 1, 1, 'samsung', 's8', 'battery Problem', 'battery Problem', '2018-08-18 00:00:00', '0000-00-00 00:00:00', '9', '9', '2018-08-18 06:44:12', '2018-08-20 05:50:06', 1),
(6, 'Cust-00000000012', '5', 2, 3, 'Vivo', 'v6', '', 'broked', '2018-08-18 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-08-18 06:45:18', '0000-00-00 00:00:00', 1),
(7, 'Cust-00000000011', '6', 1, 1, 'Motorola', 'g5', 'testing', 'testing', '2018-08-18 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-08-18 06:46:21', '0000-00-00 00:00:00', 1),
(9, 'Cust-00000000011', '9', 1, 1, 'samsung', 'j7', 'test', 'test', '2018-08-18 00:00:00', '2018-08-18 00:00:00', '9', '9', '2018-08-18 06:58:41', '2018-08-18 00:00:00', 4),
(10, 'Cust-00000000011', '9', 1, 1, 'samsung', 'j5', 'test', 'test', '2018-08-18 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-08-18 06:59:25', '0000-00-00 00:00:00', 1),
(11, 'Cust-00000000014', '10', 1, 1, 'Moto', 'g5', 'test', 'test', '2018-08-18 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-08-18 07:11:50', '0000-00-00 00:00:00', 1),
(12, 'Cust-00000000018', '12', 1, 1, 'Samsung', 'S7edge', 'dsjvhdyvry dhvyrrhl bh', 'not working', '2018-08-21 00:00:00', '0000-00-00 00:00:00', '2', '', '2018-08-21 05:07:35', '0000-00-00 00:00:00', 1),
(13, 'Cust-00000000017', '13', 1, 1, 'sony', 'xeperia', '', 'battery problem', '2018-08-21 00:00:00', '0000-00-00 00:00:00', '2', '', '2018-08-21 05:10:44', '0000-00-00 00:00:00', 1),
(14, 'Cust-00000000022', '18', 1, 1, 'Samsung', 'S6', 'back camera scratch', 'software', '2018-09-29 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-09-11 23:23:49', '0000-00-00 00:00:00', 1),
(15, 'Cust-00000000014', '20', 1, 2, 'Samsung', 'GT-720', '', '', '2018-09-12 00:00:00', '0000-00-00 00:00:00', '9', '', '2018-09-11 23:35:00', '0000-00-00 00:00:00', 1),
(16, 'Cust-00000000021', '21', 1, 1, 'Samsung', 'S8', 'testing', 'testing', '2018-09-12 00:00:00', '0000-00-00 00:00:00', '11', '', '2018-09-11 23:39:21', '0000-00-00 00:00:00', 1),
(17, 'Cust-00000000024', '22', 1, 1, 'SAMSUNG ', 'S 6 EDGE ', '', 'SIM BASE', '2018-09-26 00:00:00', '0000-00-00 00:00:00', '11', '', '2018-09-12 02:38:10', '0000-00-00 00:00:00', 1),
(18, 'Cust-00000000022', '23', 1, 1, 'Samsung', 'S8', 'testing text', 'testing text testing text testing text testing text', '2018-09-12 00:00:00', '2018-09-20 00:00:00', '9', '', '2018-09-12 06:42:13', '0000-00-00 00:00:00', 1),
(19, 'Cust-00000000025', '25', 1, 1, 'MOTOROLA ', 'XT1068', 'ON/OFF BUTTON NOT PRESS', 'DISPLAY\r\nON/OFF KEY\r\nSPEAKR\r\n', '2018-10-06 00:00:00', '2018-10-09 00:00:00', '11', '11', '2018-10-06 04:23:15', '2018-10-07 01:33:47', 1),
(20, 'Cust-00000000000', '26', 1, 1, 'SAMSUNG ', 'E 7 ', '', 'DISPLAY COMBO', '2018-10-10 00:00:00', '2018-10-12 00:00:00', '11', '', '2018-10-10 09:00:07', '0000-00-00 00:00:00', 1),
(21, 'Cust-00000000000', '27', 1, 1, 'SAAMSUNG', 'J 7 2015', '', 'DISPLAY COMBO ', '2018-10-19 00:00:00', '2018-10-30 00:00:00', '11', '', '2018-10-19 03:13:29', '0000-00-00 00:00:00', 1),
(22, 'Cust-00000000020', '28', 1, 1, 'Samsung', 'guru', 'na', 'break display', '2018-12-11 00:00:00', '2018-12-13 00:00:00', '2', '2', '2018-12-10 23:06:37', '2018-12-11 00:00:00', 2),
(23, 'Cust-00000000026', '29', 2, 5, 'vivo', 'vivo battery', 'na', 'change', '2018-12-25 00:00:00', '2018-12-13 00:00:00', '2', '', '2018-12-13 03:49:21', '0000-00-00 00:00:00', 1),
(24, 'Cust-00000000026', '30', 2, 5, 'vivo', 'vivo battery', 'na', 'change', '2018-12-25 00:00:00', '2018-12-13 00:00:00', '2', '2', '2018-12-13 03:49:22', '2018-12-13 00:00:00', 2),
(25, 'Cust-00000000000', '31', 6, 11, 'Test Name123!@#', 'Test Name123!@#', 'Test Name123!@#', 'Test Name123!@#', '2018-12-15 00:00:00', '2018-12-15 00:00:00', '9', '9', '2018-12-14 23:48:32', '2018-12-15 00:00:00', 1),
(26, 'Cust-00000000000', '32', 1, 1, 'SAMSUNG MOBILE', 'J 2 2017 GOLD', '', 'DISPLAY COMBO', '2018-12-21 00:00:00', '2018-12-22 00:00:00', '11', '', '2018-12-21 07:15:16', '0000-00-00 00:00:00', 1),
(27, 'Cust-00000000000', '33', 1, 1, 'MI POCO MOBILE ', 'POCO F1 ', 'BODY BEND ', 'DISPLAY COMBO AND MOTHAR BOARD', '2019-01-04 00:00:00', '2019-01-06 00:00:00', '11', '', '2019-01-06 06:49:25', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `repair_payment_detail`
--

CREATE TABLE `repair_payment_detail` (
  `repair_payment_id` int(11) NOT NULL,
  `customer_number` varchar(50) DEFAULT NULL,
  `repair_id` varchar(11) NOT NULL,
  `approx_cost` double DEFAULT '0',
  `advance_pay` double DEFAULT '0',
  `balance` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `payment_type` varchar(100) DEFAULT NULL,
  `bank_name` varchar(500) DEFAULT NULL,
  `cheque_no` varchar(500) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `added_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `repair_payment_detail`
--

INSERT INTO `repair_payment_detail` (`repair_payment_id`, `customer_number`, `repair_id`, `approx_cost`, `advance_pay`, `balance`, `total_payment`, `payment_type`, `bank_name`, `cheque_no`, `transaction_date`, `added_date`, `update_date`, `added_by`, `updated_by`) VALUES
(1, 'Cust-00000000001', '1', 1500, 100, 1400, 1500, 'Cash', '', '', '2018-08-08 03:51:09', '2018-08-08 03:51:09', '0000-00-00 00:00:00', '2', ''),
(2, 'Cust-00000000001', '1', 2000, 2000, 0, 2000, 'Cash', '', '', '2018-08-08 03:52:11', '2018-08-08 03:52:11', '0000-00-00 00:00:00', '2', ''),
(3, 'Cust-00000000015', '2', 250, 0, 250, 250, '', '', '', '2018-08-18 06:23:59', '2018-08-18 06:23:59', '0000-00-00 00:00:00', '10', ''),
(4, 'Cust-00000000011', '5', 400, 100, 300, 400, 'Cash', '', '', '2018-08-18 06:44:12', '2018-08-18 06:44:12', '0000-00-00 00:00:00', '9', ''),
(5, 'Cust-00000000012', '6', 100, 50, 50, 100, 'Cash', '', '', '2018-08-18 06:45:18', '2018-08-18 06:45:18', '0000-00-00 00:00:00', '9', ''),
(6, 'Cust-00000000011', '7', 1000, 100, 900, 1000, 'Cash', '', '', '2018-08-18 06:46:21', '2018-08-18 06:46:21', '0000-00-00 00:00:00', '9', ''),
(8, 'Cust-00000000011', '10', 1200, 100, 1100, 1200, '', '', '', '2018-08-18 06:59:25', '2018-08-18 06:59:25', '0000-00-00 00:00:00', '9', ''),
(9, 'Cust-00000000011', '10', 1200, 100, 1100, 1200, 'Cash', '', '', '2018-08-18 07:00:07', '2018-08-18 07:00:07', '0000-00-00 00:00:00', '9', ''),
(10, 'Cust-00000000014', '11', 350, 0, 350, 350, 'Cash', '', '', '2018-08-18 07:11:50', '2018-08-18 07:11:50', '0000-00-00 00:00:00', '9', ''),
(11, 'Cust-00000000016', '3', 400, 0, 400, 400, '', '', '', '2018-08-18 06:23:59', '2018-08-18 06:23:59', '0000-00-00 00:00:00', '10', ''),
(12, 'Cust-00000000018', '12', 5000, 1000, 4000, 5000, 'Cash', '', '', '2018-08-21 05:07:35', '2018-08-21 05:07:35', '0000-00-00 00:00:00', '2', ''),
(13, 'Cust-00000000017', '13', 2000, 500, 1500, 2000, 'Cash', '', '', '2018-08-21 05:10:44', '2018-08-21 05:10:44', '0000-00-00 00:00:00', '2', ''),
(14, 'Cust-00000000016', '3', 400, 0, 400, 400, 'Cash', '', '', '2018-08-23 10:16:53', '2018-08-23 10:16:53', '0000-00-00 00:00:00', '10', ''),
(15, 'Cust-00000000021', '0', 800, 100, 700, 800, 'Cash', '', '', '2018-09-11 23:12:30', '2018-09-11 23:12:30', '0000-00-00 00:00:00', '11', ''),
(16, 'Cust-00000000021', '0', 800, 100, 700, 800, 'Cash', '', '', '2018-09-11 23:12:34', '2018-09-11 23:12:34', '0000-00-00 00:00:00', '11', ''),
(17, 'Cust-00000000021', '0', 800, 100, 700, 800, 'Cash', '', '', '2018-09-11 23:12:45', '2018-09-11 23:12:45', '0000-00-00 00:00:00', '11', ''),
(18, 'Cust-00000000022', '14', 800, 100, 700, 800, 'Cash', '', '', '2018-09-11 23:23:49', '2018-09-11 23:23:49', '0000-00-00 00:00:00', '9', ''),
(19, 'Cust-00000000012', '0', 750, 0, 750, 750, 'Cash', '', '', '2018-09-11 23:31:28', '2018-09-11 23:31:28', '0000-00-00 00:00:00', '9', ''),
(20, 'Cust-00000000014', '15', 200, 0, 200, 200, 'Cash', '', '', '2018-09-11 23:35:00', '2018-09-11 23:35:00', '0000-00-00 00:00:00', '9', ''),
(21, 'Cust-00000000021', '16', 700, 100, 600, 700, 'Cash', '', '', '2018-09-11 23:39:21', '2018-09-11 23:39:21', '0000-00-00 00:00:00', '11', ''),
(22, 'Cust-00000000024', '17', 1490, 300, 1190, 1490, 'Cash', '', '', '2018-09-12 02:38:10', '2018-09-12 02:38:10', '0000-00-00 00:00:00', '11', ''),
(23, 'Cust-00000000022', '18', 500, 100, 400, 500, 'Cash', '', '', '2018-09-12 06:42:13', '2018-09-12 06:42:13', '0000-00-00 00:00:00', '9', ''),
(24, 'Cust-00000000016', '3', 400, 0, 400, 400, 'Cash', '', '', '2018-09-22 01:54:11', '2018-09-22 01:54:11', '0000-00-00 00:00:00', '10', ''),
(25, 'Cust-00000000000', '19', 2000, 0, 2000, 2000, 'Cash', '', '', '2018-10-06 04:23:15', '2018-10-06 04:23:15', '0000-00-00 00:00:00', '11', ''),
(26, 'Cust-00000000000', '20', 1800, 0, 1800, 1800, 'Cash', '', '', '2018-10-10 09:00:07', '2018-10-10 09:00:07', '0000-00-00 00:00:00', '11', ''),
(27, 'Cust-00000000000', '21', 2100, 0, 2100, 2100, 'Cash', '', '', '2018-10-19 03:13:29', '2018-10-19 03:13:29', '0000-00-00 00:00:00', '11', ''),
(28, 'Cust-00000000020', '22', 2000, 1000, 1000, 2000, 'Credit', '', '', '2018-12-10 23:06:37', '2018-12-10 23:06:37', '0000-00-00 00:00:00', '2', ''),
(29, 'Cust-00000000026', '23', 400, 300, 100, 400, 'Credit', '', '', '2018-12-13 03:49:21', '2018-12-13 03:49:21', '0000-00-00 00:00:00', '2', ''),
(30, 'Cust-00000000026', '24', 400, 300, 100, 400, 'Credit', '', '', '2018-12-13 03:49:22', '2018-12-13 03:49:22', '0000-00-00 00:00:00', '2', ''),
(31, 'Cust-00000000000', '25', 0, 0, 1, 0, 'Cash', '', '', '2018-12-14 23:48:32', '2018-12-14 23:48:32', '0000-00-00 00:00:00', '9', ''),
(32, 'Cust-00000000000', '26', 1500, 0, 1500, 1500, 'Cash', '', '', '2018-12-21 07:15:16', '2018-12-21 07:15:16', '0000-00-00 00:00:00', '11', ''),
(33, 'Cust-00000000000', '27', 4300, 1000, 3300, 4300, 'Cash', '', '', '2019-01-06 06:49:25', '2019-01-06 06:49:25', '0000-00-00 00:00:00', '11', '');

-- --------------------------------------------------------

--
-- Table structure for table `return`
--

CREATE TABLE `return` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(200) NOT NULL,
  `sales_date` date NOT NULL,
  `supplier_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return`
--

INSERT INTO `return` (`sales_id`, `sales_number`, `sales_date`, `supplier_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', '2018-12-11', '7', '', 0, 0, 220, '', 0, 0, 0, 0, '', 220, '2018-12-10 22:49:03', '2', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', '2018-12-11', '6', '', 0, 750, 0, '', 0, 0, 0, 0, '', 750, '2018-12-10 22:56:41', '2', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', '2018-12-11', '6', '', 0, 150, 0, '', 0, 0, 0, 0, '', 150, '2018-12-10 22:58:24', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `return_detail`
--

CREATE TABLE `return_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(200) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return_detail`
--

INSERT INTO `return_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Return-0000000000001', '5', '3', '', 2, 0, 0, '', '', 220),
(2, 'Return-0000000000002', '6', '10', '', 5, 0, 0, '', '', 750),
(3, 'Return-0000000000003', '6', '10', '', 1, 0, 0, '', '', 150);

-- --------------------------------------------------------

--
-- Table structure for table `return_payment_details`
--

CREATE TABLE `return_payment_details` (
  `payment_d_id` int(11) NOT NULL,
  `type` varchar(200) NOT NULL,
  `payment_tra_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `bank_name` varchar(500) NOT NULL,
  `cheque_no` varchar(500) NOT NULL,
  `finance_type` varchar(500) NOT NULL,
  `down_payment` varchar(500) NOT NULL,
  `emi` varchar(500) NOT NULL,
  `duration` varchar(500) NOT NULL,
  `payment_date` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `return_payment_transaction`
--

CREATE TABLE `return_payment_transaction` (
  `payment_id` int(11) NOT NULL,
  `ref_id` varchar(200) DEFAULT NULL,
  `type` enum('return') DEFAULT NULL,
  `customer_number` varchar(20) DEFAULT NULL,
  `supplier_number` varchar(20) DEFAULT NULL,
  `payment_type` varchar(500) NOT NULL,
  `sub_total` double NOT NULL DEFAULT '0',
  `payment` double NOT NULL DEFAULT '0',
  `balance` double NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `date_transaction` date DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `return_payment_transaction`
--

INSERT INTO `return_payment_transaction` (`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`, `payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Return-0000000000001', 'return', '', '7', 'Credit', 220, 0, 220, '2018-12-21', '2018-12-11', '2018-12-10 22:49:03', '2', '0000-00-00 00:00:00', ''),
(2, 'Return-0000000000002', 'return', '', '6', 'Credit', 750, 750, 0, '0000-00-00', '2018-12-11', '2018-12-10 22:56:41', '2', '0000-00-00 00:00:00', ''),
(3, 'Return-0000000000003', 'return', '', '6', 'Credit', 150, 150, 0, '0000-00-00', '2018-12-11', '2018-12-10 22:58:24', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `sales_date` date NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `notes` varchar(50) DEFAULT NULL,
  `total_amount` double DEFAULT '0',
  `total_payment` double DEFAULT '0',
  `total_balance` double DEFAULT '0',
  `discount_type` char(1) DEFAULT NULL,
  `discount_percentage` double DEFAULT '0',
  `discount_amount` double DEFAULT '0',
  `gst_percentage` double DEFAULT '0',
  `gst_amount` double DEFAULT '0',
  `gst_description` varchar(50) DEFAULT NULL,
  `final_total_amount` double DEFAULT '0',
  `date_added` datetime DEFAULT NULL,
  `added_by` varchar(50) DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sales_number`, `sales_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES
(1, 'Bill-0000000000001', '2018-08-17', '11', '', 53571.43, 0, 60000, '', 0, 0, 12, 6428.57, '', 60000, '2018-08-17 03:05:49', '9', '0000-00-00 00:00:00', ''),
(2, 'Bill-0000000000002', '2018-08-23', '19', '', 5932.2, 7000, 0, '', 0, 0, 18, 1067.8, '', 7000, '2018-08-23 10:14:03', '10', '0000-00-00 00:00:00', ''),
(3, 'Bill-0000000000003', '2018-08-28', '20', '', 7589.29, 8500, 0, '', 5.8823529411765, 500, 12, 910.71, '', 8500, '2018-08-28 05:50:13', '2', '0000-00-00 00:00:00', ''),
(4, 'Bill-0000000000004', '2018-08-28', '20', '', 7589.29, 8500, 0, '', 5.8823529411765, 500, 12, 910.71, '', 8500, '2018-08-28 05:51:49', '2', '0000-00-00 00:00:00', ''),
(5, 'Bill-0000000000005', '2018-12-10', '29', '', 1000, 0, 1000, '', -100, -1000, 0, 0, '', 1000, '2018-12-10 00:23:23', '9', '0000-00-00 00:00:00', ''),
(6, 'Bill-0000000000006', '2018-12-10', '30', '', 100, 0, 100, '', -100, -100, 0, 0, '', 100, '2018-12-10 00:35:04', '9', '0000-00-00 00:00:00', ''),
(7, 'Bill-0000000000007', '2018-12-10', '31', '', 100, 0, 100, '', -100, -100, 0, 0, '', 100, '2018-12-10 00:45:44', '9', '0000-00-00 00:00:00', ''),
(8, 'Bill-0000000000008', '2018-12-10', '32', '', 14, 0, 14, '', -100, -14, 0, 0, '', 14, '2018-12-10 04:02:57', '9', '0000-00-00 00:00:00', ''),
(9, 'Bill-0000000000009', '2018-12-11', '26', '', 6696.43, 5000, 2500, '', 0, 0, 12, 803.57, '', 7500, '2018-12-10 23:55:46', '2', '0000-00-00 00:00:00', ''),
(10, 'Bill-0000000000010', '2018-12-12', '29', '', 14982.14, 0, 16780, '', 0, 0, 12, 1797.86, '', 16780, '2018-12-11 21:45:53', '9', '0000-00-00 00:00:00', ''),
(11, 'Bill-0000000000011', '2018-12-13', '26', '', 381.36, 1800, 0, '', -75, -1350, 0, 1418.64, '', 1800, '2018-12-13 03:03:24', '2', '0000-00-00 00:00:00', ''),
(12, 'Bill-0000000000012', '2019-04-07', '17', '', 8000, 9440, 0, '', -100, -9440, 18, 1440, '', 9440, '2019-04-07 04:05:38', '2', '0000-00-00 00:00:00', ''),
(13, 'Bill-0000000000013', '2019-04-07', '17', '', 9812.5, 0, 10990, '', 0, 0, 12, 1177.5, '', 10990, '2019-04-07 04:06:17', '2', '0000-00-00 00:00:00', ''),
(14, 'Bill-0000000000014', '2019-11-08', '26', '', 8919.64, 0, 9990, '', 0, 0, 12, 1070.36, '', 9990, '2019-11-07 22:14:17', '2', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `sales_detail`
--

CREATE TABLE `sales_detail` (
  `sales_d_id` int(11) NOT NULL,
  `sales_number` varchar(20) NOT NULL,
  `supplier_number` varchar(20) NOT NULL,
  `product_number` varchar(20) NOT NULL,
  `imei_no` varchar(100) NOT NULL,
  `sales_quantity` double NOT NULL DEFAULT '0',
  `purchasing_price` double NOT NULL DEFAULT '0',
  `sales_price` double NOT NULL DEFAULT '0',
  `gst_percentage` varchar(50) NOT NULL,
  `gst_amount` varchar(50) NOT NULL,
  `sales_total_amount` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_detail`
--

INSERT INTO `sales_detail` (`sales_d_id`, `sales_number`, `supplier_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES
(1, 'Bill-0000000000001', '4', '4', '35765546556344', 1, 0, 53571.43, '12', '6428.57', 60000),
(2, 'Bill-0000000000002', '8', '6', '1234567890', 1, 0, 5932.2, '18', '1067.8', 7000),
(3, 'Bill-0000000000003', '9', '7', '860569049845434', 1, 0, 7589.29, '12', '910.71', 8500),
(4, 'Bill-0000000000004', '9', '7', '860569049845434', 1, 0, 7589.29, '12', '910.71', 8500),
(5, 'Bill-0000000000000', '', '', 'Test IMEi no 123!@#', 1, 0, 4, '5', '0', 4),
(6, 'Bill-0000000000005', '', '', '1234567890!@#ACZXSD', 1, 0, 1000, '0', '0', 1000),
(7, 'Bill-0000000000006', '', '', 'Test Name123!@#', 1, 0, 100, '0', '0', 100),
(8, 'Bill-0000000000007', '', '', 'Test Name123!@#', 1, 0, 100, '0', '0', 100),
(9, 'Bill-0000000000008', '', '', '1232321', 1, 0, 14, '0', '0', 14),
(10, 'Bill-0000000000009', '6', '9', '00000001', 1, 0, 6696.43, '12', '803.57', 7500),
(11, 'Bill-0000000000010', '14', '15', '73456', 1, 0, 14982.14, '12', '1797.86', 16780),
(12, 'Bill-0000000000011', '7', '16', '', 4, 0, 381.36, '18', '1418.64', 1800),
(13, 'Bill-0000000000012', '', 'Samasung J7', '88355091105734842', 1, 0, 8000, '18', '1440', 9440),
(14, 'Bill-0000000000013', '5', '1', '869353030845799', 1, 0, 9812.5, '12', '1177.5', 10990),
(15, 'Bill-0000000000014', '5', '2', '869948030482871', 1, 0, 8919.64, '12', '1070.36', 9990);

-- --------------------------------------------------------

--
-- Table structure for table `sim_operator`
--

CREATE TABLE `sim_operator` (
  `operator_id` int(11) NOT NULL,
  `operator_name` varchar(30) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0-Deactive,1-Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sim_operator`
--

INSERT INTO `sim_operator` (`operator_id`, `operator_name`, `status`) VALUES
(1, 'Jio', 1),
(2, 'Idea', 1),
(3, 'Vodafone', 1),
(4, 'Airtel', 1),
(5, 'Netlink', 1),
(6, 'Pmasia', 1),
(7, 'BSNL', 1),
(8, 'Uninor', 1),
(9, ' Name123!@#', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0-Deactive,1-Active '
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `status`) VALUES
(1, 'Mh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(11) NOT NULL,
  `category_id` int(10) NOT NULL,
  `sub_category_name` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `category_id`, `sub_category_name`, `status`) VALUES
(1, 1, 'Smart Phones', 1),
(2, 1, 'Phones', 1),
(3, 2, 'Headphones', 1),
(4, 2, 'ScreenGuard', 1),
(5, 2, 'Battery', 1),
(6, 2, 'Power Banks', 1),
(7, 1, 'Battery', 1),
(8, 6, 'Speaker', 1),
(9, 5, 'Sub category123!@', 1),
(10, 5, 'Sub Category2', 1),
(11, 6, 'Subcategory2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_user_level`
--

CREATE TABLE `sub_user_level` (
  `u_id` int(11) NOT NULL,
  `level_name` varchar(200) NOT NULL,
  `level_fectures` varchar(500) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_user_level`
--

INSERT INTO `sub_user_level` (`u_id`, `level_name`, `level_fectures`, `admin_id`, `status`) VALUES
(2, 'Admin', '1,2,3,4,5,6,7,9', 2, 1),
(3, 'Sub_Admin', '1,2', 0, 1),
(4, 'sub', '1,2,3', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supplier_id` int(11) NOT NULL,
  `supplier_number` varchar(50) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `supplier_address` varchar(255) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email_id` varchar(70) NOT NULL,
  `note` text NOT NULL,
  `supplier_for` varchar(200) NOT NULL,
  `balance` varchar(25) NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(50) NOT NULL,
  `update_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-Deactive/ 1-Active',
  `dealer_gst_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supplier_id`, `supplier_number`, `supplier_name`, `supplier_address`, `contact_person`, `contact_number`, `email_id`, `note`, `supplier_for`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `dealer_gst_no`) VALUES
(1, 'Dealer-00000000001', 'Harsh Communication', 'Office No.-09-10 , Santosh Heights. Apot Opp Apsara Theatre Shankarsheth Road , Gultekadi . Pune-411037', 'Harsh ', '98000000000', 'amarpardeshi28@yahoo.com', '', '6', '0', '2018-03-24 12:21:58', '', '2018-03-26 05:05:45', '1', 1, ''),
(2, 'Dealer-00000000002', 'Kishor Sales', 'S. No. 9/2B, FLAT NO.502. WING B,SHRI VENTATESH LAKE VISTA. PUNE-411046', 'Kishor Shinde', '7498512591', 'kishorshinde13@yahoo.in', '', '1,2,14', '0', '2018-03-26 06:38:35', '1', '2018-07-23 07:17:36', '1', 1, ''),
(3, 'Dealer-00000000003', 'Harsh Communication', 'Pune', 'Harsh', '9800000000', 'md@mayur.com', '', '6', '0', '2018-05-24 10:56:35', '1', '2018-05-24 10:56:35', '', 1, ''),
(4, 'Dealer-00000000004', 'Akash', 'Pune', 'Abc', '9888888888', 'akash@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14', '0', '2018-08-08 09:34:32', '9', '2018-08-08 09:34:32', '', 1, ''),
(5, 'Dealer-00000000005', 'Power Telecom', 'Pune', 'Abc', '9922008070', 'powertelpune@gmail.com', '', '7', '0', '2018-08-08 10:01:28', '2', '2018-08-08 10:01:28', '', 1, '27AAPFM4534Q1ZH'),
(6, 'Dealer-00000000006', 'harsh communcation', 'fc road opp.deccan honda showroom pune', 'gyviuer', '9970275714', 'harshcommunication@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14', '900', '2018-08-21 11:12:22', '2', '2018-08-21 11:12:22', '', 1, '9999999'),
(7, 'Dealer-00000000007', 'deep enterprises', 'oppo. kaka halwai sweets, satara road, swargate', '8989800000', '8989700000', 'deepenterprises@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14', '5680', '2018-08-21 12:48:06', '2', '2018-08-21 12:48:06', '', 1, '89898989'),
(8, 'Dealer-00000000008', 'Tork', 'Servant Qtr, Susje Sorabji Road, Near GPO, Pune 411001', 'Yogesh', '7875509898', 'nairyog@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14', '0', '2018-08-23 17:01:07', '10', '2018-08-23 17:01:07', '', 1, ''),
(9, 'Dealer-00000000009', 'Sai Mobile', 'Kondhwa Br', 'Swapnil', '7875509898', 'yogeshnair2013@gmail.com', '', '15', '0', '2018-08-28 10:22:02', '2', '2018-08-28 10:22:02', '', 1, '111847292324'),
(10, 'Dealer-00000000010', 'KRIPA ANAND RISHI CELLULAR PVT LTD', '487/B SUVRNA CHAMBERS, NARAYAN PETH ', 'rehan shikh', '0', 'karcpltd1@gmail.com', '', '1', '0', '2018-09-12 06:22:37', '11', '2018-09-12 06:22:37', '', 1, '27AACCK564G1Z7'),
(11, 'Dealer-00000000011', 'pratibha', 'adasf', 'dfsdg', '956425685', 'abc@gmail.com', '', '1,2,3,4,5,6,7,8,9,10,13,14,15', '0', '2018-09-12 06:37:42', '9', '2018-09-12 06:37:52', '9', 0, ''),
(12, 'Dealer-00000000012', 'amar', 'pune', 'sagar', '9078908978', 'amar@gmail.com', '', '', '0', '2018-09-25 11:07:17', '2', '2018-09-25 11:07:17', '', 1, 'GHJJH567'),
(13, 'Dealer-00000000013', 'amar', 'pune   ee', 'sagar', '9078908978', 'amar@gmail.com', '', '1,2', '0', '2018-09-25 11:07:58', '2', '2018-09-25 11:07:58', '', 1, 'GHJJH567'),
(14, 'Dealer-00000000014', 'Piyush', 'Test Address 1\r\n0TA1 , Katraj', 'Piyush Chate', '7030773914', 'piyush.chate@vigopa.com', '', '5', '0', '2018-12-11 07:02:32', '9', '2018-12-11 07:02:32', '', 1, '12314'),
(15, 'Dealer-00000000015', 'Test Name123!@#', 'Test Address 1\r\n0TA1', 'Piyush Chate', '7030773914', 'piy12ush.chate@vigopa.com', '', '1,2,3,4,5,6,7,8,9,10,13,14,15', '0', '2018-12-11 07:22:22', '9', '2018-12-11 07:22:22', '', 1, 'Test Name123!@#'),
(16, 'Dealer-00000000016', 'test name', '', ' 1234567890!@#ACZXSD', '1234567890', 'new@gmail.com', '', '', '0', '2018-12-11 11:32:16', '9', '2018-12-11 11:32:16', '', 1, ' 1234567890!@#ACZXSD'),
(17, 'Dealer-00000000017', 'test name', '', ' 1234567890!@#ACZXSD', '1234567890', 'new@gmail.com', '', '1', '0', '2018-12-11 11:33:45', '9', '2018-12-11 11:53:15', '9', 0, ' 1234567890!@#ACZXSD');

-- --------------------------------------------------------

--
-- Table structure for table `sup_user`
--

CREATE TABLE `sup_user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(500) NOT NULL,
  `lname` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `profile_pic` varchar(500) NOT NULL,
  `user_level` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active ,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sup_user`
--

INSERT INTO `sup_user` (`user_id`, `fname`, `lname`, `email`, `password`, `contact_no`, `profile_pic`, `user_level`, `status`) VALUES
(2, 'Super', 'Admin', 'superadmin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '8275473337', '', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `unit_of_measurement`
--

CREATE TABLE `unit_of_measurement` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 - DeActive / 1- Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(500) NOT NULL,
  `lname` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `profile_pic` varchar(500) NOT NULL,
  `admin` int(11) NOT NULL,
  `user_level` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1-active ,0-inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fname`, `lname`, `email`, `password`, `contact_no`, `profile_pic`, `admin`, `user_level`, `status`) VALUES
(2, 'Amar', 'Pardeshi', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '8275473337', '', 0, 3, 1),
(3, 'Sagar', 'Khomane', 'sagar@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '9876543210', '', 0, 2, 1),
(4, 'Swapnil', 'Hunnur', 'swarnalakshya16417@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '8087865003', '', 0, 3, 1),
(5, 'Santosh', 'Aware', 'santosh@gmail.com', '0cc175b9c0f1b6a831c399e269772661', '9767543676', '', 0, 2, 1),
(9, 'Prakash', 'Holam', 'prakash@gmail.com', '73803249c6667c5af2d51c0dedfae487', '9800000000', '', 0, 3, 1),
(10, 'Swapnil', 'Pawar', 'swapnilp644@gmail.com', '7d4e8ad1331065288afe7da4b131654e', '9623307707', '', 0, 3, 1),
(11, 'Shubham', 'Hangarge', 'shangarge499@gmail.com', '719f194e39d46eadace68fdcf0c8aea4', '8308383581', '', 0, 3, 1),
(12, 'Vinay', 'Nair', 'vinushares2011@gmail.com', 'bb107751e39a3ea6dcb28a37fd481d69', '6565535290', '', 0, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_level`
--

CREATE TABLE `user_level` (
  `u_id` int(11) NOT NULL,
  `level_name` varchar(200) NOT NULL,
  `level_fectures` varchar(500) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_level`
--

INSERT INTO `user_level` (`u_id`, `level_name`, `level_fectures`, `status`) VALUES
(2, 'Sub-Admin', '1,2,3,4,5,7,8', 1),
(3, 'Admin', '1,2,3,4,5,6,7,8,9', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `user_id` int(11) NOT NULL,
  `register_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `shop_name` varchar(500) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone_no` varchar(200) NOT NULL,
  `gst_no` varchar(200) NOT NULL,
  `mac_id` varchar(200) NOT NULL,
  `s_key` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `exp_date` date NOT NULL,
  `flag` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`user_id`, `register_date`, `shop_name`, `first_name`, `last_name`, `username`, `password`, `phone_no`, `gst_no`, `mac_id`, `s_key`, `address`, `exp_date`, `flag`, `status`) VALUES
(1, '2018-08-03 19:18:26', 'mobil Shop', 'amar', 'pardeshi', 'admin@gmail.com', '0cc175b9c0f1b6a831c399e269772661', '9800000000', '', '18-A9-05-98-3B-4E', 'a', 'pune', '0000-00-00', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_shop`
--
ALTER TABLE `about_shop`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `about_shop_own`
--
ALTER TABLE `about_shop_own`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`area_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ca_payment_transaction`
--
ALTER TABLE `ca_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `ca_sales`
--
ALTER TABLE `ca_sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `ca_sales_detail`
--
ALTER TABLE `ca_sales_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `company_supplier`
--
ALTER TABLE `company_supplier`
  ADD PRIMARY KEY (`com_sup_id`);

--
-- Indexes for table `contact_person`
--
ALTER TABLE `contact_person`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_recharge`
--
ALTER TABLE `customer_recharge`
  ADD PRIMARY KEY (`cust_r_id`);

--
-- Indexes for table `customer_return`
--
ALTER TABLE `customer_return`
  ADD PRIMARY KEY (`return_id`),
  ADD UNIQUE KEY `NoFaktur` (`return_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `customer_return_detail`
--
ALTER TABLE `customer_return_detail`
  ADD PRIMARY KEY (`return_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`return_number`);

--
-- Indexes for table `customer_return_payment_details`
--
ALTER TABLE `customer_return_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `customer_return_payment_transaction`
--
ALTER TABLE `customer_return_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `daily_recharge`
--
ALTER TABLE `daily_recharge`
  ADD PRIMARY KEY (`daily_recharge_id`);

--
-- Indexes for table `db_backup`
--
ALTER TABLE `db_backup`
  ADD PRIMARY KEY (`db_id`);

--
-- Indexes for table `exchange`
--
ALTER TABLE `exchange`
  ADD PRIMARY KEY (`exchange_id`);

--
-- Indexes for table `exchange_detail`
--
ALTER TABLE `exchange_detail`
  ADD PRIMARY KEY (`exchange_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`exchange_number`);

--
-- Indexes for table `exchange_payment_details`
--
ALTER TABLE `exchange_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `exchange_payment_transaction`
--
ALTER TABLE `exchange_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `financer`
--
ALTER TABLE `financer`
  ADD PRIMARY KEY (`financer_id`);

--
-- Indexes for table `level_tags`
--
ALTER TABLE `level_tags`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indexes for table `mobile_imei`
--
ALTER TABLE `mobile_imei`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `payment_transaction`
--
ALTER TABLE `payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  ADD PRIMARY KEY (`purchase_d_id`);

--
-- Indexes for table `purchase_sale_recharge`
--
ALTER TABLE `purchase_sale_recharge`
  ADD PRIMARY KEY (`r_purchase_id`);

--
-- Indexes for table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`repair_id`);

--
-- Indexes for table `repair_payment_detail`
--
ALTER TABLE `repair_payment_detail`
  ADD PRIMARY KEY (`repair_payment_id`);

--
-- Indexes for table `return`
--
ALTER TABLE `return`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`supplier_id`);

--
-- Indexes for table `return_detail`
--
ALTER TABLE `return_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `return_payment_details`
--
ALTER TABLE `return_payment_details`
  ADD PRIMARY KEY (`payment_d_id`);

--
-- Indexes for table `return_payment_transaction`
--
ALTER TABLE `return_payment_transaction`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD UNIQUE KEY `NoFaktur` (`sales_number`),
  ADD KEY `TCustomerTJual` (`customer_id`);

--
-- Indexes for table `sales_detail`
--
ALTER TABLE `sales_detail`
  ADD PRIMARY KEY (`sales_d_id`),
  ADD KEY `TBarangTDJual` (`product_number`),
  ADD KEY `TJualTDJual` (`sales_number`);

--
-- Indexes for table `sim_operator`
--
ALTER TABLE `sim_operator`
  ADD PRIMARY KEY (`operator_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`);

--
-- Indexes for table `sub_user_level`
--
ALTER TABLE `sub_user_level`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `sup_user`
--
ALTER TABLE `sup_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_level`
--
ALTER TABLE `user_level`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_shop`
--
ALTER TABLE `about_shop`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `about_shop_own`
--
ALTER TABLE `about_shop_own`
  MODIFY `shop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `area_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ca_payment_transaction`
--
ALTER TABLE `ca_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `ca_sales`
--
ALTER TABLE `ca_sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ca_sales_detail`
--
ALTER TABLE `ca_sales_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `company_supplier`
--
ALTER TABLE `company_supplier`
  MODIFY `com_sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `contact_person`
--
ALTER TABLE `contact_person`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `customer_recharge`
--
ALTER TABLE `customer_recharge`
  MODIFY `cust_r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_return`
--
ALTER TABLE `customer_return`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_return_detail`
--
ALTER TABLE `customer_return_detail`
  MODIFY `return_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_return_payment_details`
--
ALTER TABLE `customer_return_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_return_payment_transaction`
--
ALTER TABLE `customer_return_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `daily_recharge`
--
ALTER TABLE `daily_recharge`
  MODIFY `daily_recharge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `db_backup`
--
ALTER TABLE `db_backup`
  MODIFY `db_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange`
--
ALTER TABLE `exchange`
  MODIFY `exchange_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_detail`
--
ALTER TABLE `exchange_detail`
  MODIFY `exchange_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `exchange_payment_details`
--
ALTER TABLE `exchange_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exchange_payment_transaction`
--
ALTER TABLE `exchange_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `financer`
--
ALTER TABLE `financer`
  MODIFY `financer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `level_tags`
--
ALTER TABLE `level_tags`
  MODIFY `tag_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `mobile_imei`
--
ALTER TABLE `mobile_imei`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=299;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_transaction`
--
ALTER TABLE `payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `purchase_detail`
--
ALTER TABLE `purchase_detail`
  MODIFY `purchase_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `purchase_sale_recharge`
--
ALTER TABLE `purchase_sale_recharge`
  MODIFY `r_purchase_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `repair`
--
ALTER TABLE `repair`
  MODIFY `repair_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `repair_payment_detail`
--
ALTER TABLE `repair_payment_detail`
  MODIFY `repair_payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `return`
--
ALTER TABLE `return`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `return_detail`
--
ALTER TABLE `return_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `return_payment_details`
--
ALTER TABLE `return_payment_details`
  MODIFY `payment_d_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `return_payment_transaction`
--
ALTER TABLE `return_payment_transaction`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sales_detail`
--
ALTER TABLE `sales_detail`
  MODIFY `sales_d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sim_operator`
--
ALTER TABLE `sim_operator`
  MODIFY `operator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sub_user_level`
--
ALTER TABLE `sub_user_level`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sup_user`
--
ALTER TABLE `sup_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_level`
--
ALTER TABLE `user_level`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

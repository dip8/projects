<!DOCTYPE html>
<?php include 'header.php';

  if(!in_array("Return", $admin_rv)){
	 ?><script>
	window.location='dashboard.php';
	</script><?php
}
?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Product Return | Inventory Management System</title>
<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.6 -->

<link rel="stylesheet" href="assets/css/bill.css">
    <!-- Date Picker -->
<link rel="stylesheet" href="plugins/datepicker/datepicker3.css">

<link rel="stylesheet" type="text/css" href="assets/css/all.css" />

<script type="text/javascript" src="assets/js/shieldui-all.js"></script>

<style>
.bigicon {
	font-size: 47px;
	padding-bottom: 10px;
	padding-top: 10px;
	color: #5CB85C;
}
.main-header .navbar{
	margin-bottom:-20px;
}   
.wizard-card[data-color="red"] .moving-tab, .moving-tab, .btn.btn-danger.btn.btn-danger, .btn.btn-danger:hover{
	    background-color: #dd4b39 ;
} 
</style>

<script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
	$('#customer_master').addClass('active');
    $("#mcustreturn").addClass('active');	 
});
</script> 

<script>
$(document).ready(function(){

$(":input").keypress(function(event){
    if (event.which == '10' || event.which == '13') {
        event.preventDefault();
    }
});	

$('input:radio[name="pro_type"]').change(
    function(){
        if ($(this).is(':checked') && $(this).val() == 'mobile') {
			/*  
             $('#product_name1').val('');
            $('#product_qty1').val('');
            $('#product_price1').val('');
            $('#product_gst1').val('');
             $('#total1').val('');
             $('#hid_sale_price').val(''); */
            $('#accessories').hide();
            $('#mobile').show();
        }else{
			 
			/* $('#product_name').val('');
			$('#product_qty').val('');
			$('#imei_no').val('');
			$('#battery_no').val('');
			$('#charger_no').val('');
			 $('#data_cable').val('');
			 $('#hid_sale_price').val('');
			$('#product_qty').val('');
			 
            $('#product_qty').val('');
            $('#product_price').val('');
            $('#product_gst').val('');
             $('#total').val(''); */
			$('#mobile').hide();
            $('#accessories').show();
		}
    });
    });
</script>

<script>

function sale_product()
	{ 	 
	 
	 document.getElementById("btnproduct").disabled = true;
	    var myform = document.getElementById("product_return_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/customer_product_return_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
			   //alert(data);
				if(data==1){
				alert("Cutomer Product Return Successfully..");
				 
				   location.reload();
					 //window.location.href = 'invoice.php'; 
				}
				else{
				alert("Cutomer Product Not Return, Try again...");
					
				}
				//alert(data);
				 
			}
		});
	 
	  
}

function bill_preview()
 { 
	     var myform = document.getElementById("product_return_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/bill_model.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				$("#bill_preview_model").modal("show");
				$("#bill_data").html('');
				$("#bill_data").html(data);
				 
			}
		});
	 
	 
   
 }
 
 function view_product_details(id,name)
 { 
	//$("#view_sales_details").modal("show");
	$.ajax({
			url: "excess/view_customer_return_product_details.php",
			type: "POST",
			data: {'return_number':id,'customer_name':name} ,
		    success: function (data) {
				$("#view_sales_details").modal("show");
				$("#result_data1").html('');
				$("#result_data1").html(data);
			}
			});	
 
 }

$(function () {
    $("#btnAdd").bind("click", function () {
        $("#TextBoxContainer").append(GetDynamicTextBox());
    });
	$("#btnAdd_Access").bind("click", function () {
        $("#TextBoxContainer_access").append(GetDynamicTextBox_access());
    });
    $("body").on("click", ".remove", function () {
        $(this).closest("tr").remove();
    });
});
function GetDynamicTextBox(value) {

    return '<tr class="item-row"><input type="hidden" class="hid_product_id" name="hid_product_id[]" id="hid_product_id" /><input type="hidden" class="product_qty" name="product_qty[]" id="product_qty" value="1" /><input type="hidden" class="hid_sale_price" name="hid_sale_price[]" id="hid_sale_price" value="" /><input type="hidden" class="hid_purchase_price" name="hid_purchase_price[]" id="hid_purchase_price" value="" /><td><input type="text" class="product_name form-control" name="product_name[]" id="product_name" onkeypress="getProduct(event)" onkeyup="getProduct(event)" placeholder="Product Name" style="padding: 3px;text-align: center;" required /></td>' + '<td><input type="text" class="imei_no number1 form-control" name="imei_no[]" id="imei_no" placeholder="IMEI No" style="padding: 3px;text-align: center;" /></td>' + '<td width="9%"><input type="number" class="product_qty form-control" name="product_qty[]" id="product_qty" value="1" placeholder="Quantity" style="padding: 3px;text-align: center;" readonly /></td>'  + '<td><input type="text" class="total number form-control" name="total[]" id="total" value="0"  placeholder="Total Amount" style="padding: 3px;text-align: center;" readonly /></td>' + '<td align="center"><button type="button" class="btn btn-danger remove" style="margin-top: -1px;padding: 9px 12px 8px 12px;"><i class="glyphicon glyphicon-remove-sign"></i></button></td></tr>'
}

function GetDynamicTextBox_access(value) {

    return '<tr class="item-row"><input type="hidden" class="hid_product_id" name="hid_product_id[]" id="hid_product_id" /><input type="hidden" class="hid_sale_price" name="hid_sale_price[]" id="hid_sale_price" value="" /><input type="hidden" class="hid_purchase_price" name="hid_purchase_price[]" id="hid_purchase_price" value="" /><td><input type="text" class="product_name form-control" name="product_name[]" id="product_name" onkeypress="getProduct(event)" onkeyup="getProduct(event)" placeholder="Product Name" style="padding: 3px;text-align: center;" required /></td>' + '<td width="9%"><input type="number" class="product_qty form-control" name="product_qty[]" id="product_qty" value="1" placeholder="Quantity" style="padding: 3px;text-align: center;"/></td>' + '<td><input type="text" class="total number form-control" name="total[]" id="total" value="0"   placeholder="Total Amount" style="padding: 3px;text-align: center;" required readonly /></td>' + '<td align="center"><button type="button" class="btn btn-danger remove" style="margin-top: -1px;padding: 9px 12px 8px 12px;"><i class="glyphicon glyphicon-remove-sign"></i></button></td></tr>'
}
</script>
  
<script>

;(function($) {
var bootstrapWizardCreate = function(element, options) {
	var element = $(element);
	var obj = this;

	// selector skips any 'li' elements that do not contain a child with a tab data-toggle
	var baseItemSelector = 'li:has([data-toggle="tab"])';

	// Merge options with defaults
	var $settings = $.extend({}, $.fn.bootstrapWizard.defaults, options);
	var $activeTab = null;
	var $navigation = null;

	this.rebindClick = function(selector, fn)
	{
		selector.unbind('click', fn).bind('click', fn);
	}

	this.fixNavigationButtons = function() {
		// Get the current active tab
		if(!$activeTab.length) {
			// Select first one
			$navigation.find('a:first').tab('show');
			$activeTab = $navigation.find(baseItemSelector + ':first');
		}

		// See if we're currently in the first/last then disable the previous and last buttons
		$($settings.previousSelector, element).toggleClass('disabled', (obj.firstIndex() >= obj.currentIndex()));
		$($settings.nextSelector, element).toggleClass('disabled', (obj.currentIndex() >= obj.navigationLength()));

		// We are unbinding and rebinding to ensure single firing and no double-click errors
		obj.rebindClick($($settings.nextSelector, element), obj.next);
		obj.rebindClick($($settings.previousSelector, element), obj.previous);
		obj.rebindClick($($settings.lastSelector, element), obj.last);
		obj.rebindClick($($settings.firstSelector, element), obj.first);

		if($settings.onTabShow && typeof $settings.onTabShow === 'function' && $settings.onTabShow($activeTab, $navigation, obj.currentIndex())===false){
			return false;
		}
	};

	this.next = function(e) {

		// If we clicked the last then dont activate this
		if(element.hasClass('last')) {
			return false;
		}

		if($settings.onNext && typeof $settings.onNext === 'function' && $settings.onNext($activeTab, $navigation, obj.nextIndex())===false){
			return false;
		}

		// Did we click the last button
		$index = obj.nextIndex();
		if($index > obj.navigationLength()) {
		} else {
			$navigation.find(baseItemSelector + ':eq('+$index+') a').tab('show');
		}
	};

	this.previous = function(e) {

		// If we clicked the first then dont activate this
		if(element.hasClass('first')) {
			return false;
		}

		if($settings.onPrevious && typeof $settings.onPrevious === 'function' && $settings.onPrevious($activeTab, $navigation, obj.previousIndex())===false){
			return false;
		}

		$index = obj.previousIndex();
		if($index < 0) {
		} else {
			$navigation.find(baseItemSelector + ':eq('+$index+') a').tab('show');
		}
	};

	this.first = function(e) {
		if($settings.onFirst && typeof $settings.onFirst === 'function' && $settings.onFirst($activeTab, $navigation, obj.firstIndex())===false){
			return false;
		}

		// If the element is disabled then we won't do anything
		if(element.hasClass('disabled')) {
			return false;
		}
		$navigation.find(baseItemSelector + ':eq(0) a').tab('show');

	};
	this.last = function(e) {
		if($settings.onLast && typeof $settings.onLast === 'function' && $settings.onLast($activeTab, $navigation, obj.lastIndex())===false){
			return false;
		}

		// If the element is disabled then we won't do anything
		if(element.hasClass('disabled')) {
			return false;
		}
		$navigation.find(baseItemSelector + ':eq('+obj.navigationLength()+') a').tab('show');
	};
	this.currentIndex = function() {
		return $navigation.find(baseItemSelector).index($activeTab);
	};
	this.firstIndex = function() {
		return 0;
	};
	this.lastIndex = function() {
		return obj.navigationLength();
	};
	this.getIndex = function(e) {
		return $navigation.find(baseItemSelector).index(e);
	};
	this.nextIndex = function() {
		return $navigation.find(baseItemSelector).index($activeTab) + 1;
	};
	this.previousIndex = function() {
		return $navigation.find(baseItemSelector).index($activeTab) - 1;
	};
	this.navigationLength = function() {
		return $navigation.find(baseItemSelector).length - 1;
	};
	this.activeTab = function() {
		return $activeTab;
	};
	this.nextTab = function() {
		return $navigation.find(baseItemSelector + ':eq('+(obj.currentIndex()+1)+')').length ? $navigation.find(baseItemSelector + ':eq('+(obj.currentIndex()+1)+')') : null;
	};
	this.previousTab = function() {
		if(obj.currentIndex() <= 0) {
			return null;
		}
		return $navigation.find(baseItemSelector + ':eq('+parseFloat(obj.currentIndex()-1)+')');
	};
	this.show = function(index) {
		if (isNaN(index)) {
			return element.find(baseItemSelector + ' a[href=#' + index + ']').tab('show');
		}
		else {
			return element.find(baseItemSelector + ':eq(' + index + ') a').tab('show');
		}
	};
	this.disable = function(index) {
		$navigation.find(baseItemSelector + ':eq('+index+')').addClass('disabled');
	};
	this.enable = function(index) {
		$navigation.find(baseItemSelector + ':eq('+index+')').removeClass('disabled');
	};
	this.hide = function(index) {
		$navigation.find(baseItemSelector + ':eq('+index+')').hide();
	};
	this.display = function(index) {
		$navigation.find(baseItemSelector + ':eq('+index+')').show();
	};
	this.remove = function(args) {
		var $index = args[0];
		var $removeTabPane = typeof args[1] != 'undefined' ? args[1] : false;
		var $item = $navigation.find(baseItemSelector + ':eq('+$index+')');

		// Remove the tab pane first if needed
		if($removeTabPane) {
			var $href = $item.find('a').attr('href');
			$($href).remove();
		}

		// Remove menu item
		$item.remove();
	};

	var innerTabClick = function (e) {
		// Get the index of the clicked tab
		var clickedIndex = $navigation.find(baseItemSelector).index($(e.currentTarget).parent(baseItemSelector));
		if($settings.onTabClick && typeof $settings.onTabClick === 'function' && $settings.onTabClick($activeTab, $navigation, obj.currentIndex(), clickedIndex)===false){
			return false;
		}
	};

	var innerTabShown = function (e) {  // use shown instead of show to help prevent double firing
		$element = $(e.target).parent();
		var nextTab = $navigation.find(baseItemSelector).index($element);

		// If it's disabled then do not change
		if($element.hasClass('disabled')) {
			return false;
		}

		if($settings.onTabChange && typeof $settings.onTabChange === 'function' && $settings.onTabChange($activeTab, $navigation, obj.currentIndex(), nextTab)===false){
				return false;
		}

		$activeTab = $element; // activated tab
		obj.fixNavigationButtons();
	};

	this.resetWizard = function() {

		// remove the existing handlers
		$('a[data-toggle="tab"]', $navigation).off('click', innerTabClick);
		$('a[data-toggle="tab"]', $navigation).off('shown shown.bs.tab', innerTabShown);

		// reset elements based on current state of the DOM
		$navigation = element.find('ul:first', element);
		$activeTab = $navigation.find(baseItemSelector + '.active', element);

		// re-add handlers
		$('a[data-toggle="tab"]', $navigation).on('click', innerTabClick);
		$('a[data-toggle="tab"]', $navigation).on('shown shown.bs.tab', innerTabShown);

		obj.fixNavigationButtons();
	};

	$navigation = element.find('ul:first', element);
	$activeTab = $navigation.find(baseItemSelector + '.active', element);

	if(!$navigation.hasClass($settings.tabClass)) {
		$navigation.addClass($settings.tabClass);
	}

	// Load onInit
	if($settings.onInit && typeof $settings.onInit === 'function'){
		$settings.onInit($activeTab, $navigation, 0);
	}

	// Load onShow
	if($settings.onShow && typeof $settings.onShow === 'function'){
		$settings.onShow($activeTab, $navigation, obj.nextIndex());
	}

	$('a[data-toggle="tab"]', $navigation).on('click', innerTabClick);

	// attach to both shown and shown.bs.tab to support Bootstrap versions 2.3.2 and 3.0.0
	$('a[data-toggle="tab"]', $navigation).on('shown shown.bs.tab', innerTabShown);
};
$.fn.bootstrapWizard = function(options) {
	//expose methods
	if (typeof options == 'string') {
		var args = Array.prototype.slice.call(arguments, 1)
		if(args.length === 1) {
			args.toString();
		}
		return this.data('bootstrapWizard')[options](args);
	}
	return this.each(function(index){
		var element = $(this);
		// Return early if this element already has a plugin instance
		if (element.data('bootstrapWizard')) return;
		// pass options to plugin constructor
		var wizard = new bootstrapWizardCreate(element, options);
		// Store plugin object in this element's data
		element.data('bootstrapWizard', wizard);
		// and then trigger initial change
		wizard.fixNavigationButtons();
	});
};

// expose options
$.fn.bootstrapWizard.defaults = {
	tabClass:         'nav nav-pills',
	nextSelector:     '.wizard li.next',
	previousSelector: '.wizard li.previous',
	firstSelector:    '.wizard li.first',
	lastSelector:     '.wizard li.last',
	onShow:           null,
	onInit:           null,
	onNext:           null,
	onPrevious:       null,
	onLast:           null,
	onFirst:          null,
	onTabChange:      null,
	onTabClick:       null,
	onTabShow:        null
};

})(jQuery);


//  Material Design Core Functions

 !function(t){function o(t){return"undefined"==typeof t.which?!0:"number"==typeof t.which&&t.which>0?!t.ctrlKey&&!t.metaKey&&!t.altKey&&8!=t.which&&9!=t.which&&13!=t.which&&16!=t.which&&17!=t.which&&20!=t.which&&27!=t.which:!1}function i(o){var i=t(o);i.prop("disabled")||i.closest(".form-group").addClass("is-focused")}function n(o){o.closest("label").hover(function(){var o=t(this).find("input");o.prop("disabled")||i(o)},function(){e(t(this).find("input"))})}function e(o){t(o).closest(".form-group").removeClass("is-focused")}t.expr[":"].notmdproc=function(o){return t(o).data("mdproc")?!1:!0},t.material={options:{validate:!0,input:!0,ripples:!0,checkbox:!0,togglebutton:!0,radio:!0,arrive:!0,autofill:!1,withRipples:[".btn:not(.btn-link)",".card-image",".navbar a:not(.withoutripple)",".footer a:not(.withoutripple)",".dropdown-menu a",".nav-tabs a:not(.withoutripple)",".withripple",".pagination li:not(.active):not(.disabled) a:not(.withoutripple)"].join(","),inputElements:"input.form-control, textarea.form-control, select.form-control",checkboxElements:".checkbox > label > input[type=checkbox]",togglebuttonElements:".togglebutton > label > input[type=checkbox]",radioElements:".radio > label > input[type=radio]"},checkbox:function(o){var i=t(o?o:this.options.checkboxElements).filter(":notmdproc").data("mdproc",!0).after("<span class='checkbox-material'><span class='check'></span></span>");n(i)},togglebutton:function(o){var i=t(o?o:this.options.togglebuttonElements).filter(":notmdproc").data("mdproc",!0).after("<span class='toggle'></span>");n(i)},radio:function(o){var i=t(o?o:this.options.radioElements).filter(":notmdproc").data("mdproc",!0).after("<span class='circle'></span><span class='check'></span>");n(i)},input:function(o){t(o?o:this.options.inputElements).filter(":notmdproc").data("mdproc",!0).each(function(){var o=t(this),i=o.closest(".form-group");0===i.length&&(o.wrap("<div class='form-group'></div>"),i=o.closest(".form-group")),o.attr("data-hint")&&(o.after("<p class='help-block'>"+o.attr("data-hint")+"</p>"),o.removeAttr("data-hint"));var n={"input-lg":"form-group-lg","input-sm":"form-group-sm"};if(t.each(n,function(t,n){o.hasClass(t)&&(o.removeClass(t),i.addClass(n))}),o.hasClass("floating-label")){var e=o.attr("placeholder");o.attr("placeholder",null).removeClass("floating-label");var a=o.attr("id"),r="";a&&(r="for='"+a+"'"),i.addClass("label-floating"),o.after("<label "+r+"class='control-label'>"+e+"</label>")}(null===o.val()||"undefined"==o.val()||""===o.val())&&i.addClass("is-empty"),i.append("<span class='material-input'></span>"),i.find("input[type=file]").length>0&&i.addClass("is-fileinput")})},attachInputEventHandlers:function(){var n=this.options.validate;t(document).on("change",".checkbox input[type=checkbox]",function(){t(this).blur()}).on("keydown paste",".form-control",function(i){o(i)&&t(this).closest(".form-group").removeClass("is-empty")}).on("keyup change",".form-control",function(){var o=t(this),i=o.closest(".form-group"),e="undefined"==typeof o[0].checkValidity||o[0].checkValidity();""===o.val()?i.addClass("is-empty"):i.removeClass("is-empty"),n&&(e?i.removeClass("has-error"):i.addClass("has-error"))}).on("focus",".form-control, .form-group.is-fileinput",function(){i(this)}).on("blur",".form-control, .form-group.is-fileinput",function(){e(this)}).on("change",".form-group input",function(){var o=t(this);if("file"!=o.attr("type")){var i=o.closest(".form-group"),n=o.val();n?i.removeClass("is-empty"):i.addClass("is-empty")}}).on("change",".form-group.is-fileinput input[type='file']",function(){var o=t(this),i=o.closest(".form-group"),n="";t.each(this.files,function(t,o){n+=o.name+", "}),n=n.substring(0,n.length-2),n?i.removeClass("is-empty"):i.addClass("is-empty"),i.find("input.form-control[readonly]").val(n)})},ripples:function(o){t(o?o:this.options.withRipples).ripples()},autofill:function(){var o=setInterval(function(){t("input[type!=checkbox]").each(function(){var o=t(this);o.val()&&o.val()!==o.attr("value")&&o.trigger("change")})},100);setTimeout(function(){clearInterval(o)},1e4)},attachAutofillEventHandlers:function(){var o;t(document).on("focus","input",function(){var i=t(this).parents("form").find("input").not("[type=file]");o=setInterval(function(){i.each(function(){var o=t(this);o.val()!==o.attr("value")&&o.trigger("change")})},100)}).on("blur",".form-group input",function(){clearInterval(o)})},init:function(o){this.options=t.extend({},this.options,o);var i=t(document);t.fn.ripples&&this.options.ripples&&this.ripples(),this.options.input&&(this.input(),this.attachInputEventHandlers()),this.options.checkbox&&this.checkbox(),this.options.togglebutton&&this.togglebutton(),this.options.radio&&this.radio(),this.options.autofill&&(this.autofill(),this.attachAutofillEventHandlers()),document.arrive&&this.options.arrive&&(t.fn.ripples&&this.options.ripples&&i.arrive(this.options.withRipples,function(){t.material.ripples(t(this))}),this.options.input&&i.arrive(this.options.inputElements,function(){t.material.input(t(this))}),this.options.checkbox&&i.arrive(this.options.checkboxElements,function(){t.material.checkbox(t(this))}),this.options.radio&&i.arrive(this.options.radioElements,function(){t.material.radio(t(this))}),this.options.togglebutton&&i.arrive(this.options.togglebuttonElements,function(){t.material.togglebutton(t(this))}))}}}(jQuery),function(t,o,i,n){"use strict";function e(o,i){r=this,this.element=t(o),this.options=t.extend({},s,i),this._defaults=s,this._name=a,this.init()}var a="ripples",r=null,s={};e.prototype.init=function(){var i=this.element;i.on("mousedown touchstart",function(n){if(!r.isTouch()||"mousedown"!==n.type){i.find(".ripple-container").length||i.append('<div class="ripple-container"></div>');var e=i.children(".ripple-container"),a=r.getRelY(e,n),s=r.getRelX(e,n);if(a||s){var l=r.getRipplesColor(i),p=t("<div></div>");p.addClass("ripple").css({left:s,top:a,"background-color":l}),e.append(p),function(){return o.getComputedStyle(p[0]).opacity}(),r.rippleOn(i,p),setTimeout(function(){r.rippleEnd(p)},500),i.on("mouseup mouseleave touchend",function(){p.data("mousedown","off"),"off"===p.data("animating")&&r.rippleOut(p)})}}})},e.prototype.getNewSize=function(t,o){return Math.max(t.outerWidth(),t.outerHeight())/o.outerWidth()*2.5},e.prototype.getRelX=function(t,o){var i=t.offset();return r.isTouch()?(o=o.originalEvent,1===o.touches.length?o.touches[0].pageX-i.left:!1):o.pageX-i.left},e.prototype.getRelY=function(t,o){var i=t.offset();return r.isTouch()?(o=o.originalEvent,1===o.touches.length?o.touches[0].pageY-i.top:!1):o.pageY-i.top},e.prototype.getRipplesColor=function(t){var i=t.data("ripple-color")?t.data("ripple-color"):o.getComputedStyle(t[0]).color;return i},e.prototype.hasTransitionSupport=function(){var t=i.body||i.documentElement,o=t.style,e=o.transition!==n||o.WebkitTransition!==n||o.MozTransition!==n||o.MsTransition!==n||o.OTransition!==n;return e},e.prototype.isTouch=function(){return/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)},e.prototype.rippleEnd=function(t){t.data("animating","off"),"off"===t.data("mousedown")&&r.rippleOut(t)},e.prototype.rippleOut=function(t){t.off(),r.hasTransitionSupport()?t.addClass("ripple-out"):t.animate({opacity:0},100,function(){t.trigger("transitionend")}),t.on("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd",function(){t.remove()})},e.prototype.rippleOn=function(t,o){var i=r.getNewSize(t,o);r.hasTransitionSupport()?o.css({"-ms-transform":"scale("+i+")","-moz-transform":"scale("+i+")","-webkit-transform":"scale("+i+")",transform:"scale("+i+")"}).addClass("ripple-on").data("animating","on").data("mousedown","on"):o.animate({width:2*Math.max(t.outerWidth(),t.outerHeight()),height:2*Math.max(t.outerWidth(),t.outerHeight()),"margin-left":-1*Math.max(t.outerWidth(),t.outerHeight()),"margin-top":-1*Math.max(t.outerWidth(),t.outerHeight()),opacity:.2},500,function(){o.trigger("transitionend")})},t.fn.ripples=function(o){return this.each(function(){t.data(this,"plugin_"+a)||t.data(this,"plugin_"+a,new e(this,o))})}}(jQuery,window,document);








searchVisible = 0;
transparent = true;

$(document).ready(function(){

    $.material.init();

    /*  Activate the tooltips      */
    $('[rel="tooltip"]').tooltip();

    // Code for the Validator
    var $validator = $('.wizard-card form').validate({
		  rules: {
		    firstname: {
		      required: true,
		      minlength: 3
		    },
		    lastname: {
		      required: true,
		      minlength: 3
		    },
		    email: {
		      required: true,
		      minlength: 3,
		    }
        },

        errorPlacement: function(error, element) {
            $(element).parent('div').addClass('has-error');
         }
	});

    // Wizard Initialization
  	$('.wizard-card').bootstrapWizard({
        'tabClass': 'nav nav-pills',
        'nextSelector': '.btn-next',
        'previousSelector': '.btn-previous',

        onNext: function(tab, navigation, index) {
        	var $valid = $('.wizard-card form').valid();
        	if(!$valid) {
        		$validator.focusInvalid();
        		return false;
        	}
        },

        onInit : function(tab, navigation, index){

          //check number of tabs and fill the entire row
          var $total = navigation.find('li').length;
          $width = 100/$total;
          var $wizard = navigation.closest('.wizard-card');

          $display_width = $(document).width();

          if($display_width < 600 && $total > 3){
              $width = 50;
          }

           navigation.find('li').css('width',$width + '%');
           $first_li = navigation.find('li:first-child a').html();
           $moving_div = $('<div class="moving-tab">' + $first_li + '</div>');
           $('.wizard-card .wizard-navigation').append($moving_div);
           refreshAnimation($wizard, index);
           $('.moving-tab').css('transition','transform 0s');
       },

        onTabClick : function(tab, navigation, index){
            var $valid = $('.wizard-card form').valid();

            if(!$valid){
                return false;
            } else{
                return true;
            }
        },

        onTabShow: function(tab, navigation, index) {
            var $total = navigation.find('li').length;
            var $current = index+1;

            var $wizard = navigation.closest('.wizard-card');

            // If it's the last tab then hide the last button and show the finish instead
            if($current >= $total) {
                $($wizard).find('.btn-next').hide();
                $($wizard).find('.btn-finish').show();
            } else {
                $($wizard).find('.btn-next').show();
                $($wizard).find('.btn-finish').hide();
            }

            button_text = navigation.find('li:nth-child(' + $current + ') a').html();

            setTimeout(function(){
                $('.moving-tab').text(button_text);
            }, 150);

            var checkbox = $('.footer-checkbox');

            if( !index == 0 ){
                $(checkbox).css({
                    'opacity':'0',
                    'visibility':'hidden',
                    'position':'absolute'
                });
            } else {
                $(checkbox).css({
                    'opacity':'1',
                    'visibility':'visible'
                });
            }

            refreshAnimation($wizard, index);
        }
  	});


    // Prepare the preview for profile picture
    $("#wizard-picture").change(function(){
        readURL(this);
    });

    $('[data-toggle="wizard-radio"]').click(function(){
        wizard = $(this).closest('.wizard-card');
        wizard.find('[data-toggle="wizard-radio"]').removeClass('active');
        $(this).addClass('active');
        $(wizard).find('[type="radio"]').removeAttr('checked');
        $(this).find('[type="radio"]').attr('checked','true');
    });

    $('[data-toggle="wizard-checkbox"]').click(function(){
        if( $(this).hasClass('active')){
            $(this).removeClass('active');
            $(this).find('[type="checkbox"]').removeAttr('checked');
        } else {
            $(this).addClass('active');
            $(this).find('[type="checkbox"]').attr('checked','true');
        }
    });

    $('.set-full-height').css('height', 'auto');

});



 //Function to show image before upload

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
        }
        reader.readAsDataURL(input.files[0]);
    }
}

$(window).resize(function(){
    $('.wizard-card').each(function(){
        $wizard = $(this);
        index = $wizard.bootstrapWizard('currentIndex');
        refreshAnimation($wizard, index);

        $('.moving-tab').css({
            'transition': 'transform 0s'
        });
    });
});

function refreshAnimation($wizard, index){
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;

    $current = index + 1;

    if($current == 1){
        move_distance -= 8;
    } else if($current == total_steps){
        move_distance += 8;
    }

    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform':'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'

    });
}

materialDesign = {

    checkScrollForTransparentNavbar: debounce(function() {
                if($(document).scrollTop() > 260 ) {
                    if(transparent) {
                        transparent = false;
                        $('.navbar-color-on-scroll').removeClass('navbar-transparent');
                    }
                } else {
                    if( !transparent ) {
                        transparent = true;
                        $('.navbar-color-on-scroll').addClass('navbar-transparent');
                    }
                }
        }, 17)

}

function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		clearTimeout(timeout);
		timeout = setTimeout(function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		}, wait);
		if (immediate && !timeout) func.apply(context, args);
	};
};







/*! jQuery Validation Plugin - v1.14.0 - 6/30/2015
 * https://jqueryvalidation.org/
 * Copyright (c) 2015 Jörn Zaefferer; Licensed MIT */
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a(jQuery)}(function(a){a.extend(a.fn,{validate:function(b){if(!this.length)return void(b&&b.debug&&window.console&&console.warn("Nothing selected, can't validate, returning nothing."));var c=a.data(this[0],"validator");return c?c:(this.attr("novalidate","novalidate"),c=new a.validator(b,this[0]),a.data(this[0],"validator",c),c.settings.onsubmit&&(this.on("click.validate",":submit",function(b){c.settings.submitHandler&&(c.submitButton=b.target),a(this).hasClass("cancel")&&(c.cancelSubmit=!0),void 0!==a(this).attr("formnovalidate")&&(c.cancelSubmit=!0)}),this.on("submit.validate",function(b){function d(){var d,e;return c.settings.submitHandler?(c.submitButton&&(d=a("<input type='hidden'/>").attr("name",c.submitButton.name).val(a(c.submitButton).val()).appendTo(c.currentForm)),e=c.settings.submitHandler.call(c,c.currentForm,b),c.submitButton&&d.remove(),void 0!==e?e:!1):!0}return c.settings.debug&&b.preventDefault(),c.cancelSubmit?(c.cancelSubmit=!1,d()):c.form()?c.pendingRequest?(c.formSubmitted=!0,!1):d():(c.focusInvalid(),!1)})),c)},valid:function(){var b,c,d;return a(this[0]).is("form")?b=this.validate().form():(d=[],b=!0,c=a(this[0].form).validate(),this.each(function(){b=c.element(this)&&b,d=d.concat(c.errorList)}),c.errorList=d),b},rules:function(b,c){var d,e,f,g,h,i,j=this[0];if(b)switch(d=a.data(j.form,"validator").settings,e=d.rules,f=a.validator.staticRules(j),b){case"add":a.extend(f,a.validator.normalizeRule(c)),delete f.messages,e[j.name]=f,c.messages&&(d.messages[j.name]=a.extend(d.messages[j.name],c.messages));break;case"remove":return c?(i={},a.each(c.split(/\s/),function(b,c){i[c]=f[c],delete f[c],"required"===c&&a(j).removeAttr("aria-required")}),i):(delete e[j.name],f)}return g=a.validator.normalizeRules(a.extend({},a.validator.classRules(j),a.validator.attributeRules(j),a.validator.dataRules(j),a.validator.staticRules(j)),j),g.required&&(h=g.required,delete g.required,g=a.extend({required:h},g),a(j).attr("aria-required","true")),g.remote&&(h=g.remote,delete g.remote,g=a.extend(g,{remote:h})),g}}),a.extend(a.expr[":"],{blank:function(b){return!a.trim(""+a(b).val())},filled:function(b){return!!a.trim(""+a(b).val())},unchecked:function(b){return!a(b).prop("checked")}}),a.validator=function(b,c){this.settings=a.extend(!0,{},a.validator.defaults,b),this.currentForm=c,this.init()},a.validator.format=function(b,c){return 1===arguments.length?function(){var c=a.makeArray(arguments);return c.unshift(b),a.validator.format.apply(this,c)}:(arguments.length>2&&c.constructor!==Array&&(c=a.makeArray(arguments).slice(1)),c.constructor!==Array&&(c=[c]),a.each(c,function(a,c){b=b.replace(new RegExp("\\{"+a+"\\}","g"),function(){return c})}),b)},a.extend(a.validator,{defaults:{messages:{},groups:{},rules:{},errorClass:"error",validClass:"valid",errorElement:"label",focusCleanup:!1,focusInvalid:!0,errorContainer:a([]),errorLabelContainer:a([]),onsubmit:!0,ignore:":hidden",ignoreTitle:!1,onfocusin:function(a){this.lastActive=a,this.settings.focusCleanup&&(this.settings.unhighlight&&this.settings.unhighlight.call(this,a,this.settings.errorClass,this.settings.validClass),this.hideThese(this.errorsFor(a)))},onfocusout:function(a){this.checkable(a)||!(a.name in this.submitted)&&this.optional(a)||this.element(a)},onkeyup:function(b,c){var d=[16,17,18,20,35,36,37,38,39,40,45,144,225];9===c.which&&""===this.elementValue(b)||-1!==a.inArray(c.keyCode,d)||(b.name in this.submitted||b===this.lastElement)&&this.element(b)},onclick:function(a){a.name in this.submitted?this.element(a):a.parentNode.name in this.submitted&&this.element(a.parentNode)},highlight:function(b,c,d){"radio"===b.type?this.findByName(b.name).addClass(c).removeClass(d):a(b).addClass(c).removeClass(d)},unhighlight:function(b,c,d){"radio"===b.type?this.findByName(b.name).removeClass(c).addClass(d):a(b).removeClass(c).addClass(d)}},setDefaults:function(b){a.extend(a.validator.defaults,b)},messages:{required:"This field is required.",remote:"Please fix this field.",email:"Please enter a valid email address.",url:"Please enter a valid URL.",date:"Please enter a valid date.",dateISO:"Please enter a valid date ( ISO ).",number:"Please enter a valid number.",digits:"Please enter only digits.",creditcard:"Please enter a valid credit card number.",equalTo:"Please enter the same value again.",maxlength:a.validator.format("Please enter no more than {0} characters."),minlength:a.validator.format("Please enter at least {0} characters."),rangelength:a.validator.format("Please enter a value between {0} and {1} characters long."),range:a.validator.format("Please enter a value between {0} and {1}."),max:a.validator.format("Please enter a value less than or equal to {0}."),min:a.validator.format("Please enter a value greater than or equal to {0}.")},autoCreateRanges:!1,prototype:{init:function(){function b(b){var c=a.data(this.form,"validator"),d="on"+b.type.replace(/^validate/,""),e=c.settings;e[d]&&!a(this).is(e.ignore)&&e[d].call(c,this,b)}this.labelContainer=a(this.settings.errorLabelContainer),this.errorContext=this.labelContainer.length&&this.labelContainer||a(this.currentForm),this.containers=a(this.settings.errorContainer).add(this.settings.errorLabelContainer),this.submitted={},this.valueCache={},this.pendingRequest=0,this.pending={},this.invalid={},this.reset();var c,d=this.groups={};a.each(this.settings.groups,function(b,c){"string"==typeof c&&(c=c.split(/\s/)),a.each(c,function(a,c){d[c]=b})}),c=this.settings.rules,a.each(c,function(b,d){c[b]=a.validator.normalizeRule(d)}),a(this.currentForm).on("focusin.validate focusout.validate keyup.validate",":text, [type='password'], [type='file'], select, textarea, [type='number'], [type='search'], [type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'], [type='radio'], [type='checkbox']",b).on("click.validate","select, option, [type='radio'], [type='checkbox']",b),this.settings.invalidHandler&&a(this.currentForm).on("invalid-form.validate",this.settings.invalidHandler),a(this.currentForm).find("[required], [data-rule-required], .required").attr("aria-required","true")},form:function(){return this.checkForm(),a.extend(this.submitted,this.errorMap),this.invalid=a.extend({},this.errorMap),this.valid()||a(this.currentForm).triggerHandler("invalid-form",[this]),this.showErrors(),this.valid()},checkForm:function(){this.prepareForm();for(var a=0,b=this.currentElements=this.elements();b[a];a++)this.check(b[a]);return this.valid()},element:function(b){var c=this.clean(b),d=this.validationTargetFor(c),e=!0;return this.lastElement=d,void 0===d?delete this.invalid[c.name]:(this.prepareElement(d),this.currentElements=a(d),e=this.check(d)!==!1,e?delete this.invalid[d.name]:this.invalid[d.name]=!0),a(b).attr("aria-invalid",!e),this.numberOfInvalids()||(this.toHide=this.toHide.add(this.containers)),this.showErrors(),e},showErrors:function(b){if(b){a.extend(this.errorMap,b),this.errorList=[];for(var c in b)this.errorList.push({message:b[c],element:this.findByName(c)[0]});this.successList=a.grep(this.successList,function(a){return!(a.name in b)})}this.settings.showErrors?this.settings.showErrors.call(this,this.errorMap,this.errorList):this.defaultShowErrors()},resetForm:function(){a.fn.resetForm&&a(this.currentForm).resetForm(),this.submitted={},this.lastElement=null,this.prepareForm(),this.hideErrors();var b,c=this.elements().removeData("previousValue").removeAttr("aria-invalid");if(this.settings.unhighlight)for(b=0;c[b];b++)this.settings.unhighlight.call(this,c[b],this.settings.errorClass,"");else c.removeClass(this.settings.errorClass)},numberOfInvalids:function(){return this.objectLength(this.invalid)},objectLength:function(a){var b,c=0;for(b in a)c++;return c},hideErrors:function(){this.hideThese(this.toHide)},hideThese:function(a){a.not(this.containers).text(""),this.addWrapper(a).hide()},valid:function(){return 0===this.size()},size:function(){return this.errorList.length},focusInvalid:function(){if(this.settings.focusInvalid)try{a(this.findLastActive()||this.errorList.length&&this.errorList[0].element||[]).filter(":visible").focus().trigger("focusin")}catch(b){}},findLastActive:function(){var b=this.lastActive;return b&&1===a.grep(this.errorList,function(a){return a.element.name===b.name}).length&&b},elements:function(){var b=this,c={};return a(this.currentForm).find("input, select, textarea").not(":submit, :reset, :image, :disabled").not(this.settings.ignore).filter(function(){return!this.name&&b.settings.debug&&window.console&&console.error("%o has no name assigned",this),this.name in c||!b.objectLength(a(this).rules())?!1:(c[this.name]=!0,!0)})},clean:function(b){return a(b)[0]},errors:function(){var b=this.settings.errorClass.split(" ").join(".");return a(this.settings.errorElement+"."+b,this.errorContext)},reset:function(){this.successList=[],this.errorList=[],this.errorMap={},this.toShow=a([]),this.toHide=a([]),this.currentElements=a([])},prepareForm:function(){this.reset(),this.toHide=this.errors().add(this.containers)},prepareElement:function(a){this.reset(),this.toHide=this.errorsFor(a)},elementValue:function(b){var c,d=a(b),e=b.type;return"radio"===e||"checkbox"===e?this.findByName(b.name).filter(":checked").val():"number"===e&&"undefined"!=typeof b.validity?b.validity.badInput?!1:d.val():(c=d.val(),"string"==typeof c?c.replace(/\r/g,""):c)},check:function(b){b=this.validationTargetFor(this.clean(b));var c,d,e,f=a(b).rules(),g=a.map(f,function(a,b){return b}).length,h=!1,i=this.elementValue(b);for(d in f){e={method:d,parameters:f[d]};try{if(c=a.validator.methods[d].call(this,i,b,e.parameters),"dependency-mismatch"===c&&1===g){h=!0;continue}if(h=!1,"pending"===c)return void(this.toHide=this.toHide.not(this.errorsFor(b)));if(!c)return this.formatAndAdd(b,e),!1}catch(j){throw this.settings.debug&&window.console&&console.log("Exception occurred when checking element "+b.id+", check the '"+e.method+"' method.",j),j instanceof TypeError&&(j.message+=".  Exception occurred when checking element "+b.id+", check the '"+e.method+"' method."),j}}if(!h)return this.objectLength(f)&&this.successList.push(b),!0},customDataMessage:function(b,c){return a(b).data("msg"+c.charAt(0).toUpperCase()+c.substring(1).toLowerCase())||a(b).data("msg")},customMessage:function(a,b){var c=this.settings.messages[a];return c&&(c.constructor===String?c:c[b])},findDefined:function(){for(var a=0;a<arguments.length;a++)if(void 0!==arguments[a])return arguments[a];return void 0},defaultMessage:function(b,c){return this.findDefined(this.customMessage(b.name,c),this.customDataMessage(b,c),!this.settings.ignoreTitle&&b.title||void 0,a.validator.messages[c],"<strong>Warning: No message defined for "+b.name+"</strong>")},formatAndAdd:function(b,c){var d=this.defaultMessage(b,c.method),e=/\$?\{(\d+)\}/g;"function"==typeof d?d=d.call(this,c.parameters,b):e.test(d)&&(d=a.validator.format(d.replace(e,"{$1}"),c.parameters)),this.errorList.push({message:d,element:b,method:c.method}),this.errorMap[b.name]=d,this.submitted[b.name]=d},addWrapper:function(a){return this.settings.wrapper&&(a=a.add(a.parent(this.settings.wrapper))),a},defaultShowErrors:function(){var a,b,c;for(a=0;this.errorList[a];a++)c=this.errorList[a],this.settings.highlight&&this.settings.highlight.call(this,c.element,this.settings.errorClass,this.settings.validClass),this.showLabel(c.element,c.message);if(this.errorList.length&&(this.toShow=this.toShow.add(this.containers)),this.settings.success)for(a=0;this.successList[a];a++)this.showLabel(this.successList[a]);if(this.settings.unhighlight)for(a=0,b=this.validElements();b[a];a++)this.settings.unhighlight.call(this,b[a],this.settings.errorClass,this.settings.validClass);this.toHide=this.toHide.not(this.toShow),this.hideErrors(),this.addWrapper(this.toShow).show()},validElements:function(){return this.currentElements.not(this.invalidElements())},invalidElements:function(){return a(this.errorList).map(function(){return this.element})},showLabel:function(b,c){var d,e,f,g=this.errorsFor(b),h=this.idOrName(b),i=a(b).attr("aria-describedby");g.length?(g.removeClass(this.settings.validClass).addClass(this.settings.errorClass),g.html(c)):(g=a("<"+this.settings.errorElement+">").attr("id",h+"-error").addClass(this.settings.errorClass).html(c||""),d=g,this.settings.wrapper&&(d=g.hide().show().wrap("<"+this.settings.wrapper+"/>").parent()),this.labelContainer.length?this.labelContainer.append(d):this.settings.errorPlacement?this.settings.errorPlacement(d,a(b)):d.insertAfter(b),g.is("label")?g.attr("for",h):0===g.parents("label[for='"+h+"']").length&&(f=g.attr("id").replace(/(:|\.|\[|\]|\$)/g,"\\$1"),i?i.match(new RegExp("\\b"+f+"\\b"))||(i+=" "+f):i=f,a(b).attr("aria-describedby",i),e=this.groups[b.name],e&&a.each(this.groups,function(b,c){c===e&&a("[name='"+b+"']",this.currentForm).attr("aria-describedby",g.attr("id"))}))),!c&&this.settings.success&&(g.text(""),"string"==typeof this.settings.success?g.addClass(this.settings.success):this.settings.success(g,b)),this.toShow=this.toShow.add(g)},errorsFor:function(b){var c=this.idOrName(b),d=a(b).attr("aria-describedby"),e="label[for='"+c+"'], label[for='"+c+"'] *";return d&&(e=e+", #"+d.replace(/\s+/g,", #")),this.errors().filter(e)},idOrName:function(a){return this.groups[a.name]||(this.checkable(a)?a.name:a.id||a.name)},validationTargetFor:function(b){return this.checkable(b)&&(b=this.findByName(b.name)),a(b).not(this.settings.ignore)[0]},checkable:function(a){return/radio|checkbox/i.test(a.type)},findByName:function(b){return a(this.currentForm).find("[name='"+b+"']")},getLength:function(b,c){switch(c.nodeName.toLowerCase()){case"select":return a("option:selected",c).length;case"input":if(this.checkable(c))return this.findByName(c.name).filter(":checked").length}return b.length},depend:function(a,b){return this.dependTypes[typeof a]?this.dependTypes[typeof a](a,b):!0},dependTypes:{"boolean":function(a){return a},string:function(b,c){return!!a(b,c.form).length},"function":function(a,b){return a(b)}},optional:function(b){var c=this.elementValue(b);return!a.validator.methods.required.call(this,c,b)&&"dependency-mismatch"},startRequest:function(a){this.pending[a.name]||(this.pendingRequest++,this.pending[a.name]=!0)},stopRequest:function(b,c){this.pendingRequest--,this.pendingRequest<0&&(this.pendingRequest=0),delete this.pending[b.name],c&&0===this.pendingRequest&&this.formSubmitted&&this.form()?(a(this.currentForm).submit(),this.formSubmitted=!1):!c&&0===this.pendingRequest&&this.formSubmitted&&(a(this.currentForm).triggerHandler("invalid-form",[this]),this.formSubmitted=!1)},previousValue:function(b){return a.data(b,"previousValue")||a.data(b,"previousValue",{old:null,valid:!0,message:this.defaultMessage(b,"remote")})},destroy:function(){this.resetForm(),a(this.currentForm).off(".validate").removeData("validator")}},classRuleSettings:{required:{required:!0},email:{email:!0},url:{url:!0},date:{date:!0},dateISO:{dateISO:!0},number:{number:!0},digits:{digits:!0},creditcard:{creditcard:!0}},addClassRules:function(b,c){b.constructor===String?this.classRuleSettings[b]=c:a.extend(this.classRuleSettings,b)},classRules:function(b){var c={},d=a(b).attr("class");return d&&a.each(d.split(" "),function(){this in a.validator.classRuleSettings&&a.extend(c,a.validator.classRuleSettings[this])}),c},normalizeAttributeRule:function(a,b,c,d){/min|max/.test(c)&&(null===b||/number|range|text/.test(b))&&(d=Number(d),isNaN(d)&&(d=void 0)),d||0===d?a[c]=d:b===c&&"range"!==b&&(a[c]=!0)},attributeRules:function(b){var c,d,e={},f=a(b),g=b.getAttribute("type");for(c in a.validator.methods)"required"===c?(d=b.getAttribute(c),""===d&&(d=!0),d=!!d):d=f.attr(c),this.normalizeAttributeRule(e,g,c,d);return e.maxlength&&/-1|2147483647|524288/.test(e.maxlength)&&delete e.maxlength,e},dataRules:function(b){var c,d,e={},f=a(b),g=b.getAttribute("type");for(c in a.validator.methods)d=f.data("rule"+c.charAt(0).toUpperCase()+c.substring(1).toLowerCase()),this.normalizeAttributeRule(e,g,c,d);return e},staticRules:function(b){var c={},d=a.data(b.form,"validator");return d.settings.rules&&(c=a.validator.normalizeRule(d.settings.rules[b.name])||{}),c},normalizeRules:function(b,c){return a.each(b,function(d,e){if(e===!1)return void delete b[d];if(e.param||e.depends){var f=!0;switch(typeof e.depends){case"string":f=!!a(e.depends,c.form).length;break;case"function":f=e.depends.call(c,c)}f?b[d]=void 0!==e.param?e.param:!0:delete b[d]}}),a.each(b,function(d,e){b[d]=a.isFunction(e)?e(c):e}),a.each(["minlength","maxlength"],function(){b[this]&&(b[this]=Number(b[this]))}),a.each(["rangelength","range"],function(){var c;b[this]&&(a.isArray(b[this])?b[this]=[Number(b[this][0]),Number(b[this][1])]:"string"==typeof b[this]&&(c=b[this].replace(/[\[\]]/g,"").split(/[\s,]+/),b[this]=[Number(c[0]),Number(c[1])]))}),a.validator.autoCreateRanges&&(null!=b.min&&null!=b.max&&(b.range=[b.min,b.max],delete b.min,delete b.max),null!=b.minlength&&null!=b.maxlength&&(b.rangelength=[b.minlength,b.maxlength],delete b.minlength,delete b.maxlength)),b},normalizeRule:function(b){if("string"==typeof b){var c={};a.each(b.split(/\s/),function(){c[this]=!0}),b=c}return b},addMethod:function(b,c,d){a.validator.methods[b]=c,a.validator.messages[b]=void 0!==d?d:a.validator.messages[b],c.length<3&&a.validator.addClassRules(b,a.validator.normalizeRule(b))},methods:{required:function(b,c,d){if(!this.depend(d,c))return"dependency-mismatch";if("select"===c.nodeName.toLowerCase()){var e=a(c).val();return e&&e.length>0}return this.checkable(c)?this.getLength(b,c)>0:b.length>0},email:function(a,b){return this.optional(b)||/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test(a)},url:function(a,b){return this.optional(b)||/^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})).?)(?::\d{2,5})?(?:[/?#]\S*)?$/i.test(a)},date:function(a,b){return this.optional(b)||!/Invalid|NaN/.test(new Date(a).toString())},dateISO:function(a,b){return this.optional(b)||/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test(a)},number:function(a,b){return this.optional(b)||/^(?:-?\d+|-?\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(a)},digits:function(a,b){return this.optional(b)||/^\d+$/.test(a)},creditcard:function(a,b){if(this.optional(b))return"dependency-mismatch";if(/[^0-9 \-]+/.test(a))return!1;var c,d,e=0,f=0,g=!1;if(a=a.replace(/\D/g,""),a.length<13||a.length>19)return!1;for(c=a.length-1;c>=0;c--)d=a.charAt(c),f=parseFloat(d,10),g&&(f*=2)>9&&(f-=9),e+=f,g=!g;return e%10===0},minlength:function(b,c,d){var e=a.isArray(b)?b.length:this.getLength(b,c);return this.optional(c)||e>=d},maxlength:function(b,c,d){var e=a.isArray(b)?b.length:this.getLength(b,c);return this.optional(c)||d>=e},rangelength:function(b,c,d){var e=a.isArray(b)?b.length:this.getLength(b,c);return this.optional(c)||e>=d[0]&&e<=d[1]},min:function(a,b,c){return this.optional(b)||a>=c},max:function(a,b,c){return this.optional(b)||c>=a},range:function(a,b,c){return this.optional(b)||a>=c[0]&&a<=c[1]},equalTo:function(b,c,d){var e=a(d);return this.settings.onfocusout&&e.off(".validate-equalTo").on("blur.validate-equalTo",function(){a(c).valid()}),b===e.val()},remote:function(b,c,d){if(this.optional(c))return"dependency-mismatch";var e,f,g=this.previousValue(c);return this.settings.messages[c.name]||(this.settings.messages[c.name]={}),g.originalMessage=this.settings.messages[c.name].remote,this.settings.messages[c.name].remote=g.message,d="string"==typeof d&&{url:d}||d,g.old===b?g.valid:(g.old=b,e=this,this.startRequest(c),f={},f[c.name]=b,a.ajax(a.extend(!0,{mode:"abort",port:"validate"+c.name,dataType:"json",data:f,context:e.currentForm,success:function(d){var f,h,i,j=d===!0||"true"===d;e.settings.messages[c.name].remote=g.originalMessage,j?(i=e.formSubmitted,e.prepareElement(c),e.formSubmitted=i,e.successList.push(c),delete e.invalid[c.name],e.showErrors()):(f={},h=d||e.defaultMessage(c,"remote"),f[c.name]=g.message=a.isFunction(h)?h(b):h,e.invalid[c.name]=!0,e.showErrors(f)),g.valid=j,e.stopRequest(c,j)}},d)),"pending")}}});var b,c={};a.ajaxPrefilter?a.ajaxPrefilter(function(a,b,d){var e=a.port;"abort"===a.mode&&(c[e]&&c[e].abort(),c[e]=d)}):(b=a.ajax,a.ajax=function(d){var e=("mode"in d?d:a.ajaxSettings).mode,f=("port"in d?d:a.ajaxSettings).port;return"abort"===e?(c[f]&&c[f].abort(),c[f]=b.apply(this,arguments),c[f]):b.apply(this,arguments)})});

</script>

<script type="text/javascript">
$(function () {
	$('#datetimepicker1').datepicker({
		  format: 'yyyy-mm-dd'
		});		
		$("#datetimepicker1").datepicker().datepicker("setDate", new Date());
	
	$('#datetimepicker2').datepicker({
		  format: 'yyyy-mm-dd'
		});
		
	$('#due_date_picker').datepicker({
		  format: 'yyyy-mm-dd',
		  startDate: new Date()
		});
		var tdate = new Date();
		var ddate = new Date(tdate.setDate(tdate.getDate() + 10));	
		$("#due_date_picker").datepicker().datepicker("setDate", ddate);	
		
	$(document).on("focus", "[class*='imei_no']", function() {	
		$('.imei_no').on("focus", function(){
			var customer_id=$('#customer_id').val();
			$(this).autocomplete({
				source:"excess/return_product_name_cust.php?customer_id="+customer_id,
				select:function(event,ui){
					//alert(ui.item.dob);
					var price=parseFloat(ui.item.purchase_price);
					var gst=ui.item.product_gst;
					var row = $(this).parents('.item-row');
					var gstm=parseFloat(gst)+100;
					var gstamtm=(price*100)/gstm;
					var gstamtm1=price-gstamtm;
					var sale_price=price-gstamtm1;
					row.find('.hid_product_id').val(ui.item.product_id);
					//row.find('.hid_supplier_number').val(ui.item.supplier_number);
					//row.find('.hid_sale_price').val(ui.item.sale_price);
					 
					row.find('.product_price').val(roundNumber(sale_price,2));
					row.find('.product_gst').val(ui.item.product_gst);
					row.find('.product_name').val(ui.item.product_name);
					var gstamt=(sale_price/100)*gst;
					var total=parseFloat(sale_price)+parseFloat(gstamt);
					//var total=Math.round(price+gstamt);
					var total=roundNumber(total,2);
					row.find('.total').val(total);
					row.find('.hid_sale_price').val(total);
				}
			});	 
		});	
	});
	
	// for product name in Accessories
	$(document).on("focus", "[class*='product_name']", function() {	
		var cat=2;
		$('.product_name').on("focus", function(){
			var customer_id=$('#customer_id').val();
			$(this).autocomplete({
				source:"excess/return_product_name_cust.php?customer_id="+customer_id,
				select:function(event,ui){
					//alert(ui.item.dob);
					var price=parseFloat(ui.item.purchase_price);
					var gst=ui.item.product_gst;
					var row = $(this).parents('.item-row');
					//$("#hid_product_id").val(ui.item.product_id);
					var gstm=parseFloat(gst)+100;
					var gstamtm=(price*100)/gstm;
					var gstamtm1=price-gstamtm;
					var sale_price=price-gstamtm1;
					row.find('.hid_product_id').val(ui.item.product_id);
					row.find('.imei_no').val(ui.item.imei_no);
					//row.find('.hid_supplier_number').val(ui.item.supplier_number);
					 
					// row.find('.hid_sale_price').val(ui.item.sale_price);
					row.find('.product_price').val(roundNumber(sale_price,2));
					row.find('.product_gst').val(ui.item.product_gst);
					row.find('.product_qty').val(ui.item.product_qty);
					var gstamt=(sale_price/100)*gst;
					var total1=parseFloat(sale_price)+parseFloat(gstamt);
					var total=total1*ui.item.product_qty;
					//var total=Math.round(price+gstamt);
					var total=roundNumber(total,2);
					row.find('.total').val(total);
					row.find('.hid_sale_price').val(total);
				}
			});	 
		});	
	});
	
// For total calculation
	$(document).on("focus", "[class*='item-row']", function() {	
	
	$('.product_qty').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
			$.ajax({
			 url:'excess/check_product_qty_exce.php',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			 success: function(data)
			 {
				 var pqty=parseFloat(data);
				 if(pqty!=0)
				 {
					 alert('Quantity not available!');
					 row.find('.product_qty').val(pqty);
				 }
			 }
			}); 
		var price = row.find('.hid_sale_price').val() * row.find('.product_qty').val();
		 
		var total=roundNumber(price,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		
		});
	$('.product_qty').on("blur", function(){
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
			$.ajax({
			 url:'excess/check_product_qty_exce.php',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			 success: function(data)
			 {
				 var pqty=parseFloat(data);
				 if(pqty!=0)
				 {
					 alert('Quantity not available!');
					 row.find('.product_qty').val(pqty);
				 }
			 }
			}); 
		var price = row.find('.hid_sale_price').val() * row.find('.product_qty').val();
	 
		var total=roundNumber(price,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
	});
	
	/* $('.product_price').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		
			//alert("asd");
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total1=price+gstamt;
		var total=roundNumber(total1,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		 
	});
	$('.product_price').on("click", function(){
		var row = $(this).parents('.item-row');
		var minprice = row.find('.min_sale_cost').val() * row.find('.product_qty').val();
		
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		 
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total1=price+gstamt;
		var total=roundNumber(total1,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		 
	});
	
	$('.product_gst').on("change", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total1=price+gstamt;
		var total=roundNumber(total1,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
	});
	 */
	$('.total').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var total = row.find('.total').val();
		var qty = row.find('.product_qty').val();
		//var qty = 1;
		var gst = row.find('.product_gst').val();
		var gstext =parseFloat(100)+parseFloat(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		isNaN(net_price) ? row.find('.product_price').val("N/A") : row.find('.product_price').val(net_price);
	});
	
	$('.total').on("click", function(){
		var row = $(this).parents('.item-row');
		var total = row.find('.total').val();
		var qty = row.find('.product_qty').val();
		//var qty = 1;
		var gst = row.find('.product_gst').val();
		var gstext =parseFloat(100)+parseFloat(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		isNaN(net_price) ? row.find('.product_price').val("N/A") : row.find('.product_price').val(net_price);
	});
	
		$('.number').keypress(function(event) {
  if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
    event.preventDefault();
  }
});
	$('.number1').keypress(function(event) {
  if (event.which > 31 && (event.which < 48 || event.which > 57)) {
    event.preventDefault();
  }
});
	
	
	
	});
// End total calculation

//for next button calculations
$(document).on("click", "[class*='btn-next']", function(){	
	$('.btn-next').on("click", function(){
		var sum = 0;
		$('input[class*="total"]').each(function() {
		  sum += Number($(this).val()) || 0;
		});
	
		var sale_p = 0;
		$('input[class*="hid_sale_price"]').each(function() {
		  sale_p += Number($(this).val()) || 0;
		});
		
		var sale_qty = 0;
		$('input[class*="product_qty"]').each(function() {
		  sale_qty += Number($(this).val()) || 0;
		});
		
		sale_qty=sale_qty-1;
		var sales_pr=sale_p;
		 //alert(sales_pr);
		var sub_total=roundNumber(sum,2);
		$('#sub_total').val(sub_total);	
		
		var disc_amt=sales_pr - sum;
		//$('#disc_amt').val(roundNumber(disc_amt,2));		
		$('#paid_amt').val(roundNumber(0,2));		
		$('#payable_amt').val(roundNumber(sum,2));		
		$('#balance_amt').val(roundNumber(sum,2));
		
		var sub_t = 0;
		$('input[class*="product_price"]').each(function() {
		  sub_t += Number($(this).val()) || 0;
		});
		var total_gst = 0;
		var total_gst = sub_total-sub_t;
		$('#sub_tamt').val(roundNumber(sub_t,2));
		$('#gst_amt').val(roundNumber(total_gst,2));
		
		});
	});
	//End next button calculations
	
	//for payable amount calculation
	$('#disc_amt').on("keyup", function(){
		//var disc_amt = $('#disc_amt').val();
		var sub_total = $('#sub_total').val();
		
		//var payable_amt = roundNumber(sub_total-disc_amt,2);
		$('#payable_amt').val(sub_total);
	
		var payable_amt = $('#payable_amt').val();
		var paid_amt = $('#paid_amt').val();
		
		var balance_amt = roundNumber(payable_amt-paid_amt,2);
		$('#balance_amt').val(balance_amt);
	});
	$('#disc_amt').on("click", function(){
		var disc_amt = $('#disc_amt').val();
		var sub_total = $('#sub_total').val();
		
		//var payable_amt = roundNumber(sub_total-disc_amt,2);
		$('#payable_amt').val(sub_total);
	
		var payable_amt = $('#payable_amt').val();
		var paid_amt = $('#paid_amt').val();
		
		var balance_amt = roundNumber(payable_amt-paid_amt,2);
		$('#balance_amt').val(balance_amt);
	});
	$('#disc_amt').on("blur", function(){
		var disc_amt = $('#disc_amt').val();
		$('#disc_amt').val(roundNumber(disc_amt,2));
	});	
	//End payable amount calculation
	
	//for balance amount calculation
	$('#paid_amt').on("keyup", function(){
		var payable_amt = $('#payable_amt').val();
		var paid_amt = $('#paid_amt').val();
		if(parseFloat(paid_amt)>parseFloat(payable_amt)){
			paid_amt = payable_amt;
			$('#paid_amt').val(payable_amt);
		}
		var balance_amt = roundNumber(payable_amt-paid_amt,2);
		$('#balance_amt').val(balance_amt);
		if(balance_amt!=0){
			   $("#due_date_box").show();
				}
			else{
			  $("#due_date_box").hide(); 
				}
	});
	$('#paid_amt').on("click", function(){
		var payable_amt = $('#payable_amt').val();
		var paid_amt = $('#paid_amt').val();
		if(parseFloat(paid_amt)>parseFloat(payable_amt)){
			paid_amt = payable_amt;
			$('#paid_amt').val(payable_amt);
		}
		var balance_amt = roundNumber(payable_amt-paid_amt,2);
		$('#balance_amt').val(balance_amt);
			if(balance_amt!=0){
			   $("#due_date_box").show();
				}
			else{
			  $("#due_date_box").hide(); 
				}
	});
	$('#paid_amt').on("blur", function(){
		var paid_amt = $('#paid_amt').val();
		$('#paid_amt').val(roundNumber(paid_amt,2));
	});
	//End balance amount calculation
	
});

function roundNumber(number,decimals) {
  var newString;// The new rounded number
  decimals = Number(decimals);
  if (decimals < 1) {
    newString = (Math.round(number)).toString();
  } else {
    var numString = number.toString();
    if (numString.lastIndexOf(".") == -1) {// If there is no decimal point
      numString += ".";// give it one at the end
    }
    var cutoff = numString.lastIndexOf(".") + decimals;// The point at which to truncate the number
    var d1 = Number(numString.substring(cutoff,cutoff+1));// The value of the last decimal place that we'll end up with
    var d2 = Number(numString.substring(cutoff+1,cutoff+2));// The next decimal, after the last one we want
    if (d2 >= 5) {// Do we need to round up at all? If not, the string will just be truncated
      if (d1 == 9 && cutoff > 0) {// If the last digit is 9, find a new cutoff point
        while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
          if (d1 != ".") {
            cutoff -= 1;
            d1 = Number(numString.substring(cutoff,cutoff+1));
          } else {
            cutoff -= 1;
          }
        }
      }
      d1 += 1;
    } 
    if (d1 == 10) {
      numString = numString.substring(0, numString.lastIndexOf("."));
      var roundedNum = Number(numString) + 1;
      newString = roundedNum.toString() + '.';
    } else {
      newString = numString.substring(0,cutoff) + d1.toString();
    }
  }
  if (newString.lastIndexOf(".") == -1) {// Do this again, to the new string
    newString += ".";
  }
  var decs = (newString.substring(newString.lastIndexOf(".")+1)).length;
  for(var i=0;i<decimals-decs;i++) newString += "0";
  //var newNumber = Number(newString);// make it a number if you like
  return newString; // Output the result to the form field (change for your purposes)
}

</script>

<script>

function getCustomer(e){	
	$("#cust_name").autocomplete({
		source:"excess/customer_name.php",
		select:function(event,ui){
			//alert(ui.item.dob); 
			$("#cust_contact").val(ui.item.mobile);
			//$("#cust_dob").val(ui.item.dob);
			$("#cust_address").val(ui.item.address);
			$("#customer_id").val(ui.item.id);
			//$("#datetimepicker2").datepicker().datepicker("setDate", ui.item.dob);
		}
	});	 
}

function getProduct(e){	
 
}

/* function total_amount(){	
		var price=$('#product_price').val();
		var qty=$('#product_qty').val();
		var gst=$('#product_gst').val();
		 
		var tprice=price*qty;
		var gstamt=(tprice/100)*gst;
		var total=parseFloat(tprice)+parseFloat(gstamt);
		$("#total").val(total); 
} */


</script>

<script>
$(function (){
    $("#example1").DataTable();
	$("#example2").DataTable();
	$("#example3").DataTable();
    $('#example4').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true
    });
	
	$('select[name="payment_type"]').change(
    function(){
        if ($(this).val() == 'Cheque'){
            $('#finance1').hide();
            $('#cheque1').show();
        }else if ($(this).val() == 'Finance'){
			$('#cheque1').hide();
            $('#finance1').show();
		}else{
			$('#cheque1').hide();
            $('#finance1').hide();
		}
    });
	
});

// for Number only
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		//document.getElementById("error").style.display = ret ? "none" : "inline";
		return ret;
	}
</script> 

</head>  

<body class="hold-transition skin-blue sidebar-mini">
 

   
  <!-- Left side column. contains the logo and sidebar -->
  < 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Product Return
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active"> Product Return</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	

	    <!--   Big container   -->
	   
	<div style="margin-top:30px;margin-bottom:30px;" class="row">
		<div class="col-sm-12 ">
		            <!-- Wizard container -->
		 <div class="wizard-container">
		  <div class="card wizard-card" data-color="red" id="wizard">
			<form id="product_return_form" onsubmit="return sale_product()"  autocomplete="off" method="POST" action="javascript:void(0);">		
			<div class="wizard-header">
			<h3 class="wizard-title">
			Product Return
			</h3>
			</div>
			
			<div class="wizard-navigation">
			<ul>
			<li><a href="#details" data-toggle="tab">Customer</a></li>
			<li><a href="#captain" data-toggle="tab">Product Return</a></li>
			<li><a href="#description" data-toggle="tab">Payment Method</a></li>
			</ul>
			</div>

			<div class="tab-content">
				<div class="tab-pane" id="details">
				<div class="col-md-10 col-sm-offset-1">
					<div class="row">
						<div class="col-sm-12">
						<h4 class="info-text"> Customer Details</h4>
						</div>

						<div class="col-sm-4">
							<div class="form-group">
								<label class="control-label">Date:</label>
								<div class='input-group date' id='datetimepicker1'>
									<input type='text' name="bill_date" id="bill_date" class="form-control" required />
									<span class="input-group-addon">
									<span class="glyphicon glyphicon-calendar"></span>
								</span>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<div class="form-group label-floating">
								<label class="control-label">Enter Customer name:</label><br>
								<input type="text" class="form-control" value="" id="cust_name" name="cust_name"  spellcheck="false"  placeholder="Customer Name" onkeypress="getCustomer(event)" onkeyup="getCustomer(event)" title="e.g. abc" required>
								<input type="hidden" class="form-control" value="" id="customer_id" name="customer_id" required>
							</div>	
						</div>
						<div class="col-sm-6">
							<div class="form-group label-floating">
								<label class="control-label">Enter Contact No:</label><br>
								<input class ="form-control" name="cust_contact" id="cust_contact"  type="text" onkeypress="return IsNumeric(event);" minlenght="10" maxlenght="10" placeholder="Customer Mobile" required />
							</div>	
						</div>
					</div>

					<div class="row">
						<div class="col-sm-6">
							<div class="form-group label-floating">
								<label class="control-label">Enter Address:</label><br>
								 <input type='text' name="cust_address" id="cust_address" placeholder="Enter Email Id" class="form-control" required/>
							 </div>
						</div>
						 
					</div>
					
				</div>
				</div>

				<div class="tab-pane" id="captain">
					<div class="row">
						<div class="col-sm-12">
							<h4 class="info-text"> Product Return Details</h4>
						</div>
						 
						<div class="col-md-12">
							<div class="table table-responsive">
								<table id="mobile" class="table table-responsive table-striped table-bordered">
									<thead>
									<tr>
									<td align="center">Product Name</td>
									<td align="center">IMEI No</td>
									<td align="center">Qty</td>
									<td align="center">Total</td>
									<td align="center">Remove</td>
									</tr>
									</thead>
									<tbody id="TextBoxContainer">
									<tr class="item-row">
									<input type="hidden" class="hid_product_id" name="hid_product_id[]" id="hid_product_id" />
									<input type="hidden" class="product_qty" name="product_qty[]" id="product_qty" value="1" />
									<input type="hidden" class="hid_sale_price" name="hid_sale_price[]" id="hid_sale_price" value="" />
									<input type="hidden" class="hid_purchase_price" name="hid_purchase_price[]" id="hid_purchase_price" value="" />
									
									<td><input type="text" class="product_name form-control" name="product_name[]" id="product_name" placeholder="Product Name" style="padding: 3px;text-align: center;" required  /></td>
									
									<td><input type="text" class="imei_no number1 form-control" name="imei_no[]" id="imei_no" onkeypress="getProduct(event)" onkeyup="getProduct(event)" placeholder="IMEI No" style="padding: 3px;text-align: center;" readonly  /></td>
									
									<td width="9%"><input type="text" class="product_qty number1 form-control" name="product_qty[]" id="product_qty1" value="1" placeholder="Quantity" style="padding: 3px;text-align: center;" readonly /></td>
									
									<td><input type="text" class="total number form-control" name="total[]" id="total" value="0"  placeholder="Total Amount" style="padding: 3px;text-align: center;" required readonly /></td>
									
									<td align="center"><button type="button" class="btn btn-danger remove" style="margin-top: -1px;padding: 9px 12px 8px 12px;"><i class="glyphicon glyphicon-remove-sign"></i></button></td>
									</tr>
									</tbody>
									<tfoot>
									<tr>
									<th colspan="6">
									<button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip" data-original-title="Add more controls"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add&nbsp;</button></th>
									</tr>
									</tfoot>
								</table>
							</div>
						</div>
					</div>
				</div>

				<div class="tab-pane" id="description">
				<div class="col-md-10 col-sm-offset-1" >
					<div class="row">
						<div class="col-sm-12">
							<h4 class="info-text">Payment Method</h4>
						</div>
						<input type="hidden" name="sub_tamt" id="sub_tamt" />
						<input type="hidden" name="gst_amt" id="gst_amt" />
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label"> Amount:</label>
							<input type = "number"  class ="form-control" name="sub_total" id ="sub_total" placeholder = "" readonly>
							</div>
						</div>
						<!--div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Discount:</label>
							<input type = "number"  class ="form-control" name="disc_amt" id ="disc_amt" placeholder = "" readonly>
							</div>
						</div-->
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Payable Amount:</label>
							<input type="number" class ="form-control" name="payable_amt" id ="payable_amt" placeholder="" readonly>
							</div>
						</div>						
					
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Paid Amount:</label>
							<input type="text" class ="number1 form-control" name="paid_amt" id="paid_amt" placeholder="">
							</div>
						</div>
						</div>
					<div class="row">
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Balance Amount:</label>
							<input type ="number" class ="form-control" name="balance_amt" id ="balance_amt" placeholder="" readonly>
							</div>
						</div>
					
						<div class ="col-sm-4" id="due_date_box" >
							<div class="form-group label-floating">
							<label for="quantity" class="control-label" >Due Date:</label>
							<div class='input-group date' id='due_date_picker'>
							<input type="text"  class="form-control" id="due_date" name="due_date"  placeholder="Select Due Date."  >
							<span class="input-group-addon">
							<span class="glyphicon glyphicon-calendar"></span>
							</span>
							</div>
							</div>
						</div>

						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Payment Type:</label>
							<select name="payment_type"  id="payment_type" class="form-control">
							<option disabled="">--Select--</option>
							<option value="Cash"  > Cash </option>
							<option value="Credit" selected> Credit </option>
							<option value="Cheque"> Cheque </option>
							 
							</select>
							</div>
						</div>
						
					<!--for cheque section -->
						<div id="cheque1" class="row" style="display:none;">
						<div class="col-md-12">
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Enter Bank:</label>
							<input type="text" class ="form-control" name="bank_name" id="bank_name" pattern="[a-zA-Z0-9]+"  placeholder="">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group label-floating">
							<label class="control-label">Cheque No:</label>
							<input type ="number" class ="form-control" name="cheque_no" id ="cheque_no" pattern= "[0-9]" placeholder="">
							</div>
						</div>
						</div>
						</div>
					<!--end of cheque section -->
					
					<!--for cheque finance -->
						<div id="finance1" class="row" style="display:none;">
						<div class="col-md-12">
							<div class="col-sm-3">
								<div class="form-group label-floating">
								<label class="control-label">Finance Name:</label>
								<input type="text" class="form-control" name="finance_name" id="finance_name" placeholder="Finance Name">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group label-floating">
								<label class="control-label">Down Payment:</label>
								<input type="number" class ="form-control" name="down_payment" id="down_payment" pattern= "[0-9]" placeholder="Down Payment Amount">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group label-floating">
								<label class="control-label">EMI:</label>
								<input type ="number" class ="form-control" name="emi_amt" id ="emi_amt" pattern= "[0-9]" placeholder="EMI Amount">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group label-floating">
								<label class="control-label">Duration:</label>
								<input type ="number" class ="form-control" name="emi_duration" id ="emi_duration" pattern="[a-zA-Z0-9]+" placeholder="Number of months">
								</div>
							</div>
						</div>
						</div>
						<!--end of finance section -->
	
					</div>
																		
				</div>
				</div>
				
			</div>
			
			<div class="wizard-footer">
				<div class="pull-right">
					<input type='button' class='btn btn-next btn-fill btn-danger btn-wd' name='next' value='Next' />
					<input type='submit' id="btnproduct" class='btn btn-finish btn-fill btn-danger btn-wd' name='finish' value='Save & Continue' style="background-color: #008D4C;"/>
				</div>
				<div class="pull-left">
					<input type='button' class='btn btn-previous btn-fill btn-default btn-wd' name='previous' value='Previous' />
				</div>
				<div class="clearfix"></div>
			</div>
			</form>
		   </div>
		  </div> <!-- wizard container -->
		</div>
	</div> <!-- row -->
		

    <div class="row">
	<div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h2 class="box-title">Return Details:</h2>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>Return Number</th>
                  <th>Return Date:</th>
                  <th>Customer Name</th>
                  <th>Return Amt</th>
                  <!--<th>Payment</th>-->
                  <th>Total Balance Amt</th>
                  <th>Added</th>
                  <th>Added By</th>
				  <th Style="border-right-width:2px;">View</th>
				  <!--th Style="border-right-width:2px;">Pay Payment</th--> 
                </tr>
                </thead>
               <tbody > 
            <?php 
			$user_query = "SELECT * FROM `customer_return` WHERE added_by IN ($users_ids) ORDER BY return_number DESC";
			$user_res = mysqli_query($conn,$user_query);
			$i=0;
			while($sales_data = mysqli_fetch_assoc($user_res))
				{
					$return_number=$sales_data['return_number'];
					$return_date=$sales_data['return_date'];
					$customer_id=$sales_data['customer_id'];
					$total_amount=$sales_data['total_amount'];
					$total_payment=$sales_data['total_payment'];
					$total_balance=$sales_data['total_balance'];
					$discount_amount=$sales_data['discount_amount'];
					$gst_percentage=$sales_data['gst_percentage'];
					$gst_amount=$sales_data['gst_amount'];
					$final_total_amount=$sales_data['final_total_amount'];
					$added_by=$sales_data['added_by'];
					
					$rescm = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
					$cust_row=mysqli_fetch_assoc($rescm);
					$customer_name=$cust_row['customer_name'];
					$total_balance=$cust_row['balance'];
					$contact_number=$cust_row['mobile'];
					$rescm1 = mysqli_query($conn,"SELECT * FROM `user` WHERE `user_id`='$added_by'");
					$user_row=mysqli_fetch_assoc($rescm1);
					  $f_name=$user_row['fname'];
					$l_name=$user_row['lname'];
					 
				?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$return_number;?></td>
                  <td><?=$return_date;?></td>
                  <td><?=$customer_name.' ('.$contact_number.')';?></td>
                  <!--td><?=$total_amount;?></td>
                
                  <td><?=$gst_amount;?></td-->
                  <td><?=$final_total_amount;?></td>
                  <!--<td><?=$total_payment;?></td>-->
                  <td><?=$total_balance;?></td>
                  <td><?=date("Y-m-d", strtotime($sales_data['date_added']));?></td>
				  <td><?=$f_name." ".$l_name;?></td>
				<td><a href="javascript:void(0);"style="padding: 4px 8px;"class="btn btn-success btn-xs" onclick="view_product_details('<?=$return_number?>','<?=$customer_name?>');"><i class="fa fa-eye" title="View Product Details"></i></a></td>
                <!--td style="border-right-width:2px;">
					<a href="sales_outstanding.php" style="padding: 4px 8px;" class="btn btn-info btn-xs" onclick="pay_payment('<?php echo $sales_data['sales_number']; ?>');"><i class="fa fa-money" title="Pay Payment" style="font-size:18px;text-align: center;"></i></a>
				</td-->
                </tr>
                 
                
               
					<?php } ?>
              </tbody>
             
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	</div>   

	<div class="container">
		<div class="modal fade" id="view_sales_details" align="center" role="dialog">
			<div class="modal-dialog modal-md">
			<!-- Modal content-->
				<div  style="background-color:#f8f8ff" class="modal-content">
				<form method="POST" action="">
				<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Bill Preview</h4>
				</div>
				<div id="result_data1">
				 
				</div>
				<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
				</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Modal -->
  <div class="modal fade" id="bill_preview_model" role="dialog">
    <div  class="modal-dialog modal-lg custom ">
      <div class="modal-content">
        <div class=" ">
          <button type="button" class="close" style="background: black;" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body" id="bill_data">
          	
        </div>
        <div class="modal-footer">
		<button style="margin-bottom:0px;    background-color: indianred;" type="button" class="btn btn-default" onclick=" sale_product(); " value="print a div!">Print & Save</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  
        </div>
      </div>
    </div>
  </div>

	
<?php include 'footer.php';?>
 
 <script>
 function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
	 

     window.print();
	 	//sale_product();
	//$('#myModal').modal('hide');
	
	// location.reload();
      document.body.innerHTML = originalContents;
}
 </script>
 
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>

<!-- Bootstrap 3.3.6 --> 
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
 <script>
   //customer name
    $("#cust_name").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^a-zA-Z\s]/g)) {
       $(this).val(val.replace(/[^a-zA-Z\s]/g, ''));
   }
 });
   
   //customer contact number
    $("#cust_contact").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^0-9]|^0+(?!$)/g)) {
       $(this).val(val.replace(/[^0-9]|^0+(?!$)/g, ''));
   }
});
</script>
</body>
</html>

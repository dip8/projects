<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>

<script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#mcategory").addClass('active');
	$("#cat").css("color", "white");
});

function add_area()
{ 		
	$("#category_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
	e.preventDefault();
	document.getElementById("btncat").disabled = true;
	    var myform = document.getElementById("category_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/area_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Area Records Added Successfully..");
				}else if(data==2){
					alert("Area Already Exist...");
				}else{
					alert("Area Not Added, Please Try Again!");	
				}
				location.reload();
			}
		});
	 
	 }
	 });
} 
 function activate_deactivate(id,status)
 {
	$.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'area'},
     success: function(data)
     {
		if(data==1){
			alert("Area Status Updated Successfully..");
		}else{
			alert("Area Status Not Updated, Please Try Again!");	
		}
		location.reload();
     }

	});
	 
 } 
 function update_area()
{ 	 
	 
		document.getElementById("btnupcat").disabled = true;
	    var myform = document.getElementById("catupdate_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/area_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Area Updated Successfully..");
				}else{
					alert("Area Not Updated, Please Try Again!");	
				}
				location.reload();
			}
		});
	 
	 
	 
}
 
function edit_category(id)
{
 	 $.ajax({
     url:'excess/edit_area.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#category_edit').html('');
	  $('#cust_title').html('');
	  $('#cust_title').html('Category Update');
	  $('#cust_title1').html('');
	  $('#cust_title1').html('Category Update');
	   $('#category_edit').append(data);
	  }
	 
	}); 
}
function delete_category(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'area'},
     success: function(data)
     { 
		if(data==1){
			alert("Area Deleted Successfully..");
		}else if(data==2){
			alert("Area Not Deleted, there is sub-category present!");
		}else{
			alert("Area Not Deleted, Please Try Again!");	
		}
		location.reload();	
	 }
	});
	
	}
	else{}
 }
 </script>
 
<body class="hold-transition skin-blue sidebar-mini">
<div class=" ">
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 id="cust_title">
 Area Add:
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active" id="cust_title1">Area Add</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	<div class="row">
	<div style="padding-left:10px; padding-right:10px;" class="col-md-12">
	 <div style="border:2px solid #f39c12;" class="panel panel-warning">
	 
	  
	  <div class="panel-body" id="category_edit">
	
	   <form id="category_form" onsubmit="return add_area()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <div class="col-md-6 col-md-push-2">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Area name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control"   id="area_name" name="area_name"  data-bind="value:Id" placeholder = "Enter Category Name" required/>
      </div>
   </div>
   
  </div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
				  <button type="submit" id="btncat" class="btn btn-primary"><i class="fa fa-plus"></i>Add Area</button>
	
		  <button  type="reset" class="btn btn-danger">Cancel</button>
		</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>
	</div>
	
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">Area Details</h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Area Name</th>
                   <th Style="border-right-width:2px;">Status</th>
				  <th Style="border-right-width:2px;">Edit</th>
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead><tbody>
				<?php 
				 $user_query = "SELECT * FROM `area` ORDER BY area_id DESC";
			$cat_res = mysqli_query($conn,$user_query);
			$i=0;
			while($cat_data = mysqli_fetch_assoc($cat_res))
					{
						
						 
						$status=$cat_data['status'];
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$cat_data['area_name']?></td>
				  <td>
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $cat_data['area_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				  
				  <td><a href="javascript:void(0);" onclick="edit_category('<?php echo $cat_data['area_id']; ?>');"><i class="fa fa-pencil" title="Edit Area"></i></a></td>
                <td  Style="border-right-width:2px;">
					<a href="javascript:void(0);" onclick="delete_category('<?php echo $cat_data['area_id']; ?>');">
							<i class="fa fa-trash" title="Delete Company" style="font-size:18px;text-align: center;"></i></a>
				</td>
				</tr>
                 
                
					<?php } ?></tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	</div>
  <?php include 'footer.php';?>
</body>
</html>


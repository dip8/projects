<!DOCTYPE html>
<html lang="en">
<?php
session_start();
//include('db_config/database_config.php');
error_reporting(0);
include('db_config/database_config.php');

$admin_user_id = $_SESSION['admin_user_id'];
 
 $login_status=$_SESSION['admin_user_level'];
if($_SESSION['admin_user_id'])
{
	//header('location:index.php?ses=ex');	
	?>
	<script>window.location.href = "dashboard.php";</script>
	<?php
} 
?>
<script type='text/javascript' src='assets/js/jquery.min.js'></script> 
<script>
$(document).ready(function() {

$("#password").keyup(function(event) {
    if (event.keyCode === 13) {
      logincheck();
    }
});
});

function logincheck()
	{			
		var user_email = $('#username').val();
		var user_password = $('#password').val();
	
		if($("#remember_me").is(':checked'))
		{	
			var stay_signin = '1';
		}
		else
		{
			var stay_signin = '0';
		}

		if(user_email=="")
		{
			$('#username').focus();	
			$("#err_email").show();	
			$('#errormsg1').hide();	
			$('#validuser').hide();
			$('#err_pass1').hide();
			$('#invaliduser').hide();
			
		}
		else if(user_password=="")
		{
			$('#password').focus();
			$("#err_pass1").show();	
			$("#err_email").hide();	
			$('#errormsg1').hide();	
			$('#validuser').hide();
			$('#invaliduser').hide();						
		}
		else 
		{
		var datastring='user_email='+user_email+'&user_password='+user_password+'&stay_signin='+stay_signin;
		$.ajax({
		url:'excess/user_login_exce.php',
		type:'POST',
		data:datastring,
			success:function(data)
			{ 
				var obj=$.parseJSON(data);
				if(obj=="deactivate")
				{ 
					alert('Your profile is Deactivated by Admin! please contact to Inventory-Admin for Activate');
				}
				else if(obj=="No")
				{
					$('#validuser').hide();
					$('#invaliduser').hide();
					$('#errormsg').hide();
					$('#err_email').hide();
					$('#err_pass1').hide();
					$('#errormsg1').show();		
					$('#password').focus();	
					$("#password").val('');
				}
				else
				{
					$('#validuser').hide();
					$('#invaliduser').hide();
					$('#errormsg1').hide();	
					$('#err_email').hide();
					$('#err_pass1').hide();
					$('#successrmsg1').show();
					setTimeout(function(){ $('#successrmsg1').hide(); }, 1000);

					  window.location.href ="dashboard.php"; 
					 
				}
			}
			}); 					
		}
	}

function check_user()
	{
		 
		var emailid =document.getElementById("username").value; 	 
		if(emailid =='')
		{
			$('#username').focus();	
			$('#errormsg1').hide();	
			$('#validuser').hide();
			$('#invaliduser').hide();
			$("#err_pass1").hide();		
		}
		else
		{	
		$.ajax({
			type: 'POST',
			url: 'excess/check_user_email_exce.php',
			data: 'emailid='+ emailid ,
			success: function(data2){
			var obje=$.parseJSON(data2);
						if(obje=="Yes")
						{
							$('#errormsg1').hide();	
							$('#validuser').hide();
							$('#err_email').hide();
							$('#invaliduser').show();	
							$('#username').focus();	
							$('#profile-img').hide();
							$('#p_img').show();
						}
						else
						{
							$('#errormsg1').hide();	
							$('#invaliduser').hide();	
							$('#err_email').hide();	
							$('#validuser').show();	
							$('#err_pass1').hide();
						}
					}
				});
		}
	}
 
</script>	

<!-- Mirrored from avant.redteamux.com/extras-login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Mar 2018 12:06:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title>Shop Inventory</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Avant">
    <meta name="author" content="The Red Team">

    <link rel="stylesheet" href="assets/css/styles.minc726.css?=140">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'>
    
</head>
<body class="focusedform">
 
<div class="verticalcenter">
	<a href="index.php"> 
	<img src="assets/img/logo-big.png" alt="Logo" class="brand" /></a>
	<div class="panel panel-primary">
		<div class="panel-body">
			<h4 class="text-center" style="margin-bottom: 25px;">Log in </h4>
				 	<form class="form-horizontal" action="javascript:void(0);" method="post" role="form" autocomplete="off">
							
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user"></i></span>
								<input type="email" class="form-control" id="username" tabindex="1" name="username" onblur="check_user();" value="<?php if(isset($_COOKIE['username11'])){echo $_COOKIE['username11']; }?>"  autocomplete="off" placeholder="Username">
									 <div id="err_email" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Please Enter Registered Email-Id..!</span> </div>
									<div id="validuser" style="display: none; padding:0px; margin:0px;color:green;" class="form-group alert alert-success alert-dismissable" align="center">
										<span>Valid Username</span></div>
									<div id="invaliduser" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
										<span>Username/Email-Id not found...! Please Enter Registered Email-Id..!</span> </div>
								
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock"></i></span>
									<input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password" value="<?php if(isset($_COOKIE['password11'])){echo $_COOKIE['password11']; }?>" autocomplete="off">
					
								<div id="err_pass1" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Please Enter Valid Password..!</span> </div>
								<div id="successrmsg1" style="display: none; padding:0px; margin:0px;color:green;" class="form-group alert alert-success alert-dismissable" align="center">
									<span>Login Successfully...</span></div>
								<div id="errormsg1" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Invalid Password..! Please try again..!</span> </div>
				
								
								</div>
							</div>
						</div>
						<div class="clearfix">
							<div class="pull-right"><label><input type="checkbox" style="margin-bottom: 20px" checked=""> Remember Me</label></div>
						</div>
						<div class="panel-footer">
			<!--a href="extras-forgotpassword.html" class="pull-left btn btn-link" style="padding-left:0">Forgot password?</a-->
			
			<div class="pull-right">
				 
				<input type="reset" value="Reset" class="btn btn-default"> 
				<input type="button" onclick="logincheck()" value="Log In" class="btn btn-primary"> 
			</div>
		</div>
					</form>
					
		</div>
		
	</div>
 </div>
      
</body>


<!-- Mirrored from avant.redteamux.com/extras-login.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Mar 2018 12:06:53 GMT -->
</html>
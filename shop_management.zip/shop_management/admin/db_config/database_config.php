﻿<?php 
$hostname_db = "localhost";
$database_db = "data_shop_inventory_new_all";
$username_db = "root";
$password_db = "";
$conn = mysqli_connect($hostname_db, $username_db, $password_db, $database_db) or die(mysqli_error());
mysqli_set_charset($conn,"utf8");
?>

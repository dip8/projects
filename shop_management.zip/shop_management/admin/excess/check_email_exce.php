
<?php
include('../db_config/database_config.php');

	$email=$_POST['emailid'];
	$ques="select email_id from user where email_id='$email'";
	$query = mysqli_query($conn,$ques);
	$row =  mysqli_affected_rows($conn);
	if($row==0)
		{
			$data2[]="Yes";
		print_r(json_encode($data2));
		 
		}
		else
		{
			$data2[]="No";
		print_r(json_encode($data2));
		 
		}

?>





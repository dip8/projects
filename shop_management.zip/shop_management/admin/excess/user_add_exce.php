<?php
require_once('../db_config/database_config.php');
error_reporting(0);			
			 
			  $fname= $_POST['f_name'];
			$lname= $_POST['l_name'];
			$full_name= $fname." ".$lname;
			$email= $_POST['email'];
			$contact= $_POST['contact'];
			 
			$password= $_POST['password1'];
			$cnf_password= $_POST['cnf_password'];
			 
			$profile_pic = $_FILES['profile_pic']['name'];
			
			 
			$user_level=$_POST['user_level'];
			 

		if($profile_pic=="")
			{
				$que ="INSERT INTO `user`(`user_id`, `fname`, `lname`, `email`, `password`, `contact_no`, `profile_pic`, `admin`, `user_level`, `status`) VALUES(NULL,'$fname', '$lname', '$email', MD5('$password'),'$contact', '', '0','$user_level','1')";
				 $insprofile = mysqli_query($conn,$que);
				 $user_shop_id=mysqli_insert_id($conn); 
			 }
		  else {
					//profile pic
				$temp = explode(".", $_FILES["profile_pic"]["name"]);
				$newfilename1 =  $fname.'_'.round(microtime(true)).'.' . end($temp);
				$folder = "../img/user/";
				move_uploaded_file($_FILES["profile_pic"]["tmp_name"] , "$folder".$newfilename1);
				
			 $que ="INSERT INTO `user`(`user_id`, `fname`, `lname`, `email`, `password`, `contact_no`, `profile_pic`, `admin`, `user_level`, `status`) VALUES(NULL,'$fname', '$lname', '$email', MD5('$password'),'$contact','$newfilename1', '0','$user_level','1')";
			
				$insprofile = mysqli_query($conn, $que)or die('error insrt query');
				$user_shop_id=mysqli_insert_id($conn); 
				}
				
			  if($insprofile){
				 $que ="INSERT INTO `about_shop_own`(`shop_id`, `shop_number`, `shop_name`, `owner_name`, `shop_contact`, `shop_email`, `shop_address`, `shop_gstno`, `shop_website`, `shop_van`, `shop_pan`, `shop_terms_conditions`, `print_flag`, `admin`, `status`) VALUES (NULL,'', '', '', '', '', '', '', '', '', '', '', '1', '$user_shop_id', '1')";
				 $insp= mysqli_query($conn,$que); 
				  
			  if($insp){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
			  
			  }
?>

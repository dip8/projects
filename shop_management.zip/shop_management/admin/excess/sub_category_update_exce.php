<?php
session_start();
require_once('../db_config/database_config.php');
						 
		$category_id= $_POST['category_id'];
		$sub_cat_name= $_POST['sub_cat_name'];
		$sub_category_id= $_POST['sub_category_id'];

		$que ="UPDATE `sub_category` SET `category_id`='$category_id',`sub_category_name`='$sub_cat_name' WHERE sub_category_id='$sub_category_id'";
		$insprofile = mysqli_query($conn,$que);

		if($insprofile){
			echo 1;
		}else{
			echo 0;
		}
?>

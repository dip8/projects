<?php
require_once('../db_config/database_config.php');
session_start();
$e_id = $_POST['id'];
$status = $_POST['status'];	 
$title = $_POST['title'];	 
$user_id = $_SESSION['user_id']; 
	
	if($title=="user"){
		$updates = "update user set status='$status' WHERE user_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
		
	if($title=="user_level"){
		$updates = "update user_level set status='$status' WHERE u_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	if($title=="customer"){
		$updates = "update customer set status='$status', update_date=NULL, updated_by='$user_id' WHERE customer_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	 
	
	if($title=="company"){
		$updates = "UPDATE `company` SET `status`='$status' WHERE company_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="category"){
		$updates = "UPDATE `category` SET `status`='$status' WHERE category_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="sub_category"){
		$updates = "UPDATE `sub_category` SET `status`='$status' WHERE sub_category_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	 
	
	
	if($upt){
		echo 1;
	}else{
		echo 0;
	}
?>

	
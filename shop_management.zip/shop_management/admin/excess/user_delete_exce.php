<?php
require_once('../db_config/database_config.php');

	$user_id = $_POST['id'];
	//for profile_pic
	$select_pic = mysqli_query($conn,"SELECT * FROM `user` WHERE `user_id`='$user_id'");
	$emp_pic = mysqli_fetch_assoc($select_pic);
	$old_pic='../img/user/'.$emp_pic['profile_pic'];
	unlink($old_pic);
	
	$deletep = "delete FROM user WHERE user_id='$user_id'";
	$res = mysqli_query($conn,$deletep); 
	?>

	
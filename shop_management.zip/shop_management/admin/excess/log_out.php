<?php
session_start();
	//session_destroy();
	//session_unset['admin_user_id'];
	unset($_SESSION['admin_user_id']);
	$_SESSION["admin_user_id"] = FALSE; 
	$_SESSION["admin_user_id"] = "";
?>
	<script>window.location.href="../index.php";</script>
				 


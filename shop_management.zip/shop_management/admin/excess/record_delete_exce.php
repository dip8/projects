<?php
require_once('../db_config/database_config.php');

	$id = $_POST['id'];
	$title = $_POST['title'];

	if($title=="user_level"){
	$deletep = "delete FROM user_level WHERE u_id='$id'";
	$res = mysqli_query($conn,$deletep); 
	}
	
	if($title=="customer"){
	  $select_pic = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$user_id'");
	$emp_pic = mysqli_fetch_assoc($select_pic);
	 $old_pic='../img/customer/'.$emp_pic['id_proof'];
	unlink($old_pic);  
	 
		$deletecust = "delete FROM customer WHERE customer_id='$id'";
		$res = mysqli_query($conn,$deletecust); 
	}
	
	if($title=="product"){
		$deletep = "delete FROM product WHERE product_id='$id'";
		$res = mysqli_query($conn,$deletep); 
	}
	
	if($title=="company"){
		$deletec = "DELETE FROM `company` WHERE  company_id='$id'";
		$res = mysqli_query($conn,$deletec); 
	}
	if($title=="category"){
		$que="SELECT * FROM `sub_category` WHERE  category_id='$id'";
		$res = mysqli_query($conn,$que); 
		echo $num=mysqli_num_rows($res);
		if($num==0){
		$deletec = "DELETE FROM `category` WHERE  category_id='$id'";
		$res = mysqli_query($conn,$deletec);
		}	
		else{
			echo 2;
		}	
	}
	if($title=="sub_category"){
		$deletec = "DELETE FROM `sub_category` WHERE  sub_category_id='$id'";
		$res = mysqli_query($conn,$deletec); 
	}
	if($title=="contact"){
		$deletec = "DELETE FROM `contact_person` WHERE  contact_id='$id'";
		$res = mysqli_query($conn,$deletec); 
	}
	
	if($title=="shop"){
		$que="SELECT * FROM `about_shop` WHERE shop_id='$id' AND status='0'";
		$res = mysqli_query($conn,$que); 
		$num=mysqli_num_rows($res);
		if($num==0){
		$deletec = "DELETE FROM `about_shop` WHERE  shop_id='$id' ";
		$res = mysqli_query($conn,$deletec); 
		}	
		else{
			echo 2;
		}	
		
	}
	
	 if($res){
		echo 1;
	}else{
		echo 0;
	}
	
?>

	
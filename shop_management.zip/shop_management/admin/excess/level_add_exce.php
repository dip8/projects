<?php
require_once('../db_config/database_config.php');
			
			 
			  $level_name= $_POST['level_name'];
		  $level_tag= $_POST['level_tag'];
			// print_r($level_tag);
		    $level_t=implode(",",$level_tag);
				 $que ="INSERT INTO `user_level`(`u_id`, `level_name`, `level_fectures`, `status`) VALUES (NULL,'$level_name', '$level_t', '1')";
				  $insprofile = mysqli_query($conn,$que);
				  
			  if($insprofile){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }  
?>

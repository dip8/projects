<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
		$com_name= ucfirst($_POST['com_name']);
		$ques="select company_name from company where company_name='$com_name'";
		$query = mysqli_query($conn,$ques);
		$row =  mysqli_affected_rows($conn);
		if($row>0)
		{
			echo 2;
		}else{
			$que ="INSERT INTO `company`(`company_id`, `company_number`, `company_name`, `status`) VALUES(NULL,'','$com_name','1')";
			$inscomp = mysqli_query($conn,$que);
			 
			if($inscomp){
				echo 1;
			}else{
				echo 0;
			}
		}	   
?>

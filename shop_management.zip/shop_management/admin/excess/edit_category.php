 <?php
require_once('../db_config/database_config.php');

	$category_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
	 
		$com_row=mysqli_fetch_assoc($res);	
	 
	?>
 <form id="catupdate_form" onsubmit="return update_category()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
<input type="hidden" name="category_id" id="category_id" value="<?=$com_row['category_id']?>">
	   
   <div class="col-md-6 col-md-push-2">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Category name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control" value="<?=$com_row['category_name']?>"  id="cat_name" name="cat_name"  data-bind="value:Id" placeholder = "Enter Category Name" required>
      </div>
   </div>
   
  </div>

			<div class="col-md-12 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupcat" class="btn btn-primary"><i class="fa fa-plus"></i>Update Category</button>
	
		  <a href="" class="btn btn-danger">Cancel</a>
			</div>
			</div>
	 </form> 
<?php
require_once('../db_config/database_config.php');

	$level_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `user_level` WHERE `u_id`='$level_id'");
	 
		$userl_row=mysqli_fetch_assoc($res);	
		$str=$userl_row['level_fectures'];
		$level_fectures=explode(",",$str);
	// print_r($level_fectures);
	?>

 <form id="user_level_update" onsubmit="return update_user_level();"  autocomplete="off"  method="POST" class="form-horizontal row-border"  action="javascript:void(0);">
					  <div class="col-md-12"> 
									  
				   <div class = "form-group">
					  <label for = "dealername" class = "col-md-3 control-label">Level Name:</label>
					 <div class = "col-md-6">
					 <input type="hidden" class ="form-control" id ="level_id" name="level_id" value="<?=$userl_row['u_id']?>"   required>
			
							<input type="text" class ="form-control" id ="level_name" name="level_name" value="<?=$userl_row['level_name']?>"   placeholder = "Enter Level Name" required>
				   </div>
				   </div>
				   
				   <div class = "form-group">
					  <label for = "proname" class = "col-md-3 control-label"> Level :</label>
						<div class = "col-md-7">
						<?php
						  
					 $level_res = mysqli_query($conn, "SELECT * FROM `level_tags` where status='1' ");
						while($level_data=mysqli_fetch_array($level_res))
						{
						?>
					  <div class = "col-md-3">
					 <div class="checkbox">
							<label>
							<input type="checkbox" name="level_tag[]" id="level_tag" value="<?=$level_data['tag_id'];?>" <?php foreach($level_fectures as $key=>$val){ if($val==$level_data['tag_id']){ ?> checked  <?php } } ?>  >
							<?=$level_data['tag_name'];?> 
							</label>
						</div>
                     
					 </div>
					<?php } ?>
					  
				   </div>
				   </div>
				    
					
				  
					</div>
    

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdate" class="btn btn-primary"><i class="fa fa-plus"></i>Update Level</button>
				 <button  type="reset" onclick="document.location.reload();" class="btn btn-danger">Cancel</button>
					</div>
			</div>
	 </form>
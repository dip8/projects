<?php
ob_start(); 
session_start();

include('../db_config/database_config.php');

$username =  mysqli_real_escape_string($conn, $_POST['user_email']); 
$username = htmlentities( $username, ENT_QUOTES, 'UTF-8' );
$password = mysqli_real_escape_string($conn, $_POST['user_password']);
$password = htmlentities( $password, ENT_QUOTES, 'UTF-8' ); 
/* $username =  $_POST['user_email'];
$username = htmlentities( $username, ENT_QUOTES, 'UTF-8' );
$password =  $_POST['user_password'];
$password = htmlentities( $password, ENT_QUOTES, 'UTF-8' ); */
$stay_signin =  $_POST['stay_signin'];

	// if user check the remember me checkbox
		if($stay_signin == 1)
		{ 
        setcookie('username11', $username, time()+60*60*24*30, '/');
        setcookie('password11', $password, time()+60*60*24*30, '/');
		} 
	
	
	$query = "SELECT * FROM sup_user WHERE email=('$username') AND password = md5('$password')";
	$res = mysqli_query($conn,$query);
	$num = mysqli_affected_rows($conn);
	
	//Check profile Activate or Deactivate
	$queryb =  mysqli_query($conn,"SELECT * FROM sup_user WHERE email=('$username') AND password = md5('$password') AND status='0'");
	$numa = mysqli_affected_rows($conn);
	
	 if($numa>0)
	{	$data[]="deactivate";
		print_r(json_encode($data));
	}
	else if($num==0)
	{
		$data[]="No";
		print_r(json_encode($data));		
	}
	else
	{
		
		//$fere = mysqli_query($conn,"SELECT * FROM employee WHERE email=('$username') AND password = MD5('$password')");
		$arr = mysqli_fetch_array($res);
			
			$user_id = $arr['user_id'];
			//$emp_id = $arr['e_id'];
			 $login_status = $arr['user_level'];
			 $contact_no = $arr['contact_no'];
			 $profile_pic = $arr['profile_pic'];
			 
			$first_name = ucfirst($arr['fname']);
			$last_name = ucfirst($arr['lname']);
			$full_name = $first_name.' '.$last_name;
			
			$_SESSION['full_name'] = $full_name;
			$_SESSION['contact_no'] = $contact_no;
			$_SESSION['profile_pic'] = $profile_pic;
			$_SESSION['admin_user_id'] = $user_id;
			//$_SESSION['emp_id'] = $emp_id;
			$_SESSION['user_level_sub'] = $login_status;
			$data[]=$login_status;
		print_r(json_encode($data));
		//$upus = mysqli_query($conn,"update user_registration set is_active='1' where user_id='$user_id'");
		
					 
	}
	
?>


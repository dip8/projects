<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
		$sub_cat_name= $_POST['sub_cat_name'];
		$ques="select sub_category_name from sub_category where sub_category_name='$sub_cat_name'";
		$query = mysqli_query($conn,$ques);
		$row =  mysqli_affected_rows($conn);
		if($row>0)
		{
			echo 2;
		}else{
			$category_id= $_POST['cat_name'];
			$que ="INSERT INTO `sub_category`(`sub_category_id`, `category_id`, `sub_category_name`, `status`) VALUES (NULL,'$category_id','$sub_cat_name','1')";
			$inssubcat = mysqli_query($conn,$que);
			if($inssubcat){
				echo 1;
			}else{
				echo 0;
			}
		}
		 
				
			   
?>

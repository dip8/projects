<?php
session_start();
require_once('../db_config/database_config.php');
						 
		$company_id= $_POST['company_id'];
		$com_name= ucfirst($_POST['com_name']);

		$que ="UPDATE `company` SET `company_name`='$com_name' WHERE company_id='$company_id'";
		$insprofile = mysqli_query($conn,$que);
	 
		if($insprofile){
		  echo 1;
		}else{
		  echo 0;
		}
?>

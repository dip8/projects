<?php
session_start();
require_once('../db_config/database_config.php');
				 
		$category_id= $_POST['category_id'];
		$cat_name= $_POST['cat_name'];

		$que ="UPDATE `category` SET `category_name`='$cat_name' WHERE category_id='$category_id'";
		$insprofile = mysqli_query($conn,$que);
			 
		if($insprofile){
			  echo 1;
		}else{
			  echo 0;
		}
?>

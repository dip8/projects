<?php
 
require_once('../db_config/database_config.php');
			
			 
			   $user_id= $_POST['user_id'];
			   $f_name= $_POST['f_name'];
			   $l_name= $_POST['l_name'];
			$email= $_POST['email'];
			 
			$contact= $_POST['contact'];
			 
			$user_level= $_POST['user_level'];
			 
			 
			$profile_pic = $_FILES['profile_pic']['name'];
			 
			  
		 if($profile_pic=="")
			{
				    $que ="UPDATE `user` SET `fname`='$f_name',`lname`='$l_name',`email`='$email',`contact_no`='$contact',`user_level`='$user_level' WHERE user_id=$user_id";
				 $insprofile = mysqli_query($conn,$que);
			}
			else{
				
				$temp = explode(".", $_FILES["profile_pic"]["name"]);
				$newfilename1 =  $f_name.'_'.round(microtime(true)).'.' . end($temp);
				$folder = "../img/user/";
				move_uploaded_file($_FILES["profile_pic"]["tmp_name"] , "$folder".$newfilename1);
				
			  	   $que ="UPDATE `user` SET `fname`='$f_name',`lname`='$l_name',`email`='$email',`contact_no`='$contact', `profile_pic`='$newfilename1', `user_level`='$user_level' WHERE user_id=$user_id";
				
				 $insprofile = mysqli_query($conn, $que)or die('error update query');
				 
			}
			 if($insprofile){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
?>

 <?php
require_once('../db_config/database_config.php');

	$sub_category_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `sub_category` WHERE `sub_category_id`='$sub_category_id'");
	 
		$com_row=mysqli_fetch_assoc($res);	
	 
	?>
<form id="catsubupdate_form" onsubmit="return update_sub_category()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <div class="col-md-6 col-md-push-2">
	<input type="hidden" name="sub_category_id" id="sub_category_id" value="<?=$com_row['sub_category_id']?>">

   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Category name:</label>
		
      <div class = "col-sm-9">
	  <select  id="category_id" name="category_id" class = "form-control" required>
	  <option value="">-- Select Category --</option>
	  <?php 
	   $user_query = "SELECT * FROM `category`";
			$cat_res = mysqli_query($conn,$user_query);
			 
			while($cat_data = mysqli_fetch_assoc($cat_res))
					{
			 ?>
			<option value="<?=$cat_data['category_id']?>" <?php if($cat_data['category_id']==$com_row['category_id']){?> Selected<?php } ?>><?=$cat_data['category_name']?></option>
					<?php } ?>
	  </select>
      </div>
   </div>
  <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Sub-Category name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control" value="<?=$com_row['sub_category_name']?>"   id="sub_cat_name" name="sub_cat_name"  data-bind="value:Id" placeholder = "Enter Sub-Category Name" required>
      </div>
   </div>
   
  </div>

			<div class="col-md-12 col-md-push-5">
			<div  class="box-footer clearfix no-border">
				  <button type="submit" id="btnupsubcat" class="btn btn-primary"><i class="fa fa-plus"></i>Update Sub-Category</button>
	
				<a href="" class="btn btn-danger">Cancel</a>
		</div>
			</div>
	 </form>
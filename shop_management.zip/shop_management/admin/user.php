<?php include('header.php');?>
<script>
    $(document).ready(function() {
		 
    $("#uadd").addClass('active open');
    $("#add_u").addClass('active');
	 
});
 </script>
 <script>
 function activate_deactivate(id,status)
 {
	  //alert(status);
	 $.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status,'title':'user'},
     success: function(data)
     {
		 if(data==1){
      alert("User Status Updated Successfully..");
	   location.reload();
		 }else{
			  alert("User Status Not Updated."); 
		 }
     }

	});
	 
 } 

 function add_user()
{ 		
	//if(! $form.valid()) return false;
	 $("#user_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
		e.preventDefault();
		var pass1 = document.getElementById("password1").value;
		var password_confirm = document.getElementById("cnf_password").value;
		 
		if(pass1!= password_confirm)
		{
		alert("password Not Match");	
		$('#password1').focus();	
			$('#password1').val('');
			$('#cnf_password').focus();	
			$('#cnf_password').val('');
		}
		
		else {
			 document.getElementById("btnupdate").disabled = true;
	    var myform = document.getElementById("user_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/user_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
			    //alert(data);
				if(data==1){
				alert("User Records Added Successfully..");
				//document.getElementById("emp_btnadd").disabled = false;
				//window.location.href='profile_hr.php#employee_list_tab';
				 location.reload();
				//alert(data);
				}else{
					alert("User Records Not Added");
				}
				 
			}
		});
	}
	 }
	 });
}
 function update_user()
{ 		
	 
		/* var pass1 = document.getElementById("password1").value;
		var password_confirm = document.getElementById("cnf_password").value;
		 
		if(pass1!= password_confirm)
		{
		alert("password Not Match");	
		$('#password1').focus();	
			$('#password1').val('');
			$('#cnf_password').focus();	
			$('#cnf_password').val('');
		}
		
		else { */
			 document.getElementById("btnuserupdate").disabled = true;
	    var myform = document.getElementById("user_update_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/user_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				if(data==1){
				alert("User Records Updated Successfully..");
				 location.reload();
				 
				}else{
					alert("User Records Not Updated");
				}
				 
			}
		});
}
	 

function check_email_id()
{
  
	var emailid =document.getElementById("email").value;							 
 	
		$.ajax({
				type: 'POST',
				url: 'excess/check_user_email_exce.php',
				data: 'emailid='+ emailid ,
				success: function(data2){
					  //alert(data2);
				var obje=$.parseJSON(data2);
							if(obje=="Yes")
							{
							//alert("yes");	
							 $('#err_email').hide();
						//setTimeout(function(){ $('#invaliduser').hide(); }, 5000);
							}
							else
							{
								//alert("no");
								$('#email').focus();	
							 	 $('#err_email').show();	
							 }
				}
				});
}

function delete_user(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/user_delete_exce.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	   //alert(data);
      //delete_succefull();
	  alert("User Delete Successfully..");
	  // $('#refresh_user').load(document.URL +  ' #refresh_user');
	   location.reload();
	//  window.location.href = "profile_hr.php#employee_other_doc_list";
	 }
	});
	
	}
	else{}
 }
function edit_user(id)
{
 	 $.ajax({
     url:'excess/edit_user.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#user_edit').html('');
	  $('#user_title').html('');
	  $('#user_title').html('User Update');
	  $('#user_title1').html('');
	  $('#user_title1').html('User Update');
	   $('#user_edit').append(data);
	    $(window).scrollTop($('#user_edit').offset().top-20); 
	  }
	 
	}); 
} 
 </script>
   
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="dashboard.php">Dashboard</a></li>
               
                <li class="active">Users</li>
            </ol>
     
        </div>

<div class="col-md-12">
<div class="panel panel-midnightblue">
    <div class="panel-heading">
        <h4>Add Users</h4>
        <div class="options" style="margin-top:1%">   
             
            <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
        </div>
    </div>
    <div class="panel-body collapse in" id="user_edit">
  
      <form id="user_form" onsubmit="return add_user()"  autocomplete="off" enctype="multipart/form-data" method="POST" class="form-horizontal row-border"  action="javascript:void(0);">
      <div class="col-md-6">            
   <div class = "form-group">
      <label for = "dealername" class = "col-md-2 control-label">First Name:</label>
	 <div class = "col-md-10">
            <input type="text" class ="form-control" id ="f_name" name="f_name" pattern="[a-zA-Z]"  placeholder = "Enter First Name">
   </div>
   </div>
   
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Last Name:</label>
		
      <div class = "col-md-10">
         <input type = "text"  class ="form-control" id="l_name" name="l_name" pattern="[a-zA-Z]"  placeholder = "Enter Last Name">
      </div>
   </div>
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Email Id:</label>
		
      <div class = "col-md-10">
         <input type="email"  class="form-control"  id="email" name="email"   placeholder = "Enter Email Id Name" onblur="check_email_id();">
      <div id="err_email" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Username/Email-Id are found...! Please  Enter New Email-Id..!</span> </div>
				
	  </div>
   </div>
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Password:</label>
		
      <div class = "col-md-10">
         <input type="password"  class="form-control" id="password1" name="password1"  placeholder = "Enter Password ">
      </div>
   </div>
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Conf.-Password:</label>
		
      <div class = "col-md-10">
         <input type="password"  class="form-control" id="cnf_password" name="cnf_password"  placeholder = "Enter Confirm Password ">
      </div>
   </div>
  
    </div>
   <div class="col-md-6">
   <div class="row">
   
   <div class="form-group">
      <label for = "quantity" class = "col-md-2 control-label">Contact No:</label>
	 <div class = "col-md-10">
         <input type="number"  class ="form-control" id="contact" maxlength="10" name="contact" placeholder = "Enter Contact No.">
      </div>
   </div>
   </div>
 <div class="row">
   <div class="form-group">
      <label for = "quantity" class = "col-md-2 control-label">Profile Image:</label>
		
      <div class = "col-md-10">
         <input type="file"  class="form-control" id="profile_pic" name="profile_pic"  placeholder = "Select Profile Image">
      </div>
   </div>
   </div>
   <div class="row">
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">User Level:</label>
		
      <div class = "col-md-10">
	   <select class="select21 form-control" name="user_level" id="user_level">
		<option value="">-- Select User Level --</option>
		<?php
		 $uselq = mysqli_query($conn,"SELECT * FROM `user_level` WHERE `status`='1' ");
			while($uselr=mysqli_fetch_assoc($uselq)){
		?>
		<option value="<?=$uselr['u_id']?>"><?=$uselr['level_name']?></option>
	 			<?php } ?>
		</select>
        </div>
   </div>
   </div>
    
   
	</div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdate" class="btn btn-primary"><i class="fa fa-plus"></i>Add User</button>
					
					  <button  type="reset" class="btn btn-danger">Cancel</button>
					</div>
			</div>
	 </form> 
        
         
    </div>
    
</div>
</div>

 <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Users Details</h4>
                            <div class="options" style="margin-top:1%;">   
                                  <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
                            </div>
                        </div>
                        <div class="panel-body collapse in">
                 
				 
			   <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
            
			   <thead>
                <tr>
                  <th>User Id</th>
                  <th>User Name</th>
                  <th>Email Id</th>
                  <th>Profile Image</th>
                  <th>Contact No</th>
                  <th>User Level</th>
                  <th>Status</th>
				  <th Style="border-right-width:2px;">edit</th>
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead>
				<?php 
				 $user_query = "SELECT * FROM user where admin='0'";
			$user_res = mysqli_query($conn,$user_query);
			$i=0;
			while($user_data = mysqli_fetch_assoc($user_res))
					{
						
						$profile_pic= $user_data['profile_pic'];
						$user_level= $user_data['user_level'];
						$status=$user_data['status'];
						 $uselq1 = mysqli_query($conn,"SELECT * FROM `user_level` WHERE `u_id`='$user_level' ");
						$uselr1=mysqli_fetch_assoc($uselq1);
						?>
                <tbody>
                <tr class="gradeA">
                  <td><?php echo ++$i; ?></td>
                  <td><?php echo $user_data['fname']." ";?> <?=$user_data['lname']?></td>
                  <td><?=$user_data['email']?></td>
                  <td> <img width="30" src="img/user/<?=$user_data['profile_pic']?>" onerror="this.src='img/no_img.png';" alt="user pic"></td>
                    <td><?=$user_data['contact_no']?></td>
                    <td><?=$uselr1['level_name']?></td>
                    <td> 
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $user_data['user_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				  
				
				   
                <td  Style="border-right-width:2px;"> 
                	<a href="javascript:void(0);" onclick="edit_user('<?php echo $user_data['user_id']; ?>');">
							<i class="fa fa-pencil" title="Edit User" style="font-size:18px;text-align: center;"></i></a>
					 </td>
					
					<td  Style="border-right-width:2px;"> 
                	<a href="javascript:void(0);" onclick="delete_user('<?php echo $user_data['user_id']; ?>');">
							<i class="fa fa-trash-o" title="Delete User" style="font-size:18px;text-align: center;"></i></a>
					 </td>
				</tr>
               </tbody>
					<?php } ?>
              </table>
							</div>
                            </div>
                            </div>
                            </div>
                            </div>
							






</div>
</div>

<?php include('footer.php');?>


<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>

<script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#mcategory").addClass('active');
	$("#subcat").css("color", "white");
});

 function add_sub_category()
{ 		
	$("#sub_category_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
	e.preventDefault();
	document.getElementById("btnsubcat").disabled = true;
	    var myform = document.getElementById("sub_category_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/sub_category_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Sub-Category Records Added Successfully..");
				}else if(data==2){
					alert("Sub-Category Already Exist...");
				}else{
					alert("Sub-Category Not Added, Please Try Again!");	
				}
				location.reload();
			}
		});
	 
	 }
	 });
} 

function activate_deactivate(id,status)
{
	$.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'sub_category'},
     success: function(data)
     {
		if(data==1){
			alert("Sub-Category Status Updated Successfully..");
		}else{
			alert("Sub-Category Status Not Updated, Please Try Again!");	
		}
		location.reload();
     }
	});	 
} 
 
 function update_sub_category()
	{ 	 
	 
		document.getElementById("btnupsubcat").disabled = true;
	    var myform = document.getElementById("catsubupdate_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/sub_category_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Sub-Category Updated Successfully..");
				}else{
					alert("Sub-Category Not Updated, Please Try Again!");	
				}
				location.reload();
			}
		});
 
	}
 
function edit_sub_category(id)
{
 	 $.ajax({
     url:'excess/edit_sub_category.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#sub_category_edit').html('');
	  $('#cust_title').html('');
	  $('#cust_title').html('Sub-Category Update');
	  $('#cust_title1').html('');
	  $('#cust_title1').html('Sub-Category Update');
	   $('#sub_category_edit').append(data);
	  }
	 
	}); 
}

function delete_sub_category(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
	$.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'sub_category'},
     success: function(data)
     {
		if(data==1){
			alert("Sub-Category Deleted Successfully..");
		}else{
			alert("Sub-Category Not Deleted, Please Try Again!");	
		}
		location.reload();
	 }
	});
	
  }else{}
  
 }
 
</script>
 
<body class="hold-transition skin-blue sidebar-mini">
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="dashboard.php">Dashboard</a></li>
               
                <li class="active">Sub-Category</li>
            </ol>
     
        </div>

    <!-- Main content -->
	<div class="col-md-12">
	<div class="panel panel-midnightblue">
    <div class="panel-heading">
        <h4 id="cust_title">Add Sub-Category</h4>
        <div class="options"  >   
             
            <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
        </div>
    </div>
    <div class="panel-body collapse in" id="sub_category_edit">
	 
	
	   <form id="sub_category_form" onsubmit="return add_sub_category()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <div class="col-md-6 col-md-push-2">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Category name:</label>
		
      <div class = "col-sm-9">
	  <select  id="cat_name" name="cat_name" class = "form-control">
	  <option value="">-- Select Category --</option>
	  <?php 
	   $user_query = "SELECT * FROM `category` ";
			$cat_res = mysqli_query($conn,$user_query);
			 
			while($cat_data = mysqli_fetch_assoc($cat_res))
					{
			 ?>
			<option value="<?=$cat_data['category_id']?>"><?=$cat_data['category_name']?></option>
					<?php } ?>
	  </select>
      </div>
   </div>
  <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Sub-Category name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control"   id="sub_cat_name" name="sub_cat_name"  data-bind="value:Id" placeholder = "Enter Sub-Category Name">
      </div>
   </div>
   
  </div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
				  <button type="submit" id="btnsubcat" class="btn btn-primary"><i class="fa fa-plus"></i>Add Sub-Category</button>
	
		  <button  type="reset" class="btn btn-danger">Cancel</button>
		</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>
	</div>
	
    
	  <div class="col-md-12 ">

          <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Sub-Category Details</h4>
                            <div class="options"  >   
                                  <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
                            </div>
                        </div>
                        <div class="panel-body collapse in">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Sub-Category Name</th>
                  <th>Category Name</th>
                   <th Style="border-right-width:2px;">Status</th>
				  <th Style="border-right-width:2px;">Edit</th>
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead><tbody>
				<?php 
				$user_query = "SELECT * FROM `sub_category` ORDER BY sub_category_id DESC";
				$subcat_res = mysqli_query($conn,$user_query);
				$i=0;
				while($subcat_data = mysqli_fetch_assoc($subcat_res))
					{ 
						$status=$subcat_data['status'];
						$catid=$subcat_data['category_id'];
						$cat_res = mysqli_query($conn,"SELECT * FROM `category` where category_id='$catid'");
						$cat_data = mysqli_fetch_assoc($cat_res);
					?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$subcat_data['sub_category_name']?></td>
                  <td><?=$cat_data['category_name']?></td>
				  <td>
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $subcat_data['sub_category_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				  
				  <td><a href="javascript:void(0);" onclick="edit_sub_category('<?php echo $subcat_data['sub_category_id']; ?>');"><i class="fa fa-pencil" title="Edit Company"></i></a></td>
                <td  Style="border-right-width:2px;">
					<a href="javascript:void(0);" onclick="delete_sub_category('<?php echo $subcat_data['sub_category_id']; ?>');">
							<i class="fa fa-trash-o" title="Delete Company" style="font-size:18px;text-align: center;"></i></a>
				</td>
				</tr>
                 
                
					<?php } ?> </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
     
	</div>
  <?php include 'footer.php';?>
</body>
</html>

<?php include('header.php');?>
 
 <script>
 function activate_deactivate(id,status)
 {
	  //alert(status);
	 $.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status,'title':'user_level'},
     success: function(data)
     {
		 if(data==1){
      alert("User Level Status Updated Successfully..");
	   location.reload();
		 }else{
			  alert("User Level Status Not Updated."); 
		 }
     }

	});
	 
 } 

 function add_user_level()
{ 		
 
	 $("#user_level_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
		e.preventDefault();
		 
			 document.getElementById("btnupdate").disabled = true;
	    var myform = document.getElementById("user_level_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/level_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				  
				if(data==1){
				alert("User Records Added Successfully..");
				  location.reload();
				
				}else{
					alert("User Records Not Added");
				}
			} 
	  });
}
});
}
 function update_user_level()
{ 		
	   
			 document.getElementById("btnupdate").disabled = true;
	    var myform = document.getElementById("user_level_update");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/edit_user_level_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				  
				if(data==1){
				alert("User Level Updated Successfully..");
				 location.reload();
				 
				}else{
					alert("User Level Not Updated");
				}
				 
			}
		});
}
	 

function check_email_id()
{
  
	var emailid =document.getElementById("email").value;							 
 	
		$.ajax({
				type: 'POST',
				url: 'excess/check_user_email_exce.php',
				data: 'emailid='+ emailid ,
				success: function(data2){
					  
				var obje=$.parseJSON(data2);
							if(obje=="Yes")
							{
							//alert("yes");	
							 $('#err_email').hide();
						//setTimeout(function(){ $('#invaliduser').hide(); }, 5000);
							}
							else
							{
								//alert("no");
								$('#email').focus();	
							 	 $('#err_email').show();	
							 }
				}
				});
}

function delete_user(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id,'title':'user_level'},
     success: function(data)
     {
	  if(data==1){  
	  alert("User Level Delete Successfully..");
	    location.reload();
	  }else{
		  alert("User Level Not Delete..");
	 
	  }
	 }
	});
	
	}
	else{}
 }
function edit_user(id)
{
 	 $.ajax({
     url:'excess/edit_user_level.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
		// alert(data);
	  $('#title_id').html('');
	   $('#title_id').append("Update User Level");
	   $('#user_edit_level').html('');
	   $('#user_edit_level').append(data);
	    $(window).scrollTop($('#user_edit_level').offset().top-500); 
	  }
	 
	}); 
} 
 </script>
   
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="dashboard.php">Dashboard</a></li>
               
                <li class="active">Users Level</li>
            </ol>
     
        </div>

				<div class="col-md-12">
				<div class="panel panel-midnightblue">
					<div class="panel-heading">
						<h4 id="title_id">Add Users Level</h4>
						<div class="options" style="margin-top:1%">   
							 
							<a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
						</div>
					</div>
					<div class="panel-body collapse in" id="user_edit_level">
				  
				 <form id="user_level_form" onsubmit="return add_user_level();"  autocomplete="off"  method="POST" class="form-horizontal row-border"  action="javascript:void(0);">
					  <div class="col-md-12">            
				   <div class = "form-group">
					  <label for = "dealername" class = "col-md-3 control-label">Level Name:</label>
					 <div class = "col-md-6">
							<input type="text" class ="form-control" id ="level_name" name="level_name"   placeholder = "Enter Level Name">
				   </div>
				   </div>
				   
				   <div class = "form-group">
					  <label for = "proname" class = "col-md-3 control-label"> Level :</label>
						<div class = "col-md-7">
						<?php
						  
					 $level_res = mysqli_query($conn, "SELECT * FROM `level_tags` where status='1' ");
						while($level_data=mysqli_fetch_array($level_res))
						{
						?>
					  <div class = "col-md-3">
					 <div class="checkbox">
							<label>
							<input type="checkbox" name="level_tag[]" id="level_tag" value="<?=$level_data['tag_id'];?>" required>
							<?=$level_data['tag_name'];?> 
							</label>
						</div>
                     
					 </div>
					<?php } ?>
					  
				   </div>
				   </div>
				    
					
				  
					</div>
    

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdate" class="btn btn-primary"><i class="fa fa-plus"></i>Add Level</button>
				 <button  type="reset" class="btn btn-danger">Cancel</button>
					</div>
			</div>
	 </form> 
        
         
    </div>
    
</div>
</div>

 <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Users Details</h4>
                            <div class="options" style="margin-top:1%;">   
                                  <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
                            </div>
                        </div>
                        <div class="panel-body collapse in">
                 
				 
			   <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
            
			   <thead>
                <tr>
                  <th>Sr Id</th>
                  <th>Level Name</th>
                  <th>Level Tags</th>
                  <th>Status</th>
                  <th>Edit</th>
                   
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead>
				<?php 
				 $userl_query = "SELECT * FROM user_level ";
			$userl_res = mysqli_query($conn,$userl_query);
			$i=0;
			while($userl_data = mysqli_fetch_assoc($userl_res))
					{
					 $status=$userl_data['status'];
					  $level_fectures=$userl_data['level_fectures'];
					 $l_name=array();
					 $level_q = mysqli_query($conn,"SELECT * FROM `level_tags` where tag_id IN ($level_fectures) ");
					 
					while($level_r = mysqli_fetch_assoc($level_q)){
						  $l_name[]= $level_r['tag_name'];
					}
					 
					 $l_name1 = join(",", $l_name);
						?>
                <tbody>
                <tr class="gradeA">
                  <td><?php echo ++$i; ?></td>
                  <td><?php echo $userl_data['level_name']; ?></td>
                  <td><?=$l_name1?></td>
                   <td  Style="border-right-width:2px;"> 
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $userl_data['u_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				  
				
				   
                <td  Style="border-right-width:2px;"> 
                	<a href="javascript:void(0);" onclick="edit_user('<?php echo $userl_data['u_id']; ?>');">
							<i class="fa fa-pencil" title="Edit User" style="font-size:18px;text-align: center;"></i></a>
					 </td>
					
					<td  Style="border-right-width:2px;"> 
                	<a href="javascript:void(0);" onclick="delete_user('<?php echo $userl_data['u_id']; ?>');">
							<i class="fa fa-trash-o" title="Delete User" style="font-size:18px;text-align: center;"></i></a>
					 </td>
				</tr>
               </tbody>
					<?php } ?>
              </table>
							</div>
                            </div>
                            </div>
                            </div>
                            </div>
							






</div>
</div>

<?php include('footer.php');?>


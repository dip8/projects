jQuery(document).ready(function() {

	$("#chat").niceScroll({horizrailenabled:false,railoffset: {left:0}});

});
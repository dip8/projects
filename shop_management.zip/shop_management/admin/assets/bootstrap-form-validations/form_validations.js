"use strict";

$(document).ready(function () {

 
	$('#user_form').bootstrapValidator({
        fields: {

            f_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter First Name'
                    } 
                }
            }, 
			
			l_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Last Name'
                    }
                }
            },
			 
			email: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Email Id'
                    },
					regexp: {
                        regexp: /^\S+@\S{1,}\.\S{1,}$/,
                        message: 'Please enter valid email-id'
                    }
                }
            }, 
			 
			contact: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Contact No'
                    }
                }
            },
			
			user_level: {
                validators: {
                    notEmpty: {
                        message: 'Please Select User Level '
                    }
                }
            },
			
			password1: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Password'
                    }
                }
            },
			
			cnf_password: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Confirm Password'
                    }
                }
            }, 
            
        },
        
    }).on('reset', function (event) {
        $('#user_form').data('bootstrapValidator').resetForm();
    });
    
	
	
	$('#user_level_form').bootstrapValidator({
        fields: {

			level_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Level Name'
                    } 
                }
            },
			level_tag: {
                validators: {
                    notEmpty: {
                        message: 'Please Select Level Tags'
                    } 
                }
            }, 
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#user_level_form').data('bootstrapValidator').resetForm();
    });
	
	 
	 
	$('#customer_form').bootstrapValidator({
        fields: {

            cust_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Dealer Name'
                    } 
                }
            }, 
			address: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Address'
                    }
                }
            },
			contact_no: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Contact No '
                    },
					regexp: {
                        regexp: /^[1-9][0-9]{9}$/,
                        message: "Invalid Mobile Number!"
                    }
                }
            },
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#customer_form').data('bootstrapValidator').resetForm();
    });
	 
	 
	 
	$('#company_form').bootstrapValidator({
        fields: {

           com_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Company Name'
                    } 
                }
            }, 
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#company_form').data('bootstrapValidator').resetForm();
    });
	 
	 
	 
	$('#category_form').bootstrapValidator({
        fields: {

           cat_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Category Name'
                    } 
                }
            }, 
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#category_form').data('bootstrapValidator').resetForm();
    });
	 
	 
	 
	$('#sub_category_form').bootstrapValidator({
        fields: {

           cat_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Select Category Name'
                    } 
                }
            },
			sub_cat_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Sub - Category Name'
                    } 
                }
            }, 
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#sub_category_form').data('bootstrapValidator').resetForm();
    });
	 
	

	$('#shop_form').bootstrapValidator({
        fields: {

           shop_number: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Number'
                    } 
                }
            },
			shop_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Name'
                    } 
                }
            }, 
			owner_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop owner name'
                    }
                }
            },
			 shop_contact: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Contact'
                    }
                }
            }, 
			shop_email: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Mail-Id'
                    }
                }
            },
			shop_gstno: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop GST Number'
                    }
                }
            },
			shop_address: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Address'
                    }
                }
            },
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#shop_form').data('bootstrapValidator').resetForm();
    });
	
	
	
	$('#register_shop_form').bootstrapValidator({
        fields: {

			shop_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Name'
                    } 
                }
            }, 
			owner_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop owner name'
                    }
                }
            },
			shop_contact: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Contact'
                    }
                }
            }, 
			shop_address: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Shop Address'
                    }
                }
            },
			 
			 
		},
        
    }).on('reset', function (event) {
        $('#register_shop_form').data('bootstrapValidator').resetForm();
    });
	
	

	$('#product_form').bootstrapValidator({
        fields: {

           product_name: {
                validators: {
                    notEmpty: {
                        message: 'Please Enter Product Name.'
                    } 
                }
            },
			product_company: {
                validators: {
                    notEmpty: {
                        message: 'Please Select Product Company.'
                    } 
                }
            }, 
			category_id: {
                validators: {
                    notEmpty: {
                        message: 'Please Select Product Category.'
                    } 
                }
            }, 
			subcategory_id: {
                validators: {
                    notEmpty: {
                        message: 'Please Select Product Sub-Category.'
                    } 
                }
            }, 

			 
		},
        
    }).on('reset', function (event) {
        $('#product_form').data('bootstrapValidator').resetForm();
    });
	
	  
	
});  
		
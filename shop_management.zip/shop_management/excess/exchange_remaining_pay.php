<?php
error_reporting(0);
require_once('../db_config/database_config.php');

	  $exchange_number = $_POST['exchange_number'];
	  $id = $_POST['id'];
	   
	  	 $query1="SELECT * FROM `exchange` WHERE exchange_number='$exchange_number'";
		$selbd1 = mysqli_query($conn, $query1) or die('query error');
		  $tra_row = mysqli_fetch_assoc($selbd1);
		 
	 
 ?>
<script>
$(function () {
	 
	 
	$('#due_date_picker').datepicker({
	  format: 'yyyy-mm-dd',
	  startDate: new Date()
	});
	var tdate = new Date();
	var ddate = new Date(tdate.setDate(tdate.getDate() + 10));	
	$("#due_date_picker").datepicker().datepicker("setDate", ddate);
});
 
</script>

<form class = "form-horizontal" autocomplete="off" action="javascript:void(0);" id="transaction_form" method="POST" onsubmit="add_payment();" name="transaction_form">
		<div class = "form-group">
		<input type="hidden" name="total_pay" value="<?=$tra_row['pay_amount']?>">
		<input type="hidden" id="id" name="id" class="form-control" value="<?=$id?>" readonly> 
		
			<label for = "dealername" class = "col-md-3 control-label">Shop Name:</label>
		<?php if($id=="in"){?>
		<input type="hidden" id="shop_id" name="shop_id" class="form-control" value="<?=$tra_row['from_shop']?>" readonly> 
		<?php } else if($id=="out"){?>
		<input type="hidden" id="shop_id" name="shop_id" class="form-control" value="<?=$tra_row['to_shop']?>" readonly> 
		<?php } ?>	
		<?php if($tra_row['to_shop']!='1') { ?>
		<div class = "col-md-4">
		
		<select  class="form-control"  required  disabled>
			 <option value="">-- Shop Name--</option>
		<?php 
		  $query="SELECT * FROM `about_shop`";
		$selbd = mysqli_query($conn, $query) or die('query error');
		while($emp_row = mysqli_fetch_assoc($selbd)){
		 ?>
		 <option value="<?=$emp_row['shop_id']?>" <?php if($emp_row['shop_id']==$tra_row['to_shop']){?> selected <?php } ?>><?=$emp_row['shop_name']?></option>
		<?php } ?>
		 </select>
		</div><?php } else if($tra_row['from_shop']!='1'){?>
		<div class = "col-md-4">
		 	 <select  class="form-control"  required  disabled>
			 <option value="">-- Shop Name--</option>
		<?php 
		  $query="SELECT * FROM `about_shop`";
		$selbd = mysqli_query($conn, $query) or die('query error');
		while($emp_row = mysqli_fetch_assoc($selbd)){
		 ?>
		 <option value="<?=$emp_row['shop_id']?>" <?php if($emp_row['shop_id']==$tra_row['from_shop']){?> selected <?php } ?>><?=$emp_row['shop_name']?></option>
		<?php } ?>
		 </select>
		</div>
		<?php } ?>
		</div>
		<div id="tra_info">
		<div class="form-group">
		  <label for="email" class = "col-md-3 control-label">Exchange No:</label>
		  
		  <div class = "col-md-4">
		  <input type="text" class="form-control" value="<?=$tra_row['exchange_number']?>" id="exchange_number" placeholder="Enter Exchange No" name="exchange_number" required readonly >
		  </div>
		</div>
		<div class="form-group">
		  <label for="email" class = "col-md-3 control-label">Balance Amount:</label>
		  
		  <div class = "col-md-4">
		  <input type="number" class="form-control" id="bal_amount" value="<?=$tra_row['bal_amount']?>" placeholder="Enter Amount" name="bal_amount"  readonly>
		  </div>
		</div>
		</div>
		<div class="form-group">
		  <label for="email" class = "col-md-3 control-label">Pay Amount:</label>
		  
		  <div class = "col-md-4">
		  <input type="number" class="form-control" id="pay_amount" placeholder="Enter Amount" name="pay_amount" onkeyup="calculation(this.value);" onchange="calculation(this.value);" onblur="calculation(this.value);" required>
		  </div>
		</div><div class="form-group">
		  <label for="email" class = "col-md-3 control-label">Remaining Amount:</label>
		  
		  <div class = "col-md-4">
		  <input type="number" class="form-control" id="remaining_amount" placeholder="Enter Amount" name="remaining_amount"  readonly>
		  </div>
		</div>
		<div class = "form-group">
				<label for = "quantity" class = "col-sm-3 control-label">Payment Type:</label>
			 <div class = "col-sm-4">
			<select name="payment_by" id="payment_by" class ="form-control" onchange="cheque_fun(this.value)" required>
			<option value="">-- Select Payment Type --</option>
			<option value="Cash">Cash</option>
			<option value="Credit">Credit</option>
			<option value="Cheque">Cheque</option>
			</select>  
			</div>
			</div>
			<div id="bank_details" style="display:none;">
			 <div  style="padding: 2% 0%;">
			<div class = "form-group">
				<label for = "quantity" class = "col-sm-3 control-label">Cheque No:</label>
			 <div class = "col-sm-4">
			  <input type="text" name="cheque_no" id="cheque_no" placeholder="Cheque No." class ="form-control"  >
			
			</div>
			</div>
			<div class = "form-group">
				<label for = "quantity" class = "col-sm-3 control-label">Bank Name:</label>
			 <div class = "col-sm-4">
			  <input type="text" name="bank_name" id="bank_name" placeholder="Bank Name" class ="form-control"  >
			
			</div>
			</div>
			 
			
			</div>
			</div>
			<div class = "form-group" id="due_date_box" style="display:none;">
				<label for = "quantity" class = "col-sm-3 control-label">Due Date:</label>
			 <div class = "col-sm-4	">
			 <div class='input-group date' id='due_date_picker'>
	      <input type = "text"  class ="form-control" id="due_date" name="due_date"  placeholder = "Select Due Date."  >
			<span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
	    
			</div>
			   </div>
			</div>
			<div style="text-align:center;">
			<div  class="box-footer clearfix no-border">  
			<button type="submit" id="btntra" class="btn btn-success"> Pay Now</button>
	
		  <button  type="reset" class="btn btn-danger" onclick="window.location.reload();">Cancel</button>
			</div>
			</div>
		</form>
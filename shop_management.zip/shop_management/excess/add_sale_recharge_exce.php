<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');	
//error_reporting(0);	
		 
	$user_id = $_SESSION['user_id']; 
	$current_date= date("Y-m-d");
	$sale_date= $_POST['sale_date'];
	$sale_operator_name= $_POST['sale_operator_name'];
	$sale_opening_balance= (int)$_POST['sale_opening_balance_hidden'];
	$sale_balance= $_POST['sale_balance'];
	$status=1;
	$sale_total_balance=$sale_opening_balance;
	$sale_closing_balance=$sale_opening_balance-$sale_balance;
	 
			
			$que ="INSERT INTO `purchase_sale_recharge`(`r_purchase_id`, `operator_name`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES (NULL,'$sale_operator_name',0,'$sale_total_balance','$sale_balance','$sale_closing_balance','$sale_date','$user_id','',CURRENT_TIMESTAMP,'0000-00-00 00:00:00','$status')";
			$insque = mysqli_query($conn,$que);
			
			// for find daily recharge insert or update
			$daily_date_query = "SELECT * FROM `daily_recharge` WHERE date='$sale_date' AND added_by IN ($users_ids)" ;
			$daily_date_res = mysqli_query($conn,$daily_date_query);
			if (mysqli_num_rows($daily_date_res) > 0) {
				
				//for find and update last opening balance
				$last_opening_query = "SELECT * FROM `daily_recharge` WHERE date < '$sale_date' AND added_by IN ($users_ids) ORDER BY daily_recharge_id DESC";
				$last_opening_res = mysqli_query($conn,$last_opening_query);
				$last_opening_data = mysqli_fetch_array($last_opening_res);
				if($last_opening_data['opening_balance']>0){
					$last_opening_balance = $last_opening_data['opening_balance'];
				}else{
					$last_opening_balance = 0;
				}
				
				
				//for find last closing balance
				$last_closing_query = "SELECT * FROM `daily_recharge` WHERE date='$sale_date' AND added_by IN ($users_ids) ORDER BY daily_recharge_id DESC";
				$last_closing_res = mysqli_query($conn,$last_closing_query);
				$last_closing_data = mysqli_fetch_array($last_closing_res);
				$last_sale_amount = $last_closing_data['sale_balance'];
				if($last_closing_data['closing_balance']>0){
					$last_closing_balance = $last_closing_data['closing_balance'];
				}else{
					$last_closing_balance = 0;
				}
				//daily total balance
				$daily_total_balance = $last_closing_balance - $sale_balance;
				$daily_total_sale_balance = $last_sale_amount + $sale_balance;
				$daily_que ="UPDATE `daily_recharge` SET `total_balance`='$daily_total_balance', `sale_balance`='$daily_total_sale_balance', `closing_balance`='$daily_total_balance', `updated_by`='$user_id', `updated_date`='$current_date' WHERE date='$sale_date'";
			}
			else{
				//for find last closing balance
				$last_closing_query = "SELECT * FROM `daily_recharge` WHERE date < '$sale_date' AND added_by IN ($users_ids) ORDER BY daily_recharge_id DESC";
				$last_closing_res = mysqli_query($conn,$last_closing_query);
				$last_closing_data = mysqli_fetch_array($last_closing_res);
				if($last_closing_data['closing_balance']>0){
					$last_closing_balance = $last_closing_data['closing_balance'];
				}else{
					$last_closing_balance = 0;
				}
				
				//daily total balance
				$daily_total_balance = $last_closing_balance - $sale_balance;
				$daily_que ="INSERT INTO `daily_recharge`(`daily_recharge_id`, `opening_balance`, `purchase_balance`, `total_balance`, `sale_balance`, `closing_balance`, `date`, `added_by`, `updated_by`, `added_date`, `updated_date`, `status`) VALUES (NULL,'$last_closing_balance',0,'$daily_total_balance','$sale_balance','$daily_total_balance','$sale_date','$user_id','',CURRENT_TIMESTAMP,'0000-00-00 00:00:00','$status')";
			}
			 
			 
			$inscat = mysqli_query($conn,$daily_que);
			if($inscat){
				echo 1;
			}else{
				echo 0;
			}
				 
			
		 
?>

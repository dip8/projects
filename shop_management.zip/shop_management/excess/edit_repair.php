<?php
require_once('../db_config/database_config.php');

	$repair_id = $_POST['id'];
	 
	$res = mysqli_query($conn,"SELECT * FROM `repair` WHERE `repair_id`='$repair_id'");
	$repair_row=mysqli_fetch_assoc($res);
	$customer_number=$repair_row['customer_number'];
	$category_id=$repair_row['category_id'];
	
	$resc = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_number`='$customer_number'");
	$customer_row=mysqli_fetch_assoc($resc);
	
	$resp = mysqli_query($conn,"SELECT * FROM `repair_payment_detail` WHERE `repair_id`='$repair_id'");
	$repair_payment=mysqli_fetch_assoc($resp);

	?>

<script>
$(function () {
	/* $('#customer_dob_picker_edit').datepicker({
	  format: 'yyyy-mm-dd'
	});
	$("#customer_dob_picker_edit").datepicker().datepicker("setDate", new Date()); */
	
	$('#due_date_picker_edit').datepicker({
	  format: 'yyyy-mm-dd'
	});
	//$("#due_date_picker_edit").datepicker().datepicker("setDate", new Date());
});


$(document).ready(function(){
	$(".remain_bal").on("keyup",function(){
		var approx_cost=$("#approx_cost").val();
		var advance_pay=$("#advance_pay").val();
		if(parseInt(approx_cost)<0)
		{
			$("#approx_cost").val(0);
		}
		if(parseInt(advance_pay)<0)
		{
			$("#advance_pay").val(0);
		}
		//alert(approx_cost);
		if(parseInt(approx_cost)>parseInt(advance_pay)){
			var balance=approx_cost-advance_pay;
			$("#balance").val(balance); 
			$("#balance_hidden").val(balance); 
			}else if(parseInt(advance_pay)>0) {
			$("#balance").val(approx_cost); 
			$("#balance_hidden").val(approx_cost); 
			$("#advance_pay").val(approx_cost); 
			}else{
				$("#balance").val(approx_cost); 
				$("#balance_hidden").val(approx_cost);
			}
	});
	$(".remain_bal").on("click",function(){
		var approx_cost=$("#approx_cost").val();
		var advance_pay=$("#advance_pay").val();
		if(parseInt(approx_cost)<0)
		{
			$("#approx_cost").val(0);
		}
		if(parseInt(advance_pay)<0)
		{
			$("#advance_pay").val(0);
		}
		//alert(approx_cost);
		if((parseInt(approx_cost)>parseInt(advance_pay)) && parseInt(advance_pay)>0){
			var balance=approx_cost-advance_pay;
			$("#balance").val(balance); 
			$("#balance_hidden").val(balance); 
		}else if(parseInt(advance_pay)>0 && parseInt(approx_cost)>0){
			$("#balance").val(approx_cost); 
			$("#balance_hidden").val(approx_cost); 
			$("#advance_pay").val(approx_cost); 
		}else if(parseInt(approx_cost)>0){
			$("#balance").val(approx_cost); 
			$("#balance_hidden").val(approx_cost);
		}
	});
});

</script>
	

<div class="col-md-12">
	 <form id="repairtupdate_form" onsubmit="return update_repair()" enctype="multipart/form-data"  autocomplete="off" method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
		<input type="hidden" value="<?=$repair_row['repair_id']?>" name="repair_id_edit" id="repair_id_edit">
		<div class="col-md-10 col-sm-offset-1">
			<div class="row" style="border: 1px solid #c1c1c1;background-color: #f5f5fa;">
				<div class="col-sm-12">
				<h4 class="info-text"> Customer Details</h4>
				</div>
	
			</div><br>

			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Enter Customer name:<span style="color:red;">*</span></label><br>
						<input type="text" class="form-control" value="<?=$customer_row['customer_name']?>" id="cust_name" name="cust_name" spellcheck="false"  placeholder="Customer Name" onkeypress="getCustomer(event)" onkeyup="getCustomer(event)" title="e.g. abc" readonly>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Enter Contact No:<span style="color:red;">*</span></label><br>
						<input class ="form-control" name="cust_contact" id="cust_contact" value="<?=$customer_row['mobile']?>" type="text" onkeypress="return IsNumeric(event);" placeholder="Enter Customer Mobile" readonly  />
					</div>	
				</div>
			</div>

			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Enter Date of Birth:</label><br>
						<div class='input-group date' id='customer_dob_picker_edit'>
						<input type='text' name="cust_dob" id="cust_dob" class="form-control" value="<?=date("Y-m-d", strtotime($customer_row['date_of_birth']))?>" readonly />
						<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
						</span>
						</div>
					</div>
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Enter Address:<span style="color:red;">*</span></label><br>
						<textarea class ="form-control" rows="3" pattern="([A-z0-9À-ž\s]){2,}" name="cust_address" id="cust_address" placeholder = "Enter Address" readonly><?=$customer_row['address']?></textarea>
					</div>
					
				</div>
			</div>
			 
			<!-------------2--------------->
			
			<div class="row" style="border: 1px solid #c1c1c1;background-color: #f5f5fa;">
				<div class="col-sm-12">
				<h4 class="info-text"> Product Details</h4>
				</div>
	
			</div><br>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Categories:<span style="color:red;">*</span></label><br>
						<select  id="cat_id" name="cat_id" class = "form-control" onchange="subcat_selectf(this.value)" required>
						  <option value="">-- Select Categories --</option>
						  <?php 
						   $cat_query = "SELECT * FROM `category`";
								$cat_res = mysqli_query($conn,$cat_query);
								 
								while($cat_data = mysqli_fetch_assoc($cat_res))
										{
								 ?>
								<option <?php if($repair_row['category_id']==$cat_data['category_id']){echo 'selected';}?> value="<?=$cat_data['category_id']?>"><?=$cat_data['category_name']?></option>
										<?php } ?>
						  </select>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Sub-Categories:<span style="color:red;">*</span></label><br>
						<div   id="subcat_select">
						  <select  id="sub_cat_id" name="sub_cat_id" class = "form-control">
						  <option value="">-- Select Sub-Categories --</option>
						  <?php 
							$ressuct = mysqli_query($conn,"SELECT * FROM `sub_category` WHERE category_id=$category_id ");
							while($subcat_row = mysqli_fetch_assoc($ressuct))
							{?>
							<option <?php if($repair_row['sub_category_id']==$subcat_row['sub_category_id']){echo 'selected';}?> value="<?php echo $subcat_row['sub_category_id'] ?>"><?php echo $subcat_row['sub_category_name'] ?></option>
							<?php } ?>
						   </select>
						</div>
					</div>	
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Company / Brand:<span style="color:red;">*</span></label><br>
						<input type="text" class="form-control" value="<?=$repair_row['product_brand']?>" id="company_name" name="company_name"  spellcheck="false"  placeholder="Company Name" onkeypress="getCompany(event)" onkeyup="getCompany(event)" title="e.g. Samsung" required>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Model / Product Name:<span style="color:red;">*</span></label><br>
						<input class ="form-control" name="model_name" id="model_name"  type="text" value="<?=$repair_row['product_model']?>" placeholder="Model / Product name" onkeypress="getModel(event)" onkeyup="getModel(event)" title="e.g. Galaxy J7" required />
					</div>	
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Product Description:<span style="color:red;">&nbsp;</span></label><br>
						<textarea class ="form-control" rows="3" pattern="([A-z0-9À-ž\s]){2,}" name="product_description" id="product_description" placeholder = "Enter Product Description" ><?=$repair_row['product_description']?></textarea>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Product Issue:<span style="color:red;">&nbsp;</span></label><br>
						<textarea class ="form-control" rows="3" pattern="([A-z0-9À-ž\s]){2,}" name="product_issue" id="product_issue" placeholder = "Enter Product Issue" ><?=$repair_row['product_issue']?></textarea>
					</div>	
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Due Date:<span style="color:red;">&nbsp;</span></label><br>
						<div class='input-group date' id='due_date_picker_edit'>
						<input type='text' value="<?=date("Y-m-d", strtotime($repair_row['due_date']))?>" name="due_date" id="due_date" class="form-control" />
						<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
						</span>
						</div>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
						
				</div>
			</div>
			
			<!-------------3--------------->
			
			<div class="row" style="border: 1px solid #c1c1c1;background-color: #f5f5fa;">
				<div class="col-sm-12">
				<h4 class="info-text"> Payment Details</h4>
				</div>
	
			</div><br>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Approx Cost:<span style="color:red;">&nbsp;</span></label><br>
						<input class ="remain_bal form-control" name="approx_cost" id="approx_cost" value="<?=$repair_payment['approx_cost']?>" type="number" placeholder="Approx cost" required />
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Advance Pay:<span style="color:red;">&nbsp;</span></label><br>
						<input class =" remain_bal form-control" name="advance_pay" id="advance_pay" value="<?=$repair_payment['advance_pay']?>" type="number" value="0" placeholder="Advance Pay" />
					</div>	
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Payment Type:<span style="color:red;">&nbsp;</span></label><br>
						<select name="payment_by" id="payment_by" class ="form-control" onchange="cheque_fun(this.value)"  >
						<option value="">-- Select Payment Type --</option>
						<option selected value="Cash">Cash</option>
						<option value="Credit">Credit</option>
						<option value="Cheque">Cheque</option>
						</select>
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Balance:<span style="color:red;">&nbsp;</span></label><br>
						<input class ="form-control" name="balance" id="balance"  type="number" placeholder="Balance" value="<?=$repair_payment['balance']?>" disabled />
						<input class ="form-control" name="balance_hidden" id="balance_hidden"  type="hidden" placeholder="Balance" />
					</div>	
				</div>
			</div>
			
			 
			<div class="row" id="bank_details" style="display:none;">
				<div class="col-sm-5">
					<div class="form-group label-floating">
						<label class="control-label">Cheque number:<span style="color:red;">*</span></label><br>
						<input type="text" name="cheque_no" id="cheque_no" value="<?=$repair_payment['cheque_no']?>" placeholder="Cheque No." class ="form-control"  >
					</div>	
				</div>
				<div class="col-sm-5 col-sm-push-1">
					<div class="form-group label-floating">
						<label class="control-label">Bank Name:<span style="color:red;">*</span></label><br>
						<input type="text" name="bank_name" id="bank_name" value="<?=$repair_payment['bank_name']?>" placeholder="Bank Name" class ="form-control"  >
					</div>	
				</div>
			</div>
			
			<div class="row" style="text-align:center;">
				<div  class="box-footer clearfix no-border">
				<button type="submit" id="btnupdateproduct" class="btn btn-primary"><i class="fa fa-plus"></i> Update</button>
				<a href="" class="btn btn-danger">Cancel</a>
				</div>
			</div>
			
		</div>
		</form>
    </div>
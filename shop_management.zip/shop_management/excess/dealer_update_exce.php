<?php
session_start();

require_once('../db_config/database_config.php');
error_reporting(0);				
			 
			  $supplier_id= $_POST['supplier_id'];
			  $dealer_id= $_POST['dealer_id'];
			$dealer_name= $_POST['dealer_name'];
			$brand_s= $_POST['brand'];
			$dealer_gst_no = $_POST['dealer_gst_no']; 
			 
			$email= strtolower($_POST['email']);
			$address= $_POST['address'];
			$contact= $_POST['contact_no'];
			$c_person= $_POST['c_person'];
			 $user_id = $_SESSION['user_id']; 
			 

		 $brand=implode(",",$brand_s);
				 $que ="UPDATE `supplier` SET `supplier_name`='$dealer_name',`supplier_address`='$address',`contact_number`='$contact',`email_id`='$email',`supplier_for`='$brand',`update_date`=NULL,`updated_by`='$user_id',`status`=1,`dealer_gst_no`='$dealer_gst_no' WHERE supplier_id='$supplier_id'";
				 $insprofile = mysqli_query($conn,$que);
			 
			 if($insprofile){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
?>

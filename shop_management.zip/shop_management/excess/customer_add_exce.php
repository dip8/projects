<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
			$cust_name= $_POST['cust_name'];
			$email_id= $_POST['email_id'];
			 
			$contact_no= $_POST['contact_no'];
			$cust_gst_no= $_POST['cust_gst_no'];
			 
			$birth_date= $_POST['birth_date'];
			if($birth_date==''){
				$birth_date='0000-00-00 00:00:00';
			}
			$wedd_date= $_POST['anniversary_date'];
			if($wedd_date==''){
				$wedd_date='0000-00-00 00:00:00';
			}
			$address= $_POST['address'];
			 
			$document = $_FILES['document']['name'];
			$user_id = $_SESSION['user_id'];
		 	 

		if($document=="")
			{
				$que ="INSERT INTO `customer` (`customer_id`, `customer_number`, `customer_name`, `mobile`, `email_id`, `address`, `id_proof`, `date_of_birth`, `wedding_date`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `customer_gst_no`) VALUES (NULL, '', '$cust_name', '$contact_no', '$email_id', '$address', '', '$birth_date', '$wedd_date', '0', CURRENT_TIMESTAMP, '$user_id', '0000-00-00 00:00:00', '', '1', '$cust_gst_no')";	
				$insprofile = mysqli_query($conn, $que);					  
				
			}
		 
			else
				{
					//profile pic
				$temp = explode(".", $_FILES["document"]["name"]);
				$newfilename1 =  $cust_name.'_'.round(microtime(true)).'.' . end($temp);
				$folder = "../img/customer/";
				move_uploaded_file($_FILES["document"]["tmp_name"] , "$folder".$newfilename1);
				
				$que ="INSERT INTO `customer` (`customer_id`, `customer_number`, `customer_name`, `mobile`, `email_id`, `address`, `id_proof`, `date_of_birth`, `wedding_date`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `customer_gst_no`) VALUES (NULL, '', '$cust_name', '$contact_no', '$email_id', '$address', '$newfilename1', '$birth_date', '$wedd_date', '0', CURRENT_TIMESTAMP, '', '0000-00-00 00:00:00', '', '1', '$cust_gst_no')";	
				$insprofile = mysqli_query($conn, $que);
				 
				}
				
				$emp_last_insert = mysqli_insert_id($conn);
				 
				$exportId = str_pad($emp_last_insert, 11, '0', STR_PAD_LEFT);
				$cust_no='Cust-'.$exportId;
				$update_id = mysqli_query($conn, "UPDATE `customer` SET `customer_number`='$cust_no' WHERE `customer_id`='$emp_last_insert'");
			  
			 if($update_id){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
				
			   
?>

<?php
session_start();
require_once('../db_config/database_config.php');
			 $supplier_id= $_POST['id'];
?>
	<select id="company_id" name="company_id" class = "form-control">
	  <option value="">-- Select Company / Brand --</option>
	  <?php 
		$com_query11 = "SELECT * FROM `supplier` where supplier_id=$supplier_id";
		$com11 = mysqli_query($conn,$com_query11);
		$rs11 = mysqli_fetch_assoc($com11); 
		   
		$company_id=$rs11['supplier_for'];
		$com_query = "SELECT * FROM `company` where company_id IN($company_id)";
		$com_res = mysqli_query($conn,$com_query);
		while($com_data = mysqli_fetch_assoc($com_res)){
		?>
		<option value="<?=$com_data['company_id']?>"><?=$com_data['company_name']?></option>
		<?php } ?>
	  </select>
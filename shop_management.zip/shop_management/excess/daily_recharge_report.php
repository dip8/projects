<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
error_reporting(0);	
$from_date=$_POST['from_date'];
  $to_date=$_POST['to_date'];
?>
		<table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
			<thead>
			 <tr>
			  <th>Sr No:</th>
			  <th>Date</th>
			  <th>Opening Balance</th>
			  <th>purchase balance</th>
			  <th>Total balance</th>
			  <th>sale balance</th>
			  <th>closing balance</th> 
			  <th>Download pdf</th>				  
			</tr>
			</thead>
			<tbody id="search_res">

			<?php 
			$tra_query = "SELECT * FROM `daily_recharge` WHERE date BETWEEN '$from_date' AND '$to_date' AND added_by IN ($users_ids) ORDER BY date DESC";
			$tra_res = mysqli_query($conn,$tra_query);
			$i=0;
			while($total_daily_data = mysqli_fetch_assoc($tra_res))
				{ ?>
				<tr>
				<td><?php echo ++$i;?></td>
				<td><?php echo $total_daily_data['date'];?></td>
				<td><?php echo $total_daily_data['opening_balance'];?></td>
				<td><?php echo $total_daily_data['purchase_balance']; ?></td>
				<td><?php echo $total_daily_data['total_balance'];?></td>
				<td><?php echo $total_daily_data['sale_balance'];?></td>
				<td><?php echo $total_daily_data['closing_balance'];?></td>
				<td>
					<a  class="btn btn-info btn-xs" onclick="pdf_download('<?php echo $total_daily_data['date']; ?>');">
					<i class="fa fa-download" title="PDF Download" style="font-size:18px;text-align: center;"></i></a>
				</td>
				</tr>
			<?php } ?>
			</tbody>
		</table>
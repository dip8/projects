<?php
session_start();
require_once('../db_config/database_config.php');
				 
		$financer_id= $_POST['financer_id'];
		$financer_name= $_POST['financer_name'];

		$que ="UPDATE `financer` SET `financer_name`='$financer_name' WHERE financer_id='$financer_id'";
		$insprofile = mysqli_query($conn,$que);
			 
		if($insprofile){
			  echo 1;
		}else{
			  echo 0;
		}
?>


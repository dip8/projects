<?php
	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $customer_id=$_REQUEST['customer_id'];
    
    $query=mysqli_query($conn,"select * from customer where customer_id='$customer_id'");
     $row=mysqli_fetch_assoc($query);
?>
		<div class="col-md-12">	 
			<table class="table">
				<tr>
				<th>Name</th>
				<td><?=$row['customer_name']?></td>
				</tr>
				
				<tr>
				<th>Contact No</th>
				<td><?=$row['mobile']?></td>
				</tr>
				<tr>
				<th>Email Id</th>
				<td><?=$row['email_id']?></td>
				</tr>
				
				<tr>
				<th> Address</th>
				<td><?=$row['address']?></td>
				</tr>
				
				<tr>
				<th>Birth Date</th>
					<td><?=$row['date_of_birth']?></td>
				</tr>
				
				<tr>
				<th>Wedding Date</th>
				<td><?=$row['wedding_date']?></td>
				</tr>
				 
			</table>
		</div>	 
    

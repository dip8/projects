<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
error_reporting(0);	
$from_date=$_POST['from_date'];
  $to_date=$_POST['to_date'];
?>
	<table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Purchase No</th>
                  <th>Purchase Date</th>
                  <th>Dealer Name</th>
                  <th>Type</th>
                  <th>Total Amount</th>
				  
                  <th>Total Payment</th>
				  <th>Balance Amount</th>
                  <th>Due Date</th>
				  <th>View Product </th>
				  
                </tr>
                </thead><tbody id="search_res">
 
					<?php 
				 $tra_query = "SELECT * FROM `purchase` WHERE purchase_date BETWEEN '$from_date' AND '$to_date' AND added_by IN ($users_ids) ORDER BY purchase_id DESC";
			$tra_res = mysqli_query($conn,$tra_query);
			$i=0;
			while($tra_data = mysqli_fetch_assoc($tra_res))
					{
						 
					 $supplier_id=$tra_data['supplier_id'];
					 $purchase_number=$tra_data['purchase_number'];
				 
					     
						$traq = mysqli_query($conn,"SELECT * FROM `payment_transaction` WHERE `ref_id`='$purchase_number'");
						$tral=mysqli_fetch_assoc($traq);
						$due_date= $tral['due_date'];
						 
						
						$supp_q = mysqli_query($conn,"SELECT * FROM `supplier` WHERE `supplier_id`='$supplier_id'");
						$sup_data= mysqli_fetch_assoc($supp_q);
						$supplier_name=$sup_data['supplier_name'];
						 
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$tra_data['purchase_number']?></td>
                  <td><?=$tra_data['purchase_date']?></td>
				  <td><?=$supplier_name?></td>
                  <td><?php if($tra_data['type']==1){ echo "A"; } else { echo "C"; }?></td>
                  <td><?=$tra_data['total_amount']?></td>
                  <td><?=$tra_data['total_payment']?></td>
				  <td><?=$tra_data['total_balance']?></td>
				  <td><?=$due_date?></td>
                  
				   <td>
					<a  class="btn btn-success btn-xs" onclick="view_details('<?php echo $tra_data['purchase_number']; ?>');">
					<i class="glyphicon glyphicon-eye-open" title="View product" style="font-size:18px;text-align: center;"></i></a>
				  </td>
                  
                  
                 
                  
                </tr>
                 
                
                
					<?php } ?></tbody></table>
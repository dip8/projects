<?php
  error_reporting(0);
require_once('../db_config/database_config.php');
	session_start();		
			
			$bill_date= $_POST['bill_date'];

			$customer_id= $_POST['customer_id'];
			
			$user_id = $_SESSION['user_id']; 
			
			$product_id= $_POST['hid_product_id'];
			$product_name= $_POST['product_name'];
			$product_qty= $_POST['product_qty'];
			$total= $_POST['total'];

			if(isset($_POST['imei_no']) && $_POST['imei_no']!="" && $_POST['imei_no']!=NULL){
				$imei_no= $_POST['imei_no'];
			} 
			
			$sub_tamt= $_POST['sub_tamt'];
			$gst_amt= $_POST['gst_amt'];
			$sub_total= $_POST['sub_total'];
			$paid_amt= $_POST['paid_amt'];
			$balance_amt= $_POST['balance_amt'];
			$final_total_amount=$_POST['payable_amt'];
			 
			$payment_type= $_POST['payment_type'];
			$cheque_no= $_POST['cheque_no'];
			$bank_name= $_POST['bank_name'];
			$finance_name= $_POST['finance_name'];
			$down_payment= $_POST['down_payment'];
			$emi_amt= $_POST['emi_amt'];
			$emi_duration= $_POST['emi_duration'];

			if(isset($_POST['due_date']) && $_POST['due_date']!="" && $_POST['due_date']!=NULL){
			if($balance_amt==0){
			$due_date="0000-00-00";
				}
				else {
			   $due_date = $_POST['due_date'];
				}
			 
			}else{
				$due_date= '0000-00-00';
			}
			
			
				$que12 ="INSERT INTO `customer_return`(`return_id`, `return_number`, `return_date`, `customer_id`, `notes`, `total_amount`, `total_payment`, `total_balance`, `discount_type`, `discount_percentage`, `discount_amount`, `gst_percentage`, `gst_amount`, `gst_description`, `final_total_amount`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES (NULL, '', '$bill_date', '$customer_id', '', '$sub_tamt', '$paid_amt', '$balance_amt', '', '0', '0', '0', '0', '', '$final_total_amount', CURRENT_TIMESTAMP,'$user_id', '0000-00-00 00:00:00', '')";
			
				$insproduct12 = mysqli_query($conn,$que12);
			 	 $re_id=mysqli_insert_id($conn);
				 $re_num = str_pad($re_id, 13, '0', STR_PAD_LEFT);
				$return_number='Return-'.$re_num;
				
				$uptabt = mysqli_query($conn,"UPDATE `customer_return` SET `return_number`='$return_number' WHERE `return_id`='$re_id'");
				 
				$i=0;	
				foreach ($product_name as $value) {
				$value = trim($value);
				if(empty($value)){
					
				}
				else
				{

				$que ="INSERT INTO `customer_return_detail`(`return_d_id`, `return_number`, `customer_number`, `product_number`, `imei_no`, `sales_quantity`, `purchasing_price`, `sales_price`, `gst_percentage`, `gst_amount`, `sales_total_amount`) VALUES(NULL,'$return_number','$customer_id','$product_id[$i]','$imei_no[$i]','$product_qty[$i]','0','0', '', '','$total[$i]')";
				 $inssales = mysqli_query($conn,$que);
				
				 
				$update_product_qty = mysqli_query($conn, "UPDATE `product` SET `quantity`=quantity+$product_qty[$i] WHERE `product_id`='$product_id[$i]'");
				
				$update_imei_no = mysqli_query($conn, "UPDATE `mobile_imei` SET `status`='1' WHERE `imei_no`='$imei_no[$i]'");
				
				}
				$i++;
				}
				 
				$que2 ="INSERT INTO `customer_return_payment_transaction`(`payment_id`, `ref_id`, `type`, `customer_number`, `supplier_number`,`payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES(NULL, '$return_number', 'return', '$customer_id', '', '$payment_type', '$final_total_amount', '$paid_amt', '$balance_amt', '$due_date', '$bill_date', CURRENT_TIMESTAMP, '$user_id', '0000-00-00 00:00:00', '')";
				$insproduct2 = mysqli_query($conn,$que2);
				$payment_tra_id=mysqli_insert_id($conn);
				
				if($_POST['payment_type'] == "Cheque")
				{
					$que21 ="INSERT INTO `customer_return_payment_details`(`payment_d_id`, `type`, `payment_tra_id`, `payment_type`, `bank_name`, `cheque_no`, `finance_type`, `down_payment`, `emi`, `duration`, `payment_date`, `status`) VALUES(NULL, 'return','$payment_tra_id', '$payment_type', '$bank_name', '$cheque_no', '', '', '', '', CURRENT_TIMESTAMP, '1')";
				 $insproduct21 = mysqli_query($conn,$que21);
				} 
				
				$quesup ="SELECT * FROM `customer` where customer_id='$customer_id'";
				$quesup_q = mysqli_query($conn,$quesup);
				$quesup_r=mysqli_fetch_assoc($quesup_q);
				$balance_sup=$quesup_r['balance'];
				if($balance_sup>$balance_amt)
				{
					$bal_sup=$balance_sup-$balance_amt;
				}else{
					$bal_sup=$balance_amt-$balance_sup;
				}
				
			 
				$a=mysqli_query($conn,"UPDATE `customer` SET `balance`='$bal_sup' where customer_id='$customer_id'");
			 
				
			 if($insproduct2){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }  
?>

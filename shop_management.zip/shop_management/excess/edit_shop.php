<?php
require_once('../db_config/database_config.php');

	$shop_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `about_shop` WHERE `shop_id`='$shop_id'");
	 
		$shop_data=mysqli_fetch_assoc($res);	
	 
	?>

 	
<form id="shopupdate_form" onsubmit="return update_shop()"  autocomplete="off" enctype="multipart/form-data" method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <input type="hidden" name="shop_id" id="shop_id" value="<?=$shop_data['shop_id']?>">
	<div class="col-md-6">
	   <div class = "form-group">
		  <label class = "col-sm-4 control-label">Shop Number:</label>
			
		  <div class = "col-sm-8">
			 <input type = "text" value="<?php echo $shop_data['shop_number'];?>" class = "form-control" pattern="([A-z0-9À-ž\s]){2,}" id="shop_number" name="shop_number"  data-bind="value:Id" placeholder = "Enter Shop Number" >
		  </div>
	   </div>
	   
	   <div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">Shop Name:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['shop_name'];?>"  id="shop_name" placeholder="Enter Shop Name" name="shop_name" required>
		  </div>
		</div>
		
		<div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">Owner name:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['owner_name'];?>"  id="owner_name" placeholder="Enter Owner Name" name="owner_name" required>
		  </div>
		</div>
	   
	   
	   <div class = "form-group">
		  <label for = "quantity" class = "col-sm-4 control-label">Shop Contact No.:</label>
			
		  <div class = "col-sm-8">
			 <input type ="number" value="<?php echo $shop_data['shop_contact'];?>"  class ="form-control" id="shop_contact" name="shop_contact" data-bind="value:quantity" placeholder = "Enter Contact No." required>
		  </div>
	   </div>
	   
	   <div class = "form-group">
		  <label for = "quantity" class = "col-sm-4 control-label">Shop Email-Id.:</label>
			
		  <div class = "col-sm-8">
			 <input type ="email" value="<?php echo $shop_data['shop_email'];?>"  class ="form-control" id="shop_email" name="shop_email"  placeholder = "Enter Email-Id" >
		  </div>
	   </div>
   
	</div>
 
	<div class="col-md-6">	
		<div class = "form-group" >
			<label for ="price" class = "col-sm-4 control-label">Shop Address:</label>
			
			<div class = "col-sm-8">
			<textarea class = "form-control" rows="3" name="shop_address" id="shop_address" pattern="([A-z0-9À-ž\s]){2,}" placeholder = "Enter Address" required><?php echo $shop_data['shop_address']; ?></textarea>
			</div>
		</div>
	   
		<div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">GST Number:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['shop_gstno'];?>"  id="shop_gstno" placeholder="Enter GST Number" name="shop_gstno">
		  </div>
		</div>
		
		<div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">PAN Number:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['shop_pan'];?>"  id="shop_pan" placeholder="Enter PAN Number" name="shop_pan">
		  </div>
		</div>
		
		
		<div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">VAT Number:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['shop_van'];?>"  id="shop_van" placeholder="Enter VAT Number" name="shop_van">
		  </div>
		</div>
		
		
		<div class="form-group">
		  <label for="email" class = "col-sm-4 control-label">Shop Website:</label>
		  
		  <div class = "col-sm-8">
		  <input type="text" class="form-control" value="<?php echo $shop_data['shop_website'];?>"  id="shop_website" placeholder="Enter Shop Website" name="shop_website">
		  </div>
		</div>
		
	   
	</div>

			<div class="col-md-12 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdateshop" class="btn btn-primary"><i class="fa fa-plus"></i>Update Shop</button>
		
			<a href="" class="btn btn-danger">Cancel</a>
		</div>
			</div>
	 </form> 
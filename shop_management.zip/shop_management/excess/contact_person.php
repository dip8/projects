<?php
session_start();
require_once('../db_config/database_config.php');
			
			 $key=$_REQUEST['term'];
			  $supplier_id= $_REQUEST['supplier_id'];
			   $array = array();
			    $con_query = "SELECT * FROM `contact_person` WHERE supplier_id='$supplier_id' and contact_name LIKE '%{$key}%'";
				$query=mysqli_query($conn,$con_query);
				while($row=mysqli_fetch_assoc($query))
				{
				//echo $row['contact_name'];
				  $array[]=array(
								'value'=> $row["contact_name"],
								'label'=>$row["contact_name"], 
								'phone'=>$row["contact_phone"]
									); 
				}
				$json = json_encode($array);
				print_r($json); 
?>			  
  
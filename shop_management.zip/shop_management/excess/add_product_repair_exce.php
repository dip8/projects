<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
//error_reporting(0);
			$cust_name= $_POST['cust_name'];
			$cust_contact= $_POST['cust_contact'];
			//$cust_dob= $_POST['cust_dob'];
			$cust_gst_no= '';
			$cust_address= $_POST['cust_address'];

			//$contact_id= $_POST['contact_id'];
			$cat_id= $_POST['cat_id'];
			$sub_cat_id= $_POST['sub_cat_id'];
			$company_name= $_POST['company_name'];
			$model_name= $_POST['model_name'];
			
			$user_id = $_SESSION['user_id']; 
			
			$product_description= $_POST['product_description'];
			$product_issue= $_POST['product_issue'];
			
			if(isset($_POST['due_date']) && $_POST['due_date']!="" && $_POST['due_date']!=NULL){
				$due_date = $_POST['due_date'];		 
			}else{
				$due_date= '0000-00-00';
			}
			
			if(isset($_POST['return_date']) && $_POST['return_date']!="" && $_POST['return_date']!=NULL){
				$return_date = $_POST['return_date'];		 
			}else{
				$return_date= '0000-00-00';
			}
			 
			//$return_date= '0000-00-00';
			
			$approx_cost= $_POST['approx_cost'];
			$advance_pay= $_POST['advance_pay'];
			
			$payment_type= $_POST['payment_by'];
			$balance= $_POST['balance_hidden'];
			$cheque_no= $_POST['cheque_no'];
			$bank_name= $_POST['bank_name'];
			$status= 1;
			
		
			
			//customer number
			$ques="select * from customer where mobile='$cust_contact' AND added_by IN ($users_ids)";
			$query = mysqli_query($conn,$ques);
			$row = mysqli_affected_rows($conn);
			if($row>0)
				{
				$custrow= mysqli_fetch_assoc($query);
				$customer_id=$custrow['customer_id'];
				$customer_number=$custrow['customer_number'];
				}
				else
				{
				$que ="INSERT INTO `customer` (`customer_id`, `customer_number`, `customer_name`, `mobile`, `email_id`, `address`, `id_proof`, `date_of_birth`, `wedding_date`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `customer_gst_no`) VALUES (NULL, '', '$cust_name', '$cust_contact', '', '$cust_address', '', '$cust_dob', '0000-00-00', '0', CURRENT_TIMESTAMP, '$user_id', '0000-00-00 00:00:00', '', '1', '$cust_gst_no')";	
				$inscustomer = mysqli_query($conn, $que);
				$customer_id=mysqli_insert_id($conn);
				$cust_num = str_pad($customer_id, 11, '0', STR_PAD_LEFT);
				$customer_number='Cust-'.$cust_num;
				
				$update_cust_id = mysqli_query($conn, "UPDATE `customer` SET `customer_number`='$customer_number' WHERE `customer_id`='$customer_id'");
				}
			
				//insert product repair query
				$que = "INSERT INTO `repair` (`repair_id`, `customer_number`, `repair_payment_id`, `category_id`, `sub_category_id`, `product_brand`, `product_model`, `product_description`, `product_issue`, `due_date`, `return_date`, `added_by`, `updated_by`, `added_date`, `update_date`, `status`) VALUES (NULL, '$customer_number', '', '$cat_id', '$sub_cat_id', '$company_name', '$model_name', '$product_description', '$product_issue', '$due_date', '$return_date', '$user_id', '', CURRENT_TIMESTAMP, '0000-00-00 00:00:00', '$status');";
			 	$insproduct = mysqli_query($conn,$que);
			
				$last_repair_id=mysqli_insert_id($conn);
				
				
				$que2 ="INSERT INTO `repair_payment_detail`(`repair_payment_id`, `customer_number`, `repair_id`, `approx_cost`, `advance_pay`, `balance`, `total_payment`, `payment_type`, `bank_name`, `cheque_no`, `transaction_date`, `added_date`, `update_date`, `added_by`, `updated_by`) VALUES(NULL, '$customer_number', '$last_repair_id', '$approx_cost', '$advance_pay', '$balance', '$approx_cost', '$payment_type', '$bank_name', '$cheque_no', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, '0000-00-00 00:00:00', '$user_id', '')";
				$insproduct2 = mysqli_query($conn,$que2);
				$payment_tra_id=mysqli_insert_id($conn);
			
				$update_repair_id = mysqli_query($conn, "UPDATE `repair` SET `repair_payment_id`='$payment_tra_id' WHERE `repair_id`='$last_repair_id'");
			
				
				if($insproduct){
					 echo 1;
				 }
				 else{
					  echo 0;
				  }  
?>

<?php
require_once('../db_config/database_config.php');
session_start();
$e_id = $_POST['id'];
$status = $_POST['status'];	 
$title = $_POST['title'];	 
$user_id = $_SESSION['user_id']; 
	
	if($title=="user"){
		$updates = "update user set status='$status' WHERE user_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="user_level"){
		$updates = "update user_level set status='$status' WHERE u_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
		
	if($title=="dealer"){
		$updates = "update supplier set status='$status', update_date=NULL, updated_by='$user_id' WHERE supplier_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	if($title=="customer"){
		$updates = "update customer set status='$status', update_date=NULL, updated_by='$user_id' WHERE customer_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	if($title=="product"){
		$updates = "update product set status='$status', update_date=NULL, updated_by='$user_id' WHERE product_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	if($title=="company"){
		$updates = "UPDATE `company` SET `status`='$status' WHERE company_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="category"){
		$updates = "UPDATE `category` SET `status`='$status' WHERE category_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
    if($title=="area"){
		$updates = "UPDATE `area` SET `status`='$status' WHERE area_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="sub_category"){
		$updates = "UPDATE `sub_category` SET `status`='$status' WHERE sub_category_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	if($title=="contact"){
		$updates = "UPDATE `contact_person` SET `status`='$status' WHERE contact_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	}
	
	
	if($upt){
		echo 1;
	}else{
		echo 0;
	}
?>

	
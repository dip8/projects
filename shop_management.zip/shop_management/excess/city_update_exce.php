<?php
session_start();
require_once('../db_config/database_config.php');
				 
		$city_id= $_POST['city_id'];
		$city_name= $_POST['city_name'];

		$que ="UPDATE `city` SET `city_name`='$city_name' WHERE city_id='$city_id'";
		$insprofile = mysqli_query($conn,$que);
			 
		if($insprofile){
			  echo 1;
		}else{
			  echo 0;
		}
?>


<?php
error_reporting(0);
require_once('../db_config/database_config.php');
	session_start();		
		$users_ids = $_SESSION['multi_users_ids'];
		
			$type= $_POST['type'];
			$bill_date= $_POST['bill_date'];
			//$customer_id= $_POST['customer_id'];
			$cust_name= $_POST['cust_name'];
			$cust_contact= $_POST['cust_contact'];
			$cust_address= $_POST['cust_address'];
			$cust_dob= $_POST['cust_dob'];
			$cust_gst_no= $_POST['cust_gst_no'];

			$contact_id= $_POST['contact_id'];
			  $category_id= $_POST['cat_id'];
			 $pro_type= $_POST['pro_type'];
			$subcategory_id= $_POST['sub_cat_id'];
			$product_company= $_POST['company_id'];
			
			$user_id = $_SESSION['user_id']; 
			
		  $product_id= $_POST['hid_product_id'];
			// print_r($product_id);
			$supplier_id= $_POST['hid_supplier_number'];
			$product_name= $_POST['product_name'];
			$product_qty= $_POST['product_qty'];
			$product_price= $_POST['product_price'];
		    $product_gst= $_POST['product_gst'];
			$total= $_POST['total'];
			
			if(isset($_POST['imei_no']) && $_POST['imei_no']!="" && $_POST['imei_no']!=NULL){
				$color= $_POST['color_name'];
				$imei_no= $_POST['imei_no'];
				$battery_no= $_POST['battery_no'];
				$charger_no= $_POST['charger_no'];
			} 
			
			$sub_tamt= $_POST['sub_tamt'];
			$gst_amt= $_POST['gst_amt'];
			$sub_total= $_POST['sub_total'];
			  $disc_amt= $_POST['disc_amt'];
			  $min_sale_cost= $_POST['min_sale_cost'];
			  $hid_sale_price= $_POST['hid_sale_price'];
			$disc_perc= $disc_amt/$sub_total*100;
			$paid_amt= $_POST['paid_amt'];
			$balance_amt= $_POST['balance_amt'];
			$final_total_amount=$_POST['payable_amt'];
			 
			$payment_type= $_POST['payment_type'];
			$cheque_no= $_POST['cheque_no'];
			$bank_name= $_POST['bank_name'];
			$finance_name= $_POST['finance_name'];
			$down_payment= $_POST['down_payment'];
			$emi_amt= $_POST['emi_amt'];
			$emi_duration= $_POST['emi_duration'];

			if(isset($_POST['due_date']) && $_POST['due_date']!="" && $_POST['due_date']!=NULL){
			$due_date= $_POST['due_date'];
			}else{
				$due_date= '0000-00-00';
			}
		$ques="SELECT * FROM about_shop_own WHERE admin IN ($users_ids)";
			$query = mysqli_query($conn,$ques);
			$shop_data= mysqli_fetch_assoc($query);

			$quesb="select MAX(sales_id) AS b_id from sales ";
			$queryb = mysqli_query($conn,$quesb);
			$bill_data= mysqli_fetch_assoc($queryb);
			$b_id=$bill_data['b_id'];
			$bl_id=$b_id+1;
			 $bill_no = str_pad($bl_id, 13, '0', STR_PAD_LEFT);	
			$bill_number='Bill-'.$bill_no;	
			
			$uques="select * from user WHERE user_id='$user_id' ";
			$uquery = mysqli_query($conn,$uques);
			$user_data= mysqli_fetch_assoc($uquery);
			
?>
<style>
@page { size: auto;  margin: 0mm; }
p {
    margin: 0 0 0px;
}
</style>
 
	 <div id="printableArea">
	<div  id="invoice-template" class="card-body">
	<div class="col-sm-12 offset-1">
	<h4 class="myheading" style="text-align:center;">GST TAX INVOICE</h4>
	</div>
		<!-- Invoice Company Details -->
		<div style="border:1px solid #000;" class="col-md-12">
		
		<div style="border-bottom:1px solid #000;" id="invoice-company-details" class="row ">
			<div  class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:left; border-right:1px solid #000;">
				<div class="row">
					<div class=" " style="padding: 1% 2%;">
						<ul class="ml-2 ml-ul px-0 list-unstyled">
							<li class="text-bold-800"><b><?=$shop_data['shop_name']?></b><br><?=$shop_data['shop_address']?> <br> <b>Contact No:</b> &nbsp<?=$shop_data['shop_contact']?> </li>
							<li><b>GSTIN/UIN:</b>&nbsp <?=$shop_data['shop_gstno']?></li>
							<li><b>Email:</b>&nbsp <?=$shop_data['shop_email']?></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:right; padding:0px; ">
			
			<div style="border-bottom:1px solid #000; padding: 0px; margin: 0px;" class="row">
			<div style="border-right:1px solid #000; padding-bottom: 7px;" class="col-md-6 col-xs-6" >
			<p>Invoice Number:</p>
			<p><b># <?=$bill_number?></b></p>
			</div>
			<div class="col-md-6 col-xs-6 ">
			<p>Date:</p>
			<p><b><?=date("d-M-Y")?></b></p>
			</div>
			</div>
		
			<div style="padding: 0px; margin: 0px;" class="row">
			<div style="border-right:1px solid #000;" class="col-md-6 col-xs-6 ">
			<p>Salesman:</p>
			<p><b><?=$user_data['fname']." ".$user_data['lname']?></b></p>
			</div>
			<div class="col-md-6 col-xs-6 ">
			<p>Mobile:</p>
			<p><b><?=$user_data['contact_no']?></b></p>
			</div>
			</div>
			</div>
		</div>
		<!--/ Invoice Company Details -->

		<!-- Invoice Customer Details -->
		<div style="border-bottom:1px solid #000;" id="invoice-customer-details" class="row pt-2">
			<div class="col-sm-12 text-md-left">
				<p style="margin-bottom: 0rem;" class="text-muted">Customer Info:</p>
			</div>
			<div class="col-md-6 col-sm-12 text-md-left" style="width:50%;float:left;">
				<ul class="px-0 list-unstyled">
					<li class="text-bold-800"> Name :&nbsp 	<b><?=ucfirst($cust_name)?> </b></li>
					<li>Mobile No:&nbsp <?=$cust_contact?></li>
					 
				</ul>
			</div>
			
			<div class="col-md-6 col-sm-12 text-md-left" style="width:50%;float:right;">
				<ul class="px-0 list-unstyled">
					 
					<li>Address:&nbsp <?=$cust_address?></li>
					<?php if($cust_gst_no){?><li>GST No:&nbsp <?=$cust_gst_no?></li><?php } ?>
					
				</ul>
			</div>
			
		</div>
		<!--/ Invoice Customer Details -->

		<!-- Invoice Items Details -->
		<div id="invoice-items-details" class="">
			<div style="margin-left:-15px;margin-right:-14.5px;">
				<div style="padding:0px;" class="table-responsive col-sm-12">
					<table class="table table-bordered" style="min-height: 375px;">
					  <thead>
					    <tr>
					      <th class="text-center" style="padding: 8px 0px;">Sr.No</th>
					      <th class="text-center">Item & Description</th>
					      <th style="padding: 8px 0px;" class="text-center">HSN/SAC</th>
					      <th style="padding: 8px 0px;" class="text-center">Qty</th>
					      <th style="padding: 8px 0px;" class="text-center">Rate</th>
						  <!--<th class="text-center">Disc</th>-->
						  <th style="padding: 8px 0px;" class="text-center">CGST</th>
						  <th style="padding: 8px 0px;" class="text-center">SGST</th>
						  <th style="padding: 8px 0px;" class="text-center">Amount</th>
					    </tr>
					  </thead>
					  <tbody>
					  <?php
					  $total_qty=0;
					$sr_no=1;					  
					 
					   $p_count1=0;
					 foreach ($product_name as $value) {
				$value = trim($value);
				if(empty($value)){ }
					 else{ $p_count1++; }
					 }
					if($pro_type=="accessories")
					 {
						 $val_i=1;
						 $p_count=$p_count1+1;
						   
						    //$total_qty=array_sum($product_qty);
							  $total_qty1=array_shift($product_qty);
							  $total_qty=array_sum($total_qty1);
					 }else{
						 $val_i=0;
						 $p_count=$p_count1;
					 }
					//print_r($product_name);
					 
					  $i=0;
						foreach ($product_name as $value) {
				$value = trim($value);
				if(empty($value)){ $i++; }
					 else{ //for($i=0;$i<count($product_name);$i++){
							 $tax=$product_price[$i]*$product_gst[$i]/100 ;
						$total_tax=$tax/2;
						$final_total_tax+=$total_tax;
			 
			$pquery = mysqli_query($conn,"select * from product WHERE product_id='$product_id[$i]'");
			$pro_data= mysqli_fetch_assoc($pquery);
			 $com_id=$pro_data['product_company']; 
			 $cat_id=$pro_data['category_id']; 
			 $product_color=$pro_data['color']; 
			 
			$cquery = mysqli_query($conn,"select * from company WHERE company_id='$com_id'");
			$com_data= mysqli_fetch_assoc($cquery);
			$product_company_name=$com_data['company_name'];
			$p_name=$product_company_name." ".$product_name[$i];
			$product_names = implode(' ', array_unique(explode(' ', $p_name)));
			$gst=$product_gst[$i]/2;
						  
			$bno=str_replace('Bill-', '', $bill_number)			   
					  ?>
					    <tr>
					      <td class="text-center" style="padding: 8px 0px;"><?=$sr_no++?></td>
					      <td style="padding: 5px">
					      	<p style="margin-bottom: 0rem;"><?=$product_names." ".$product_color?></p>
					      	<?php if($cat_id==2){ }else{?><p style="margin-bottom: 0rem;" class="text-muted"><?php if($imei_no!=""){echo "IMEI No : ".$imei_no[$i];}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($battery_no!=""){echo "Battery No : ".$battery_no[$i];}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($charger_no!=""){echo "Charger No : ".$charger_no[$i];}?></p>
							<?php } ?>
					      </td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$pro_data['hsn_no']?></td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$product_qty[$i]?></td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$product_price[$i]?></td>
						  
						  <!--<td class="text-center">-</td>-->
						  <td style="padding: 8px 0px;" class="text-center"><?php if($gst<=0){ echo "-";} else{ echo $gst."%"."(".round($total_tax,2).")"; } ?></td>
						 <td style="padding: 8px 0px;" class="text-center"><?php if($gst<=0){ echo "-";} else{ echo $gst."%"."(".round($total_tax,2).")"; } ?></td>
						  <td style="padding: 8px 0px;" class="text-center"><b><?php if($total[$i]<=$hid_sale_price[$i]){ echo $hid_sale_price[$i];} else { echo $total[$i]; }?></b></td>

					    </tr>
					  <?php $i++; }  }  ?>
						
						<tr style="height: 0px;">
					      <th scope="row"></th>
					      <td>
					      	<p style="margin-bottom: 0rem;"><b>Total</b></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"></p>
							
					      </td>
					      <td class="text-center"></td>
					      <td class="text-center"><b><?php if($total_qty==0){ echo $p_count1;} else { echo $total_qty;}?></b></td>
					      <td class="text-center"></td>
						  
						  <!--<td class="text-center"><?php if($disc_amt<=0){ echo "-";} else{ echo $disc_amt ; }?></td>-->
						 <td class="text-center"><?=round($final_total_tax, 2);?></td>
						  <td class="text-center"><?=round($final_total_tax, 2);?></td>
						  <td class="text-center"><b><?=$final_total_amount?></b></td>
					    </tr>
						
					    
					   
					  </tbody>
					</table>
				</div>
			</div>
			
			<div class="row text-md-left">
				<div class="col-md-7 col-sm-7" style="width:60%;float:left;">
				<ul style="padding-bottom:15px;" class="px-0 list-unstyled">
					<li style="" class="text-bold-800">Amount Chargeable &nbsp(in words):<b> <?php echo ucfirst(convertNumber($final_total_amount));   ?>  Rupees only</b></li>
				 </ul>
				</div>
				
				<div class="col-md-5 col-sm-5" style="text-align:right;width:40%;float:right;">
				<ul class="px-0 list-unstyled">
				<li>Paid Amount : <b><?=$paid_amt?></b></li>
				<li>Balance Amount : <b><?=$balance_amt?></b></li>
				</ul>
				</div>
			</div>
			
			 
				<div class="row">
				<div class="col-md-6 col-sm-6" style="width:50%;float:left;">
				<ul class="px-0 list-unstyled">
				<li>Company's VAT TIN: &nbsp <b><?=$shop_data['shop_van']?></b></li>
				<li>Company's PAN:&nbsp <b><?=$shop_data['shop_pan']?></b></li>
				
				
				</ul>
				</div>

				
			</div>
		</div>

		<!-- Invoice Footer -->
		<div id="invoice-footer">
			<div class="row">
				<div class="col-md-6 col-sm-6" style="width:50%;float:left;">
					<h5 style="margin-bottom: 5px;font-weight: 600;">Terms & Conditions:</h5>
					<p><?=$shop_data['shop_terms_conditions']?></p>
				</div>
				
				<div class="col-md-6 col-sm-6" style="text-align:right;width:50%;float:right;padding:0px 5px;">
				<ul class="px-0 list-unstyled">
				<li><img alt='testing' src="excess/barcode.php?text=<?php echo $bno;?>&codetype=Code128&orientation=Horizontal&size=40&print=true"/></li>
				 
				
				
				</ul>
				</div>
				
			</div>
		</div>
		
		
		<div id="invoice-footer">
			<div style="border-top:1px solid #000;" class="row">
				<div style="border-right:1px solid #000;" class="col-md-6 col-xs-6">
				<div class="text-center">
						 
					<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-top: 7%; font-size:12px;">Customer Signatory</p>
						
					</div>
					
				</div>
				<div class="col-md-6 col-xs-6 ">
					<div class="text-center">
						 
						<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-bottom: 0rem;margin-top: 7%; font-size:12px;" >For celluer Pvt. Ltd -&nbsp;&nbsp;&nbsp;&nbsp; Authorized Signatory</p>
						
					</div>
				</div>
			</div>
		</div>
		<!--/ Invoice Footer -->
</div>

<div class="col-sm-12 offset-1">
	<p style="text-align:center;margin-bottom: 0rem;font-size:12px;">This is computer generated Invoice </p>
	</div>
	</div>
	</div>
 
<?php
function convertNumber($number)
{
    list($integer, $fraction) = explode(".", (string) $number);

    $output = "";

    if ($integer{0} == "-")
    {
        $output = "negative ";
        $integer    = ltrim($integer, "-");
    }
    else if ($integer{0} == "+")
    {
        $output = "positive ";
        $integer    = ltrim($integer, "+");
    }

    if ($integer{0} == "0")
    {
        $output .= "zero";
    }
    else
    {
        $integer = str_pad($integer, 36, "0", STR_PAD_LEFT);
        $group   = rtrim(chunk_split($integer, 3, " "), " ");
        $groups  = explode(" ", $group);

        $groups2 = array();
        foreach ($groups as $g)
        {
            $groups2[] = convertThreeDigit($g{0}, $g{1}, $g{2});
        }

        for ($z = 0; $z < count($groups2); $z++)
        {
            if ($groups2[$z] != "")
            {
                $output .= $groups2[$z] . convertGroup(11 - $z) . (
                        $z < 11
                        && !array_search('', array_slice($groups2, $z + 1, -1))
                        && $groups2[11] != ''
                        && $groups[11]{0} == '0'
                            ? " and "
                            : ", "
                    );
            }
        }

        $output = rtrim($output, ", ");
    }

    if ($fraction > 0)
    {
        $output .= " point";
        for ($i = 0; $i < strlen($fraction); $i++)
        {
            $output .= " " . convertDigit($fraction{$i});
        }
    }

    return $output;
}

function convertGroup($index)
{
    switch ($index)
    {
        case 11:
            return " decillion";
        case 10:
            return " nonillion";
        case 9:
            return " octillion";
        case 8:
            return " septillion";
        case 7:
            return " sextillion";
        case 6:
            return " quintrillion";
        case 5:
            return " quadrillion";
        case 4:
            return " trillion";
        case 3:
            return " billion";
        case 2:
            return " million";
        case 1:
            return " thousand";
        case 0:
            return "";
    }
}

function convertThreeDigit($digit1, $digit2, $digit3)
{
    $buffer = "";

    if ($digit1 == "0" && $digit2 == "0" && $digit3 == "0")
    {
        return "";
    }

    if ($digit1 != "0")
    {
        $buffer .= convertDigit($digit1) . " hundred";
        if ($digit2 != "0" || $digit3 != "0")
        {
            $buffer .= " and ";
        }
    }

    if ($digit2 != "0")
    {
        $buffer .= convertTwoDigit($digit2, $digit3);
    }
    else if ($digit3 != "0")
    {
        $buffer .= convertDigit($digit3);
    }

    return $buffer;
}

function convertTwoDigit($digit1, $digit2)
{
    if ($digit2 == "0")
    {
        switch ($digit1)
        {
            case "1":
                return "ten";
            case "2":
                return "twenty";
            case "3":
                return "thirty";
            case "4":
                return "forty";
            case "5":
                return "fifty";
            case "6":
                return "sixty";
            case "7":
                return "seventy";
            case "8":
                return "eighty";
            case "9":
                return "ninety";
        }
    } else if ($digit1 == "1")
    {
        switch ($digit2)
        {
            case "1":
                return "eleven";
            case "2":
                return "twelve";
            case "3":
                return "thirteen";
            case "4":
                return "fourteen";
            case "5":
                return "fifteen";
            case "6":
                return "sixteen";
            case "7":
                return "seventeen";
            case "8":
                return "eighteen";
            case "9":
                return "nineteen";
        }
    } else
    {
        $temp = convertDigit($digit2);
        switch ($digit1)
        {
            case "2":
                return "twenty-$temp";
            case "3":
                return "thirty-$temp";
            case "4":
                return "forty-$temp";
            case "5":
                return "fifty-$temp";
            case "6":
                return "sixty-$temp";
            case "7":
                return "seventy-$temp";
            case "8":
                return "eighty-$temp";
            case "9":
                return "ninety-$temp";
        }
    }
}

function convertDigit($digit)
{
    switch ($digit)
    {
        case "0":
            return "zero";
        case "1":
            return "one";
        case "2":
            return "two";
        case "3":
            return "three";
        case "4":
            return "four";
        case "5":
            return "five";
        case "6":
            return "six";
        case "7":
            return "seven";
        case "8":
            return "eight";
        case "9":
            return "nine";
    }
}
?>
<?php
session_start();
  error_reporting(0);
require_once('../db_config/database_config.php');
		
		$user_id = $_SESSION['user_id']; 
	   $exchange_number = $_POST['exchange_number'];
	   $shop_id = $_POST['shop_id'];
	   $id = $_POST['id'];
	  if($id=="in"){$ids="inward";}else{$ids="outward";}
	   $total_amount = $_POST['bal_amount'];
	   $pay_amount = $_POST['pay_amount'];
	   $total_pay1 = $_POST['total_pay'];
	   $bal_amount = $_POST['remaining_amount'];
		$total_pay=$pay_amount+$total_pay1;
	   if($bal_amount==0){
			$due_date="0000-00-00";
		}
		else {
	   $due_date = $_POST['due_date'];
		}
	   $pur_date =  date("Y-m-d"); ;
	   
		  $payment_by = $_POST['payment_by'];	
		  $cheque_no = $_POST['cheque_no'];	
		  $bank_name = $_POST['bank_name'];	
  
  $query1 ="UPDATE `exchange` SET `pay_amount`='$total_pay',`bal_amount`='$bal_amount' WHERE exchange_number='$exchange_number'";
		 $selbd1 = mysqli_query($conn, $query1) or die('query error');
		 
  $query ="INSERT INTO `exchange_payment_transaction`(`payment_id`, `ref_id`, `type`, `shop_number`,`payment_type`, `sub_total`, `payment`, `balance`, `due_date`, `date_transaction`, `date_added`, `added_by`, `date_updated`, `updated_by`) VALUES(NULL, '$exchange_number', '$ids', '$shop_id', '$payment_by', '$total_amount', '$pay_amount', '$bal_amount', '$due_date', '$pur_date', CURRENT_TIMESTAMP, '$user_id', '0000-00-00 00:00:00', '')";
		 $selbd = mysqli_query($conn, $query) or die('query error');
		 
  				  $payment_tra_id=mysqli_insert_id($conn);
				
				 if($_POST['payment_by'] == "Cheque")
				{
					 
					$que21 ="INSERT INTO `exchange_payment_details`(`payment_d_id`, `payment_tra_id`, `payment_type`, `bank_name`, `cheque_no`, `finance_type`, `down_payment`, `emi`, `duration`, `payment_date`, `status`) VALUES(NULL, '$payment_tra_id', '$payment_by', '$bank_name', '$cheque_no', '', '', '', '', CURRENT_TIMESTAMP, '1')";
				 $insproduct21 = mysqli_query($conn,$que21);
				}  	 

				if($selbd){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }  	 
 ?>
<?php
session_start();
	//session_destroy();
			/* unset($_SESSION['user_id']);
			//unset($_SESSION['emp_id']);
			unset($_SESSION['full_name']);
			unset($_SESSION['user_level']);
			unset($_SESSION['contact_no']);
			unset($_SESSION['profile_pic']);
			//unset($_SESSION['randam1']); */
			session_destroy();

		?>
				<script>window.location.href="../index.php";</script>
				<?php
?>



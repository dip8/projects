<?php
require_once('../db_config/database_config.php');
session_start();
$repair_id = $_POST['id'];

	// for finding repair data
	 $repair_balance_query="SELECT * FROM `repair` WHERE repair_id='$repair_id'";
	 $repair_balance_data = mysqli_query($conn, $repair_balance_query) or die('query error');
	 $repair_balance_row = mysqli_fetch_assoc($repair_balance_data);
	 $repair_payment_id=$repair_balance_row['repair_payment_id'];
	 
	// finding transaction details
	 $show_balance_query="SELECT * FROM `repair_payment_detail` WHERE repair_payment_id='$repair_payment_id'";
	 $show_balance_data = mysqli_query($conn, $show_balance_query) or die('query error');
	 $show_balance_row = mysqli_fetch_assoc($show_balance_data);
	 echo $show_balance=$show_balance_row['balance'];
?>

	
<script>

$(document).ready(function(){

$(document).on("focus", "[class*='imei_no']", function() {	
		$('.imei_no').on("focus", function(){
			$(this).autocomplete({
				source:"excess/mobile_imei_exch.php",
				select:function(event,ui){
					//alert(ui.item.dob);
					var price=parseFloat(ui.item.sale_price);
					var gst=ui.item.product_gst;
					var row = $(this).parents('.item1_class');
					var gstm=parseFloat(gst)+100;
					var gstamtm=(price*100)/gstm;
					var gstamtm1=price-gstamtm;
					var sale_price=price-gstamtm1;
					row.find('.hid_product_id').val(ui.item.product_id);
					row.find('.hid_supplier_number').val(ui.item.supplier_number);
					row.find('.hid_purchase_price').val(ui.item.sale_price);
					row.find('.product_price').val(roundNumber(sale_price,2));
					row.find('.product_gst').val(ui.item.product_gst);
					row.find('.product_name').val(ui.item.product_name);
					var gstamt=(sale_price/100)*gst;
					var total=parseFloat(sale_price)+parseFloat(gstamt);
					//var total=Math.round(price+gstamt);
					var total=roundNumber(total,2);
					row.find('.total').val(total);
					
					var total1 = 0;
					$('.total').each(function() {
					total1 += Number($(this).val()) || 0;
					}); 
					var total=roundNumber(total1,2);
					$("#total_price").val(total); 
					$("#pay_amount").val(roundNumber(0,2)); 
					$("#bal_amount").val(total);
				}
			});	 
		});	
	});	
	
/* $(document).on("focus", "[class*='item1_class']", function() {
$(".product_name").on("focus",function(){ 
	//alert("as");
	var category_id=$("#cat_id_hid").val();
	//var sub_category_id=$("#subcat_id_hid").val();
	//var company_id=$("#com_id_hid").val();
	 
	$(this).autocomplete({
		 source:'excess/mobile_cat_select_value_exch.php?category_id='+category_id,
		select:function(event,ui){
		 }
 });
});

$(".product_name").on("focus",function(){ 
	//alert("as");
	var category_id=$("#cat_id_hid").val();
	//var sub_category_id=$("#subcat_id_hid").val();
	//var company_id=$("#com_id_hid").val();
	 
	$(this).autocomplete({
		 source:'excess/mobile_imei_exch.php?category_id='+category_id,
		select:function(event,ui){
		 }
 });
});

$(".color").on("focus",function(){ 
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	$(this).autocomplete({
		 source:'excess/color_name.php',
		select:function(event,ui){
			 
		}
	 });
	});

}); */
});
 
</script>
<script>
    $(document).ready(function(){
	var category_id=$("#cat_id").val();
	//var sub_category_id=$("#sub_cat_id").val();
	//var company_id=$("#company_id").val();
	 $("#cat_id_hid").val(category_id);
	 //$("#subcat_id_hid").val(sub_category_id);
	 //$("#com_id_hid").val(company_id);

});

</script>  

	<tr class="item1_class">
		<input type="hidden" class="hid_product_id" name="hid_product_id[]" id="hid_product_id" />
		<input type="hidden" class="hid_supplier_number" name="hid_supplier_number[]" id="hid_supplier_number" />
		<input type="hidden" class="product_qty" name="product_qty[]" id="product_qty" value="1" />
		<input type="hidden" class="hid_sale_price" name="hid_sale_price[]" id="hid_sale_price" value="" />
		<input type="hidden" class="hid_purchase_price" name="hid_purchase_price[]" id="hid_purchase_price" value="" />
		
		<td><input type="text" class="imei_no form-control" name="imei_no[]" id="imei_no"placeholder="IMEI No" style="padding: 3px;text-align: center;" required /></td>
		
		<td><input type="text" class="product_name form-control" name="product_name[]" id="product_name" placeholder="Product Name" style="padding: 3px;text-align: center;" required /></td>
		
		<td><input type="number" class="total form-control" name="total[]" id="total" value="0"  placeholder="Total Amount" style="padding: 3px;text-align: center;" required /></td>
		
		<td align="center"><button type="button" class="btn btn-danger remove" style="margin-top: -1px;padding: 9px 12px 8px 12px;"><i class="glyphicon glyphicon-remove-sign"></i></button></td>
	</tr>
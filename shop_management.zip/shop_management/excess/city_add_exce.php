<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
		$city_name= ucfirst($_POST['city_name']);
		$ques="select city_name from city where city_name='$city_name'";
		$query = mysqli_query($conn,$ques);
		$row =  mysqli_affected_rows($conn);
		if($row>0)
		{
			echo 2;
		}else{
			$que ="INSERT INTO `city`(`city_id`, `city_name`, `status`) VALUES (NULL,'$city_name','1')";
			$inscat = mysqli_query($conn,$que);
			if($inscat){
				echo 1;
			}else{
				echo 0;
			}
		}
		 
?>


<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

	include ('../db_config/database_config.php');
     $key=$_REQUEST['term'];
    $category_id= $_GET['category_id'];
    $sub_category_id= $_GET['sub_category_id'];
    $company_id= $_GET['company_id'];
    $array = array();
	 $que ="SELECT * FROM `product` WHERE category_id= '$category_id' and sub_category_id= '$sub_category_id' and product_company= '$company_id' and product_name LIKE '%{$key}%' AND added_by IN ($users_ids)";
		
    $query=mysqli_query($conn,$que);
    while($row=mysqli_fetch_assoc($query))
    {
    // $array[] = $row['product_name'];
	 $array[]=array(
                    'value'=> $row["product_name"],
                    'label'=>$row["product_name"],
					'id'=>$row["product_id"],
					'hsn_no'=>$row["hsn_no"], 
                    'gst_percentage'=>$row["gst_percentage"], 
                    'purchase_price'=>$row["purchase_price"], 
                    'sale_price'=>$row["sale_price"]
                        ); 
    }
    $json = json_encode($array);
    print_r($json);
?>

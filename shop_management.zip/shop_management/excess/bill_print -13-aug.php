<?php
session_start();
error_reporting(0);
require_once('../db_config/database_config.php');
	
		$users_ids = $_SESSION['multi_users_ids'];
	
		$sales_number = $_POST['sales_number']; 
		
		$ques22=mysqli_query($conn,"SELECT * FROM `sales` WHERE `sales_number`='$sales_number'");
			$rowv22 =  mysqli_fetch_assoc($ques22);
			$customer_id = $rowv22['customer_id'];	
			$sales_number = $rowv22['sales_number'];	
			$bill_number = $rowv22['sales_number'];	
			$date_added = $rowv22['date_added'];	
			$user_id = $rowv22['added_by'];	
			$sales_date = $rowv22['sales_date'];
			 
		$ques="SELECT * FROM about_shop_own WHERE admin IN ($users_ids)";
		$query = mysqli_query($conn,$ques);
		$shop_data= mysqli_fetch_assoc($query);
	
		$ques1=mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
		$rowv1 =  mysqli_fetch_assoc($ques1);
			$cust_name = $rowv1['customer_name'];
			$cust_mobile = $rowv1['mobile'];
			$cust_address = $rowv1['address'];
			$cust_gst_no = $rowv1['customer_gst_no'];
			
		$uques="select * from user WHERE user_id='$user_id' ";
		$uquery = mysqli_query($conn,$uques);
		$user_data= mysqli_fetch_assoc($uquery);
	
?>

<style>
@page { size: auto;  margin: 0mm; }
p {
    margin: 0 0 0px;
}
</style>
<div id="printableArea">
	<div  id="invoice-template" class="card-body">
	<div class="col-sm-12 offset-1">
	<h4 class="myheading" style="text-align:center;">GST TAX INVOICE</h4>
	</div>
		<!-- Invoice Company Details -->
		<div style="border:1px solid #000;" class="col-md-12">
		
		<div style="border-bottom:1px solid #000;" id="invoice-company-details" class="row ">
			<div  class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:left; border-right:1px solid #000;">
				<div class="row">
					<div class=" " style="padding: 1% 2%;">
						<ul class="ml-2 ml-ul px-0 list-unstyled">
							<li class="text-bold-800"><b><?=$shop_data['shop_name']?></b><br><?=$shop_data['shop_address']?> <br> <b>Contact No:</b> &nbsp<?=$shop_data['shop_contact']?> </li>
							<li><b>GSTIN/UIN:</b>&nbsp <?=$shop_data['shop_gstno']?></li>
							<li><b>Email:</b>&nbsp <?=$shop_data['shop_email']?></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:right; padding:0px; ">
			
			<div style="border-bottom:1px solid #000; padding: 0px; margin: 0px;" class="row">
			<div style="border-right:1px solid #000; padding-bottom: 7px;" class="col-md-6 col-xs-6" >
			<p>Invoice Number:</p>
			<p><b># <?=$sales_number?></b></p>
			</div>
			<div class="col-md-6 col-xs-6" >
			<p>Date:</p>
			<p><b><?=$sales_date?></b></p>
			</div>
			</div>
			<div style="padding: 0px; margin: 0px;" class="row">
			<div style="border-right:1px solid #000;" class="col-md-6 col-xs-6 ">
			<p>Salesman:</p>
			<p><b><?=$user_data['fname']." ".$user_data['lname']?></b></p>
			</div>
			<div class="col-md-6 col-xs-6 ">
			<p>Mobile:</p>
			<p><b><?=$user_data['contact_no']?></b></p>
			</div>
			</div>
			
			</div>
		</div>
		<!--/ Invoice Company Details -->

		<!-- Invoice Customer Details -->
		<div style="border-bottom:1px solid #000;" id="invoice-customer-details" class="row pt-2">
			<div class="col-sm-12 text-md-left">
				<p style="margin-bottom: 0rem;" class="text-muted">Customer Info:</p>
			</div>
			<div class="col-md-6 col-sm-12 text-md-left" style="width:50%;float:left;">
				<ul class="px-0 list-unstyled">
					<li class="text-bold-800"> Name :&nbsp 	<b><?=ucfirst($cust_name)?> </b></li>
					<li>Mobile No:&nbsp <?=$cust_mobile?></li> 
				</ul>
			</div>
			
			<div class="col-md-6 col-sm-12 text-md-left" style="width:50%;float:right;">
				<ul class="px-0 list-unstyled">
					 
					<li>Address:&nbsp <?=$cust_address?></li>
					<?php if($cust_gst_no){?><li>GST No:&nbsp <?=$cust_gst_no?></li><?php } ?>
					
				</ul>
			</div>
			
		</div>
		<!--/ Invoice Customer Details -->

		<!-- Invoice Items Details -->
		<div id="invoice-items-details" class="">
			<div style="margin-left:-15px;margin-right:-14.5px;">
				<div style="padding:0px;" class="table-responsive col-sm-12">
					<table class="table table-bordered" style="min-height: 375px;">
					  <thead>
					    <tr>
					      <th class="text-center" style="padding: 8px 0px;">Sr.No</th>
					      <th class="text-center">Item & Description</th>
					      <th style="padding: 8px 0px;" class="text-center">HSN/SAC</th>
					      <th style="padding: 8px 0px;" class="text-center">Qty</th>
					      <th style="padding: 8px 0px;" class="text-center">Rate</th>
						  <!--<th class="text-center">Disc</th>-->
						  <th style="padding: 8px 0px;" class="text-center">CGST</th>
						  <th style="padding: 8px 0px;" class="text-center">SGST</th>
						  <th style="padding: 8px 0px;" class="text-center">Amount</th>
					    </tr>
					  </thead>
					  <tbody>
				
					<?php
					$total_qty=0;
					$sr_no=1;					  
					$p_count1=0;
					$sale_q=0;
					$i=0;
					$ques2=mysqli_query($conn,"SELECT * FROM `sales_detail` WHERE `sales_number`='$sales_number'");
					while ($rowv2 =  mysqli_fetch_assoc($ques2)){
						$product_number = $rowv2['product_number'];
						$imei_no = $rowv2['imei_no'];
						$sales_number1 = $rowv2['sales_number'];
						$sales_quantity = $rowv2['sales_quantity'];
						$total_amount = $rowv2['sales_price'];
						$gst_amount = $rowv2['gst_amount'];
						$gst_percentage1 = $rowv2['gst_percentage'];
						$gst_percentage = $gst_percentage1/2;
						$final_total_amount = $rowv2['sales_total_amount'];
						$sale_q=$sale_q+$sales_quantity; 
					
					$ques22=mysqli_query($conn,"SELECT * FROM `sales` WHERE `sales_number`='$sales_number1'");
					$rowv22 =  mysqli_fetch_assoc($ques22);
						$customer_id = $rowv22['customer_id'];	
						$date_added = $rowv22['date_added'];	
						$user_id = $rowv22['added_by'];	
						$sales_date = $rowv22['sales_date'];
						$discount_amount = $rowv22['discount_amount'];
						$paid_amt = $rowv22['total_payment'];
						$balance_amt = $rowv22['total_balance'];
						
						$total_amt=$total_amt+$total_amount;
						$final_total_amt=$final_total_amt+$final_total_amount;
						$total_tax=$gst_amount/2;
						$final_total_tax=$final_total_tax+$total_tax;
						$total_gst_amt=$total_gst_amt+$total_tax;
							  
					$ques3=mysqli_query($conn,"SELECT * FROM `product` WHERE `product_id`='$product_number'");
					$rowv3 =  mysqli_fetch_assoc($ques3);
						$product = $rowv3['product_name'];	
						$product_company = $rowv3['product_company'];	
						$category_id = $rowv3['category_id'];	
						$hsn_no = $rowv3['hsn_no'];	
						$product_color = $rowv3['color'];
						$battery_no = $rowv3['battery_no'];
						$charger_no = $rowv3['charger_no'];
				
					$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$product_company'");
					$cmp_row=mysqli_fetch_assoc($rescm);
						$company_name=$cmp_row['company_name'];
						$product_name=$company_name." ".$product;
					
					$resct = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
					$cat_row=mysqli_fetch_assoc($resct);
						$category_name=$cat_row['category_name'];
								  
					$bno=str_replace('Bill-', '', $bill_number);			   
					  ?>
					    <tr>
					      <td class="text-center" style="padding: 8px 0px;"><?=$sr_no++?></td>
					      <td style="padding: 5px">
					      	<p style="margin-bottom: 0rem;"><?=$product_name." ".$product_color?></p>
					      	<?php if($category_id==2){ }else{?><p style="margin-bottom: 0rem;" class="text-muted"><?php if($imei_no!=""){echo "IMEI No : ".$imei_no;}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($battery_no!=""){echo "Battery No : ".$battery_no;}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($charger_no!=""){echo "Charger No : ".$charger_no;}?></p>
							<?php } ?>
					      </td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$hsn_no ?></td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$sales_quantity ?></td>
					      <td style="padding: 8px 0px;" class="text-center"><?=$total_amount ?></td>
						  
						  <!--<td class="text-center">-</td>-->
						  <td style="padding: 8px 0px;" class="text-center"><?php if($gst_percentage1<=0){ echo "-";} else{ echo $gst_percentage1."%"."(".round($total_tax,2).")"; } ?></td>
						 <td style="padding: 8px 0px;" class="text-center"><?php if($gst_percentage1<=0){ echo "-";} else{ echo $gst_percentage1."%"."(".round($total_tax,2).")"; } ?></td>
						  <td style="padding: 8px 0px;" class="text-center"><b><?php  echo $final_total_amount; ?></b></td>

					    </tr>
					  <?php $i++;   }  ?>
						
						<tr style="height: 0px;">
					      <th scope="row"></th>
					      <td>
					      	<p style="margin-bottom: 0rem;"><b>Total</b></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"></p>
							
					      </td>
					      <td class="text-center"></td>
					      <td class="text-center"><b><?php if($sale_q==0){ echo $p_count1;} else { echo $sale_q;}?></b></td>
					      <td class="text-center"></td>
						  
						  <!--<td class="text-center"><?php if($disc_amt<=0){ echo "-";} else{ echo $disc_amt ; }?></td>-->
						 <td class="text-center"><?=round($final_total_tax, 2);?></td>
						  <td class="text-center"><?=round($final_total_tax, 2);?></td>
						  <td class="text-center"><b><?=$final_total_amt?></b></td>
					    </tr>
						
					  </tbody>
					</table>
				</div>
			</div>
			
			<div class="row text-md-left">
				<div class="col-md-7 col-sm-7" style="width:60%;float:left;">
				<ul style="padding-bottom:15px;" class="px-0 list-unstyled">
					<li style="" class="text-bold-800">Amount Chargeable &nbsp(in words):<b> <?php echo ucfirst(convertNumber($final_total_amt));   ?>  Rupees only</b></li>
				 </ul>
				</div>
				
				<div class="col-md-5 col-sm-5" style="text-align:right;width:40%;float:right;">
				<ul class="px-0 list-unstyled">
				<li>Paid Amount : <b><?=$paid_amt?></b></li>
				<li>Balance Amount : <b><?=$balance_amt?></b></li>
				</ul>
				</div>
			</div>

			<div class="row">
				<div class="col-md-6 col-sm-6" style="width:50%;float:left;">
				<ul class="px-0 list-unstyled">
				<li>Company's VAT TIN: &nbsp <b><?=$shop_data['shop_van']?></b></li>
				<li>Company's PAN:&nbsp <b><?=$shop_data['shop_pan']?></b></li>
				</ul>
				</div>
			</div>
		</div>

		<!-- Invoice Footer -->
		<div id="invoice-footer">
			<div class="row">
				<div class="col-md-6 col-sm-6" style="width:50%;float:left;">
					<h5 style="margin-bottom: 5px;font-weight: 600;">Terms & Conditions:</h5>
					<p><?=$shop_data['shop_terms_conditions']?></p>
				</div>
				
				<div class="col-md-6 col-sm-6" style="text-align:right;width:50%;float:right;padding:0px 5px;">
				<ul class="px-0 list-unstyled">
				<li><img alt='testing' src="excess/barcode.php?text=<?php echo $bno;?>&codetype=Code128&orientation=Horizontal&size=40&print=true"/></li>

				</ul>
				</div>	
			</div>
		</div>
		
		
		<div id="invoice-footer">
			<div style="border-top:1px solid #000;" class="row">
				<div style="border-right:1px solid #000;" class="col-md-6 col-xs-6">
				<div class="text-center">
						 
					<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-top: 7%; font-size:12px;">Customer Signatory</p>
						
					</div>
					
				</div>
				<div class="col-md-6 col-xs-6 ">
					<div class="text-center">
						 
						<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-bottom: 0rem;margin-top: 7%; font-size:12px;" >For celluer Pvt. Ltd -&nbsp;&nbsp;&nbsp;&nbsp; Authorized Signatory</p>
						
					</div>
				</div>
			</div>
		</div>
		<!--/ Invoice Footer -->
</div>

<div class="col-sm-12 offset-1">
	<p style="text-align:center;margin-bottom: 0rem;font-size:12px;">This is computer generated Invoice </p>
	</div>
	</div>
	</div>
<?php
function convertNumber($number)
{
    list($integer, $fraction) = explode(".", (string) $number);

    $output = "";

    if ($integer{0} == "-")
    {
        $output = "negative ";
        $integer    = ltrim($integer, "-");
    }
    else if ($integer{0} == "+")
    {
        $output = "positive ";
        $integer    = ltrim($integer, "+");
    }

    if ($integer{0} == "0")
    {
        $output .= "zero";
    }
    else
    {
        $integer = str_pad($integer, 36, "0", STR_PAD_LEFT);
        $group   = rtrim(chunk_split($integer, 3, " "), " ");
        $groups  = explode(" ", $group);

        $groups2 = array();
        foreach ($groups as $g)
        {
            $groups2[] = convertThreeDigit($g{0}, $g{1}, $g{2});
        }

        for ($z = 0; $z < count($groups2); $z++)
        {
            if ($groups2[$z] != "")
            {
                $output .= $groups2[$z] . convertGroup(11 - $z) . (
                        $z < 11
                        && !array_search('', array_slice($groups2, $z + 1, -1))
                        && $groups2[11] != ''
                        && $groups[11]{0} == '0'
                            ? " and "
                            : ", "
                    );
            }
        }

        $output = rtrim($output, ", ");
    }

    if ($fraction > 0)
    {
        $output .= " point";
        for ($i = 0; $i < strlen($fraction); $i++)
        {
            $output .= " " . convertDigit($fraction{$i});
        }
    }

    return $output;
}

function convertGroup($index)
{
    switch ($index)
    {
        case 11:
            return " decillion";
        case 10:
            return " nonillion";
        case 9:
            return " octillion";
        case 8:
            return " septillion";
        case 7:
            return " sextillion";
        case 6:
            return " quintrillion";
        case 5:
            return " quadrillion";
        case 4:
            return " trillion";
        case 3:
            return " billion";
        case 2:
            return " million";
        case 1:
            return " thousand";
        case 0:
            return "";
    }
}

function convertThreeDigit($digit1, $digit2, $digit3)
{
    $buffer = "";

    if ($digit1 == "0" && $digit2 == "0" && $digit3 == "0")
    {
        return "";
    }

    if ($digit1 != "0")
    {
        $buffer .= convertDigit($digit1) . " hundred";
        if ($digit2 != "0" || $digit3 != "0")
        {
            $buffer .= " and ";
        }
    }

    if ($digit2 != "0")
    {
        $buffer .= convertTwoDigit($digit2, $digit3);
    }
    else if ($digit3 != "0")
    {
        $buffer .= convertDigit($digit3);
    }

    return $buffer;
}

function convertTwoDigit($digit1, $digit2)
{
    if ($digit2 == "0")
    {
        switch ($digit1)
        {
            case "1":
                return "ten";
            case "2":
                return "twenty";
            case "3":
                return "thirty";
            case "4":
                return "forty";
            case "5":
                return "fifty";
            case "6":
                return "sixty";
            case "7":
                return "seventy";
            case "8":
                return "eighty";
            case "9":
                return "ninety";
        }
    } else if ($digit1 == "1")
    {
        switch ($digit2)
        {
            case "1":
                return "eleven";
            case "2":
                return "twelve";
            case "3":
                return "thirteen";
            case "4":
                return "fourteen";
            case "5":
                return "fifteen";
            case "6":
                return "sixteen";
            case "7":
                return "seventeen";
            case "8":
                return "eighteen";
            case "9":
                return "nineteen";
        }
    } else
    {
        $temp = convertDigit($digit2);
        switch ($digit1)
        {
            case "2":
                return "twenty-$temp";
            case "3":
                return "thirty-$temp";
            case "4":
                return "forty-$temp";
            case "5":
                return "fifty-$temp";
            case "6":
                return "sixty-$temp";
            case "7":
                return "seventy-$temp";
            case "8":
                return "eighty-$temp";
            case "9":
                return "ninety-$temp";
        }
    }
}

function convertDigit($digit)
{
    switch ($digit)
    {
        case "0":
            return "zero";
        case "1":
            return "one";
        case "2":
            return "two";
        case "3":
            return "three";
        case "4":
            return "four";
        case "5":
            return "five";
        case "6":
            return "six";
        case "7":
            return "seven";
        case "8":
            return "eight";
        case "9":
            return "nine";
    }
}
?>
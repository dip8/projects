<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

include('../db_config/database_config.php');

	$email=$_POST['emailid'];
	$ques="select email_id from supplier where email_id='$email' AND added_by IN ($users_ids)";
	$query = mysqli_query($conn,$ques);
	$row =  mysqli_affected_rows($conn);
	if($row==0)
		{
			$data2[]="Yes";
		print_r(json_encode($data2));
		 
		}
		else
		{
			$data2[]="No";
		print_r(json_encode($data2));
		 
		}

?>





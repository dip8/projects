<?php
include ('../db_config/database_config.php');
		
		$n_id=$_POST['n_id'];
  $query=mysqli_query($conn,"UPDATE `notification` SET `status`='0' WHERE n_id='$n_id'");
     
	 
	 if($query){echo 1;}else{ echo 0;}
?>
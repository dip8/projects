<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
			$operator_id= $_POST['operator_id'];
			 
				$que ="DELETE FROM `sim_operator` WHERE operator_id='$operator_id'";
				$insprofile = mysqli_query($conn,$que);
			
			 if($insprofile){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
?>

<?php
require_once('../db_config/database_config.php');			
error_reporting(0);			
		  $contact_id= $_POST['contact_id'];
		  $c_name= $_POST['contact_name'];
		  $phone_no= $_POST['contact_phone'];
		  $email= $_POST['contact_email'];
			  
			 $que ="UPDATE `contact_person` SET `contact_name`='$c_name',`contact_phone`='$phone_no',`contact_email`='$email' WHERE contact_id=$contact_id";
				$insdocument = mysqli_query($conn, $que)or die('error insrt query');
				 
			
			if($insdocument)
			{ echo 1; }else{ echo'eroor';} 


?>
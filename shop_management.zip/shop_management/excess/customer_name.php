<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $array = array();
    $query=mysqli_query($conn,"select * from customer where customer_name LIKE '%{$key}%' AND added_by IN ($users_ids)");
    while($row=mysqli_fetch_assoc($query))
    {
     // $array[] = $row;
	   $array[]=array(
                    'value'=> $row["customer_name"],
                    'label'=>$row["customer_name"],
					'id'=>$row["customer_id"],
					'mobile'=>$row["mobile"],
					'dob'=>date("Y-m-d", strtotime($row["date_of_birth"])),
					'address'=>$row["address"]
                        ); 
    }
    //echo json_encode($array);
	$json = json_encode($array);
    print_r($json);
?>

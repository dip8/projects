<script>
$(function () {
        $('#brand_edit').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<?php
require_once('../db_config/database_config.php');

	$supplier_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `supplier` WHERE `supplier_id`='$supplier_id'");
	 
		$dealer_row=mysqli_fetch_assoc($res);	
	 
	?>

	

<div class="tab-pane active" id=" ">
						<p>
	 <form id="dealerupdate_form" onsubmit="return update_dealer()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
  <input type="hidden" value="<?=$dealer_row['supplier_id']?>" name="supplier_id">
   <div class = "form-group">
      <label for = "dealerid" class = "col-md-3 control-label">Dealer Id:</label>
		
      <div class = "col-md-4">
         <input type = "text" value="<?php echo $dealer_row['supplier_number'];?>" class = "form-control" pattern="([A-z0-9À-ž\s]){2,}" id = "dealer_id" name="dealer_id"  data-bind="value:Id" placeholder = "Enter Id" readonly>
      </div>
   </div>
   
   <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Dealer Name:</label>
	  
	  <div class = "col-md-4">
      <input type="text" class="form-control" value="<?php echo $dealer_row['supplier_name'];?>" id="dealer_name" placeholder="Enter Name" name="dealer_name" required>
	  </div>
    </div>
	 <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Dealer Address:</label>
	  
	  <div class = "col-md-4">
      <textarea  class="form-control" id="address" name="address" placeholder="Enter Address"><?php echo $dealer_row['supplier_address'];?></textarea>
	  </div>
    </div>
	 
	 <div class = "form-group">
      <label for = "dealerid" class = "col-md-3 control-label">Company / Brand:</label>
		
      <div class="col-md-4">
			<select name="brand[]" id="brand_edit" multiple required>
		  
	  <?php 
	   $company_query = "SELECT * FROM `company`";
			$com_res = mysqli_query($conn,$company_query);
			 $brand=explode(",",$dealer_row['supplier_for']);
			//print_r($brand);
			while($com_data = mysqli_fetch_array($com_res))
					{
			 ?>
			<option value="<?=$com_data['company_id']?>" <?php  foreach($brand as $val){ if($com_data['company_id']==$val){ echo "selected"; } } ?>><?=$com_data['company_name']?></option>
			 <?php } ?>
			</select>
		</div>
                                          
      </div>
	   <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Email Id:</label>
	  
	  <div class = "col-md-4">
      <input type="email" value="<?php echo $dealer_row['email_id'];?>" class="form-control" id="email" placeholder="Enter email"  name="email" required>
	  <div id="err_email" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Username/Email-Id are found...! Please  Enter New Email-Id..!</span> </div>
	
	  </div>
    </div>
	<div class="form-group">
      <label for="email" class = "col-md-3 control-label">Contact No:</label>
	  
	  <div class = "col-md-4">
      <input type="number" class="form-control" value="<?php echo $dealer_row['contact_number'];?>" id="contact_no" placeholder="Enter Contact No"   name="contact_no">
	   
    </div>
    </div>
	
	<div class = "form-group">
      <label class = "col-md-3 control-label">Dealer GST No.:</label>
		
      <div class ="col-md-4">
         <input style="margin-bottom: 13px;" type = "text" name="dealer_gst_no" id="dealer_gst_no" class ="form-control" value="<?php echo $dealer_row['dealer_gst_no'];?>" placeholder = "Enter Dealer GST No.">
      </div>
   </div>
	
	<!--div class="form-group">
      <label for="email" class = "col-md-3 control-label">Contact Person:</label>
	  
	  <div class = "col-md-4">
      <input type="text" class="form-control"  value="<?php echo $dealer_row['contact_person'];?>" id="c_person" placeholder="Enter Contact Person Name" name="c_person">
	  </div>
    </div>
	 <div class = "form-group">
      <label for = "quantity" class = "col-md-3 control-label">Contact Person Phone.:</label>
		
      <div class = "col-md-4">
         <input style="margin-bottom: 13px;" type = "text" value="<?php echo $dealer_row['contact_number'];?>" name="p_contact_no" id="p_contact_no" class ="form-control" id = "quantity"    placeholder = "Enter Contact No." required>
      </div>
   </div-->
   <div class="  " style="text-align:center;">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdatedealer" class="btn btn-primary"><i class="fa fa-plus"></i>Update Dealer</button>
				
				<a href="" class="btn btn-danger">Cancel</a>
						</div>
			</div>
   
   
                                           
   
  

</form>
</p>
</div>
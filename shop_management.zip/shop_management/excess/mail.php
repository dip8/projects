<?php
error_reporting( E_ALL );

include('send_mail_variables.php');
 $email_id=$_POST['email_id_mail'];
 $page_url=$_POST['page_url'];
 $name=$_POST['cust_name_mail'];
 $message=$_POST['message'];
 $subject=$_POST['subject'];
 $project_name="www.shopinventory.com";

		ob_start();
		include 'email_format.php';
		$msg_body=ob_get_clean(); 			
	
			try{							
			$mail             = new PHPMailer();
			$body=$msg_body;
			//$mail->IsSMTP();
			$mail->Host       = "smtp.sendgrid.net";
			$mail->SMTPAuth   = true;
			$mail->SMTPSecure = 'tls';   
			$mail->Port 	  = 587;
			$mail->Username   = "yogeshnair2013@gmail.com"; 
			$mail->Password   = "yogesh123@";  
			$mail->SetFrom($activation_from,'Swarnalakshya Celluler');
			$mail->AddReplyTo($email_id);
			$mail->Subject    = $subject;
			$mail->MsgHTML($body);
			$address 		  =$email_id;
			$mail->AddAddress($address);
			$mail->Send();
			  echo "<script>alert('Mail Send Successfully.');window.location.href = '../$page_url';</script>";
			} catch (phpmailerException $e) {
			  echo $e->errorMessage(); //Pretty error messages from PHPMailer
			} catch (Exception $e) {
			  echo $e->getMessage(); //Boring error messages from anything else!
			}					
							
		 	
?>

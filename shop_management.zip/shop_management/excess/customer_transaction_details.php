<?php
//error_reporting(0);
require_once('../db_config/database_config.php');

	   $customer_id = $_POST['customer_id'];
    	

?>
	 
 <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Sale No</th>
                  <th>Sale Date</th>
                  <th>Customer Name</th>
                   
                  <th>Total Amount</th>
				  
                  <th>Total Payment</th>
				  <th>Balance Amount</th>
                  <th>Due Date</th>
				  <th>View Transaction </th>
				  <th>Pay Now</th>
				   
				  
                  
                </tr>
                </thead><tbody >
					<?php 
				 $tra_query = "SELECT * FROM `sales` where customer_id='$customer_id' ORDER BY sales_id DESC";
			$tra_res = mysqli_query($conn,$tra_query);
			$i=0;
			while($tra_data = mysqli_fetch_assoc($tra_res))
					{
						 
					 $customer_id=$tra_data['customer_id'];
					  $sales_number=$tra_data['sales_number'];
				  $traq = mysqli_query($conn,"SELECT * FROM `payment_transaction` WHERE `ref_id`='$sales_number'");
						$tral=mysqli_fetch_assoc($traq);
						$due_date= $tral['due_date'];
						 
						
						$supp_q = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
						$sup_data= mysqli_fetch_assoc($supp_q);
						$customer_name=$sup_data['customer_name'];
						 
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$tra_data['sales_number']?></td>
                  <td><?=$tra_data['sales_date']?></td>
				  <td><?=$customer_name?></td>
                  
                  <td><?=$tra_data['final_total_amount']?></td>
                  <td><?=$tra_data['total_payment']?></td>
				  <td><?=$tra_data['total_balance']?></td>
				  <td><?=$due_date?></td>
                  
				   <td>
					<a  class="btn btn-success btn-xs" onclick="trasaction_details('<?php echo $tra_data['sales_number']; ?>','<?=$customer_name?>');">
					<i class="glyphicon glyphicon-eye-open" title="View Application" style="font-size:18px;text-align: center;"></i></a>
				  </td>
                  <td>
				  <?php if($tra_data['total_balance']!=0){?>
				  <a class="btn btn-info btn-xs" onclick="payment_now('<?php echo $tra_data['sales_number']; ?>');">
				  <i class="fa fa-money" title="Pay Remaining Amount" style="font-size:18px;text-align: center;"></i></a>
					<?php } ?>
				  </td>
                  
                 
                  
                </tr>
                 
                
                
					<?php } ?></tbody>
              </table>
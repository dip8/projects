<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
error_reporting(0);	
$from_date=$_POST['from_date'];
  $to_date=$_POST['to_date'];
?>
		<table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
			<thead>
			<tr>
			  <th>Sr No:</th>
			  <th>Date</th>
			  <th>Customer Name</th>
			  <th>Product Name</th>
			  <th>Product Issue</th>
			  <th>Due Date</th>
			  <th>Approx Cost</th>
			  <th>Advance Payment</th>
			  <th>Balance</th>
			  <th>Total Amount</th>
			  <th>Payment type</th>
			  <th>Status</th>
			  <th>Download pdf</th>
			</tr>
			</thead>
			<tbody id="search_res">
			<?php 
			$tra_query = "SELECT * FROM `repair` WHERE added_date BETWEEN '$from_date' AND '$to_date' AND added_by IN ($users_ids) ORDER BY repair_id DESC";
			$tra_res = mysqli_query($conn,$tra_query);
			$i=0;
			while($repair_data = mysqli_fetch_assoc($tra_res))
			{
				$customer_number=$repair_data['customer_number'];
				$repair_payment_id=$repair_data['repair_payment_id'];
				$status=$repair_data['status'];
				$product_brand=$repair_data['product_brand'];
				$product_model=$repair_data['product_model'];
				$product_name=$product_brand.' '.$product_model;
								
				 $customer_res = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_number`='$customer_number'");
				 $customer_row = mysqli_fetch_assoc($customer_res);
				 
				 $payment_res = mysqli_query($conn,"SELECT * FROM `repair_payment_detail` WHERE `repair_payment_id`='$repair_payment_id'");
				 $payment_row = mysqli_fetch_assoc($payment_res);
			?> 
			<tr>
			  <td><?php echo ++$i;?></td>
			  <td><?php echo date("Y-m-d", strtotime($repair_data['added_date']));?></td>
			  <td><?=$customer_row['customer_name'];?></td>
			  <td><?=$product_name;?></td>
			  <td><?=$repair_data['product_issue'];?></td>
			  <td><?php echo date("Y-m-d", strtotime($repair_data['due_date']));?></td>
			  <td><?=$payment_row['approx_cost'];?></td>
			  <td><?=$payment_row['advance_pay'];?></td>
			  <td><?=$payment_row['balance'];?></td>
			  <td><?=$payment_row['total_payment'];?></td>
			  <td><?=$payment_row['payment_type'];?></td>
			  <td><?php if($status==1){ echo 'Recieved'; }else if($status==2){ echo 'Working'; }else if($status==3){ echo 'Complete'; }else if($status==4){ echo 'Return'; }?>  
			  </td>
			  <td>
				<a  class="btn btn-info btn-xs" onclick="pdf_download('<?php echo $repair_data['repair_id']; ?>');">
				<i class="fa fa-download" title="PDF Download" style="font-size:18px;text-align: center;"></i></a>
			  </td>
			</tr>
			<?php } ?>
			</tbody>
		</table>
<?php
	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $cat=$_REQUEST['cat'];
    $array = array();
    $query=mysqli_query($conn,"select * from product where category_id='$cat' AND product_name LIKE '%{$key}%' AND quantity > 0");
    while($row=mysqli_fetch_assoc($query))
    {
     //$row["product_name"];
	 $company_name = explode(' ',trim($row["product_name"]));
		$array[]=array(
                    'value'=>$company_name[0],
                    'label'=>$company_name[0],
					'company_name'=>$company_name[0]
                        ); 
    }
    //echo json_encode($array);
	$json = json_encode($array);
    print_r($json);
?>

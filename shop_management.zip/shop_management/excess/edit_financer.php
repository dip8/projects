 <?php
require_once('../db_config/database_config.php');

	$financer_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `financer` WHERE `financer_id`='$financer_id'");
	 
		$com_row=mysqli_fetch_assoc($res);	
	 
	?>
 <form id="catupdate_form" onsubmit="return update_financer()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
<input type="hidden" name="financer_id" id="financer_id" value="<?=$com_row['financer_id']?>">
	   
   <div class="col-md-6 col-md-push-2">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Financer name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control" value="<?=$com_row['financer_name']?>"  id="financer_name" name="financer_name"  data-bind="value:Id" placeholder = "Enter Category Name" required>
      </div>
   </div>
   
  </div>

			<div class="col-md-12 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupcat" class="btn btn-primary"><i class="fa fa-plus"></i>Update Financer</button>
	
		  <a href="" class="btn btn-danger">Cancel</a>
			</div>
			</div>
	 </form> 
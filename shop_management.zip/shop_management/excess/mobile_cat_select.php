<script>
/*   function getProduct(e){
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	 //alert(category_id);
	$("#product_name").autocomplete({
		 source:'excess/mobile_cat_select_value.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id,
		select:function(event,ui){
			 
		}
 });
}
 function getColor(e){
	 
	$("#color_name").autocomplete({
		 source:'excess/color_name.php',
		select:function(event,ui){
			 
		}
 });
}  */
$(document).ready(function(){
$(document).on("focus", "[class*='item1_class']", function() {
$(".product_name").on("focus",function(){ 
	//alert("as");
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	var flag =$("input[name=type]:checked").val();
	
	//alert(flag);
	$(this).autocomplete({
		source:'excess/mobile_cat_select_value.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id+'&flag='+flag,
		select:function(event,ui){
					var price=parseFloat(ui.item.sale_price);
					var price=parseFloat(ui.item.purchase_price);
					var gst=ui.item.gst_percentage;
					var row = $(this).parents('.item1_class');
					var gstm=parseFloat(gst)+100;
					var gstamtm=(price*100)/gstm;
					var gstamtm1=price-gstamtm;
					var unit_cost=price-gstamtm1;
					row.find('.color').val(ui.item.color);
					row.find('.hsn_no').val(ui.item.hsn_no);
					row.find('.cost1').val(roundNumber(unit_cost,2));
					row.find('.total_cost').val(roundNumber(ui.item.purchase_price,2));
					row.find('.sale_cost').val(roundNumber(ui.item.sale_price,2));
					row.find('.gst_cost').val(ui.item.gst_percentage);
					row.find('.cost1').keyup();
		 }
 });
});

$(".color").on("focus",function(){ 
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	var flag=$("#flag_hid").val();
	$(this).autocomplete({
		 source:'excess/color_name.php',
		select:function(event,ui){
			 
		}
	 });
	});

});
});
 
</script>
<script>
    $(document).ready(function(){
	var category_id=$("#cat_id").val();
	var sub_category_id=$("#sub_cat_id").val();
	var company_id=$("#company_id").val();
	var flag=$("#flag").val();	
	 $("#cat_id_hid").val(category_id);
	 $("#subcat_id_hid").val(sub_category_id);
	 $("#com_id_hid").val(company_id);
	 $("#flag_hid").val(flag);
	 /* $('input#product_name').typeahead({
        name: 'gotra',
         remote:'excess/mobile_cat_select_value.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id+'&key=%QUERY',
         limit : 10
    });
	  */
});
 /* $(document).ready(function(){
	$('input#color_name').typeahead({
        name: 'gotra',
        remote:'excess/color_name.php?key=%QUERY',
        limit : 10
    }); 
 }); */
</script>  
<tr class="item1_class">
<input type="hidden" id="cat_id_hid">
<input type="hidden" id="subcat_id_hid">
<input type="hidden" id="com_id_hid">
<input type="hidden" id="flag_hid">	
<input type="hidden" id="type_select">	
<td>
<input type="text"  class="form-control product_name" name="product_name[]" id="product_name" placeholder="e.g  Samsung" required>
</td>
<td>
<input type="text"  class="form-control color " name="color_name[]" id="color_name"   placeholder="e.g  Black" required>
</td>
 
<td id="">
<input name="emi_no[]" id="emi_no" type="text"  class="number1 form-control" placeholder="IMEI No."required />
 		 
</td>
<td>
<input name="hsn_no[]" id="hsn_no" type="text"  class="hsn_no number1 form-control" placeholder="HSN/SAC No."required />
</td>
 
<td class="">
<input name="unit_cost[]" id="unit_cost" type="text"  class="cost1 number form-control"     placeholder="Unit Cost" required/ >
</td>
<td>
<select name="gst_cost[]" id="gst_cost" style="padding: 1%;" class="gst_cost form-control" required >
<option value="0"> 0%</option>
<option value="5"> 5%</option>
<option value="12" selected> 12%</option>
<option value="18"> 18%</option>
<option value="28"> 28%</option>
</select>
</td>
<td>
<input name="total_cost[]" id="total_cost" type="text" value = "" class="total_cost form-control" readonly/>
</td>
<td>
<input name="sale_cost[]" id="sale_cost" type="text" value = "" placeholder="Sale Cost" class="sale_cost number1 form-control" required/>
</td>
<td>
<button type="button" class="btn btn-danger remove">
<i class="glyphicon glyphicon-remove-sign"></i></button>
</td>
</tr>
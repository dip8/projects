<?php

require_once('../db_config/database_config.php');

	$db_name = $_POST['db_name'];
	$unfile = '../database-backup/'.$db_name;
	$deletep = "delete FROM db_backup WHERE db_name='$db_name'";
	$res = mysqli_query($conn,$deletep);
	unlink($unfile);
	if($res)
	{
		echo 1;
		//header('location:../customer_list.php?udlt=yss');
	}
	else{
		echo 0;
	}
?>

	
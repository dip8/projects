<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
			   $customer_id= $_POST['customer_id'];
			   $cust_name= $_POST['cust_name'];
			$email_id= $_POST['email_id'];
			 
			$contact_no= $_POST['contact_no'];
			$cust_gst_no= $_POST['cust_gst_no'];
			 
			$birth_date= $_POST['birth_date'];
			$anniversary_date= $_POST['anniversary_date'];
			$address= $_POST['address'];
			 
			$document = $_FILES['document']['name'];
			$user_id = $_SESSION['user_id'];
			  
		 if($document=="")
			{
				  $que ="UPDATE `customer` SET `customer_name`='$cust_name',`mobile`='$contact_no',`email_id`='$email_id',`address`='$address',`date_of_birth`='$birth_date',`wedding_date`='$anniversary_date',`update_date`=NULL,`updated_by`='$user_id',`status`=1,`customer_gst_no`='$cust_gst_no' WHERE customer_id='$customer_id'";
				 $insprofile = mysqli_query($conn,$que);
			}
			else{
				
				$temp = explode(".", $_FILES["document"]["name"]);
				$newfilename1 =  $cust_name.'_'.round(microtime(true)).'.' . end($temp);
				$folder = "../img/customer/";
				move_uploaded_file($_FILES["document"]["tmp_name"] , "$folder".$newfilename1);
				
			   $que ="UPDATE `customer` SET `customer_name`='$cust_name',`mobile`='$contact_no',`email_id`='$email_id',`address`='$address',`id_proof`='$newfilename1',`date_of_birth`='$birth_date',`wedding_date`='$anniversary_date',`update_date`=NULL,`updated_by`='$user_id',`status`=1,`cust_gst_no`='$cust_gst_no' WHERE customer_id='$customer_id'";
				
				 $insprofile = mysqli_query($conn, $que)or die('error insrt query');
				 
			}
			 if($insprofile){
				  echo 1;
			  }
			  else{
				  echo 0;
			  }
?>

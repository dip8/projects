<?php
session_start();
 error_reporting(0);
require_once('../db_config/database_config.php');
	
 
	   $sales_number = $_POST['sales_number']; 
	
	
			
			 $ques22=mysqli_query($conn,"SELECT * FROM `ca_sales` WHERE `sales_number`='$sales_number'");
		 $rowv22 =  mysqli_fetch_assoc($ques22);
			  $customer_id = $rowv22['customer_id'];	
			$date_added = $rowv22['date_added'];	
			$user_id = $rowv22['added_by'];	
		 
			$sales_date = $rowv22['sales_date'];
			 
		
				$ques="select * from about_shop ";
			$query = mysqli_query($conn,$ques);
			$shop_data= mysqli_fetch_assoc($query);
	
	  $ques1=mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
		 $rowv1 =  mysqli_fetch_assoc($ques1);
		  $customer_name = $rowv1['customer_name'];
			$mobile = $rowv1['mobile'];
	 
			$uques="select * from user WHERE user_id='$user_id' ";
			$uquery = mysqli_query($conn,$uques);
			$user_data= mysqli_fetch_assoc($uquery);
	
?>
 
<style>
@page { size: auto;  margin: 0mm; }
input {
          border: 0;
    resize: none;
	  background: transparent;
}
</style>
<form action="javascript:void(0);" name="edit_bill" id="edit_bill"  method="POST" >
			
<section class="card">
	 <div id="printableArea">
	<div  id="invoice-template" class="card-body">
	<div class="col-sm-12 offset-1">
	<h3 class="myheading" style="text-align:center;">INVOICE</h3>
	</div>
		<!-- Invoice Company Details -->
		<div style="border:1px solid #000;" class="col-md-12">
		<div style="border-bottom:1px solid #000;" id="invoice-company-details" class="row ">
			<div  class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:left; border-right:1px solid #000;">
			<div class="row">
				<!--div class="col-sm-5 col-md-5" style="float:left;">
				
					<img src="logo.png" alt="company logo" width="100px" class="myimage"/>
					</div-->
					<div class=" " style="float:right;padding: 2%;">
						<ul class="ml-2 ml-ul px-0 list-unstyled">
							<li class="text-bold-800"><b><?=$shop_data['shop_name']?></b><br><?=$shop_data['shop_address']." ."?> <br> Contact No: &nbsp<?=$shop_data['shop_contact']?> </li>
							<li><b>GSTIN/UIN:</b>&nbsp <?=$shop_data['shop_gstno']?></li>
							
							
							<li><b>Email:</b>&nbsp <?=$shop_data['shop_email']?></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-6 col-lg-6" style="float:right; padding:0px;border-bottom:1px solid #000;">
			
			<div style="border-right:1px solid #000;border-bottom:1px solid #000;" class="col-md-6 col-xs-6 ">
			<p style="margin-bottom: 0rem;">Invoice Number:</p>
			<p style="margin-bottom: 0rem;"><b># <?=$sales_number?></b></p>
			</div>
			<div style="border-bottom:1px solid #000;"class="col-md-6 col-xs-6 ">
			<p style="margin-bottom: 0rem;">Date:</p>
			<p style="margin-bottom: 0rem;"><b><?php echo $sales_date;?></b></p>
			</div>
		
			
			<div style="border-right:1px solid #000;" class="col-md-6 col-xs-6 ">
			<p style="margin-bottom: 0rem;">Salesman:</p>
			<p style="margin-bottom: 0rem;"><b><?=$user_data['fname']." ".$user_data['lname']?></b></p>
			</div>
			<div class="col-md-6 col-xs-6 ">
			<p style="margin-bottom: 0rem;">Mobile:</p>
			<p style="margin-bottom: 0rem;"><b><?=$user_data['contact_no']?></b></p>
			</div>
			
			
			</div>
		</div>
		<!--/ Invoice Company Details -->

		<!-- Invoice Customer Details -->
		<div style="border-bottom:1px solid #000;" id="invoice-customer-details" class="row pt-2">
			<div class="col-sm-12 text-md-left">
				<p style="margin-bottom: 0rem;" class="text-muted">Customer Info:</p>
			</div>
			<div class="col-md-6 col-sm-12 text-md-left">
				<ul class="px-0 list-unstyled">
					<li class="text-bold-800"> Name :&nbsp 	<b><?=ucfirst($customer_name)?> </b></li>
					<li>Mobile No:&nbsp <?=$mobile?></li>
					
				</ul>
			</div>
			
		</div>
		<!--/ Invoice Customer Details -->

		<!-- Invoice Items Details -->
		<div id="invoice-items-details" class="">
			<div class="row">
				<div style="padding:0px;" class="  col-sm-12">
					<table class="table table-bordered">
					  <thead>
					    <tr>
					      <th>Sr. No</th>
					      <th>Item & Description</th>
					      <th class="text-right">HSN/SAC</th>
					      <th class="text-right">Quantity</th>
					      <th class="text-right">Rate</th>
						 <th class="text-right">Disc%</th>
						  <th class="text-right">CGST</th>
						  <th class="text-right">SGST</th>
						   <th class="text-right">Amount</th>
					    </tr>
					  </thead>
					  <tbody>
					  <?php
					  $total_qty=0;
					$sr_no=1;					  
					 
					   $p_count1=0;
					   $sale_q=0;
				 
				 
					 
					  $i=0;
					  $final_total_amount1=0;
					    $ques2=mysqli_query($conn,"SELECT * FROM `ca_sales_detail` WHERE `sales_number`='$sales_number'");
		while ($rowv2 =  mysqli_fetch_assoc($ques2)){
			  $product_number = $rowv2['product_number'];
			  $imei_no = $rowv2['imei_no'];
			  $sales_number1 = $rowv2['sales_number'];
			  $sales_quantity = $rowv2['sales_quantity'];
			  $total_amount = $rowv2['sales_price'];
			  $gst_amount = $rowv2['gst_amount'];
			  $gst_percentage1 = $rowv2['gst_percentage'];
			$gst_percentage = $gst_percentage1/2;
			   $final_total_amount11 = $rowv2['sales_total_amount'];
			  $final_total_amount1 = $final_total_amount1+$final_total_amount11;
			  
			  $sales_quantity = $rowv2['sales_quantity'];
				$sale_q=$sale_q+$sales_quantity;  
			 $ques22=mysqli_query($conn,"SELECT * FROM `ca_sales` WHERE `sales_number`='$sales_number1'");
		 $rowv22 =  mysqli_fetch_assoc($ques22);
			  $customer_id = $rowv22['customer_id'];	
			$date_added = $rowv22['date_added'];	
			$user_id = $rowv22['added_by'];	
		 
			$sales_date = $rowv22['sales_date'];
			$discount_amount = $rowv22['discount_amount'];
			$disc_perc = $rowv22['discount_percentage'];
			//$total_amount = $rowv22['total_amount'];
			//$gst_amount = $rowv22['gst_amount'];
			
			//$final_total_amount = $rowv22['final_total_amount'];
			 //$total_amt=$total_amt+$total_amount;
			  
			 //$final_total_amt=$final_total_amt+$final_total_amount;
							
								 
						$total_tax=$gst_amount/2;
			   $total_gst_amt=$total_gst_amt+$total_tax;
			  
						  
			 $ques3=mysqli_query($conn,"SELECT * FROM `product` WHERE `product_id`='$product_number'");
		 $rowv3 =  mysqli_fetch_assoc($ques3);
			$product = $rowv3['product_name'];	
			  $product_company = $rowv3['product_company'];	
			$category_id = $rowv3['category_id'];	
			   $hsn_no = $rowv3['hsn_no'];	
			$color = $rowv3['color'];
			  $battery_no = $rowv3['battery_no'];
			$charger_no = $rowv3['charger_no'];
			
			$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$product_company'");
			$cmp_row=mysqli_fetch_assoc($rescm);
			$company_name=$cmp_row['company_name'];
			$product_name=$company_name." ".$product;
			
			$resct = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
			$cat_row=mysqli_fetch_assoc($resct);
			$category_name=$cat_row['category_name'];
			
			/* $ressct = mysqli_query($conn,"SELECT * FROM `mobile_imei` WHERE `product_id`='$product_number'");
			$subcat_row=mysqli_fetch_assoc($ressct);
			  $imei_no=$subcat_row['imei_no']; */
					  ?>
					  <tr class="item-row">
					 
					      <input type="hidden" value="<?=$product_number?>" name="product_id[]">
					      <input type="hidden" value="<?=$sales_number?>" name="bill_no">
					      <th style="padding-bottom:100px;" scope="row"><?=$sr_no++?></th>
					      <td>
					      	<p style="margin-bottom: 0rem;"><?=$product_name?></p>
					      	<?php if($category_id==2){ }else{?><p style="margin-bottom: 0rem;" class="text-muted"><?php if($imei_no!=""){echo "IMEI No : ".$imei_no;}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($battery_no!=""){echo "Battery No : ".$battery_no;}?></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"><?php if($charger_no!=""){echo "Charger No : ".$charger_no;}?></p>
							<?php } ?>
					      </td>
					      <td class="text-right"><?php if($hsn_no==""){ echo "-";}else{ echo $hsn_no;} ?></td>
					      <td class="text-right"> <input type="number" value="<?=$sales_quantity?>" style="width: 30px;" name="product_qty[]" id="product_qty" class="product_qty" readonly  required> pcs</td>
					      <td class="text-right"> <input type="number" value="<?=round($total_amount, 2)?>" style="width: 90px;" name="unit_price[]" id="unit_price" class="unit_price"  required></td>
						  
						  <td class="text-right"><?php if($discount_amount<=0){ echo "-";} else{ echo $discount_amount." (".$disc_perc." )"; }?></td>
						  <td class="text-right"><?php if($gst_percentage<=0){ echo "-";} else{ echo $gst_percentage."%"; ?> (<input type="text" style="width: 40px;" class="product_gst" value="<?=round($total_tax, 2)?>" id="gst1" name="gst_amt[]" readonly>) <?php } ?><input type="hidden" value="<?=$gst_percentage1?>" name="product_gst[]" class="gst_per"></td>
						 <td class="text-right"><?php if($gst_percentage<=0){ echo "-";} else{ echo $gst_percentage."%"; ?>(<input type="text" style="width: 40px;"   value="<?=round($total_tax, 2)?>" name="gst2[]" id="gst2" class="gst1" readonly>)<?php } ?></td>
						  <td class="text-right"><b><input type="number" value="<?=round($final_total_amount11, 2)?>" style="width: 90px;" name="total_price11[]" id="total_price"   class="total_price" required></b></td>

					    </tr>
					  <?php $i++; }    ?>
					    
						
						<tr>
					      <th scope="row"></th>
					      <td>
					      	<p style="margin-bottom: 0rem;"><b>Total</b></p>
					      	<p style="margin-bottom: 0rem;" class="text-muted"></p>
							
					      </td>
					      <td class="text-right"></td>
					      <td class="text-right"><b><?php  echo $sale_q; ?> pcs</b></td>
					      <td class="text-right"></td>
						  
						  <td class="text-right"></td>
						  <td class="text-right"><?php if($gst_percentage<=0){ echo "-";} else{ ?><input type="text" style="width: 60px;" class="product_gst1" value="<?=round($total_gst_amt, 2)?>" readonly><?php } ?></td>
						  <td class="text-right"><?php if($gst_percentage<=0){ echo "-";} else{ ?><input type="text" style="width: 60px;" class="product_gst1" value="<?=round($total_gst_amt, 2)?>" readonly><?php } ?></td>
						  <td class="text-right"><b>  <input type="number" style="width: 90px;" value="<?=round($final_total_amount1, 2)?>" class="total_price1" id="total_price1"  name="final_total_amt[]" readonly></b></td>
					    </tr>
						
					   
					  </tbody>
					</table>
				</div>
				
			</div>
			
			<div class="row text-md-left">
				<ul style="padding-bottom:15px;" class="px-0 list-unstyled">
					<li style="margin-left:10px;" class="text-bold-800">Amount Chargeable &nbsp(in words):<b > <span id="word_amt"><?php echo ucfirst(convertNumber($final_total_amount));   ?> </span> Rupees only</b></li>
				 </ul>
			</div>
			
			 
				<div class="row">
				<div class="col-md-12 col-sm-12">
				<ul class="px-0 list-unstyled">
				<li>Company's VAT TIN: &nbsp <b><?=$shop_data['shop_van']?></b></li>
				<li>Company's PAN:&nbsp <b><?=$shop_data['shop_pan']?></b></li>
				
				
				</ul>
				</div>
				
				
			</div>
		</div>

		<!-- Invoice Footer -->
		<div id="invoice-footer">
			<div class="row">
				<div class="col-md-7 col-sm-12">
					<h4>Terms & Conditions:</h4>
					<p><?=$shop_data['shop_terms_conditions']?></p>
				</div>
				
			</div>
		</div>
		
		
		<div id="invoice-footer">
			<div style="border-top:1px solid #000;" class="row">
				<div style="border-right:1px solid #000;    height: 90px;" class="col-md-6 col-xs-6">
				<div class="text-center">
						 
					<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-bottom: 2rem;">Customer Signatory</p>
						
					</div>
					
				</div>
				<div class="col-md-6 col-xs-6 text-center">
					<div class="text-center">
						<p style="margin-bottom: 0rem;">For celluer Pvt. Ltd</p>
						<!--img style="width:20%;" src="signature-scan.png" alt="signature" -->
						<p style="margin-bottom: 0rem;    margin-top: 11%;" >Authorized Signatory</p>
						
					</div>
				</div>
			</div>
		</div>
		<!--/ Invoice Footer -->
</div>

<div class="col-sm-12 offset-1">
	<p style="text-align:center;margin-bottom: 0rem;">This is computer generated Invoice </p>
	</div>
	</div>
	</div>
</section>

 <div class="modal-footer">
 <button style="margin-bottom:0px; " type="button" class="btn btn-success" onclick="edit_bill_details();" id="ca_update" value="Save">Save</button>
      
		<button style="margin-bottom:0px;    background-color: indianred;" type="button" class="btn btn-default" onclick="printDiv('printableArea'); "  >Print</button>
		    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  
        </div>
</form>
<?php
function convertNumber($number) {
  $no = round($number);
  $decimal = round($number - ($no = floor($number)), 2) * 100;   
  $digits_length = strlen($no);    
  $i = 0;
  $str = array();
  $words = array(
   0 => '',
   1 => 'One',
   2 => 'Two',
   3 => 'Three',
   4 => 'Four',
   5 => 'Five',
   6 => 'Six',
   7 => 'Seven',
   8 => 'Eight',
   9 => 'Nine',
   10 => 'Ten',
   11 => 'Eleven',
   12 => 'Twelve',
   13 => 'Thirteen',
   14 => 'Fourteen',
   15 => 'Fifteen',
   16 => 'Sixteen',
   17 => 'Seventeen',
   18 => 'Eighteen',
   19 => 'Nineteen',
   20 => 'Twenty',
   30 => 'Thirty',
   40 => 'Forty',
   50 => 'Fifty',
   60 => 'Sixty',
   70 => 'Seventy',
   80 => 'Eighty',
   90 => 'Ninety');
  $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
  while ($i < $digits_length) {
   $divider = ($i == 2) ? 10 : 100;
   $number = floor($no % $divider);
   $no = floor($no / $divider);
   $i += $divider == 10 ? 1 : 2;
   if ($number) {
    $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
    $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
   } else {
    $str [] = null;
   }  
  }
  
  
  $Rupees = implode(' ', array_reverse($str));
  if($decimal>0){
	  $first_dec = substr($decimal, 0, 1);
	  $second_dec = substr($decimal, 1, 1);
	  
	  $paise = ($decimal < 20) ? "And " . ($words[$decimal - $decimal%1]) ." " .($words[$decimal%1])  : "And " . ($words[$decimal - $decimal%10]) ." " .($words[$second_dec]);
	}
  //return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Paise Only";
  return ($Rupees ? $Rupees : '');
 }
?> 
<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>

<script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#customer_master").addClass('active');
    $("#mcustomer").addClass('active');
	 
});

function add_customer()
{ 		
	$("#customer_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
	e.preventDefault();
	document.getElementById("btncustomer").disabled = true;
	    var myform = document.getElementById("customer_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/customer_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Customer Records Added Successfully..");
				}else{
					alert("Customer Not Added, Please Try Again!");	
				}
				 location.reload();
			}
		});
	 
	 }
	 });
} 

function activate_deactivate(id,status)
 {
	$.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'customer'},
     success: function(data)
     {
		if(data==1){
			alert("Customer Status Updated Successfully..");
		}else{
			alert("Customer Status Not Updated, Please Try Again!");	
		}
		 location.reload();
     }

	});
	 
 } 
 
function update_customer()
 { 	 
		document.getElementById("btnupdatecustomer").disabled = true;
	    var myform = document.getElementById("custupdate_form");
		var fd = new FormData(myform);
	    $.ajax({
		  url: "excess/customer_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Customer Records Updated Successfully..");
				}else{
					alert("Customer Not Updated, Please Try Again!");	
				}
				 location.reload();	 
			}
		});
	 
	 
	 
}
 
function edit_customer(id)
{
 	 $.ajax({
     url:'excess/edit_customer.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#customer_edit').html('');
	  $('#cust_title').html('');
	  $('#cust_title').html('Customer Update');
	  $('#cust_title1').html('');
	  $('#cust_title1').html('Customer Update');
	   $('#customer_edit').append(data);
	    $(window).scrollTop($('#customer_edit').offset().top-20); 
	  }
	 
	}); 
}

function delete_customer(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'customer'},
     success: function(data)
     {
	   if(data==1){
			alert("Customer Deleted Successfully..");
		}else{
			alert("Customer Not Deleted, Please Try Again!");	
		}
		 location.reload();
	 }
	});
	
	}
	else{}
 }
 
// for datetimepicker
	$(function () {
		$('#datetimepicker1').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
		$('#datetimepicker2').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
	});

// for Number only
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		//document.getElementById("error").style.display = ret ? "none" : "inline";
		return ret;
	}
	
// for mobile number exist or not	
function check_mobile()
{
	var forr='customer';
	var mobile = $('#contact_no').val();
	if(mobile!=''){
		$.ajax({
		url:'excess/check_customer_mobile_exce.php',
		 type:'POST',
		 data:{'mobile':mobile,'forr':forr},
		 success: function(data)
		 {
			 //alert(data);
			if(data==1){
				alert("Mobile Number Already Exist!");
				$('#contact_no').val('');
				$('#contact_no').focus();
				 document.getElementById("btncustomer").disabled = true;
			}else{
				//alert("Status Not Updated, Please Try Again!");	
				 document.getElementById("btncustomer").disabled = false;
			}
		 }

		});
	}
				 
}

function email_customer(id,name)
{
	//alert(id);
	$('#email_id_mail').val(id);
	$('#cust_name_mail').val(name);
	$('#page_url').val('customer.php');
	$("#mail_email").modal("show");	
}	
</script>
<body class="hold-transition skin-blue sidebar-mini">
<div class=" ">
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 id="cust_title">
Customer Add:
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active" id="cust_title1">Customer Add</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	<div class="row">
	<div  class="col-md-12">
	 <div style="border:2px solid #f39c12;" class="panel panel-warning">
	 
	  
	  <div class="panel-body" id="customer_edit">
	
	   <form id="customer_form" onsubmit="return add_customer()"  autocomplete="off" enctype="multipart/form-data" method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <div class="col-md-6">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-2 control-label">Customer name:</label>
		
      <div class = "col-sm-10">
         <input type = "text" class = "form-control" pattern="([A-z0-9À-ž\s]){2,}" id="cust_name" name="cust_name"  data-bind="value:Id" placeholder = "Enter Name">
      </div>
   </div>
   
   <div class="form-group">
      <label for="email" class = "col-sm-2 control-label">Email:</label>
	  
	  <div class = "col-sm-10">
      <input type="email" class="form-control" id="email_id" placeholder="Enter email" name="email_id">
	  </div>
    </div>
   
   <div class = "form-group">
      <label for ="quantity" class = "col-sm-2 control-label">Mobile No.:</label>
		
      <div class = "col-sm-10">
         <input style="margin-bottom: 13px;" type = "text"  class ="form-control" id="contact_no" name="contact_no" onkeypress="return IsNumeric(event);" onblur="check_mobile();" placeholder = "Enter Contact No.">
		 <span id="errmobileexist" style="display:none;">Mobile Number Already Exist!</span>
      </div>
   </div>
   
   <div class = "form-group">
      <label for = "document" class = "col-sm-2 control-label">Documents:</label>
		
		<div class = "col-sm-10">
		   <input type="file" class="form-control" id="document" placeholder="Enter Select Document" name="document">
	 </div>
	</div>
</div>
 
 <div class="col-md-6">
    
   
   
   
   <div class = "form-group" >
      <label for = "price" class = "col-sm-2 control-label">Date Of Birth:</label>
		
      <div class = "col-sm-10">
	  
	   <div class='input-group date' id='datetimepicker1'>
        <input   type = "text"  class ="form-control" id = "birth_date" name="birth_date"   placeholder = "Enter DOB">
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
   
   <div class = "form-group" >
      <label for="price" class="col-sm-2 control-label">Anniversary Date:</label>
		
      <div class = "col-sm-10">
	  
	   <div class='input-group date' id='datetimepicker2'>
        <input   type = "text"  class ="form-control" id = "anniversary_date" name="anniversary_date"   placeholder = "Enter Anniversary Date">
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
   
   <div class = "form-group" >
      <label for="price" class="col-sm-2 control-label">Customer GST No:</label>
		
      <div class = "col-sm-10">
	  
	   <input type = "text" class = "form-control"  id="cust_gst_no" name="cust_gst_no" placeholder = "Enter Customer GST No">
        </div>
   </div>
   
  
   <div class = "form-group">
      <label for = "dealername" class = "col-sm-2 control-label">Address:</label>
		
      <div class = "col-sm-10">
		<textarea class = "form-control" rows="3" pattern="([A-z0-9À-ž\s]){2,}" id = "address" name="address" placeholder = "Enter Address"></textarea>
      </div>
   </div>
    
   
</div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">  
			<button type="submit" id="btncustomer" class="btn btn-primary"><i class="fa fa-plus"></i>Add Customer</button>
	
		  <button  type="reset" class="btn btn-danger">Cancel</button>
			</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>

	  <div class="col-md-12 ">
	  <div style="border:2px solid #f39c12;" class="panel panel-warning">

          <div class=" ">
            <div class="box-header">
              <h3 class="box-title">Customer Details</h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Document</th>
				  <th>Contact No.</th>
                  <th Style="border-right-width:2px;">Date of Birth</th>
                  <th Style="border-right-width:2px;">Anniversary Date</th>
				  <th Style="border-right-width:2px;">Address</th>
				 
				  <th Style="border-right-width:2px;">Status</th>
				  <?php if(in_array("Email", $admin_rv)){?>
				  <th Style="border-right-width:2px;">Mail Send</th>
				  <?php } ?>
				  <th Style="border-right-width:2px;">Edit</th>
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead><tbody>
				<?php 
				 $user_query = "SELECT * FROM `customer` WHERE added_by IN ($users_ids) ORDER BY customer_id DESC";
			$cust_res = mysqli_query($conn,$user_query);
			$i=0;
			while($cust_data = mysqli_fetch_assoc($cust_res))
					{
						
						$id_proof= $cust_data['id_proof'];
						$user_level= $cust_data['user_level'];
						$status=$cust_data['status'];
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  
                  <td><?=$cust_data['customer_name']?></td>
				  <td><?=$cust_data['email_id']?></td>
				   <td> <img width="30" src="img/customer/<?=$cust_data['id_proof']?>" alt="pic" onerror="this.src='img/no_img.png';" ></td>
                  
                  <td><?=$cust_data['mobile']?></td>
                  <td><?php if($cust_data['date_of_birth']){ echo  $cust_data['date_of_birth'];} else { echo "-";}?></td>
                  <td><?php if($cust_data['wedding_date']){ echo  $cust_data['wedding_date'];} else { echo "-";}?></td>
                    <td Style="border-right-width:2px;" align="center"><?=$cust_data['address']?></td>
				   <td> 
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $cust_data['customer_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				   <?php if(in_array("Email", $admin_rv)){?>
				  <td>
					<?php if($cust_data['email_id']!="") {?>
				  <a href="javascript:void(0);" class="btn" onclick="email_customer('<?php echo $cust_data['email_id']; ?>','<?php echo $cust_data['customer_name']; ?>');"><i class="fa fa-envelope" title="Email Send"></i></a>
					<?php } ?>
				  </td>
				   <?php } ?>
				  <td><a href="javascript:void(0);" class="btn" onclick="edit_customer('<?php echo $cust_data['customer_id']; ?>');"><i class="fa fa-pencil" title="Edit Customer"></i></a></td>
                <td  Style="border-right-width:2px;">
					<a href="javascript:void(0);" class="btn" onclick="delete_customer('<?php echo $cust_data['customer_id']; ?>');">
							<i class="fa fa-trash" title="Delete Customer" style="font-size:18px;text-align: center;"></i></a>
				</td>
				</tr>
                 
                
					<?php } ?></tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	</div>
	</div>
	
	
	
  <?php include 'footer.php';?>
</body>
</html>

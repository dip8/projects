<script>
  /* function getProduct(e){
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	 //alert(category_id);
	$("#product_name").autocomplete({
		 source:'excess/mobile_cat_select_value.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id,
		select:function(event,ui){
			 
		}
 });
}
 function getColor(e){
	 
	$("#color_name").autocomplete({
		 source:'excess/color_name.php',
		select:function(event,ui){
			 
		}
 });
} */

$(document).ready(function(){
$(document).on("focus", "[class*='item1_class1']", function() {
$(".product_name").on("focus",function(){ 
	//alert("as");
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	 
	$(this).autocomplete({
		 source:'excess/mobile_cat_select_value_purch.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id,
		select:function(event,ui){
		 }
 });
});
/* 
$(".color").on("focus",function(){ 
	var category_id=$("#cat_id_hid").val();
	var sub_category_id=$("#subcat_id_hid").val();
	var company_id=$("#com_id_hid").val();
	$(this).autocomplete({
		 source:'excess/color_name.php',
		select:function(event,ui){
			 
		}
	 });
	}); */

});
});
   
</script>
<script>
    $(document).ready(function(){
			var category_id=$("#cat_id_purch").val();
	var sub_category_id=$("#sub_cat_id").val();
	var company_id=$("#company_id").val();
	 $("#cat_id_hid").val(category_id);
	 $("#subcat_id_hid").val(sub_category_id);
	 $("#com_id_hid").val(company_id);
	
	 /* $('input#product_name').typeahead({
        name: 'gotra',
         remote:'excess/mobile_cat_select_value.php?category_id='+category_id+'&sub_category_id='+sub_category_id+'&company_id='+company_id+'&key=%QUERY',
         limit : 10
    });
	  */
});
 /* $(document).ready(function(){
	$('input#color_name').typeahead({
        name: 'gotra',
        remote:'excess/color_name.php?key=%QUERY',
        limit : 10
    }); 
 }); */
</script>  
<tr class="item1_class1">
<input type="hidden" id="cat_id_hid">
<input type="hidden" id="subcat_id_hid">
<input type="hidden" id="com_id_hid">
<td>
<input type="text"  class="form-control product_name" name="product_name_purch[]" id="product_name_purch"  onkeypress="getProduct(event)" onkeyup="getProduct(event)"    placeholder="e.g  Samsung" required>
</td>
 
<td>
<input name="quantity[]" id="quantity" type="number" value="1" class="product_qty form-control" placeholder="Quantity" required>
</td>
<td class="">
<input name="unit_cost[]" id="unit_cost" type="number"  class="acce_cost form-control"   onblur="unit_cost(this.value)" placeholder="Unit Cost" required >
</td>
<td>
<select name="gst_cost[]" id="gst_cost" style="padding: 1%;" class="acce_gst form-control" onchange="gst_costff(this.value)" required>
<option value="0"> 0%</option>
<option value="5"> 5%</option>
<option value="12"> 12%</option>
<option value="18"> 18%</option>
<option value="28"> 28%</option>
</select>
</td>
<td>
<input name="total_cost[]" id="total_cost" type="text" value = "" class="total_cost form-control" readonly/>
</td>
<td>
<input name="sale_cost[]" id="sale_cost" type="text" value = "" placeholder="Sale Cost" class=" form-control"/>
</td>
<td>
<button type="button" class="btn btn-danger remove1">
<i class="glyphicon glyphicon-remove-sign"></i></button>
</td>
</tr>
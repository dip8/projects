<?php
require_once('../db_config/database_config.php');

	$user_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `user` WHERE `user_id`='$user_id'");
	 
		$user_row=mysqli_fetch_assoc($res);	
	 
	?>
<form id="user_update_form" onsubmit="return update_user()"  autocomplete="off" enctype="multipart/form-data" method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
      <div class="col-md-11 col-md-push-1">  
<input type="hidden" name="user_id" id="user_id" value="<?=$user_row['user_id']?>">	  
   <div class = "form-group">
      <label for = "dealername" class = "col-md-3 control-label">First Name:</label>
	 <div class = "col-md-6">
            <input type="text"  value="<?php echo $user_row['fname'];?>" class ="form-control" id ="f_name" name="f_name"    placeholder = "Enter First Name" required>
   </div>
   </div>
   
   <div class = "form-group">
      <label for = "proname" class = "col-md-3 control-label">Last Name:</label>
		
      <div class = "col-md-6">
         <input type = "text" value="<?php echo $user_row['lname'];?>"  class ="form-control" id="l_name" name="l_name"    placeholder = "Enter Last Name" required>
      </div>
   </div>
   <div class = "form-group">
      <label for = "proname" class = "col-md-3 control-label">Email Id:</label>
		
      <div class = "col-md-6">
         <input type="email"  class="form-control"   id="email" name="email" value="<?php echo $user_row['email'];?>"  placeholder = "Enter Email Id Name"  required>
      <div id="err_email" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Username/Email-Id are found...! Please  Enter New Email-Id..!</span> </div>
				
	  </div>
   </div>
   <!--div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Password:</label>
		
      <div class = "col-md-10">
         <input type="password"  class="form-control" id="password1" name="password1"  placeholder = "Enter Password ">
      </div>
   </div>
   <div class = "form-group">
      <label for = "proname" class = "col-md-2 control-label">Conf.-Password:</label>
		
      <div class = "col-md-10">
         <input type="password"  class="form-control" id="cnf_password" name="cnf_password"  placeholder = "Enter Confirm Password ">
      </div>
   </div-->
  
     
    
   
   <div class="form-group">
      <label for = "quantity" class = "col-md-3 control-label">Contact No:</label>
	 <div class = "col-md-6">
         <input   type="number" value="<?php echo $user_row['contact_no'];?>"  class ="form-control" id="contact" maxlength="10" name="contact" placeholder = "Enter Contact No." required>
      </div>
   </div>
   
   <div class="form-group">
      <label for = "quantity" class = "col-md-3 control-label">Profile Image:</label>
		
      <div class = "col-md-6">
	  <?php if($user_row['profile_pic']) { ?>
		 <img width="50" src="img/user/<?=$user_row['profile_pic']?>" alt="pic" >
		<?php } ?>
         <input type="file"  class="form-control" id="profile_pic" name="profile_pic"  placeholder = "Select Profile Image">
      </div>
   </div>
   
   <div class = "form-group">
      <label for = "proname" class = "col-md-3 control-label">User Level:</label>
		
      <div class = "col-md-6">
	    <select class="select21 form-control" name="user_level" id="user_level" required>
		<option value="">-- Select User Level --</option>
		<?php
		 $uselq = mysqli_query($conn,"SELECT * FROM `user_level` WHERE `status`='1' ");
			while($uselr=mysqli_fetch_assoc($uselq)){
		?>
		<option value="<?=$uselr['u_id']?>"  <?php if($uselr['u_id']==$user_row['user_level']){?>selected<?php } ?>><?=$uselr['level_name']?></option>
	 			<?php } ?>
		</select>
        </div>
   </div>
    
    
   
	</div>

			<div class="col-md-5 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnuserupdate" class="btn btn-primary"><i class="fa fa-plus"></i>Update User</button>
					
				<a href="" class="btn btn-danger">Cancel</a>
					</div>
			</div>
	 </form>
<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
		$area_name= ucfirst($_POST['area_name']);
		$ques="select area_name from area where area_name='$area_name'";
		$query = mysqli_query($conn,$ques);
		$row =  mysqli_affected_rows($conn);
		if($row>0)
		{
			echo 2;
		}else{
			$que ="INSERT INTO `area`(`area_id`, `area_name`, `status`) VALUES (NULL,'$area_name','1')";
			$inscat = mysqli_query($conn,$que);
			if($inscat){
				echo 1;
			}else{
				echo 0;
			}
		}
		 
?>


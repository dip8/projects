<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $array = array();
    $query=mysqli_query($conn,"select * from supplier where supplier_name LIKE '%{$key}%' AND added_by IN ($users_ids)");
    while($row=mysqli_fetch_assoc($query))
    {
     // $array[] = $row;
	   $array[]=array(
                    'value'=> $row["supplier_name"],
                    'label'=>$row["supplier_name"],
					'id'=>$row["supplier_id"],
					'mobile'=>$row["contact_number"],
					'email'=>$row["email_id"],
					 
                        ); 
    }
    //echo json_encode($array);
	$json = json_encode($array);
    print_r($json);
?>

<?php
	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $cat=$_REQUEST['cat'];
    $array = array();
    $query=mysqli_query($conn,"select * from company where company_name LIKE '%{$key}%' AND status=1");
    while($row=mysqli_fetch_assoc($query))
    {
		//$company_name = explode(' ',trim($row["product_name"]));
		$array[]=array(
                    'value'=>$row['company_name'],
                    'label'=>$row['company_name'],
					'company_name'=>$row['company_name']
                        ); 
    }
	$json = json_encode($array);
    print_r($json);
?>

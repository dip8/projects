<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];
require_once('../db_config/database_config.php');

	$product_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `product` WHERE `product_id`='$product_id'");
		$product_row=mysqli_fetch_assoc($res);	

	?>

	

<div class="tab-pane active" id=" ">
	<form id="productupdate_form" onsubmit="return update_product()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
	<input type="hidden" value="<?=$product_row['product_id']?>" name="product_id_edit" id="product_id_edit">
			
		<div class="form-group">
		<label for="Brand" class="col-sm-3 control-label">Type</label>
		<div class = "col-sm-5" id="">
	    <div class="col-sm-2"> 
	    <input type="radio" name="type1" id="type1" value="1" <?php  if($product_row['flag']==1){ echo "checked";}else {echo "";}?>><label for="radio102"> A </label>
	    </div>
	    <div class="col-sm-2">
	    <input type="radio" name="type1" id="type1"  value="0" <?php  if($product_row['flag']==0){ echo "checked";}else {echo "";}?>><label for="radio102"> C </label>
        </div>
        </div>
	   </div>
		
		   <div class = "form-group">
				<label for ="dealerid" class = "col-md-2 control-label">Product Number:</label>
				<div class = "col-md-4">
				<input type = "text" value="<?php echo $product_row['product_number'];?>" class = "form-control" id ="product_number_edit" name="product_number_edit" placeholder = "Enter Id" disabled>
				</div>
			</div>

			<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Product Name:</label>
				<div class = "col-md-4">
				<input type="text" class="form-control" value="<?php echo $product_row['product_name'];?>" id="product_name_edit" placeholder="Enter Product Name" name="product_name_edit" required>
				</div>
			</div>
			
			<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Category :</label>
				<div class = "col-md-4">
				 <input type="hidden" name="category_id_edit" id="category_id_edit" value ="<?= $product_row['category_id'];?>">
				 <select class="select21 form-control" name="category_i" id="category_i" required disabled>
					<option value="">Select Category</option>
					<?php 
					$resct = mysqli_query($conn,"SELECT * FROM `category`");
					while($cat_row = mysqli_fetch_assoc($resct))
					{?>
					<option <?php if($product_row['category_id']==$cat_row['category_id']){echo 'selected';}?> value="<?php echo $cat_row['category_id'] ?>"><?php echo $cat_row['category_name'] ?></option>
					<?php } ?>
				</select>
				</div>
			</div>

			<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Sub-Category :</label>
				<div class = "col-md-4">
				<input type="hidden" name="subcategory_id_edit" id="subcategory_id_edit" value ="<?= $product_row['sub_category_id'];?>" >
				<select class="select21 form-control" name="subcategory_id" id="subcategory_id" required disabled>
					<option value="">Select Sub-Category</option>
					<?php 
					$ressuct = mysqli_query($conn,"SELECT * FROM `sub_category`");
					while($subcat_row = mysqli_fetch_assoc($ressuct))
					{?>
					<option <?php if($product_row['sub_category_id']==$subcat_row['sub_category_id']){echo 'selected';}?> value="<?php echo $subcat_row['sub_category_id'] ?>"><?php echo $subcat_row['sub_category_name'] ?></option>
					<?php } ?>
				</select>
				</div>
			</div>

			<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Company :</label>
				<div class = "col-md-4">
				<select class="select21 form-control" name="product_company_edit" id="product_company_edit" required>
					<option value="">Select Company</option>
					<?php 
					$rescmp = mysqli_query($conn,"SELECT * FROM `company`");
					while($cmop_row = mysqli_fetch_assoc($rescmp))
					{?>
					<option <?php if($product_row['product_company']==$cmop_row['company_id']){echo 'selected';}?> value="<?php echo $cmop_row['company_id'] ?>"><?php echo $cmop_row['company_name'] ?></option>
					<?php } ?>
				</select>
				</div>
			</div>

			<div class = "form-group">
				<label for = "dealerid" class = "col-md-2 control-label">Dealer :</label>
				<div class = "col-md-4">
				<select class="select21 form-control" name="product_supplier_edit" id="product_supplier_edit" required>
					<option value="">Select Dealer</option>
					<?php 
					$ressup = mysqli_query($conn,"SELECT * FROM `supplier` where added_by IN ($users_ids)");
					while($sup_row = mysqli_fetch_assoc($ressup))
					{?>
					<option <?php if($product_row['supplier_number']==$sup_row['supplier_id']){echo 'selected';}?> value="<?php echo $sup_row['supplier_id'] ?>"><?php echo $sup_row['supplier_name'] ?></option>
					<?php } ?>
				</select>
				</div>					  
			</div>
			
			<div class="form-group">
				<label for="number" class = "col-md-2 control-label">Quantity:</label>
				<div class = "col-md-4">
				<?php if($product_row['category_id']==1){?>	
				<input type="number" value="<?php echo $product_row['quantity'];?>" class="form-control" id="product_quantity_edit" name="product_quantity_edit" placeholder="Enter Quantity" required readonly/>
				<?php } else{?>
				<input type="number" value="<?php echo $product_row['quantity'];?>" class="form-control" id="product_quantity_edit" name="product_quantity_edit" placeholder="Enter Quantity" required />
                 <?php } ?>
				</div>
			</div>
			
			<div class="form-group">
				<label for="number" class = "col-md-2 control-label">Minimum Qty:</label>
				<div class = "col-md-4">
				<input type="number" value="<?php echo $product_row['min_qty'];?>" class="form-control" id="min_qty_edit" name="min_qty_edit"  placeholder="Enter Minimum Quantity" required>
				</div>
			</div>
			
			<!--<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Unit of Measurement:</label>
				<div class = "col-md-4">
				<select class="select21 form-control" name="uom_edit" id="uom_edit" required>
					<option value="">Unit of Measurement</option>
					<option <?php if($product_row['unit_of_measurement']=='PCS'){echo 'selected';}?> value="PCS">PCS</option>
				</select>
				</div>
			</div>-->
			
			<div class="form-group">
				<label for="email" class = "col-md-2 control-label">Purchase Price:</label>
				<div class = "col-md-4">
				<input type="number" class="form-control" value="<?php echo $product_row['purchase_price'];?>" id="purchase_price_edit" name="purchase_price_edit" placeholder="Enter Purchase Price" required>
				</div>
			</div>
			
			<div class = "form-group">
				<label for = "quantity" class = "col-md-2 control-label">Selling Price:</label>
				<div class = "col-md-4">
				<input type="number" style="margin-bottom: 13px;" value="<?php echo $product_row['sale_price'];?>" name="selling_price_edit" id="selling_price_edit" class ="form-control" placeholder = "Enter Selling Price" required>
				</div>
			</div>
			
			<div class="row" style="text-align:center;">
				<div  class="box-footer clearfix no-border">
				<button type="submit" id="btnupdateproduct" class="btn btn-primary"><i class="fa fa-plus"></i> Update Product</button>
				<a href="" class="btn btn-danger">Cancel</a>
				</div>
			</div>
   
	</form>
</div>
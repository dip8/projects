<?php
session_start();
require_once('../db_config/database_config.php');
				 
		$area_id= $_POST['area_id'];
		$area_name= $_POST['area_name'];

		$que ="UPDATE `area` SET `area_name`='$area_name' WHERE area_id='$area_id'";
		$insprofile = mysqli_query($conn,$que);
			 
		if($insprofile){
			  echo 1;
		}else{
			  echo 0;
		}
?>
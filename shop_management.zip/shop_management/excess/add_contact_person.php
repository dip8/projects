<?php
//error_reporting(0);
require_once('../db_config/database_config.php');
 
		$supplier_id=$_POST['supplier_id'];
		
		 $query11="SELECT * FROM `supplier` WHERE supplier_id='$supplier_id'";
		$selbd11 = mysqli_query($conn, $query11) or die('query error');
		$emp_row11 = mysqli_fetch_assoc($selbd11);
		?>
		 <div class="page-head">
         
          <ol class="breadcrumb  " style="height: 25px;">
              <span style="float:left;color:red;"> Dealer Name : <?php echo ucfirst($emp_row11['supplier_name']);?> </span>
             <span style="float:right;color:red;"> Dealer No : <?php echo $emp_row11['supplier_number'];?> </span>
             
          </ol>
        </div>
    <form name="contact_form11" id="contact_form11" action="javascript:void(0);"  method="POST" class="form-horizontal group-border-dashed">
	 <div class="modal-body" style="overflow-y: auto; max-height:500px;">   
		 <div class="row">
			<input type="hidden" name="supplier_id" id="supplier_id" value="<?php echo $supplier_id;?>">
			<div class="col-sm-11">
			<div class="form-group">
			  <label class="col-sm-4 control-label">Person Name :</label>
			  <div class="col-sm-8">
			  <input type="text" name="c_name" id="contact_name"   parsley-trigger="change" required="" placeholder="Person Name" autocomplete="off" class="form-control">
			</div>
			</div>
			</div>
			</div><p>
			<div class="row">
			<div class="col-sm-11">
			 <div class="form-group">
			  <label class="col-sm-4 control-label">Phone No :</label>
			  <div class="col-sm-8">
			  <input type="number" name="phone_no" id="contact_phone"   parsley-trigger="change" required="" placeholder="Contact No" autocomplete="off" class="form-control">
			</div>
			</div>
			</div>
		 </div>
		 <p>
			<div class="row">
		 <div class="col-sm-11">
			<div class="form-group">
			  <label class="col-sm-4 control-label">Email Id :</label>
			  <div class="col-sm-8">
			  <input type="email" name="email" id="contact_email"   parsley-trigger="change"   placeholder="Email Id" autocomplete="off" class="form-control">
			</div>
			</div>
			</div>
			</div>
		 </div>
		<div class="row">
		<input type="button" onclick="add_contact()" id="btncontact" class="btn btn-space btn-primary" value="Add">
		 	</div>
	</form>
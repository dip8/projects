<?php
session_start();
require_once('../db_config/database_config.php');
		
error_reporting(0);	
$shop_id=$_POST['shop_id'];
  $id=$_POST['id'];
 ?>
 <table style="margin-left:10px;"  class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Exchange No</th>
                  <th>Exchange Date</th>
                  
                  <th>  Shop Name</th>
                
                  <th>Total Amount</th>
				  
                  <th>Total Payment</th>
				  <th>Balance Amount</th>
                  <th>Due Date</th>
				  <th>View Transaction </th>
				  <th>Pay Now</th>
				   
				  
                  
                </tr>
                </thead><tbody >
					<?php 
					if($id=="out"){
				 $tra_query = "SELECT * FROM `exchange` where to_shop='$shop_id' ORDER BY exchange_id DESC";
					}else if($id=="in"){
				 $tra_query = "SELECT * FROM `exchange` where from_shop='$shop_id' ORDER BY exchange_id DESC";
					}
			$tra_res = mysqli_query($conn,$tra_query);
			$i=0;
			while($tra_data = mysqli_fetch_assoc($tra_res))
					{
						 
					  $from_shop=$tra_data['from_shop'];
					 $to_shop=$tra_data['to_shop'];
					  $exchange_number=$tra_data['exchange_number'];
				  $traq = mysqli_query($conn,"SELECT * FROM `exchange_payment_transaction` WHERE `ref_id`='$exchange_number'");
						$tral=mysqli_fetch_assoc($traq);
						$due_date= $tral['due_date'];
						 
						
						$supp_q = mysqli_query($conn,"SELECT * FROM `about_shop` WHERE `shop_id`='$from_shop'");
						$sup_data= mysqli_fetch_assoc($supp_q);
						$shop_namef=$sup_data['shop_name'];
						$supp_q1 = mysqli_query($conn,"SELECT * FROM `about_shop` WHERE `shop_id`='$to_shop'");
						$sup_data1= mysqli_fetch_assoc($supp_q1);
						$shop_namet=$sup_data1['shop_name'];
						 
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$tra_data['exchange_number']?></td>
                  <td><?=$tra_data['exchange_date']?></td>
				  <td><?php if($id=="in"){ echo $shop_namef; } else if($id=="out"){ echo $shop_namet; }?></td>
				   
				   <td><?=$tra_data['amount']?></td>
                  <td><?=$tra_data['pay_amount']?></td>
				  <td><?=$tra_data['bal_amount']?></td>
				  <td><?=$due_date?></td>
				   <td>
					<a  class="btn btn-success btn-xs" onclick="trasaction_details('<?php echo $tra_data['sales_number']; ?>','<?=$supplier_name?>');">
					<i class="glyphicon glyphicon-eye-open" title="View Application" style="font-size:18px;text-align: center;"></i></a>
				  </td>
                  <td>
				  <?php if($tra_data['bal_amount']!=0){?>
				  <a class="btn btn-info btn-xs" onclick="payment_now('<?php echo $tra_data['exchange_number']; ?>','<?=$id?>');">
				  <i class="fa fa-money" title="Pay Remaining Amount" style="font-size:18px;text-align: center;"></i></a>
					<?php } ?>
				  </td>
                  
                 
                  
                </tr>
                 
                
                
					<?php } ?></tbody>
              </table>
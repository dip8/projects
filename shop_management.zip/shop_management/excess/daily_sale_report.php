<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
error_reporting(0);	
$from_date=$_POST['from_date'];
  $to_date=$_POST['to_date'];
 ?>
 <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>Bill Number</th>
                  <th>Bill Date</th>
                  <th>Category</th>
                  <th>Product Name</th>
                  <th>IMEI No</th>
                  <th>HSN No</th>
                  <th>Color</th>
                  <th>Customer Name</th>
				  <th>Total Amt</th>
				  <th>GST Amt</th>
                  <th>Final Total Amt</th>
                  <!--th>Edit Price</th>
                  <th>Print Bill</th-->
                 
                </tr>
                </thead>
               <tbody > 
 
 <?php
			$user_query = "SELECT * FROM sales WHERE sales_date BETWEEN '$from_date' AND '$to_date' AND added_by IN ($users_ids) ORDER BY sales_id DESC";
			$user_res = mysqli_query($conn,$user_query);
			$i=0;
			while($sales_data = mysqli_fetch_assoc($user_res))
				{
					$sales_number=$sales_data['sales_number'];
					$sales_date=$sales_data['sales_date'];
					$customer_id=$sales_data['customer_id'];
					$total_amount=$sales_data['total_amount'];
					 
					 
					$gst_amount=$sales_data['gst_amount'];
					$final_total_amount=$sales_data['final_total_amount'];
				 
					
					$rescm = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
					$cust_row=mysqli_fetch_assoc($rescm);
					$customer_name=$cust_row['customer_name'];
					$customer_mobile=$cust_row['mobile'];
					
			 $ques2=mysqli_query($conn,"SELECT * FROM `sales_detail` WHERE `sales_number`='$sales_number'");
		 $rowv2 =  mysqli_fetch_assoc($ques2);
			$product_number = $rowv2['product_number'];	
			  $ques3=mysqli_query($conn,"SELECT * FROM `product` WHERE `product_id`='$product_number'");
		 $rowv3 =  mysqli_fetch_assoc($ques3);
			$product = $rowv3['product_name'];	
			$product_company = $rowv3['product_company'];	
			$category_id = $rowv3['category_id'];	
			$hsn_no = $rowv3['hsn_no'];	
			$color = $rowv3['color'];	
			 
			$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$product_company'");
						$cmp_row=mysqli_fetch_assoc($rescm);
						$company_name=$cmp_row['company_name'];
						$product_name=$company_name." ".$product;
						
			$resct = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
			$cat_row=mysqli_fetch_assoc($resct);
			$category_name=$cat_row['category_name'];
			$ressct = mysqli_query($conn,"SELECT * FROM `mobile_imei` WHERE `product_id`='$product_number'");
			$subcat_row=mysqli_fetch_assoc($ressct);
			$imei_no=$subcat_row['imei_no'];
				?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$sales_number;?></td>
                  <td><?=$sales_date;?></td>
                  <td><?=$category_name;?></td>
                  <td><?=$product_name;?></td>
                  <td><?php if($imei_no){ echo $imei_no;}else{ echo "-";}?></td>
                  <td><?php if($hsn_no){ echo $hsn_no;}else{ echo "-";}?></td>
                  <td><?php if($color){ echo $color;}else{ echo "-";}?></td>
                 
                  <td><?=$customer_name.' ('.$customer_mobile.')';?></td>
                  <td><?=$total_amount;?></td>
                 
                  <td><?=$gst_amount;?></td>
                  <td><?=$final_total_amount;?></td>
		  
				<!--td>
					<a class="btn btn-info btn-xs" onclick="edit_price('<?php echo $sales_data['sales_number']; ?>');">
					<i class="fa fa-pencil" title="View Profile" style="font-size:20px;text-align: center;"></i></a>
				</td>
                <td>
				 <a class="btn btn-success btn-xs" onclick="bill_preview('<?php echo $sales_data['sales_number']; ?>');">
				 <i class="fa fa-print" title="View Profile" style="font-size:20px;text-align: center;"></i></a>
				</td-->
                </tr>
                 
                
               
					<?php } ?></tbody > </table>
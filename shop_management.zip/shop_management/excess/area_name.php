<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $array = array();
    $query=mysqli_query($conn,"select * from area where area_name LIKE '%{$key}%'");
    while($row=mysqli_fetch_assoc($query))
    {
     
	   $array[]=array(
                    'value'=> $row["area_name"]
                     ); 
    }
    //echo json_encode($array);
	$json = json_encode($array);
    print_r($json);
?>
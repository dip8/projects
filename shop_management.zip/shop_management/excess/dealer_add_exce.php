<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
			   
			$dealer_name= $_POST['dealer_name'];
			$brand= $_POST['brand'];
			 
			$email= strtolower($_POST['email']);
			$address= $_POST['address'];
			$contact= $_POST['contact_no'];
			$p_contact_no= $_POST['p_contact_no'];
			$c_person= $_POST['c_person'];
			$dealer_gst_no= $_POST['dealer_gst_no'];
			 $user_id = $_SESSION['user_id']; 
		 $brand_s=implode(",",$brand);
				$que ="INSERT INTO `supplier`(`supplier_id`, `supplier_number`, `supplier_name`, `supplier_address`, `contact_person`, `contact_number`, `email_id`, `supplier_for`, `note`, `balance`, `added_date`, `added_by`, `update_date`, `updated_by`, `status`, `dealer_gst_no`) VALUES (NULL,'', '$dealer_name', '$address', '$c_person','$contact','$email', '$brand_s', '', '0',NULL,'$user_id',NULL,'','1','$dealer_gst_no')";
				 $insprofile = mysqli_query($conn,$que);
			 
			 $supplier_id = mysqli_insert_id($conn);
				 
				$exportId = str_pad($supplier_id, 11, '0', STR_PAD_LEFT);
				 
			$cust_no='Dealer-'.$exportId;
			$update_id = mysqli_query($conn, "UPDATE `supplier` SET `supplier_number`='$cust_no' WHERE `supplier_id`='$exportId'")or die('error last insert id');
			 
			$contact_q="INSERT INTO `contact_person`(`contact_id`, `supplier_id`, `contact_name`, `contact_phone`, `contact_email`, `status`) VALUES( NULL, '$supplier_id', '$c_person', '$p_contact_no', '', '1')";
			 $contact_q11 = mysqli_query($conn,$contact_q);
			 
			  for($i=0;$i<count($brand);$i++){
			  $query="INSERT INTO `company_supplier`(`com_sup_id`, `supplier_id`, `company_id`, `status`) VALUES ( NULL, '$supplier_id', '$brand[$i]', '1')";
			$insprofile11 = mysqli_query($conn,$query);
			  }
			if($insprofile11)
			{ echo 1;}else{echo 0;}
?>

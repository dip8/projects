<?php
require_once('../db_config/database_config.php');
session_start();
$e_id = $_POST['id'];
$status = $_POST['status'];	 
$user_id = $_SESSION['user_id']; 
$current_date= date("Y-m-d");
	
	$updates = "UPDATE repair SET status='$status', update_date='$current_date', updated_by='$user_id' WHERE repair_id='$e_id'";
	$upt = mysqli_query($conn,$updates)or die("error");
	
	if($status == 4)
	{
		$return_updates = "UPDATE repair SET return_date='$current_date' WHERE repair_id='$e_id'";
		$return_upt = mysqli_query($conn,$return_updates)or die("error");
	}else{
		
	}

	if($upt){
		echo 1;
	}else{
		echo 0;
	}
?>

	
<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

require_once('../db_config/database_config.php');
		
error_reporting(0);	
$from_date=$_POST['from_date'];
  $to_date=$_POST['to_date'];
 ?>



<?php

            $purch = "SELECT SUM(p.total_amount) AS total_amount, SUM(p.total_payment) AS total_payment, SUM(p.total_balance) AS total_balance FROM purchase p WHERE added_by IN ($users_ids) AND purchase_date BETWEEN '$from_date' AND '$to_date'";
			$total_purch = mysqli_query($conn,$purch);
			$totalpur_data = mysqli_fetch_assoc($total_purch); 

            $sale = "SELECT SUM(p.total_amount) AS total_amount, SUM(p.total_payment) AS total_payment, SUM(p.total_balance) AS total_balance, SUM(p.discount_amount) AS discount_amount, SUM(p.gst_amount) AS gst_amount FROM sales p WHERE added_by IN ($users_ids) AND sales_date BETWEEN '$from_date' AND '$to_date'";
		    $total_sale = mysqli_query($conn,$sale);
		    $totalsale_data = mysqli_fetch_assoc($total_sale); 

			
				?>
           <div class="row">
           <div class="col-lg-6 col-md-6 col-sm-6">
		    <div class="panel panel-default">
		      <div class="panel-heading"><strong>Purchase</strong></div>   
 			   <div class="panel-body">
			      <table class="table table-bordered table-striped ewDbTable"><tbody><tr><th>Total Amount</th><td style="text-align: right;"><?= $totalpur_data['total_amount']; ?></td></tr><tr><th>Total Payment</th><td style="text-align: right;"><?= $totalpur_data['total_payment']; ?></td></tr><tr><th>Total Balance</th><td style="text-align: right;"><?= $totalpur_data['total_balance']; ?></td></tr></tbody></table>  
                </div>
		     </div>
	      </div>
	      
	

         <div class="col-lg-6 col-md-6 col-sm-6">
		  <div class="panel panel-default">
		    <div class="panel-heading"><strong>Sales</strong></div>
             <div class="panel-body">
				<table class="table table-bordered table-striped ewDbTable"><tbody><tr><th>Total Amount</th><td style="text-align: right;"><?= $totalsale_data['total_amount']; ?></td></tr><tr><th>Discount Amount</th><td style="text-align: right;"><?= $totalsale_data['discount_amount']; ?></td></tr><tr><th>GST Amount</th><td style="text-align: right;"><?= $totalsale_data['gst_amount']; ?></td></tr><tr><th>Total Payment</th><td style="text-align: right;"><?= $totalsale_data['total_payment']; ?></td></tr><tr><th>Total Balance</th><td style="text-align: right;"><?= $totalsale_data['total_balance']; ?></td></tr></tbody></table>  
			</div>
		</div>
	  </div>
	</div>


 
 
               
		  
				
               
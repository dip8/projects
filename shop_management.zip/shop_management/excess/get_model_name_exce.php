<?php
	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $key=$_REQUEST['term'];
    $cat=$_REQUEST['cat'];
    $array = array();
    $query=mysqli_query($conn,"select * from product where category_id='$cat' AND product_name LIKE '%{$key}%' AND quantity > 0");
    while($row=mysqli_fetch_assoc($query))
    {
	 $product_name=$row["product_name"];
	 $company_name = explode(' ',trim($product_name));
	 $model_name = substr_replace($company_name[0],$product_name,0);
		$array[]=array(
                    'value'=>$model_name,
                    'label'=>$model_name,
					'model_name'=>$model_name
                        ); 
    }
    //echo json_encode($array);
	$json = json_encode($array);
    print_r($json);
?>

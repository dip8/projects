<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
			   
			$contact_name= $_POST['contact_name'];
			$contact_phone= $_POST['contact_phone'];
			 
			$contact_email= strtolower($_POST['contact_email']);
			$supplier_id= $_POST['supplier_id'];
			 
	  $contact_q="INSERT INTO `contact_person`(`contact_id`, `supplier_id`, `contact_name`, `contact_phone`, `contact_email`, `status`) VALUES( NULL, '$supplier_id', '$contact_name', '$contact_phone', '$contact_email', '1')";
			 $contact_q11 = mysqli_query($conn,$contact_q);
			 
			  
			if($contact_q)
			{ echo 1;}else{echo 0;}
?>

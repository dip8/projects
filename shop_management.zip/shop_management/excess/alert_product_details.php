<?php
	include ('../db_config/database_config.php');
    //$key=$_GET['key'];
    $product_id=$_REQUEST['product_id'];
    
    $query=mysqli_query($conn,"select * from product where product_id='$product_id'");
     $row=mysqli_fetch_assoc($query);
	 $product_company=$row['product_company'];
	 $category_id=$row['category_id'];
	 $rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$product_company'");
						$cmp_row=mysqli_fetch_assoc($rescm);
						$company_name=$cmp_row['company_name'];
						
						$resct = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
						$cat_row=mysqli_fetch_assoc($resct);
						$category_name=$cat_row['category_name'];
?>
		<div class="col-md-12">	 
			<table class="table">
				<tr>
				<th>Category</th>
				<td><?=$category_name?></td>
				</tr>
				<tr>
				<th>Product Company</th>
				<td><?=$company_name?></td>
				</tr>
				<tr>
				<th>Product Name</th>
				<td><?=$row['product_name']?></td>
				</tr>
				
				<tr>
				<th>HSN No</th>
				<td><?=$row['hsn_no']?></td>
				</tr>
				
				<tr>
				<th>Color</th>
				<td><?=$row['color']?></td>
				</tr>
				
				<!--tr>
				<th>Quantity</th>
				<td><?=$row['quantity']?></td>
				</tr-->
				
				 
				 
			</table>
		</div>	 
    

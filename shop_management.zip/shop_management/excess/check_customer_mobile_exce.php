<?php
session_start();
$users_ids = $_SESSION['multi_users_ids'];

include('../db_config/database_config.php');

	$mobile=$_POST['mobile'];
	$for=$_POST['forr'];
		if($for=='customer')
		{
			$ques="select mobile from customer where mobile='$mobile' AND added_by IN ($users_ids)";
			$query = mysqli_query($conn,$ques);
			$row = mysqli_affected_rows($conn);
			if($row>0)
				{
				echo 1;
				}
				else
				{
				 echo 0;
				}
		}

	
	
?>





<?php
session_start();
require_once('../db_config/database_config.php');
			
			 
		$financer_name= ucfirst($_POST['financer_name']);
		$ques="select financer_name from financer where financer_name='$financer_name'";
		$query = mysqli_query($conn,$ques);
		$row =  mysqli_affected_rows($conn);
		if($row>0)
		{
			echo 2;
		}else{
			$que ="INSERT INTO `financer`(`financer_id`, `financer_name`, `status`) VALUES (NULL,'$financer_name','1')";
			$inscat = mysqli_query($conn,$que);
			if($inscat){
				echo 1;
			}else{
				echo 0;
			}
		}
		 
?>


<?php
require_once('../db_config/database_config.php');

	$customer_id = $_POST['id'];
	 
	  $res = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
	 
		$customer_row=mysqli_fetch_assoc($res);	
	 
	?>

<script type="text/javascript">
		 $(function () {
			  $('#datetimepicker2').datepicker({
				  format: 'yyyy-mm-dd'
			  });
			  $('#datetimepicker3').datepicker({
				  format: 'yyyy-mm-dd'
			  });
			  
            });
        </script> 	
<form id="custupdate_form" onsubmit="return update_customer()"  autocomplete="off" enctype="multipart/form-data" method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <input type="hidden" name="customer_id" id="customer_id" value="<?=$customer_row['customer_id']?>">
	<div class="col-md-6">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-2 control-label">Customer name:</label>
		
      <div class = "col-sm-10">
         <input type = "text" value="<?php echo $customer_row['customer_name'];?>" class = "form-control" pattern="([A-z0-9À-ž\s]){2,}" id="cust_name" name="cust_name"  data-bind="value:Id" placeholder = "Enter Name" required>
      </div>
   </div>
   
   <div class="form-group">
      <label for="email" class = "col-sm-2 control-label">Email:</label>
	  
	  <div class = "col-sm-10">
      <input type="email" class="form-control" value="<?php echo $customer_row['email_id'];?>"  id="email_id" placeholder="Enter email" name="email_id">
	  </div>
    </div>
   
   
   <div class = "form-group">
      <label for = "document" class = "col-sm-2 control-label">Documents:</label>
		
		<div class = "col-sm-10">
		<?php if($customer_row['id_proof']) { ?>
		 <img width="50" src="img/customer/<?=$customer_row['id_proof']?>" alt="pic" onerror="img/no_img.png">
		<?php } ?>
		<input type="file" class="form-control" id="document" placeholder="Enter Select Document" name="document">
	 </div>
	</div>

   <div class = "form-group">
      <label for = "quantity" class = "col-sm-2 control-label">Contact No.:</label>
		
      <div class = "col-sm-10">
         <input style="margin-bottom: 13px;" type = "text" value="<?php echo $customer_row['mobile'];?>"  class ="form-control" id="contact_no" name="contact_no" data-bind="value:quantity" placeholder = "Enter Contact No." required>
      </div>
   </div>
   
   </div>
 
 <div class="col-md-6">
    
   <div class = "form-group" >
      <label for = "price" class = "col-sm-2 control-label">Date Of Birth:</label>
		
      <div class = "col-sm-10">
	  
	   <div class='input-group date' id='datetimepicker2'>
        <input   type = "text"  class ="form-control" id = "birth_date" name="birth_date" value="<?php echo $customer_row['date_of_birth'];?>"  placeholder = "Enter DOB">
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
  <div class = "form-group" >
      <label for="price" class="col-sm-2 control-label">Anniversary Date:</label>
		
      <div class = "col-sm-10">
	  
	   <div class='input-group date' id='datetimepicker3'>
        <input   type = "text"  class ="form-control" id = "anniversary_date" name="anniversary_date" value="<?php echo $customer_row['wedding_date'] ;?>"   placeholder = "Enter Anniversary Date">
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div> 
   
   <div class = "form-group" >
      <label for="price" class="col-sm-2 control-label">Customer GST No:</label>
		
      <div class = "col-sm-10">
	  
	   <input type = "text" class = "form-control"  id="cust_gst_no" name="cust_gst_no" value="<?php echo $customer_row['customer_gst_no'];?>" placeholder = "Enter Customer GST No">
        </div>
   </div>
  
   <div class = "form-group">
      <label for = "dealername" class = "col-sm-2 control-label">Address:</label>
		
      <div class = "col-sm-10">
		<textarea class = "form-control" rows="3" pattern="([A-z0-9À-ž\s]){2,}" id = "address" name="address" placeholder = "Enter Address" required><?php echo $customer_row['address'];?></textarea>
      </div>
   </div>
    
   
</div>

			<div class="col-md-12 col-md-push-5">
			<div  class="box-footer clearfix no-border">
			  <button type="submit" id="btnupdatecustomer" class="btn btn-primary"><i class="fa fa-plus"></i>Update Customer</button>
		
			<a href="" class="btn btn-danger">Cancel</a>
		</div>
			</div>
	 </form> 
<?php
	include ('../db_config/database_config.php');
      $key=$_REQUEST['term'];
    $array1 = array();
    $query=mysqli_query($conn,"select  DISTINCT color from product where color LIKE '%{$key}%'");
    while($row=mysqli_fetch_assoc($query))
    {
        $array1[]=array(
                    'value'=> $row["color"],
                    'label'=>$row["color"]
                        ); 
    }
    //echo json_encode($array);
	$json = json_encode($array1);
    print_r($json);
?>

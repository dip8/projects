<?php

//$con = mysqli_connect("199.79.62.23","siddhans_offer","p@v@n@123","siddhans_offernearme","3306");

$con = mysqli_connect("43.255.154.93","data_shop_inventory_new","usershop@123","usershopinvennew","3306");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  else{
   echo "success";
  }
?>
<!DOCTYPE html>
<?php include 'header.php';

  if(!in_array("CA_outstanding", $admin_rv)){
	 ?><script>
	window.location='dashboard.php';
	</script><?php
}
?>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Customer-record | Inventory Management System</title>
  <!-- Tell the browser to be responsive to screen width -->
	<style>
@page { size: auto;  margin: 0mm; }
input {
          border: 0;
    resize: none;
	  background: transparent;
}
</style>
</head>
 <script>
    $( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#mout").addClass('active');
	 
});

 
 function edit_price(id)
 { 
	//$("#view_sales_details").modal("show");
	//alert(id);
	$.ajax({
			url: "excess/edit_ca_sales_details.php",
			type: "POST",
			data: {'sales_number':id} ,
		    success: function (data) {
				  $("#edit_details").modal("show");
				$("#result_data12").html('');
				$("#result_data12").html(data);  
				 
			}
			});	
 
 }
 
 
 function pdf_all_product()
 {
    var from_date = $("#from_date").val();
	   var to_date = $("#to_date").val();
	   
	     if(from_date=='' && to_date==''){
		  window.location='excess/report_product_pdf.php?from=&to=';
		    
	   }
	   else if(from_date==null || from_date==""){
		   alert("Please Select From Date");
		   $("#from_date").focus();
	   }
	   else if(to_date==null || to_date==""){
		     alert("Please Select To Date");
		   $("#to_date").focus();
	   }
	  else{
		 window.location='excess/report_product_pdf.php?from='+from_date+'&to='+to_date;
	  }
	   
  
 } 
 function excel_all_product()
 {
  
	var from_date = $("#from_date").val();
	   var to_date = $("#to_date").val();
	   
	     if(from_date=='' && to_date==''){
		  window.location='excess/report_product_excel.php?from=&to=';
		    
	   }
	   else if(from_date==null || from_date==""){
		   alert("Please Select From Date");
		   $("#from_date").focus();
	   }
	   else if(to_date==null || to_date==""){
		     alert("Please Select To Date");
		   $("#to_date").focus();
	   }
	  else{
		 window.location='excess/report_product_excel.php?from='+from_date+'&to='+to_date;
	  }
 }
 
function bill_preview(id)
 { 
	     
	   $.ajax({
		  url: "excess/ca_bill_print.php",
		  type: "POST",
			data: {'sales_number':id} ,
			success: function (data) {
				//alert(data);
				$("#bill_preview_model").modal("show");
				$("#bill_data").html('');
				$("#bill_data").html(data);
				 
			}
		});
	 
	 
   
 }
 

function edit_bill_details()
	{ 	 
	 
	 document.getElementById("ca_update").disabled = true;
	    var myform = document.getElementById("edit_bill");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/product_ca_sale_edit_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				if(data==1){
				alert("Product Sales Records Updated Successfully..");
				//printDiv('printableArea');
				   location.reload();
					 //window.location.href = 'invoice.php'; 
				}
				else{
				alert("Product Sales Records Not Updated..");
					
				}
				//alert(data);
				 
			}
		});
	 
	  
}
 $(document).on("focus", "[class*='item-row']", function() {	
 $('.total_price').on("blur", function(){
	 
		var row = $(this).parents('.item-row');
		var total = row.find('.total_price').val();
		var qty = row.find('.product_qty').val();
		 // alert(qty);
		  //alert(total);
		//var qty = 1;
		var gst = row.find('.gst_per').val();
		var gstext =parseInt(100)+parseInt(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		var price1=roundNumber(price,2);
		 // alert(gst);
		 
		isNaN(net_price) ? row.find('.unit_price').val("N/A") : row.find('.unit_price').val(net_price);
		isNaN(price1) ? row.find('.product_gst').val("N/A") : row.find('.product_gst').val(price1);
		isNaN(price1) ? row.find('.gst1').val("N/A") : row.find('.gst1').val(price1);
		var total1 = 0;
			$('.total_price').each(function() {
			total1 += Number($(this).val()) || 0;
			}); 
			var total=roundNumber(total1,2);
			$("#total_price1").val(total); 
			var total_gst = 0;
			$('.product_gst').each(function() {
			total_gst += Number($(this).val()) || 0;
			}); 
			var totalg=roundNumber(total_gst,2);
			$(".product_gst1").val(totalg); 
		 
	});
	
	$('.total_price').on("keyup", function(){
	 
		var row = $(this).parents('.item-row');
		var total = row.find('.total_price').val();
		var qty = row.find('.product_qty').val();
		 // alert(qty);
		  //alert(total);
		//var qty = 1;
		var gst = row.find('.gst_per').val();
		var gstext =parseInt(100)+parseInt(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		var price1=roundNumber(price,2);
		 // alert(gst);
		 
		isNaN(net_price) ? row.find('.unit_price').val("N/A") : row.find('.unit_price').val(net_price);
		isNaN(price1) ? row.find('.product_gst').val("N/A") : row.find('.product_gst').val(price1);
		isNaN(price1) ? row.find('.gst1').val("N/A") : row.find('.gst1').val(price1);
		var total1 = 0;
			$('.total_price').each(function() {
			total1 += Number($(this).val()) || 0;
			}); 
			var total=roundNumber(total1,2);
			$("#total_price1").val(total); 
			var total_gst = 0;
			$('.product_gst').each(function() {
			total_gst += Number($(this).val()) || 0;
			}); 
			var totalg=roundNumber(total_gst,2);
			$(".product_gst1").val(totalg); 
		 
	});
	$('.unit_price').on("blur", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.unit_price').val() * row.find('.product_qty').val();
		
			//alert("asd");
		//var price = row.find('.unit_price').val() * 1;
		var gst = row.find('.gst_per').val();
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		var gstamt1=gstamt/2;
		var gstamt1=roundNumber(gstamt1,2);
		isNaN(total) ? row.find('.total_price').val("N/A") : row.find('.total_price').val(total);
		isNaN(gstamt1) ? row.find('.product_gst').val("N/A") : row.find('.product_gst').val(gstamt1);
		isNaN(gstamt1) ? row.find('.gst1').val("N/A") : row.find('.gst1').val(gstamt1);
			var total1 = 0;
			$('.total_price').each(function() {
			total1 += Number($(this).val()) || 0;
			}); 
			var total=roundNumber(total1,2);
			$("#total_price1").val(total); 
			$("#word_amt").html(convertNumberToWords(total));
			var total_gst = 0;
			$('.product_gst').each(function() {
			total_gst += Number($(this).val()) || 0;
			}); 
			 
			var totalg=roundNumber(total_gst,2);
			$(".product_gst1").val(totalg); 
			  
		 
	});
 $('.unit_price').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.unit_price').val() * row.find('.product_qty').val();
		
			//alert("asd");
		//var price = row.find('.unit_price').val() * 1;
		var gst = row.find('.gst_per').val();
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		var gstamt1=roundNumber(gstamt,2);
		isNaN(total) ? row.find('.total_price').val("N/A") : row.find('.total_price').val(total);
		isNaN(gstamt1) ? row.find('.product_gst').val("N/A") : row.find('.product_gst').val(gstamt1);
		isNaN(gstamt1) ? row.find('.gst1').val("N/A") : row.find('.gst1').val(gstamt1);
			var total1 = 0;
			$('.total_price').each(function() {
			total1 += Number($(this).val()) || 0;
			}); 
			var total=roundNumber(total1,2);
			$("#total_price1").val(total); 
			$("#word_amt").html(convertNumberToWords(total));
			var total_gst = 0;
			$('.product_gst').each(function() {
			total_gst += Number($(this).val()) || 0;
			}); 
			 
			var totalg=roundNumber(total_gst,2);
			$(".product_gst1").val(totalg); 
			  
		 
	});
 
 });
 
 
 
 
function roundNumber(number,decimals) {
  var newString;// The new rounded number
  decimals = Number(decimals);
  if (decimals < 1) {
    newString = (Math.round(number)).toString();
  } else {
    var numString = number.toString();
    if (numString.lastIndexOf(".") == -1) {// If there is no decimal point
      numString += ".";// give it one at the end
    }
    var cutoff = numString.lastIndexOf(".") + decimals;// The point at which to truncate the number
    var d1 = Number(numString.substring(cutoff,cutoff+1));// The value of the last decimal place that we'll end up with
    var d2 = Number(numString.substring(cutoff+1,cutoff+2));// The next decimal, after the last one we want
    if (d2 >= 5) {// Do we need to round up at all? If not, the string will just be truncated
      if (d1 == 9 && cutoff > 0) {// If the last digit is 9, find a new cutoff point
        while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
          if (d1 != ".") {
            cutoff -= 1;
            d1 = Number(numString.substring(cutoff,cutoff+1));
          } else {
            cutoff -= 1;
          }
        }
      }
      d1 += 1;
    } 
    if (d1 == 10) {
      numString = numString.substring(0, numString.lastIndexOf("."));
      var roundedNum = Number(numString) + 1;
      newString = roundedNum.toString() + '.';
    } else {
      newString = numString.substring(0,cutoff) + d1.toString();
    }
  }
  if (newString.lastIndexOf(".") == -1) {// Do this again, to the new string
    newString += ".";
  }
  var decs = (newString.substring(newString.lastIndexOf(".")+1)).length;
  for(var i=0;i<decimals-decs;i++) newString += "0";
  //var newNumber = Number(newString);// make it a number if you like
  return newString; // Output the result to the form field (change for your purposes)
}

function convertNumberToWords(amount) {
    var words = new Array();
    words[0] = '';
    words[1] = 'One';
    words[2] = 'Two';
    words[3] = 'Three';
    words[4] = 'Four';
    words[5] = 'Five';
    words[6] = 'Six';
    words[7] = 'Seven';
    words[8] = 'Eight';
    words[9] = 'Nine';
    words[10] = 'Ten';
    words[11] = 'Eleven';
    words[12] = 'Twelve';
    words[13] = 'Thirteen';
    words[14] = 'Fourteen';
    words[15] = 'Fifteen';
    words[16] = 'Sixteen';
    words[17] = 'Seventeen';
    words[18] = 'Eighteen';
    words[19] = 'Nineteen';
    words[20] = 'Twenty';
    words[30] = 'Thirty';
    words[40] = 'Forty';
    words[50] = 'Fifty';
    words[60] = 'Sixty';
    words[70] = 'Seventy';
    words[80] = 'Eighty';
    words[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words_string += words[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words_string += "Hundred ";
            }
        }
        words_string = words_string.split("  ").join(" ");
    }
    return words_string;
}


$(function () {
		$('#datetimepicker1').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
		$('#datetimepicker2').datepicker({
		  format: 'yyyy-mm-dd',
		  endDate: new Date()
		});
	document.getElementById('to_date').setAttribute("disabled","disabled");
	 
	 $('#from_date').change(function(){
			 
			$("#to_date").removeAttr("disabled"); 
			
		});
$('#to_date').change(function(){
			
			 var from_date = $('#from_date').val();
			var to_date = $('#to_date').val();
			 
			 //alert(to_date);
			 if(from_date > to_date)
			 {
			 	alert('Please select From date AND To date correctly..!');
				$('#to_date').val('');
				
			 }
			 
			
           });    
           });  

function ca_search()
{ 		 
	   var myform = document.getElementById("ca_search_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/ca_search_details.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				$('#report_result').html('');
				$('#report_result').html(data);
				 
			}
		});
	 
	 
} 		   
 </script>

<body class="hold-transition skin-blue sidebar-mini">
<div class=" ">

   
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
CA_Outstanding
      </h1>
      <ol class="breadcrumb">
        <li><a href="index1.html"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active">CA-Outstanding</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	
	
      <div class="row">
	  <div  class="col-md-12">
	 <div style="border:2px solid #f39c12;" class="panel panel-warning">
	 
	  
	  <div class="panel-body" id="customer_edit">
	
	   <form id="ca_search_form" onsubmit="ca_search();"  autocomplete="off"  method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
      
 
		<div class="col-md-10 col-md-push-1">
    
    <div class = "form-group" >
      <label for="price" class="col-sm-3 control-label">From Date:</label>
		
      <div class = "col-sm-6">
	  
	   <div class='input-group date' id='datetimepicker2'>
        <input   type = "text"  class ="form-control" id = "from_date" name="from_date"   placeholder = "Enter From Date" required>
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
   
    
   <div class = "form-group" >
      <label for = "price" class = "col-sm-3 control-label">To Date:</label>
		
      <div class = "col-sm-6">
	  
	   <div class='input-group date' id='datetimepicker1'>
        <input   type = "text"  class ="form-control" id = "to_date" name="to_date"   placeholder = "Enter To Date" required>
     <span class="input-group-addon">
           <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
        </div>
   </div>
    
   
</div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">  
			<button type="submit" id="btncustomer" class="btn btn-primary">Search</button>
	
		  <button  type="reset" class="btn btn-danger" onclick="window.location.reload();">Cancel</button>
			</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">CA-Outstanding Details</h3>
			  <button style="margin-left: 55%;" onclick="excel_all_product()" class="btn btn-primary btn-sm"><i class="fa fa-download" aria-hidden="true"></i>&nbsp;Product List Excel</button>
				<button onclick="pdf_all_product()" class="btn btn-primary btn-sm"><i class="fa fa-download" aria-hidden="true"></i>&nbsp;Product List pdf</button>
				
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1" id="report_result">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>Bill Number</th>
                  <th>Bill Date</th>
                  <th>Category</th>
                  <th>Product Name</th>
                  <th>IMEI No</th>
                  <th>HSN No</th>
                  <th>Quantity</th>
                  <th>Customer Name</th>
				  <th>Total Amt</th>
				  <th>GST Amt</th>
                  <th>Final Total Amt</th>
                  <th>Edit Price</th>
                  <th>Print Bill</th>
                 
                </tr>
                </thead>
               <tbody > 
            <?php 
			$user_query = "SELECT * FROM ca_sales WHERE added_by IN ($users_ids) ORDER BY sales_number DESC";
			$user_res = mysqli_query($conn,$user_query);
			$i=0;
			$total_amount1=0;
			while($sales_data = mysqli_fetch_assoc($user_res))
				{
					$sales_number=$sales_data['sales_number'];
					$sales_date=$sales_data['sales_date'];
					$customer_id=$sales_data['customer_id'];
					
				 
					
					$rescm = mysqli_query($conn,"SELECT * FROM `customer` WHERE `customer_id`='$customer_id'");
					$cust_row=mysqli_fetch_assoc($rescm);
					$customer_name=$cust_row['customer_name'];
					$customer_mobile=$cust_row['mobile'];
				$total_amount=0;	
				$gst_amount=0;	
				$final_total_amount=0;	
				$sales_quantity=0;	
			 $ques2=mysqli_query($conn,"SELECT * FROM `ca_sales_detail` WHERE `sales_number`='$sales_number'");
		 while($rowv2 =  mysqli_fetch_assoc($ques2)){
			$product_number = $rowv2['product_number'];	
			$imei_no = $rowv2['imei_no'];	
			  $total_amount+=$rowv2['sales_price'];
			  $gst_amount+=$rowv2['gst_amount'];
			 $final_total_amount+=$rowv2['sales_total_amount'];
			 $sales_quantity+=$rowv2['sales_quantity'];
		 }
			//$total_amount1=$total_amount1+$total_amount;
			
			  $ques3=mysqli_query($conn,"SELECT * FROM `product` WHERE `product_id`='$product_number'");
		 $rowv3 =  mysqli_fetch_assoc($ques3);
			$product = $rowv3['product_name'];	
			$product_company = $rowv3['product_company'];	
			$category_id = $rowv3['category_id'];	
			$hsn_no = $rowv3['hsn_no'];	
			$color = $rowv3['color'];	
			 
			$rescm = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$product_company'");
						$cmp_row=mysqli_fetch_assoc($rescm);
						$company_name=$cmp_row['company_name'];
						$product_name=$company_name." ".$product;
						//print_r($product);
			$resct = mysqli_query($conn,"SELECT * FROM `category` WHERE `category_id`='$category_id'");
			$cat_row=mysqli_fetch_assoc($resct);
			$category_name=$cat_row['category_name'];
			/* $ressct = mysqli_query($conn,"SELECT * FROM `mobile_imei` WHERE `product_id`='$product_number' AND imei_no='$imei_no' ");
			$subcat_row=mysqli_fetch_assoc($ressct);
			$imei_no=$subcat_row['imei_no']; */
				?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$sales_number;?></td>
                  <td><?=$sales_date;?></td>
                  <td><?=$category_name;?></td>
                  <td><?=$product_name;?></td>
                   
                  <td><?php if($imei_no==""){ echo "-";} else{ echo $imei_no;}?></td>
                  <td><?php if($hsn_no==""){ echo "-";} else{ echo $hsn_no;}?></td>
                  <td><?php if($sales_quantity==0){ echo "-";} else{ echo $sales_quantity;}?></td>
                   
                  <td><?=$customer_name.' ('.$customer_mobile.')';?></td>
                  <td><?php if($total_amount==0){ echo "-"; }else{ echo $total_amount; } ?></td>
                 
                  <td><?php if($gst_amount==0){ echo "-"; } else{ echo $gst_amount;}?></td>
                  <td> <?php if($final_total_amount==0){ echo "-"; }else{ echo $final_total_amount; } ?></td>
		  
				<td>
					<a class="btn btn-info btn-xs" onclick="edit_price('<?php echo $sales_data['sales_number']; ?>');">
					<i class="fa fa-pencil" title="View Profile" style="font-size:20px;text-align: center;"></i></a>
				</td>
                <td>
				 <a class="btn btn-success btn-xs" onclick="bill_preview('<?php echo $sales_data['sales_number']; ?>');">
				 <i class="fa fa-print" title="View Profile" style="font-size:20px;text-align: center;"></i></a>
				</td>
                </tr>
                 
                
               
					<?php } ?>
              </tbody>
             
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	</div>
   

  
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<!--model pop up for alert messages-->
<div  class="modal fade" id="myModal" role="dialog">
    <div style="border:4px solid #f39c12; width: 35%;" class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button style="border-radius:50%;padding:0px 5px; border:2px solid #f39c12; background-color:#f39c12;opacity: 1.2;"type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 style="color:#f39c12; text-align:center;" class="modal-title">Alert Message!</h4>
        </div>
        <div class="modal-body">
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
	  </div>
	  </div>
	  
 
		 
<!-- Modal -->
  <div class="modal fade" id="edit_details" role="dialog">
    <div  class="modal-dialog modal-lg custom ">
      <div class="modal-content" style="background-color:#f8f8ff" >
        <div class=" ">
          <button type="button" class="close" style="background: black;" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body" id="result_data12">
          	
        </div>
       
      </div>
    </div>
  </div>
  
   <div class="modal fade" id="bill_preview_model" role="dialog">
    <div  class="modal-dialog modal-lg custom ">
      <div class="modal-content">
        <div class=" ">
          <button type="button" class="close" style="background: black;" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body" id="bill_data">
          	
        </div>
        <div class="modal-footer">
		<button style="margin-bottom:0px;    background-color: indianred;" type="button" class="btn btn-default" onclick="printDiv('printableArea'); " value="print a div!">Print</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		  
        </div>
      </div>
    </div>
  </div>
 

 <?php include 'footer.php';?>
 <script>
 function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
	 

     window.print();
	 	//sale_product();
	// $('#bill_preview_model').modal('hide');
	
	 location.reload();
     // document.body.innerHTML = originalContents;
}
 </script>
 
</body>
</html>

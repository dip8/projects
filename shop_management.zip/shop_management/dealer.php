<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>
  <link rel="stylesheet" href="assets/css/jquery.multiselect.css">
  <script src="assets/js/bootstrap-multiselect.js"></script>  
</head>
<script type="text/javascript">
    $(function () {
        $('#brand').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<style>
.multiselect-container{
	overflow: auto;
    max-height: 150px;
}
.tabbable-panel {
  border:2px solid #eee;
  padding: 10px;
  margin-bottom:20px;
}
.multiselect-container{
	width:100% !important;
}
.multiselect{
	width:100% !important;
}
.btn-group{
	    width: -webkit-fill-available;
}
/* Default mode */
.tabbable-line > .nav-tabs {
  border: none;
  margin: 0px;
}
.tabbable-line > .nav-tabs > li {
  margin-right: 2px;
}
.tabbable-line > .nav-tabs > li > a {
  border: 0;
  margin-right: 0;
  color: #737373;
}
.tabbable-line > .nav-tabs > li > a > i {
  color: #a6a6a6;
}
.tabbable-line > .nav-tabs > li.open, .tabbable-line > .nav-tabs > li:hover {
  border-bottom: 4px solid #fbcdcf;
}
.tabbable-line > .nav-tabs > li.open > a, .tabbable-line > .nav-tabs > li:hover > a {
  border: 0;
  background: none !important;
  color: #333333;
}
.tabbable-line > .nav-tabs > li.open > a > i, .tabbable-line > .nav-tabs > li:hover > a > i {
  color: #a6a6a6;
}
.tabbable-line > .nav-tabs > li.open .dropdown-menu, .tabbable-line > .nav-tabs > li:hover .dropdown-menu {
  margin-top: 0px;
}
.tabbable-line > .nav-tabs > li.active {
  border-bottom: 4px solid #f3565d;
  position: relative;
}
.tabbable-line > .nav-tabs > li.active > a {
  border: 0;
  color: #333333;
}
.tabbable-line > .nav-tabs > li.active > a > i {
  color: #404040;
}
.tabbable-line > .tab-content {
  margin-top: -3px;
  background-color: #fff;
  border: 0;
  border-top: 1px solid #eee;
  padding: 15px 0;
}
.portlet .tabbable-line > .tab-content {
  padding-bottom: 0;
}

/* Below tabs mode */

.tabbable-line.tabs-below > .nav-tabs > li {
  border-top: 4px solid transparent;
}
.tabbable-line.tabs-below > .nav-tabs > li > a {
  margin-top: 0;
}
.tabbable-line.tabs-below > .nav-tabs > li:hover {
  border-bottom: 0;
  border-top: 4px solid #fbcdcf;
}
.tabbable-line.tabs-below > .nav-tabs > li.active {
  margin-bottom: -2px;
  border-bottom: 0;
  border-top: 4px solid #f3565d;
}
.tabbable-line.tabs-below > .tab-content {
  margin-top: -10px;
  border-top: 0;
  border-bottom: 1px solid #eee;
  padding-bottom: 15px;
}

</style>
<script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
	$('#dealer_master').addClass('active');
    $("#mdealer").addClass('active');
	
});
 function add_dealer()
{ 		
	//if(! $form.valid()) return false;
	 $("#dealer_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
		e.preventDefault();
		  document.getElementById("btndealer").disabled = true;
	    var myform = document.getElementById("dealer_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/dealer_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Dealer Records Added Successfully..");
				 location.reload();
				}
				else{
					alert("Dealer Records Not Added");	
				}
			 
				 
			}
		});
	 
	 }
	 });
}
function update_dealer()
{ 	 
	 
		  document.getElementById("btnupdatedealer").disabled = true;
	    var myform = document.getElementById("dealerupdate_form");
		var fd = new FormData(myform);
	   $.ajax({
		  url: "excess/dealer_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Dealer Records Updated Successfully..");
				 location.reload();
				}
				else{
					alert("Dealer Records Not Updated");	
				}
				 
			}
		});
	 
	 
	 
}
 function update_contact()
{ 	 
	 var contact_id=$("#contact_id").val();
	 var contact_name=$("#contact_name").val();
	 var contact_phone=$("#contact_phone").val();
	 var contact_email=$("#contact_email").val();
	 if(contact_name==''|| contact_name==null){
		 alert("Please Enter Contact Person Name");
		 $('#contact_name').focus();
	 }
	 else if(contact_phone==''|| contact_phone==null){
		  alert("Please Enter Contact Person Phone No");
		 $('#contact_phone').focus();
		 }
	 else{
	 $.ajax({
     url:'excess/contact_person_edit_exce.php',
     type:'POST',
     data:{'contact_id':contact_id ,'contact_name':contact_name ,'contact_phone':contact_phone ,'contact_email':contact_email},
     success: function(data)
     {
		 //alert(data);
	  if(data==1){
					alert("Contact Person Records Updated Successfully..");
				 location.reload();
				}
				else{
					alert("Contact Person  Records Not Updated");	
				}
	 }
	}); 
	 } 
}
 function add_contact()
{ 	 
 
	 var supplier_id=$("#supplier_id").val();
	 var contact_name=$("#contact_name").val();
	 var contact_phone=$("#contact_phone").val();
	 var contact_email=$("#contact_email").val();
	 if(contact_name==''|| contact_name==null){
		 alert("Please Enter Contact Person Name");
		 $('#contact_name').focus();
	 }
	 else if(contact_phone==''|| contact_phone==null){
		  alert("Please Enter Contact Person Phone No");
		 $('#contact_phone').focus();
	 }
	 else{
	 $.ajax({
     url:'excess/add_contact_person_exce.php',
     type:'POST',
     data:{'supplier_id':supplier_id ,'contact_name':contact_name ,'contact_phone':contact_phone ,'contact_email':contact_email},
     success: function(data)
     {
		// alert(data);
	  if(data==1){
					alert("Contact Person Records Added Successfully..");
				 location.reload();
				}
				else{
					alert("Contact Person  Records Not Added");	
				}
	 }
	 
	}); 
	 }
	   
}
 

function check_email_id()
{
  
	var emailid =document.getElementById("email").value;							 
 	
		$.ajax({
				type: 'POST',
				url: 'excess/check_email_exce.php',
				data: 'emailid='+ emailid ,
				success: function(data2){
					  
				var obje=$.parseJSON(data2);
							if(obje=="Yes")
							{
							//alert("yes");	
							 $('#err_email').hide();
						//setTimeout(function(){ $('#invaliduser').hide(); }, 5000);
							}
							else
							{
								//alert("no");
								$('#email').focus();	
							 	 $('#err_email').show();	
							 }
				}
				});
}

function edit_dealer(id)
{
 	 $.ajax({
     url:'excess/edit_dealer.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#tab_default_1').html('');
	  $('#title_head').html('');
	  $('#title_head').html('Update Dealer');
	 // $('#edit_dealer_div').hide();
	  $('#tab_default_1').append(data);
	   $(window).scrollTop($('#tab_default_1').offset().top-20); 
 
     }
	 
	}); 
}

function edit_contact(id)
{
	 //alert(id);
 	 $.ajax({
     url:'excess/edit_contact_person.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
		 // alert(data);
	  //$("#contact_person_d").modal("show");
	 $("#result_data1").html('');
	$("#result_data1").html(data);
	}
	 }); 
}
function add_contact_view(id)
{
	 //alert(id);
 	 $.ajax({
     url:'excess/add_contact_person.php',
     type:'POST',
     data:{'supplier_id':id},
     success: function(data)
     {
		 // alert(data);
	  //$("#contact_person_d").modal("show");
	 $("#result_data1").html('');
	$("#result_data1").html(data);
	}
	 }); 
}

 function activate_deactivate(id,status)
 {
	 //alert(status);
	 $.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'dealer'},
     success: function(data)
     {
		 if(data==1){
       alert("Dealer Status Updated Successfully..");
	   location.reload();
		 }
		 else{
			alert("Dealer Status Not Updated."); 
		 }
       
		//window.location.href='profile_hr.php#employee_list_tab';
	 //$('#refresh_user').load(document.URL +  ' #refresh_user');
     }

	});
	 
 }
 function activate_deactivate_contact(id,status)
 {
	 //alert(status);
	 $.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'contact'},
     success: function(data)
     {
		 if(data==1){
      alert("Contact Person Status Updated Successfully..");
		 }else{
			alert("Contact Person Status Not Updated."); 
		 }
		//window.location.href='profile_hr.php#employee_list_tab';
	 //$('#refresh_user').load(document.URL +  ' #refresh_user');
     }

	});
	 
 }
function delete_dealer(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'dealer'},
     success: function(data)
     {
	   if(data==1){
	  alert("Dealer Delete Successfully..");
	   location.reload();
	  }else{
		 alert("Dealer Not Deleted.");  
	  }
	 }
	});
	
	}
	else{}
 }
 function delete_contact(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'contact'},
     success: function(data)
     {
	   //alert(data);
      //delete_succefull();
	  if(data==1){
	  alert("Contact Person Delete Successfully..");
	   location.reload();
	  }else{
		 alert("Contact Person Not Deleted.");  
	  }
	//  window.location.href = "profile_hr.php#employee_other_doc_list";
	 }
	});
	
	}
	else{}
 }
</script>

<script>
function showdiv(id){
if(id=='dealer'){
$('#sect1').show();
$('#sect2').hide();
}

if(id=='payment'){
$('#sect1').hide();
$('#sect2').show();

}
}

function contact_p_details(c_id)
 { 
	 //alert(em_id);
	$.ajax({
			url: "excess/view_contact_person_details.php",
			type: "POST",
			data: {'supplier_id':c_id} ,
		    success: function (data) {
				//alert(data);
					$("#contact_person_d").modal("show");
					
					
					$("#result_data1").html('');
					$("#result_data1").html(data);
			  		
			}
			});	
 
 }
 function email_customer(id,name)
{
	//alert(id);
	$('#email_id_mail').val(id);
	$('#cust_name_mail').val(name);
	$('#page_url').val('dealer.php');
	$("#mail_email").modal("show");	
}
</script>



<body class="hold-transition skin-blue sidebar-mini">
<div class=" ">
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section  class="content-header">
      <h1>
Dealer:
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active">Dealer </li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	
	 	
    <div class="row">
    	<div class="col-md-12">
			

			<div style="border-radius:4px;" class="tabbable-panel">
				<div class="tabbable-line">
					<ul class="nav nav-tabs">
						<li class="active">
							<a style="padding: 2px 40px;" href="#tab_default_1" onclick="showdiv('dealer')" data-toggle="tab">
							<h4 id="title_head">Add Dealer</h4></a>
						</li>
						 
						
                                            
					</ul>
					<div class="tab-content">
					
					 
						<div class="tab-pane active" id="tab_default_1">
						<p>
	 <form id="dealer_form" onsubmit="return add_dealer()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
  
   
   
   <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Dealer Name:</label>
	  
	  <div class = "col-md-4">
      <input type="text" class="form-control" id="dealer_name" placeholder="Enter Name" name="dealer_name">
	  </div>
    </div>
	 <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Dealer Address:</label>
	  
	  <div class = "col-md-4">
      <textarea  class="form-control" id="address" name="address" placeholder="Enter Address"></textarea>
	  </div>
    </div>
	
	 <div class = "form-group">
      <label for = "dealerid" class = "col-md-3 control-label">Company / Brand:</label>
		
      <div class="col-md-4">
			<select name="brand[]" id="brand" multiple required>
		  
	  <?php 
	   $company_query = "SELECT * FROM `company`";
			$com_res = mysqli_query($conn,$company_query);
			 
			while($com_data = mysqli_fetch_array($com_res))
					{
			 ?>
			<option value="<?=$com_data['company_id']?>"><?=$com_data['company_name']?></option>
			 <?php } ?>
			</select>
		</div>
                                          
      </div>
	   <div class="form-group">
      <label for="email" class = "col-md-3 control-label">Email Id:</label>
	  
	  <div class = "col-md-4">
      <input type="text" class="form-control" id="email" placeholder="Enter email" onblur="check_email_id()" name="email">
	  <div id="err_email" style="display: none; padding:0px; margin:0px;color:red;" class="form-group alert alert-danger alert-dismissable"" align="center">
									<span>Username/Email-Id are found...! Please  Enter New Email-Id..!</span> </div>
	
	  </div>
    </div>
	<div class="form-group">
      <label for="email" class = "col-md-3 control-label">Contact No:</label>
	  
	  <div class = "col-md-4">
      <input type="number" class="form-control" id="contact_no"  minlenght="10" maxlenght="10" placeholder="Enter Contact No"   name="contact_no">
	   
    </div>
    </div>
	<div class="form-group">
      <label for="email" class = "col-md-3 control-label">Delivery Person Name:</label>
	  
	  <div class = "col-md-4">
      <input type="text" class="form-control" id="c_person" placeholder="Enter Contact Person Name" name="c_person">
	  </div>
    </div>
	 <div class = "form-group">
      <label class = "col-md-3 control-label">Delivery Person Phone.:</label>
		
      <div class ="col-md-4">
         <input style="margin-bottom: 13px;" type = "number" name="p_contact_no" id="p_contact_no" class ="form-control" minlenght="10" maxlenght="10" placeholder = "Enter Contact No.">
      </div>
   </div>
   
   <div class = "form-group">
      <label class = "col-md-3 control-label">Dealer GST No.:</label>
		
      <div class ="col-md-4">
         <input style="margin-bottom: 13px;" type = "text" name="dealer_gst_no" id="dealer_gst_no" class ="form-control" maxlenght="10"  placeholder = "Enter Dealer GST No.">
      </div>
   </div>
   <div class="  " style="text-align:center;">
			<div  class="box-footer clearfix no-border">
					    <button type="submit" id="btndealer" class="btn btn-primary"><i class="fa fa-plus"></i>Add Dealer</button>
				
					  <button  type="reset" class="btn btn-danger">Cancel</button>
						</div>
			</div>
   
   
    </form>
</p>
</div>
							
							
			  
						
	 </div>
	 </div>
	 </div>

	 </div>
	</div>
	
	<section id="sect1" class="content">
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">Product Dealer Details</h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Dealer Id</th>
                  <th>Dealer Name</th>
                  <th>Dealer Address</th>
                  <th>Company / Brand</th>
				   <?php if(in_array("Email", $admin_rv)){?>
                  <th>Email</th>
				   <?php } ?>
                  <th>Balance</th>
				   
				  <th>Added By</th>
				  <th>Updated By</th>
				  <th>Contact Person</th>
				  <th>GST No.</th>
				  <th>Status</th>
				  <th>Send Email</th>
				  <th >Edit</th>
				  <th>Delete</th>
                  
                </tr>
                </thead><tbody>
					<?php 
				 $user_query = "SELECT * FROM `supplier` WHERE added_by IN ($users_ids) ORDER BY supplier_id DESC";
			$user_res = mysqli_query($conn,$user_query);
			$i=0;
			while($dealer_data = mysqli_fetch_assoc($user_res))
					{
						$company_name="";
					 $status=$dealer_data['status'];
					 $user_id=$dealer_data['added_by'];
					 $user_id1=$dealer_data['updated_by'];
					 $supplier_id=$dealer_data['supplier_number'];
					 //$brand_a=$dealer_data['supplier_for'];
					   $brand_a=explode(",",$dealer_data['supplier_for']);
						foreach($brand_a as $val){
						$ressct = mysqli_query($conn,"SELECT * FROM `company` WHERE `company_id`='$val'");
						$subcat_row=mysqli_fetch_assoc($ressct);
						$company_name.= $subcat_row['company_name'].", ";
						}
						
						$user_q = mysqli_query($conn,"SELECT * FROM `user` WHERE `user_id`='$user_id'");
						$user_data11= mysqli_fetch_assoc($user_q);
						$fname1=$user_data11['fname'];
						$lname1=$user_data11['lname'];
						$full_name11=$fname1.$lname1;
						$user_q2 = mysqli_query($conn,"SELECT * FROM `user` WHERE `user_id`='$user_id1'");
						$user_data22= mysqli_fetch_assoc($user_q2);
						$fname2=$user_data22['fname'];
						$lname2=$user_data22['lname'];
						$full_name22=$fname2.$lname2;
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$dealer_data['supplier_number']?></td>
                  <td><?=$dealer_data['supplier_name']?></td>
                  <td><?=$dealer_data['supplier_address']?></td>
                  <td><?=rtrim($company_name,', ')?></td>
                  <td><?=$dealer_data['email_id']?></td>
                  <td><?=$dealer_data['balance']?></td>
                   
                  <td><?=$full_name11?></td>
                  <td><?=$full_name22?></td>
                  <td>
					<a  class="btn btn-success btn-xs" onclick="contact_p_details('<?php echo $dealer_data['supplier_id']; ?>');">
					<i class="glyphicon glyphicon-eye-open" title="View Application" style="font-size:18px;text-align: center;"></i></a>
				  </td>
				  
				  <td><?=$dealer_data['dealer_gst_no']?></td>
				
				<td> 
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $dealer_data['supplier_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
							 <?php if(in_array("Email", $admin_rv)){?>
				 <td>
					<?php if($dealer_data['email_id']!="") {?>
				  <a href="javascript:void(0);" class="btn" onclick="email_customer('<?php echo $dealer_data['email_id']; ?>','<?php echo $dealer_data['supplier_name']; ?>');"><i class="fa fa-envelope" title="Email Send  "></i></a>
					<?php } ?>
				  </td>
				  <?php } ?>
				  <td><a href="javascript:void(0);" onclick="edit_dealer('<?php echo $dealer_data['supplier_id']; ?>');"><i class="fa fa-pencil" title="Edit Dealer"></i></a></td>
                <td  Style="border-right-width:2px;">
					<a href="javascript:void(0);" onclick="delete_dealer('<?php echo $dealer_data['supplier_id']; ?>');">
							<i class="fa fa-trash" title="Delete Dealer" style="font-size:18px;text-align: center;"></i></a>
				</td>
                </tr>
                 
                
                
					<?php } ?></tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	
	 
	</section>
	
	</div>
	</div>
	<div class="container">
  <div class="modal fade" id="contact_person_d" align="center" role="dialog">
   <div class="modal-dialog modal-md">
    <!-- Modal content-->
    <div  style="background-color:#f8f8ff" class="modal-content">
   <form method="POST" action="">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      <h4 class="modal-title">Dealer Contact Person Details</h4>
        </div>
       <div id="result_data1"></div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </form>
    </div>
    
   </div>
  </div>
 </div>
 
 

  <?php include 'footer.php';?>
   <script>
   //customer name
    $("#dealer_name").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^a-zA-Z\s]/g)) {
       $(this).val(val.replace(/[^a-zA-Z\s]/g, ''));
   }
 });
   
   //customer contact number
    $("#contact_no").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^0-9]|^0+(?!$)/g)) {
       $(this).val(val.replace(/[^0-9]|^0+(?!$)/g, ''));
   }
});
      // delivery person name
    $("#c_person").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^a-zA-Z\s]/g)) {
       $(this).val(val.replace(/[^a-zA-Z\s]/g, ''));
   }
 });
   
   //delivery person contact number
    $("#p_contact_no").on('keyup', function(e) {
    var val = $(this).val();
   if (val.match(/[^0-9]|^0+(?!$)/g)) {
       $(this).val(val.replace(/[^0-9]|^0+(?!$)/g, ''));
   }
});
</script>
   
</body>
</html>

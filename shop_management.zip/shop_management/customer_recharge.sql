-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 11, 2018 at 11:53 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_shop_inventory_new_all`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_recharge`
--

CREATE TABLE `customer_recharge` (
  `cust_r_id` int(11) NOT NULL,
  `recharge_date` datetime NOT NULL,
  `cust_name` varchar(500) NOT NULL,
  `cust_contact_no` varchar(50) NOT NULL,
  `operator_id` varchar(50) NOT NULL,
  `recharge_amount` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `added_by` varchar(500) NOT NULL,
  `updated_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(500) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_recharge`
--

INSERT INTO `customer_recharge` (`cust_r_id`, `recharge_date`, `cust_name`, `cust_contact_no`, `operator_id`, `recharge_amount`, `added_date`, `added_by`, `updated_date`, `updated_by`, `status`) VALUES
(1, '2018-12-11 00:00:00', 'shree', '9890897867', 'Vodafone', '50', '2018-12-11 16:02:29', '2', '0000-00-00 00:00:00', '', 1),
(2, '2018-12-11 00:00:00', 'krushna', '8909897867', 'Vodafone', '150', '2018-12-11 16:05:52', '2', '0000-00-00 00:00:00', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_recharge`
--
ALTER TABLE `customer_recharge`
  ADD PRIMARY KEY (`cust_r_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_recharge`
--
ALTER TABLE `customer_recharge`
  MODIFY `cust_r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

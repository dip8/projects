<!DOCTYPE html>
<?php include 'header.php';

  if(!in_array("Notification", $admin_rv)){
	 ?><script>
	window.location='dashboard.php';
	</script><?php
}
?>
<html>
<head>
  

<script src="https://cdnjs.cloudflare.com/ajax/libs/notify/0.4.2/notify.js"></script>
  
</head>

<script>
function showdiv(id){
if(id=='mobile'){
$('#section1').show()
$('#section2').hide();
$('#section3').hide();
$('#section4').hide();
}
if(id=='accessories'){
$('#section1').hide();
$('#section2').show();
$('#section3').hide();
$('#section4').hide();
}if(id=='dealer'){
$('#section1').hide();
$('#section2').hide();
$('#section3').show();
$('#section4').hide();
}if(id=='customer'){
$('#section1').hide();
$('#section2').hide();
$('#section3').hide();
$('#section4').show();
}
}




$(document).ready(function(){

$('input:radio[name="c1"]').change(
    function(){
        if ($(this).is(':checked') && $(this).val() == 'adhar') {
            $('#div2').hide();
            $('#div1').show();
        }else{
		$('#div1').hide();
            $('#div2').show();
		}
    });
    });





function n_close(id){
	 $.ajax({
			url: "excess/close_alert_tab.php",
			type: "POST",
			data: {'n_id':id} ,
		    success: function (data) {
				  //alert(data);
					 
			 }
			});
}

</script>

 <style>
 a {
    color: #202121;
}
.alert {
    padding: 6px;
    
}
.colorpur{
	    background-color: #69ab7ad6;
    color: white;
}.colorc{
	    background-color: #8e8c8ac7 ;
    color: white;
}.colorg{
	    background-color: #61c195e6 ;
    color: white;
}.colorb{
	    background-color: #6dbcd0 ;
    color: white;
}.coloro{
	    background-color: #d2a867 ;
    color: white;
}
.alert a{
	text-decoration: none;
}
.alert a:hover{
	color:#000;
}
.modal-dialog{
	width: 35%;
}
 </style>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
Alert Messages:
      </h1>
      <ol class="breadcrumb">
        <li><a href="index1.html"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active">Notifications</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	<div class="row">
	<div style="padding-left:10px; padding-right:10px;" class="col-md-12">
	<div class="box box-warning">
            <div class="box-header with-border">
              <i class="fa fa-warning"></i>

              <h3 class="box-title">Alerts / Notifications</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
				<a   data-toggle="collapse" href="#customer_bday" role="button" aria-expanded="false" aria-controls="collapseExample">
			
              <div style="background-color:#eee;padding:10px;" class="alert alert-default alert-dismissible"> 
                  <h4><i style="border-radius:50px;background-color:#fff;padding:5px 7px; border:5px solid #f39c12;" class="icon fa fa-user"></i>&nbsp &nbsp Customer Birthday!</h4>
                <p style="margin-left: 62px;margin-top: -17px;">Today's Customer Birthday </p>
               </div>
			   </a>
			   
			   <div class="collapse" id="customer_bday">
					<div class="card card-body" style="max-height: 300px; overflow: auto;">
					<?php 
					 $c_bday= mysqli_query($conn,"SELECT * FROM `notification` where type = 'birthday' and status='1' ORDER BY n_id DESC");
				while($c_bday_r=mysqli_fetch_assoc($c_bday)){
					?>
					
					<div class="alert coloro alert-dismissible" role="alert" > 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$c_bday_r['n_id']?>');">&times;</button>
							<a onclick="show_details('<?=$c_bday_r['id']?>')" href="javascript:void(0);">Today's '<?=$c_bday_r['title']?>' Birthday Date: '<?=$c_bday_r['bdate']?>'</a>
					</div>
				<?php } ?>
					</div>
				</div>
				
			   <a   data-toggle="collapse" href="#customer_wedding" role="button" aria-expanded="false" aria-controls="collapseExample">
			 <div style="background-color:#eee;padding:10px;" class="alert alert-default alert-dismissible"> 
                  <h4><i style="border-radius:50px;background-color:#fff;padding:5px 7px; border:5px solid #f39c12;" class="icon fa fa-user"></i>&nbsp &nbsp Customer Wedding Date !</h4>
                <p style="margin-left: 62px;margin-top: -17px;">Today's Customer Wedding Date </p>
               </div>
			   </a>
			   
			   <div class="collapse" id="customer_wedding">
					<div class="card card-body" style="max-height: 300px; overflow: auto;">
					
					<?php 
					 $c_wday= mysqli_query($conn,"SELECT * FROM `notification` where type = 'wedding' and status='1' ORDER BY n_id DESC");
				while($c_w_r=mysqli_fetch_assoc($c_wday)){
					/* 
					if($c_bday_r['bdate'] == date('Y-m-d')) {
					  $date = 'Today';
					} 
					else if($c_bday_r['bdate'] == date('Y-m-d',now() - (24 * 60 * 60))) {
					  $date = 'Yesterday';
					}
					else{
						//$date =date('l', $c_bday_r['bdate']);
					} */
					?>
					
					<div class="alert colorb alert-dismissible" role="alert" > 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$c_w_r['n_id']?>');">&times;</button>
							<a onclick="show_details('<?=$c_w_r['id']?>')" href="javascript:void(0);"><?=$date?> '<?=$c_w_r['title']?>' Wedding Date : '<?=$c_w_r['bdate']?>'</a>
					</div>
				<?php } ?>
					
					</div>
				</div> 
				
				
			   <a   data-toggle="collapse" href="#cust_retain" role="button" aria-expanded="false" aria-controls="collapseExample">
			 <div style="background-color:#eee;padding:10px;" class="alert alert-default alert-dismissible"> 
                  <h4><i style="border-radius:50px;background-color:#fff;padding:5px 7px; border:5px solid #f39c12;" class="icon fa fa-user-o"></i>&nbsp &nbsp Retain Customer!</h4>
                <p style="margin-left: 62px;margin-top: -17px;">Customer Does Not Retain 6 Months  </p>
               </div>
			   </a>
			   
			   <div class="collapse" id="cust_retain">
					<div class="card card-body" style="max-height: 300px; overflow: auto;">
					
						<?php 
					 $cust_return1= mysqli_query($conn,"SELECT * FROM `notification` where type = 'cust_retain' and status='1' ORDER BY n_id DESC");
				while($cust_return=mysqli_fetch_assoc($cust_return1)){
					//if($product_r['date'] == date('Y-m-d')){
					?>
					
					<div class="alert colorg alert-dismissible" role="alert"> 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$cust_return['n_id']?>');">&times;</button>
					<a onclick="show_details('<?=$cust_return['id']?>')" href="javascript:void(0);">Customer Name '<?=$cust_return['title']?>' Is Not Retain to last '6' Months</a>
					</div>
				<?php } //}?>
					
					</div>
				</div>
			   
			   <a   data-toggle="collapse" href="#stock_item" role="button" aria-expanded="false" aria-controls="collapseExample">
			 <div style="background-color:#eee;padding:10px;" class="alert alert-default alert-dismissible"> 
                  <h4><i style="border-radius:50px;background-color:#fff;padding:6px 12px; border:5px solid #f39c12;" class="icon fa fa-info"></i>&nbsp &nbsp Stock Item!</h4>
                <p style="margin-left: 62px;margin-top: -17px;">Stock Item ! </p>
               </div>
			   </a>
			   
			   <div class="collapse" id="stock_item">
					<div class="card card-body" style="max-height: 300px; overflow: auto;">
					
					<?php 
					 $product_q= mysqli_query($conn,"SELECT * FROM `notification` where type = 'stock' and status='1' ORDER BY n_id DESC");
				while($product_r=mysqli_fetch_assoc($product_q)){
					//if($product_r['date'] == date('Y-m-d')){
					?>
					
					<div class="alert colorc alert-dismissible"  role="alert"> 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$product_r['n_id']?>');">&times;</button>
								<a onclick="show_pdetails('<?=$product_r['id']?>')" href="javascript:void(0);"> Product   ' <?=$product_r['title']?> '  Stock Are Not Available</a>
					</div>
				<?php } //}?>
					</div>
				</div>
			   
			   
                 <a   data-toggle="collapse" href="#pro_return" role="button" aria-expanded="false" aria-controls="collapseExample">
			 <div style="background-color:#eee;padding:10px;" class="alert alert-default alert-dismissible"> 
                  <h4><i style="border-radius:50px;background-color:#fff;padding:5px 6px; border:5px solid #f39c12;" class="icon fa fa-product-hunt"></i>&nbsp &nbsp Product Return!</h4>
                <p style="margin-left: 62px;margin-top: -17px;">Product Does Not Sale  45 Days  </p>
               </div>
			   </a>
			   
			   <div class="collapse" id="pro_return">
					<div class="card card-body" style="max-height: 300px; overflow: auto;">
					
						<?php 
					 $product_r1= mysqli_query($conn,"SELECT * FROM `notification` where type = 'preturn45' or type = 'preturn60' or type = 'preturn55' and status='1' ORDER BY n_id DESC");
				while($product_re=mysqli_fetch_assoc($product_r1)){
					 if($product_re['type']=="preturn45"){
					?>
					
					<div class="alert colorpur alert-dismissible" role="alert"> 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$product_re['n_id']?>');">&times;</button>
										<a onclick="show_pdetails('<?=$product_re['id']?>')" href="javascript:void(0);"> Product '<?=$product_re['title']?>' Are Not Sale to Last '45' Days</a>
					</div>
				<?php } else if($product_re['type']=="preturn55")  {?>
				<div class="alert colorpur alert-dismissible" role="alert"> 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$product_re['n_id']?>');">&times;</button>
										<a onclick="show_pdetails('<?=$product_re['id']?>')" href="javascript:void(0);"> Product '<?=$product_re['title']?>' Are Not Sale to Last '55' Days</a>
					</div>
				<?php } else if($product_re['type']=="preturn60")  {?>
				<div class="alert colorpur alert-dismissible" role="alert"> 
					  <button style="top: -8px;right: 0px;" type="button" class="close" data-dismiss="alert" aria-hidden="true" onclick="n_close('<?=$product_re['n_id']?>');">&times;</button>
										<a onclick="show_pdetails('<?=$product_re['id']?>')" href="javascript:void(0);"> Product '<?=$product_re['title']?>' Are Not Sale to Last '60' Days</a>
					</div>
				<?php } }?>
				
					</div>
				</div>
			   
                <!-- /.box-body -->
          </div>
	</div>
	</div>
	
     
      
    </section>
	</div>
  
<?php include 'footer.php';?>
</body>
</html>

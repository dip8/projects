<!DOCTYPE html>
<?php include 'header.php';?>
<html>
<head>
 <script>
$( document ).ready(function() {
    $("#mdash").removeClass('active');
    $("#mcategory").addClass('active');
	$("#com").css("color", "white");
});
 
 function add_company()
{ 		
	$("#company_form").submit(function(e) {
	if (e.isDefaultPrevented()) {
	} 
	else {
		
	e.preventDefault();
	document.getElementById("btncompany").disabled = true;
	    var myform = document.getElementById("company_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/company_add_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,
		  contentType: false,
			success: function (data) {
				if(data==1){
					alert("Company Records Added Successfully..");
				}else if(data==2){
					alert("Company Already Exist...");
				}else{
					alert("Company Not Added, Please Try Again!");	
				}
				location.reload();
			}
		});
	 
	}
	});
} 

function activate_deactivate(id,status)
 {
	$.ajax({
    url:'excess/activate_deactivate_user.php',
     type:'POST',
     data:{'id':id,'status':status, 'title':'company'},
     success: function(data)
     {
		if(data==1){
			alert("Status Updated Successfully..");
		}else{
			alert("Status Not Updated, Please Try Again!");	
		}
		location.reload();
     }

	});
	 
 } 
 
function update_company()
{ 	 	 
		document.getElementById("btnupcompany").disabled = true;
	    var myform = document.getElementById("companyupdate_form");
		var fd = new FormData(myform);
		$.ajax({
		  url: "excess/company_update_exce.php",
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				if(data==1){
					alert("Company Records Updated Successfully..");
				}else{
					alert("Company Not Updated, Please Try Again!");	
				}
				location.reload();
			}
		});
	 
	 
	 
}
 
function edit_company(id)
{
 	 $.ajax({
     url:'excess/edit_company.php',
     type:'POST',
     data:{'id':id},
     success: function(data)
     {
	  $('#company_edit').html('');
	  $('#cust_title').html('');
	  $('#cust_title').html('Company Update');
	  $('#cust_title1').html('');
	  $('#cust_title1').html('Company Update');
	   $('#company_edit').append(data);
	  }
	 
	}); 
}

function delete_company(id)
 {
  if(confirm("Are You Sure You Want To Delete It"))
  {
  $.ajax({
     url:'excess/record_delete_exce.php',
     type:'POST',
     data:{'id':id, 'title':'company'},
     success: function(data){
			if(data==1){
				alert("Company Deleted Successfully..");
			}else{
				alert("Company Not Delete, Please Try Again!");	
			}
			location.reload();
		}
	});
	}
	else{}
 }
 </script>
 
<body class="hold-transition skin-blue sidebar-mini">
<div class=" ">
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1 id="cust_title">
Company Add:
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li class="active" id="cust_title1">Company Add</li>
      </ol>
    </section>

    <!-- Main content -->
	<section class="content">
	<div class="row">
	<div style="padding-left:10px; padding-right:10px;" class="col-md-12">
	 <div style="border:2px solid #f39c12;" class="panel panel-warning">
	 
	  
	  <div class="panel-body" id="company_edit">
	
	   <form id="company_form" onsubmit="return add_company()"  autocomplete="off"   method="POST" class="form-horizontal group-border-dashed"  action="javascript:void(0);">
    <div class="col-md-6 col-md-push-3">
   <div class = "form-group">
      <label for = "dealerid" class = "col-sm-3 control-label">Company name:</label>
		
      <div class = "col-sm-9">
         <input type = "text" class = "form-control"   id="com_name" name="com_name"  data-bind="value:Id" placeholder = "Enter Company Name">
      </div>
   </div>
   
  </div>

			<div class="col-md-7 col-md-push-5">
			<div  class="box-footer clearfix no-border">
				  <button type="submit" id="btncompany" class="btn btn-primary"><i class="fa fa-plus"></i>Add Company</button>
	
		  <button  type="reset" class="btn btn-danger">Cancel</button>
		</div>
			</div>
	 </form> 
	 </div>
	 </div>
	</div>
	</div>
	
      <div class="row">
	  <div class="col-md-12 ">

          <div class="box box-warning">
            <div class="box-header">
              <h3 class="box-title">Company Details</h3>
            </div>
            <!-- /.box-header -->
			
            <div class="box-body table-responsive1">
              <table style="margin-left:10px;" id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Company Name</th>
                   <th Style="border-right-width:2px;">Status</th>
				  <th Style="border-right-width:2px;">Edit</th>
				  <th Style="border-right-width:2px;">Delete</th>
                  
                </tr>
                </thead><tbody>
				<?php 
				 $user_query = "SELECT * FROM `company` ORDER BY company_id DESC";
			$com_res = mysqli_query($conn,$user_query);
			$i=0;
			while($com_data = mysqli_fetch_assoc($com_res))
					{
						
						 
						$status=$com_data['status'];
						?>
                
                <tr>
                  <td><?php echo ++$i;?></td>
                  <td><?=$com_data['company_name']?></td>
				  <td>
					<select id="activate_deactivate1" class="form-control" onchange="activate_deactivate('<?php echo $com_data['company_id']; ?>',this.value);" >
											
					<option value="1" <?php if($status==1){?> selected <?php }?>>Activate</option>
					<option value="0" <?php if($status==0){?> selected <?php }?>>DeActivate</option>
					</select>
							</td>
				  
				  <td><a href="javascript:void(0);" onclick="edit_company('<?php echo $com_data['company_id']; ?>');"><i class="fa fa-pencil" title="Edit Company"></i></a></td>
                <td  Style="border-right-width:2px;">
					<a href="javascript:void(0);" onclick="delete_company('<?php echo $com_data['company_id']; ?>');">
							<i class="fa fa-trash" title="Delete Company" style="font-size:18px;text-align: center;"></i></a>
				</td>
				</tr>
                 
               
					<?php } ?> </tbody>
              </table>
            </div>
            <!-- /.box-body -->
			
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      
    </section>
	</div>
  <?php include 'footer.php';?>
</body>
</html>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('get_cat_name')){
   function get_cat_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('product_category',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_subcat_name')){
   function get_subcat_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('product_subcategory',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_goals_name')){
   function get_goals_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('goals',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_childcat_name')){
   function get_childcat_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('product_childcategory',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_customer_name')){
   function get_customer_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('customer',array('id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
		   return $result['company_name'].' ('.$result['name'].')';
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_product_name')){
   function get_product_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('products',array('product_id'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['product_name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_company_name')){
   function get_company_name($id){
       $ci =& get_instance();
       $ci->load->database();
       $query = $ci->db->get_where('about_shop_own',array('admin'=>$id));
       
       if($query->num_rows() > 0){
           $result = $query->row_array();
           return $result['shop_name'];
       }else{
           return false;
       }
   }
}

if ( ! function_exists('get_blog_cat_name')){
    function get_blog_cat_name($id){
        $ci =& get_instance();
        $ci->load->database();
        $query = $ci->db->get_where('blog_category',array('id'=>$id));
        
        if($query->num_rows() > 0){
            $result = $query->row_array();
            return $result['name'];
        }else{
            return false;
        }
    }
 }
 
 if ( ! function_exists('get_flavour_name')){
    function get_flavour_name($id){
        $ci =& get_instance();
        $ci->load->database();
        $query = $ci->db->get_where('flavour',array('id'=>$id));
        
        if($query->num_rows() > 0){
            $result = $query->row_array();
            return $result['name'];
        }else{
            return false;
        }
    }
 }
 
 if ( ! function_exists('get_brand_name')){
    function get_brand_name($id){
        $ci =& get_instance();
        $ci->load->database();
        $query = $ci->db->get_where('brands',array('id'=>$id));
        
        if($query->num_rows() > 0){
            $result = $query->row_array();
            return $result['name'];
        }else{
            return false;
        }
    }
 }
 
?>
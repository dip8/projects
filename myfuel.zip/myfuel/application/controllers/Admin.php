<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	public function print_data($data,$query=''){
		if($query){
			echo $this->db->last_query();
		}
		echo "<pre>";
		print_r($data);
		exit;
	}

	function view_forum_reply($id){
				
		$data=array(
		'id' => $id
		);

		$this->load->view('admin/forum_reply_view.php', $data);
	}

	function check_login(){
		if($this->session->userdata('profile')==''){
			redirect(base_url('admin'));
		}else{
			return true;
		}
	}

	function set_flashdata($type, $message){
		if($type == 'success'){
			$this->session->set_flashdata('success_message', $message);
		}else{
			$this->session->set_flashdata('failed_message', $message);
		}
	}

	public function index(){
		if($this->session->userdata('profile')!=''){
			redirect(base_url('admin/dashboard'));
		}

		$this->load->view('admin/login');
	}

	public function do_login(){

		$this->form_validation->set_rules("email_id","Email","required|valid_email");
		$this->form_validation->set_rules("password","Password","required");

		if($this->form_validation->run()==false){
			$this->index();
		}else{
			echo $_POST['email_id'];
			echo $_POST['password'];
			$table = 'users';
			$where = array('email' => $_POST['email_id'], 'password' => md5($_POST['password']));
			$profile = $this->user_model->get_common($table, $where);
			
			if($profile == ''){
				$this->session->set_flashdata("error_message","Invalid username and password.");
				redirect(base_url('admin/index'));
			}else{
				$this->session->set_userdata('profile', $profile);
				redirect(base_url('admin/dashboard'));
			}
		}
	}

	function logout(){
		$this->session->set_userdata('profile','');
		redirect(base_url('admin'));
	}
	
	/*  Reset password */
	// forgost password view
	function forgot_password(){
		$this->load->view('admin/forgot-pwd');
	}
	
	// Reset password,, sent new password
	function reset_password(){
		error_reporting(0);
		if(!empty($_REQUEST['random_no'])){
			
			$random_no=$_REQUEST['random_no'];
			$uid_arr=explode('-',$random_no);
			$user_id=(int)$uid_arr[1];
			$cur_time=date("Y-m-d H:i:s");

			$this->db->where('id ', $user_id);
			$this->db->where('random_no ', $random_no);
			$this->db->where('valid_till >=', $cur_time);
			$profile1 =$this->db->get('users');
			$profile = $profile1->row();
			
			$rec = count($profile);
			if($rec > 0 ){
				/* $this->session->set_flashdata("success_message","We have sent the password reset link to your email. Please check and reset your password by clicking on link."); */
				$data=array('id' => $user_id, 'random_no' => $random_no);
				$this->load->view('admin/reset-pwd',$data);
			}else{
				$this->session->set_flashdata("error_message","Your change password time has expired! Please try again.");
				redirect(base_url('admin/forgot_password'));	 
			}
		}
	}
	
	// save reset password
	function update_reset_password(){

		$this->form_validation->set_rules("user_id","User Id","required");
		$this->form_validation->set_rules("new_password","New Password","required|matches[confirm_password]");
		$this->form_validation->set_rules("confirm_password","Confirm Password","required");

		if($this->form_validation->run()==false){

			//$this->reset_password();
			$this->session->set_flashdata("error_message","Enter New Password and Confirm Password Same!");
			redirect(base_url('admin/reset_password?random_no='.$_POST['random_no']));
			
		}else{
			$table = 'users';
			$where = array('id' => $_POST['user_id']);
			$updateData = array('password' => md5($_POST['confirm_password']));
			
			$this->user_model->update_common($table, $where, $updateData);

			$this->session->set_flashdata("success_message","Password Reset successfully.");
			redirect(base_url('admin/index'));
		}
	}
	/* End Reset password */
	
	function change_password(){
		$this->check_login();
		$data['active_menu'] = 'dashboard';
		$this->load->view('admin/change_password', $data);
	}

	function update_password(){

		$this->form_validation->set_rules("current_password","Current Password","required|callback_check_current_password");
		$this->form_validation->set_rules("new_password","New Password","required|matches[confirm_password]");
		$this->form_validation->set_rules("confirm_password","Confirm Password","required");

		if($this->form_validation->run()==false){

			$this->change_password();
		}else{
			$table = 'users';
			$where = array('id' => $_SESSION['profile']->id);
			$updateData = array('password' => md5($_POST['confirm_password']));
			
			$this->user_model->update_common($table, $where, $updateData);

			$this->session->set_flashdata("success_message","Password updated successfully.");
			redirect(base_url('admin/change_password'));
		}
	}

	function check_current_password($pwd){
		$where = array('id' => $_SESSION['profile']->id);
		$table="users";

		$profile = $this->user_model->get_common($table, $where);

		if($profile->password != md5($pwd)){
			$this->form_validation->set_message('check_current_password','The Current Password is incorrect.');
			return false;
		}else{
			return true;
		}
	}

	function profile(){
		
		$this->check_login();
		$table = 'users';
		$where = array('id'=>$_SESSION['profile']->id);
		$group_by = '';
		$order_by = 'id';
		$order1 = '';
		$data['profile'] = $this->user_model->get_common($table, $where,'*',1, '', $group_by, $order_by, $order1);
		
		$this->load->view('admin/profile', $data);
	}
	
	function dashboard(){

		$this->check_login();
		
		$where = array('status_id !=' => 0);
		$where_p = array('status!='=>0);
		 
		$data['active_menu'] = 'dashboard';
		
		$data['total_products'] = $this->user_model->get_common('products', $where_p, 'count(*) as total',1,'','','');
		$data['total_brands'] = $this->user_model->get_common('brands', $where, 'count(*) as total');	
		$data['total_category'] = $this->user_model->get_common('product_category', $where, 'count(*) as total');	
		$this->load->view('admin/dashboard', $data);
	}

	function update_shop(){
	   @extract($_POST);
	    $this->form_validation->set_rules ( 'shop_number', 'Shop Number', 'required' );
	    $this->form_validation->set_rules ( 'shop_name', 'Shop Name', 'required|callback__alpha_dash_space' );
		$this->form_validation->set_rules ( 'shop_email', 'Email', 'trim|required|valid_email|xss_clean' );
		$this->form_validation->set_rules ( 'shop_contact', 'Contact', 'required|numeric' );
	    $this->form_validation->set_rules ( 'shop_address', 'Address', 'required' );
		if($this->form_validation->run()==false){

			$this->dashboard();
		}else{

		if(!empty($_FILES['logo']['name'])){
				$temp = explode(".", $_FILES["logo"]["name"]);
				$newfilename = 'logo_'.round(microtime(true)).'.' . end($temp);
				$folder = "./assets/images/";
				move_uploaded_file($_FILES["logo"]["tmp_name"] , "$folder".$newfilename);	
				 
			}else{
				$newfilename="";
			}

			$shop_id=$_POST['shop_id'];
			$where = array('shop_id' => $shop_id);
			$updateData = array(
				'shop_number' =>	$_POST['shop_number'],
				'shop_name'	=>	$_POST['shop_name'],
				'owner_name'	=>	$_POST['owner_name'],
				'shop_contact'	=>	$_POST['shop_contact'],
				'shop_contact1'	=>	$_POST['shop_contact1'],
				'shop_email' =>	$_POST['shop_email'],
				'shop_email1' =>	$_POST['shop_email1'],
				'shop_address'	=>	$_POST['shop_address'],
				'shop_address1'	=>	$_POST['shop_address1'],
				'shop_gstno'	=>	$_POST['shop_gstno'],
				'shop_pan'	=>	$_POST['shop_pan'],
				'shop_van' =>	$_POST['shop_van'],
				'shop_website'	=>	$_POST['shop_website'],
				'print_flag'	=>	0,
				'shop_terms_conditions'	=>	$_POST['shop_terms_conditions'],
				'bank_name'	=>	$_POST['bank_name'],
				'account_name'	=>	$_POST['account_name'],
				'account_number'	=>	$_POST['account_number'],
				'ifsc_code'	=>	$_POST['ifsc_code']
			);
			
			if(!empty($_FILES['logo']['name'])){
			$updateData['logo'] = $newfilename;
			}else{
				$newfilename="";
			}
						
		    $uptabt = $this->user_model->update_common('about_shop_own', $where, $updateData);	    
			 
			if($uptabt){
				echo 1;
			}else{
				echo 0;
			}
		}
    }

	function subusers(){
		$this->check_login();

		$table = 'users';
		$where = array('main_admin' =>0,'status_id !=' => 0);
		$subusers = $this->user_model->get_common($table, $where,'*',2);

		$data = array('subusers' => $subusers);
		$data['active_menu'] = 'subusers';

		$this->load->view('admin/subusers', $data);
	}

	function save_user(){

    	$this->form_validation->set_rules ( 'name', 'Name', 'required|callback__alpha_dash_space' );
    	$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email|xss_clean' );
    	$this->form_validation->set_rules ( 'contact', 'Contact', 'required|numeric' );
    	$this->form_validation->set_rules ( 'pwd', 'Password', 'required|min_length[6]|matches[cpassword]' );
		$this->form_validation->set_rules ( 'cpassword', 'Confirm Password', 'required' );
    	$this->form_validation->set_rules ( 'user_desc', 'Description', 'required' );
    	if($this->form_validation->run()==false){

    		$this->add_user();
    	}else{

    		$insert_data = array(
    						'name'	=>	$_POST['name'],
    						'email'	=>	$_POST['email'],
				            'phone'	=>	$_POST['contact'],
				            'password'	=>	md5($_POST['pwd']),
				            'main_admin'	=>	0,
    						'admin_level'	=>	2,
				            'about'	=>	$_POST['user_desc'],
    						'status_id'	=>	1
    					);

    		$table = 'users';

    		$this->user_model->save_common($table, $insert_data);

    		$this->session->set_flashdata("success_message","User added successfully.");
    		redirect(base_url('admin/subusers'));
    	}
    }

	function update_subusers($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('users', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Subuser deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/subusers'));
	}

	function subusers_details($id){
		$this->check_login();

		$table = 'users';
		$where = array('id' => $id);
		$subusers = $this->user_model->get_common($table, $where,'*');

		$data = array('subusers' => $subusers);
		$data['active_menu'] = 'subusers';

		$this->load->view('admin/subusers_details', $data);
	}
	
	function edit_subuser($id){

		$this->check_login();

		$table = 'users';
		$where = array('id' => $id);
		$subusers = $this->user_model->get_common($table, $where,'*');

		$data = array('subusers' => $subusers);
		$data['active_menu'] = 'subusers';

		$this->load->view('admin/edit_subuser', $data);
	}
	
	function update_subuser_details(){

		$this->form_validation->set_rules ( 'name', 'User Name', 'required' );
    	$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email|xss_clean' );
    	$this->form_validation->set_rules ( 'contact', 'Contact', 'required|numeric' );
    	//$this->form_validation->set_rules ( 'pwd', 'Password', 'required' );
    	$this->form_validation->set_rules ( 'user_desc', 'Description', 'required' );
		
		if($this->form_validation->run()==false){

			$this->edit_subuser($_POST['id']);
		}else{
			
			$update_data = array(
    						'name'	=>	$_POST['name'],
    						'email'	=>	$_POST['email'],
				            'phone'	=>	$_POST['contact'],
				            'about'	=>	$_POST['user_desc']
    					);

			
			$table = 'users';

			$where = array('id' => $_POST['id']);

			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Sub-user updated successfully.");
			redirect(base_url('admin/subusers'));
		}
	}   

	function product(){
		$this->check_login();

		$table = 'products';
		$where = array('status !=' => 0);
		$group_by = '';
		$order_by = 'position';
		$order = 'DESC';
		 
		$product = $this->user_model->get_common($table, $where,'*',2, '', $group_by, $order_by, $order);

		$data = array('product' => $product);
		$data['active_menu'] = 'product';

		$this->load->view('admin/product', $data);
	}
	
	function update_product($status, $id){
		
		$table = 'products';
		$where = array('product_id' => $id);
		$updateData = array('status' => $status);

		$this->user_model->update_common($table, $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'product deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/product'));
	}
	
	
	function brands(){
		$this->check_login();

		$table = 'brands';
		$where = array('status_id !=' => 0);
		$group_by = '';
		$brands = $this->user_model->get_common($table, $where,'*',2, '', $group_by);

		$data = array('brands' => $brands);
		$data['active_menu'] = 'brands';
		$this->load->view('admin/brands', $data);
	}
	
	function brand_details($id){
		$this->check_login();

		$table = 'brands';
		$where = array('id' => $id);
		$brands = $this->user_model->get_common($table, $where);

		$data = array('brands' => $brands);
		$data['active_menu'] = 'project';

		$this->load->view('admin/brand_details', $data);
	}	
	
	function add_brand(){
		$this->check_login();
		$table = 'brands';
		$where = array('status_id !=' => 0);
		$group_by = '';
		$brands = $this->user_model->get_common($table, $where,'*',2, '', $group_by);

		$data = array('brands' => $brands);
		$data['active_menu'] = 'category';
		$this->load->view('admin/add_brand', $data);
	}
	
	function save_brand(){
		error_reporting(0);

		$this->form_validation->set_rules ( 'name', 'Brand Name', 'required' );

		if ($_FILES ["image"] ["name"] == "") {
			$this->form_validation->set_rules ( "image", "Upload  Brand Image", "required" );
		}

		$config ['upload_path'] = './site_data/uploads/brands/';
		$config ['allowed_types'] = 'jpeg|jpg|png';
		//$config ['max_size'] = 2048;
		$config ['file_name'] = uniqid ( "brand_" );
		$this->upload->initialize ( $config );
		
		if($this->form_validation->run()==false || $this->upload->do_upload('image') == FALSE){
			$this->add_brand();
		}else{
			$upload_data = $this->upload->data ();
			$uploaded_file_name=$upload_data['file_name'];

			$insert_data = array(
				'name'	=>	$_POST['name'],
				'image'	=>	$uploaded_file_name,
				'created_by'	=>	$_SESSION['profile']->id,
			);

			$table = 'brands';
			$this->user_model->save_common($table, $insert_data);

			$this->session->set_flashdata("success_message","Image uploaded successfully.");
			redirect(base_url('admin/add_brand'));
		}	
	}
	
	function update_brand_status($status, $id){
		
		$table = 'brands';
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common($table, $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Brand deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/add_brand'));
	}
	
	function edit_brand($id){

		$table = 'brands';
		$where = array('id' => $id);
        $brands = $this->user_model->get_common($table, $where);

		$data['active_menu'] = 'category';
		$data['brands'] = $brands;
		$this->load->view('admin/edit_brand', $data);
	}

	function update_brand_details(){

		$this->form_validation->set_rules ( 'name', 'Brand Name', 'required' );
		
		if ($_FILES ["image"] ["name"] != "") {
			
			/* upload config */
			$config ['upload_path'] = './site_data/uploads/brands/';
			$config ['allowed_types'] = 'jpeg|jpg|png';
			//$config ['max_size'] = 2048;
			$config ['file_name'] = uniqid ( "project_" );
			$this->upload->initialize ( $config );
		}

		if($_FILES ["image"] ["name"] != ""){
			if($this->upload->do_upload('image') == FALSE){
				$this->edit_brand($_POST['id']);
			}
		}
		if($this->form_validation->run()==false){

			$this->edit_brand($_POST['id']);
		}else{
			if($_FILES ["image"] ["name"] != ""){
				$upload_data = $this->upload->data();
				$uploaded_file_name=$upload_data['file_name'];
			}

			$update_data = array(
				'name'	=>	$_POST['name']
			);
			if($_FILES ["image"] ["name"] != ""){
				$update_data['image'] = $uploaded_file_name;
			}
			$table = 'brands';

			$where = array('id' => $_POST['id']);

			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Brand updated successfully.");
			redirect(base_url('admin/add_brand'));
		}
	}
	
	function add_product(){
		$this->check_login();
		$group_by = '';
		$order_by = 'id';
		$order = 'ASC';
		
		$table = 'product_category';
		$where = array('status_id' => 1);
		$category = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		
		$table = 'product_subcategory';
		$where = array('status_id' => 1);
		$sub_category = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		      
		$table = 'flavour';
		$where = array('status_id' => 1);
		$flavour = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		      
		$table = 'goals';
		$where = array('status_id' => 1);
		$goals = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);

		$table = 'brands';
		$where = array('status_id' => 1);
		$brand = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		$order_by = 'product_id';
		$table = 'products';
		$where = array('status' => 1);
		$products = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		
		$data = array('products' => $products,'goals' => $goals,'flavour' => $flavour,'category' => $category,'sub_category' => $sub_category,'brand' =>$brand);
		$data['active_menu'] = 'product';
		$this->load->view('admin/add_product', $data);
	}
	
	
	function edit_product($id){

		$table = 'products';
		$where = array('product_id' => $id);
		$group_by = '';
		$order_by = '';
		$order = 'DESC';
		$product = $this->user_model->get_common($table, $where, '*', 2, '', $group_by, $order_by, $order);
        
		$group_byc = '';
		$order_byc = 'id';
		$orderc = 'ASC';
		$table = 'product_category';
		$where = array('status_id' => 1);
		$category = $this->user_model->get_common($table, $where,'*',2, '', $group_byc, $order_byc, $orderc);
      		
		$table = 'product_subcategory';
		$where = array('status_id' => 1,'product_cat_id'=>$product[0]->main_category);
		$sub_category = $this->user_model->get_common($table, $where,'*',2, '', $group_byc, $order_byc, $orderc);
		
		$table = 'flavour';
		$where = array('status_id' => 1);
		$flavour = $this->user_model->get_common($table, $where,'*',2, '', $group_byc, $order_byc, $orderc);
       
		$table = 'goals';
		$where = array('status_id' => 1);
		$goals = $this->user_model->get_common($table, $where,'*',2, '', $group_byc, $order_byc, $orderc);

		$table = 'brands';
		$where = array('status_id' => 1);
		$brand = $this->user_model->get_common($table, $where,'*',2, '', $group_byc, $order_byc, $orderc);

		$order_by = 'product_id';
		$table = 'products';
		$where = array('status' => 1);
		$products = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
				
		$data = array('products' => $products,'goals' => $goals,'flavour' => $flavour,'category' => $category,'sub_category' => $sub_category,'brand' =>$brand);
		$data['active_menu'] = 'product';
		$data['product'] = $product;
	
		$this->load->view('admin/edit_product', $data);
	}
	
	function update_review_status($status, $id, $product_id){
		$where = array('id' => $id);
		$updateData = array('status' => $status);

		$this->user_model->update_common('rating', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Product Review & Rating deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/product_review/'.$product_id));
	}
	
	
	function update_product_details()
	{
		//$this->form_validation->set_rules ('product_code', 'Product Code', 'required' );
		$this->form_validation->set_rules ( 'product_name', 'Product Name', 'required' );
		//$this->form_validation->set_rules ( 'product_desc', 'Product Remart', 'required' );
		$this->form_validation->set_rules ( 'price', 'Unit cost', 'required' );
		$this->form_validation->set_rules ( 'weight', 'weight', 'required' );
		//$this->form_validation->set_rules ( 'product_qty', 'Quantity', 'required|numeric' );
		//$this->form_validation->set_rules ( 'product_minqty', 'Min Quantity', 'required|numeric' );
		// $this->form_validation->set_rules ( 'gst', 'GST', 'required|max_length[15]' );
		$this->form_validation->set_rules ( 'main_category', 'Main Category', 'required' );
		//$this->form_validation->set_rules ( 'sub_category', 'Sub Category', 'required' );
		//$this->form_validation->set_rules ( 'child_category','Child Category', 'required' );
		$product_id = $_POST['id'];
		if($this->form_validation->run()==false){
			$this->edit_product($_POST['id']);
		}else{

			$update_data = array(
				'product_code'	=>	$_POST['product_code'],
				'product_name'	=>	$_POST['product_name'],
				'price'	=>	$_POST['price'],
				'offer_price'	=>	$_POST['offer_price'],
				'weight'	=>	$_POST['weight'],
				'goals_id'	=>	$goals_id,
				'quantity'=> $_POST['product_qty'],
				'min_quantity'=> $_POST['product_minqty'],
				'gst'	=>	$_POST['gst'],
				'main_category'	=> $_POST['main_category'],
				'sub_category'	=>	$_POST['sub_category'],
				'brand_id' => $_POST['brand_category'],
				'flavour' => $_POST['flavour_id'],
				'servings'=> $_POST['servings'],
				'size'=> $_POST['size'],
				'stack_with'=> $related_product_id,
				'updated_date'=>$date,
			);

	
			$table = 'products';
			$where = array('product_id' => $_POST['id']);
			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Product updated successfully.");
			redirect(base_url('admin/product'));
		}
	}
	
	
	function save_product(){
			//error_reporting(0);
			$this->form_validation->set_rules ( 'product_name', 'Product Name', 'required' );
			$this->form_validation->set_rules ( 'price', 'Unit Cost', 'required|numeric' );
			$this->form_validation->set_rules ( 'gst', 'GST', 'required' );
			$this->form_validation->set_rules ( 'main_category', 'Main Category', 'required' );
			$this->form_validation->set_rules ( 'brand_category', 'Brand Category', 'required' );
			$this->form_validation->set_rules ( 'product_qty', 'Product Quantity', 'required' );


			if($this->form_validation->run()==false ){

			$this->add_product();

			}else{

			$insert_data = array(
			'product_code'	=>	$_POST['product_code'],
			'product_name'	=>	$_POST['product_name'],
			'weight'	=>	$_POST['weight'],
			'price'	=>	$_POST['price'],
			'offer_price'	=>	$_POST['offer_price'],
			'gst'	=>	$_POST['gst'],
			'main_category'	=> $_POST['main_category'],
			'sub_category'	=>	$_POST['sub_category'],
			'flavour'	=> $_POST['flavour_id'],
			'brand_id'=> $_POST['brand_category'],
			'quantity'=> $_POST['product_qty'],
			'min_quantity'=> $_POST['product_minqty'],
			'servings'=> $_POST['servings'],
			'size'=> $_POST['size'],
			'product_type'	=> '',
			'position'	=> 0,
			'added_by'	=>	$_SESSION['profile']->id,
			'status'	=>	1,
			);

			$table = 'products';
			$this->user_model->save_common($table, $insert_data);
			$this->session->set_flashdata("success_message","Product uploaded successfully.");
			redirect(base_url('admin/product'));

	 }			}
	
	function add_user(){

		$this->check_login();

		$table = 'blog_category';
		$where = array('status_id !=' => 0);
		$category = $this->user_model->get_common($table, $where,'*',2);
        // print_r($category);
		$data = array('category' => $category);
		$data['active_menu'] = 'subusers';

		$this->load->view('admin/add_user', $data);
		
	}
	function category(){

		$table = 'product_category';
		$where = array('status_id !=' => 0);
		$category = $this->user_model->get_common($table, $where,'*',2);
       // print_r($category);
		$data = array('category' => $category);
		$data['active_menu'] = 'category';
		$this->load->view('admin/category', $data);
		
	}

	function add_subcategory(){

		$table = 'product_category';
		$where = array('status_id !=' => 0);
		$category = $this->user_model->get_common($table, $where,'*',2);
		
		$table = 'product_subcategory';
		$where = array('status_id !=' => 0);
		$sub_category = $this->user_model->get_common($table, $where,'*',2);
      
		$data = array('category' => $category,'sub_category' => $sub_category);
		$data['active_menu'] = 'category';
		$this->load->view('admin/add_subcategory', $data);
		
	}

	function add_childcategory(){

		$table = 'product_category';
		$where = array('status_id !=' => 0);
		$category = $this->user_model->get_common($table, $where,'*',2);
      
		$table = 'product_childcategory';
		$where = array('status_id !=' => 0);
		$child_category = $this->user_model->get_common($table, $where,'*',2);
		
		$table = 'product_subcategory';
		$where = array('status_id !=' => 0);
		$sub_category = $this->user_model->get_common($table, $where,'*',2);
      
		$data = array('category' => $category,'sub_category' => $sub_category,'child_category' => $child_category);
		//$data = array('category' => $category);
		$data['active_menu'] = 'category';
		$this->load->view('admin/add_childcategory', $data);
		
	}
	
	function add_flavour(){
		
		$table = 'flavour';
		$where = array('status_id !=' => 0);
		$flavour = $this->user_model->get_common($table, $where,'*',2);
		$data = array('flavour' => $flavour);
		$data['active_menu'] = 'category';
		$this->load->view('admin/add_flavour', $data);
		
	}
	
	function add_goal(){
		
		$table = 'goals';
		$where = array('status_id !=' => 0);
		$goals = $this->user_model->get_common($table, $where,'*',2);
		$data = array('goals' => $goals);
		$data['active_menu'] = 'category';
		$this->load->view('admin/add_goal', $data);
		
	}
	
	function save_category(){
        //$this->lang->load('lang');
		$this->form_validation->set_rules ( 'category', 'Main Category Name', 'required' );
		$date = date("Y-m-d");  
		
		if($this->form_validation->run()==false){
			$this->category();
			
		}else{
			$insert_data = array(
				'name'	=>	ucfirst($_POST['category']),
				'status_id'	=>	1,
				'created_date'	=>	$date,
			);

			$table = 'product_category';
			$this->user_model->save_common($table, $insert_data);
 
			$this->session->set_flashdata("success_message","Category added successfully.");
			redirect(base_url('admin/category'));
		}
	}

	function save_sub_category(){

		$this->form_validation->set_rules ( 'main_category', 'Main Category', 'required' );
		$this->form_validation->set_rules ( 'category', 'Sub-Category Name', 'required' );
		$date = date("Y-m-d");  
		
		if($this->form_validation->run()==false){
			$this->add_subcategory();
			
		}else{
			$insert_data = array(
							'name'	=>	ucfirst($_POST['category']),
				            'product_cat_id'=> $_POST['main_category'],
							'status_id'	=>	1,
							'created_date'	=>	$date,
							//'created_by'	=>	$_SESSION['profile']->id,
						);

			$table = 'product_subcategory';

			$this->user_model->save_common($table, $insert_data);
 
			$this->session->set_flashdata("success_message","Sub Category added successfully.");
			redirect(base_url('admin/add_subcategory'));
		}
	}

	function save_child_category(){

		$this->form_validation->set_rules ( 'main_category', 'Main Category', 'required' );
		$this->form_validation->set_rules ( 'sub_category', 'Sub Category', 'required' );
		$this->form_validation->set_rules ( 'child_category', 'Child Category Name', 'required' );
		$date = date("Y-m-d");  
		
		if($this->form_validation->run()==false){
			$this->add_childcategory();
			
		}else{
			$insert_data = array(
							'name'	=>	ucfirst($_POST['child_category']),
				            'product_cat_id'=> $_POST['main_category'],
				            'product_subcat_id'=> $_POST['sub_category'],
							'status_id'	=>	1,
							'created_date'	=>	$date,
							//'created_by'	=>	$_SESSION['profile']->id,
						);

			$table = 'product_childcategory';

			$this->user_model->save_common($table, $insert_data);
 
			$this->session->set_flashdata("success_message","Sub Category added successfully.");
			redirect(base_url('admin/add_childcategory'));
		}
	}
	
	function save_flavour(){

		$this->form_validation->set_rules ( 'name', 'Flavour', 'required' );
		
		if($this->form_validation->run()==false){
			$this->add_flavour();
		}else{
			
			$insert_data = array(
				'name' => ucfirst($_POST['name']),
				'status_id'	=>	1
			);

			$table = 'flavour';
			$this->user_model->save_common($table, $insert_data);
			$this->session->set_flashdata("success_message","Flavour added successfully.");
			redirect(base_url('admin/add_flavour'));
		}
	}
	
	function save_goal(){

		$this->form_validation->set_rules ( 'name', 'Goal', 'required' );
		
		if($this->form_validation->run()==false){
			$this->add_flavour();
		}else{
			
			$insert_data = array(
				'name' => ucfirst($_POST['name']),
				'status_id'	=>	1
			);

			$table = 'goals';
			$this->user_model->save_common($table, $insert_data);
			$this->session->set_flashdata("success_message","Goal added successfully.");
			redirect(base_url('admin/add_goal'));
		}
	}
	
	function update_category_status($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('product_category', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Category deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/category'));
	}
	
	function update_subcategory_status($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('product_subcategory', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Sub Category deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/add_subcategory'));
	}
	
	function update_childcategory_status($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('product_childcategory', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Child Category deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/add_childcategory'));
	}
	
	function update_flavour_status($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('flavour', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Flavour deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/add_flavour'));
	}
	
	function update_goal_status($status, $id){
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('goals', $where, $updateData);

		if($status == 0){
			$this->set_flashdata('success', 'Goal deleted successfully.');
		}else{
			$this->set_flashdata('success', 'Status updated successfully.');
		}

		redirect(base_url('admin/add_goal'));
	}
	
	function edit_category($id){
		
		$this->check_login();

		$table = 'product_category';
		$where = array('id' => $id);

		$category = $this->user_model->get_common($table, $where);
 
		$data['active_menu'] = 'category';
		$data['category'] = $category;
        $this->load->view('admin/edit_category', $data);
	}
	
	function edit_subcategory($id){
		
		$this->check_login();

		$table = 'product_subcategory';
		$where = array('id' => $id);

		$sub_category = $this->user_model->get_common($table, $where);
 
		$data['active_menu'] = 'category';
		$data['sub_category'] = $sub_category;
        $this->load->view('admin/edit_subcategory', $data);
		
		
	}
	
	function edit_childcategory($id){
		
		$this->check_login();

		$table = 'product_childcategory';
		$where = array('id' => $id);

		$child_category = $this->user_model->get_common($table, $where);
 
		$data['active_menu'] = 'category';
		$data['child_category'] = $child_category;
        $this->load->view('admin/edit_childcategory', $data);
	}
	
	function edit_flavour($id){
		
		$this->check_login();

		$table = 'flavour';
		$where = array('id' => $id);

		$flavour = $this->user_model->get_common($table, $where);
 
		$data['active_menu'] = 'category';
		$data['flavour'] = $flavour;
        $this->load->view('admin/edit_flavour', $data);
	}
	
	function edit_goal($id){
		
		$this->check_login();

		$table = 'goals';
		$where = array('id' => $id);

		$goal = $this->user_model->get_common($table, $where);
 
		$data['active_menu'] = 'category';
		$data['goal'] = $goal;
        $this->load->view('admin/edit_goal', $data);
	}
	
	function update_edit_category(){

		$this->form_validation->set_rules ( 'category', 'Category','required' );
		  
		if($this->form_validation->run()==false){

			$this->edit_category($_POST['id']);
		}else{
			 
			$date = date("Y-m-d");

			$update_data = array(
				'name'	=>	$_POST['category'],
				'updated_date'	=>	$date,
			);
					 
			$table = 'product_category';
			$where = array('id' => $_POST['id']);

			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Category updated successfully.");
			redirect(base_url('admin/category'));
		}
	}
	
	function update_edit_subcategory(){

		$this->form_validation->set_rules ( 'category', 'Category','required' );
		  
		if($this->form_validation->run()==false){

			$this->edit_subcategory($_POST['id']);
		}else{
			 
			$date = date("Y-m-d");

			$update_data = array(
							'name'	=>	$_POST['category'],
							'updated_date'	=>	$date,
							//'updated_by'	=>	$_SESSION['profile']->id,
						);
			 
			$table = 'product_subcategory';

			$where = array('id' => $_POST['id']);

			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Sub Category updated successfully.");
			redirect(base_url('admin/add_subcategory'));
		}
	}

	function update_edit_childcategory(){

		$this->form_validation->set_rules ( 'category', 'Category','required' );
		  
		if($this->form_validation->run()==false){

			$this->edit_childcategory($_POST['id']);
		}else{
			 
			$date = date("Y-m-d");

			$update_data = array(
							'name'	=>	$_POST['category'],
							'updated_date'	=>	$date,
							//'updated_by'	=>	$_SESSION['profile']->id,
						);
			 
			$table = 'product_childcategory';

			$where = array('id' => $_POST['id']);

			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Child Category updated successfully.");
			redirect(base_url('admin/add_childcategory'));
		}
	}
	
	function update_edit_flavour(){

		$this->form_validation->set_rules ( 'name', 'Flavour','required' );
		  
		if($this->form_validation->run()==false){

			$this->edit_flavour($_POST['id']);
			
		}else{

			$update_data = array(
				'name'	=>	$_POST['name']
			);
			 
			$table = 'flavour';
			$where = array('id' => $_POST['id']);
			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Flavour updated successfully.");
			redirect(base_url('admin/add_flavour'));
		}
	}
	
	function update_edit_goal(){

		$this->form_validation->set_rules ( 'name', 'Goal','required' );
		  
		if($this->form_validation->run()==false){

			$this->edit_flavour($_POST['id']);
			
		}else{

			$update_data = array(
				'name'	=>	$_POST['name']
			);
			 
			$table = 'goals';
			$where = array('id' => $_POST['id']);
			$this->user_model->update_common($table, $where, $update_data);

			$this->session->set_flashdata("success_message","Goal updated successfully.");
			redirect(base_url('admin/add_goal'));
		}
	}
	
	function customer()
	{
		$this->check_login();
		
		$table = 'customer';
		$where = array('status_id !=' => 0);
		$customer = $this->user_model->get_common($table, $where,'*',2);
		$data = array('customer' => $customer);
		$data['active_menu'] = 'customer';
		$this->load->view('admin/customer', $data);
	}

	function add_customer()
	{
		$this->check_login();

		$data['active_menu'] = 'customer';
		$this->load->view('admin/add_customer', $data);
	}
	
	function save_customer()
	{
		//@extract($_POST);
		$this->form_validation->set_rules ( 'name', 'Name', 'required' );
		$this->form_validation->set_rules ( 'contact', 'Contact', 'required|numeric|min_length[10]|max_length[10]|is_unique[customer.contact]' );
		$this->form_validation->set_rules ( 'country', 'Country', 'xss_clean' );
		$this->form_validation->set_rules ( 'state', 'State', 'required|xss_clean' );
		$this->form_validation->set_rules ( 'city', 'City', 'required|xss_clean' );
		$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email|xss_clean|is_unique[customer.email]' );
		$this->form_validation->set_rules ( 'pin', 'Pincode', 'required|numeric|max_length[6]' );
		$this->form_validation->set_rules ( 'address1', 'Address', 'required' );
		$this->form_validation->set_rules ( 'password', 'Password', 'required|min_length[6]|matches[cpassword]' );
		$this->form_validation->set_rules ( 'cpassword', 'Confirm Password', 'required' );

		if($this->form_validation->run()==false)
		{

		$this->add_customer();

		}
		else
		{ 
		$customer_name=ucwords($_POST['name']);
		$customer_mail=strtolower($_POST['email']);
		$customer_contact=$_POST['contact'];
		$customer_address1=$_POST['address1'];
		$customer_address2=$_POST['address2'];
		$customer_country=ucwords($_POST['country']);
		$customer_state=ucwords($_POST['state']);
		$customer_city=ucwords($_POST['city']);
		$customer_pin=$_POST['pin'];
		
		$birth= $_POST['birth'];
		
		$insert_data = array(
		'name'	=>	$customer_name,
		'email'	=>	$customer_mail,
		'contact'	=>	$customer_contact,
		'birth '	=>	$birth, 
		'password'	=> md5($_POST['password']),
		'country'	=> $customer_country,
		'state'	=>	$customer_state, 
		'city '	=>	$customer_city, 
		'pincode'	=>	$_POST['pin'],
		'address1'	=>	$_POST['address1'],
		'address2'	=>	$_POST['address2'],
		'added_by' => $_SESSION['profile']->id,
		'status_id'	=>	1
		);

		$table = 'customer';
		$this->user_model->save_common($table, $insert_data);
		$customer_id = $this->db->insert_id();
		$insert_data_add = array(
		'customer_id'=> $customer_id,
		'name' =>$customer_name,
		'contact' =>$customer_contact,
		'address' =>$_POST['address1'].", ".$_POST['address2'],
		'city'=>$customer_city,
		'state'=> $customer_state,
		'pin_code' =>$_POST['pin'] 
		);

		$this->user_model->save_common('cust_address', $insert_data_add);
		$this->session->set_flashdata("success_message","Customer added successfully.");
		redirect(base_url('admin/customer'));
		}
	}

	function edit_customer($id){
		$this->check_login();
		
		$table = 'customer';
		$where = array('id' => $id);

		$customer = $this->user_model->get_common($table, $where);
		$data['active_menu'] = 'customer';
		$data['customer'] = $customer;

		$this->load->view('admin/edit_customer', $data);		 
	} 
	
	function update_customer(){
		
		$this->form_validation->set_rules ( 'name', 'Name', 'required' );
		$this->form_validation->set_rules ( 'contact', 'Contact', 'required|numeric' );
		$this->form_validation->set_rules ( 'country', 'Country', 'required|xss_clean' );
		$this->form_validation->set_rules ( 'state', 'State', 'required|xss_clean' );
		$this->form_validation->set_rules ( 'city', 'City', 'required|xss_clean' );
		$this->form_validation->set_rules ( 'pin', 'Pincode', 'required|numeric|max_length[6]' );
		$this->form_validation->set_rules ( 'address1', 'Address', 'required' );
		
        
		if($this->form_validation->run()==false)
		{

			$this->edit_dealer($_POST['id']);
			
		}else
		{
			
			$cur_date = date("Y-m-d h:i:s");
			 $update_data = array(
									'name'	=>	$_POST['name'],
									'email'	=>	$_POST['email'],
									'contact'	=>	$_POST['contact'],
									'birth '	=>	$_POST['birth'], 
									'ani'	=>	$_POST['ani'], 
									'country'	=> $_POST['country'],
									'state'	=>	$_POST['state'], 
									'city '	=>	$_POST['city'], 
									'pincode'	=>	$_POST['pin'],
									'address1'	=>	$_POST['address1'],
									'updated_date' => $cur_date,
									'updated_by' => $_SESSION['profile']->id,
								);
						 
			$table = 'customer';
			$where = array('id' => $_POST['id']);

		$this->user_model->update_common($table, $where, $update_data);

		$this->session->set_flashdata("success_message","Customer updated successfully.");
		redirect(base_url('admin/customer'));
		
		}
	}
	
	function customer_details($id)
	{
		$table = 'customer';
		$where = array('id' => $id);
		$customer = $this->user_model->get_common($table, $where);

		$data['active_menu'] = 'customer';
		$data['customer'] = $customer;

		$this->load->view('admin/customer_details', $data);		 
	} 
	
	function update_customer_status($status, $id)
	{
			
		$where = array('id' => $id);
		$updateData = array('status_id' => $status);

		$this->user_model->update_common('customer', $where, $updateData);

		if($status == 0)
		{
			$this->user_model->delete_common('customer', $where);
			$this->set_flashdata('success_message', 'Customer deleted successfully.');
		}
		else
		{
			$this->set_flashdata('success_message', 'Status updated successfully.');
		}

		redirect(base_url('admin/customer'));		 
	}
	
	// add new dealer
	function add_dealer(){
		$this->check_login();

		$table = 'stores';
		$where = array('status_id !=' => 0);
		$product = $this->user_model->get_common($table, $where,'*',2);
		$data = array('product' => $product);
		$data['active_menu'] = 'dealer';
		$this->load->view('admin/add_dealer', $data);	
	}
	
	// save new dealer
	function save_dealer(){
		error_reporting(0);
        //@extract($_POST);
        $this->form_validation->set_rules ( 'client_id', 'Client Id', 'required|numeric' );
        $this->form_validation->set_rules ( 'req_qun', 'Request Quntity(By Customer)', 'required|numeric' );
		$this->form_validation->set_rules ( 'client_name', 'Client Name', 'trim|required' );
		$this->form_validation->set_rules ( 'cun_quntity', 'Avalable quantity (in your branch)', 'required|numeric' );
	 	$this->form_validation->set_rules ( 'bar_code', 'Bar Code', 'required' );
	 	$this->form_validation->set_rules ( 'quntity', 'quntity', 'required' );
	 	$this->form_validation->set_rules ( 'brand', 'Brand', 'required' );
	 	$this->form_validation->set_rules ( 'discount', 'Discount', 'required' );
		$this->form_validation->set_rules ( 'unit', 'Unit', 'required' );
		$this->form_validation->set_rules ( 'dis_amt', 'Discount Amount', 'required' );
		$this->form_validation->set_rules ( 'sale_price', 'Sale Price', 'required' );
		$this->form_validation->set_rules ( 'total_amount', 'Total Amount', 'required' );
	
		if($this->form_validation->run()==false  ){

			$this->add_dealer();
		}else{   
			 
			$insert_data = array(
				'client_id'	=>	$_POST['client_id'],
				'request_quntity'	=>	$_POST['req_qun'],
				'client_name'	=>	$_POST['client_name'],
				'current_quntity'	=>	$_POST['cun_quntity'],
				'bar_code'	=>	$_POST['bar_code'],
				'total_quntity'	=>	$_POST['quntity'], 
				'brand'	=>	$_POST['brand'],
				'discount'	=>	$_POST['discount'],
				'unit'	=>	$_POST['unit'],
				'discount_amount'	=>	$_POST['dis_amt'],
				'sale_price'	=>	$_POST['sale_price'],
				'total_amount'	=>	$_POST['total_amount'],
				'status_id'	=>	1
			);

			$table = 'stores';
			
			$this->user_model->save_common($table, $insert_data);
			$dealer_id = $this->db->insert_id();
	
			$this->session->set_flashdata("success_message","Quotation added successfully.");
			redirect(base_url('admin/add_dealer'));
		}
	}

	function save_quotation(){
		error_reporting(0);
        //@extract($_POST);
       // $this->form_validation->set_rules ( 'client_id[]', 'Client Id', 'required|numeric' );
        //$this->form_validation->set_rules ( 'client_name[]', 'Client Name', 'trim|required' );
		//$this->form_validation->set_rules ( 'cun_quntity[]', 'Avalable quantity (in your branch)', 'required|numeric' );
	 	///$this->form_validation->set_rules ( 'bar_code[]', 'Bar Code', 'required' );
	 //	$this->form_validation->set_rules ( 'quntity[]', 'quntity', 'required' );
	 //	$this->form_validation->set_rules ( 'discount[]', 'Discount', 'required' );
	//	$this->form_validation->set_rules ( 'dis_amt[]', 'Discount Amount', 'required' );
		//$this->form_validation->set_rules ( 'total_amount[]', 'Total Amount', 'required' );
	
		if($this->form_validation->run()==false  ){

			$this->add_dealer();
		}else{   
			 
			$insert_data = array(
				'client_id'	=>	$_POST['client_id[]'],
				'client_name'	=>	$_POST['client_name[]'],
				'current_quntity'	=>	$_POST['cun_quntity[]'],
				'bar_code'	=>	$_POST['bar_code[]'],
				'total_quntity'	=>	$_POST['quntity[]'], 
				'discount'	=>	$_POST['discount[]'],
				'discount_amount'	=>	$_POST['dis_amt[]'],
				'total_amount'	=>	$_POST['total_amount[]'],
				'description'	=>	$_POST['data_text'],
				'status_id'	=>	0
			);

			$table = 'quotation';
			
			$this->user_model->save_common($table, $insert_data);
	
			$this->session->set_flashdata("success_message","Quotation text added successfully.");
			redirect(base_url('admin/add_dealer'));
		}
	}

	function getSubcat(){
		//print $_REQUEST['category_id'];
		$cat_id=(int)$_POST['category_id'];
		$group_by = '';
		$order_by = 'id';
		$order = 'ASC';
		
		$table = 'product_subcategory';
		$where = array('status_id' => 1,'product_cat_id'=>$cat_id);
		$subcat = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);
		
		if(count($subcat) && is_array($subcat)){
			foreach($subcat AS $k => $v){
				 $subcat_list[$v->id]=$v->name;
			}
			$list='<option value="">-- Sub-category --</option>';
			foreach($subcat_list AS $key=>$val){
					if(count($val) && is_array($val)){
						foreach($val AS $k => $v){
							$list.="<option value=".$k.">$v</option>";
						}
					}else{
						$list.="<option value=".$key.">$val</option>";
					}
			}
			print $list;
		}else{
			print "Subcategory not present";
		}
   }
   
   function getChildcat(){
		$subcat_id=(int)$_POST['subcategory_id'];
		$group_by = '';
		$order_by = 'id';
		$order = 'ASC';
		
		$table = 'product_childcategory';
		$where = array('status_id' => 1,'product_subcat_id'=>$subcat_id);
		$subcat = $this->user_model->get_common($table, $where,'*',2,'',$group_by,$order_by,$order);

		if(count($subcat) && is_array($subcat)){
			foreach($subcat AS $k => $v){
				 $subcat_list[$v->id]=$v->name;
			}
			$list='<option value="">-- Sub-category --</option>';
			foreach($subcat_list AS $key=>$val){
					if(count($val) && is_array($val)){
						foreach($val AS $k => $v){
							$list.="<option value=".$k.">$v</option>";
						}
					}else{
						$list.="<option value=".$key.">$val</option>";
					}
			}
			print $list;
		}else{
			print "Childcategory not present";
		}
	}

	function bindCity(){

		$where = array('status_id' => 1,'state_id' => $_POST['id']);
			
		//$state = $this->user_model->get_common('state', $where,'*',2);
		$city = $this->user_model->get_common('city', $where,'*',2);
		$area = $this->user_model->get_common('pincode', $where,'*',2);
		$data = array('city' => $city,'area' => $area);

		$this->load->view('admin/bindCity', $data);
	} 
	
	public function _alpha_dash_space($str_in = '')
	{
		//if (! preg_match("/^([-a-z0-9_ ])+$/i", $str_in))	
		if (! preg_match("/^([-a-z_ ])+$/i", $str_in))
		{
			$this->form_validation->set_message('_alpha_dash_space', 'The %s field may only contain alpha characters, spaces.');
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}
}

<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->
<style>

	.dashboard-stat .details .number 
	{
		padding-top: 25px;
		text-align: right;
		font-size: 20px;
		line-height: 36px;
		letter-spacing: -1px;
		margin-bottom: 0;
		font-weight: 300;
	}

	.checkbox input[type="checkbox"], .checkbox-inline input[type="checkbox"], .radio input[type="radio"], .radio-inline input[type="radio"] 
	{
		position: absolute;
		margin-left: -10px;
		margin-top: 4px;
	}	
</style>

<script>
 
	function showdiv1()
	{
		$('#display_shop').hide();
		$('#edit_shop').show();
	}


	function showdiv2()
	{
		$('#display_shop').show();
		$('#edit_shop').hide();
	}


	function add_shop()
	{ 		
		$("#shop_form").submit(function(e) 
		{
			if (e.isDefaultPrevented()) 
			{
			} 
			else 
			{
			
				e.preventDefault();
				document.getElementById("btn2").disabled = true;
				var myform = document.getElementById("shop_form");
				var fd = new FormData(myform);
				$.ajax({
					url: '<?php echo base_url("admin/update_shop");?>',
					type: "POST",
					data: fd,
					cache: false,
					processData: false,  // tell jQuery not to process the data
					contentType: false,   // tell jQuery not to set contentType
						success: function (data) 
						{
							alert(data);
							if(data==1){
								alert("Shop Details Updated Successfully..");
							}else{
								alert("Shop Details Not Updated...try again!");
							}
							
							location.reload();
							
						}
				});
			
			}
		});
	}
</script>


<?php 
	$this->db->select('*'); 
	$query = $this->db->get('about_shop_own'); 
	$this->db->where('status', 1);
	$shop_data = $query->result();		
?>
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->
		<h3 class="page-title">
			Dashboard <?php //print_r($shop_data);
			 echo $shop_data[0]->shop_name;?>
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> 
				<a href="<?php echo base_url('admin/dashboard');?>">Home</a>
				<i class="fa fa-angle-right"></i></li>
				<li><span>Dashboard</span></li>
			</ul>
		</div>
		<!-- END PAGE HEADER-->
		<!-- BEGIN DASHBOARD STATS 1-->
		<?php
			if($this->session->flashdata("success_message")!="")
			{
		?>
            <div class="Metronic-alerts alert alert-info fade in">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
				<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
            </div>
		<?php 
			}
			if($this->session->flashdata("error_message")!="")
			{
		?>
            <div class="Metronic-alerts alert alert-danger fade in">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
				<i class="fa-lg fa fa-warning"></i>  
				<?php echo $this->session->flashdata("error_message");?>
            </div>
		<?php 
			}
		?>
		<?php if($_SESSION['profile']->flag == 0){ ?>
			<div class="row">
				<a href="<?= base_url('admin/product')?>" >
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="dashboard-stat red">
						<div class="visual">
							<i class="fa fa-bar-chart-o"></i>
						</div>
						<div class="details">
							<div class="number">
								<span data-counter="counterup" data-value="<?= $total_products->total; ?>">0</span>
							</div>
							<div class="desc">Total Products</div>
						</div>
					</div>
				</div>
				</a>
				
				<a href="<?= base_url('admin/brands')?>" >
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="dashboard-stat red">
						<div class="visual">
							<i class="fa fa-comments"></i>
						</div>
						<div class="details">
							<div class="number">
								<span data-counter="counterup" data-value="<?= $total_brands->total; ?>">0</span>
							</div>
							<div class="desc">Total Brand</div>
						</div>
					</div>
				</div>
				</a>
				
				<a href="<?= base_url('admin/category')?>" >
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="dashboard-stat green">
						<div class="visual">
							<i class="fa fa-globe"></i>
						</div>
						<div class="details">
						<div class="number">
							<span data-counter="counterup" data-value="<?= $total_category->total; ?>"></span>
						</div>
						<div class="desc">Total Category</div>
						</div>
					</div>
				</div>
				</a>
			</div>
		<br>
		<!--table for pending orders-->
		 
		
<div class="row" >
	<div class="col-md-12">
		<!-- BEGIN EXAMPLE TABLE PORTLET-->
		<div class="portlet light ">
			<div class="portlet-title">
				<div class="caption font-dark">
					<i class="fa fa-home"></i> 
					<span class="caption-subject bold uppercase">About</span>
				</div>
			</div>		
  			
			<div class="content-wrapper">
  				<!-- Content Header (Page header) -->

    			<!-- Main content -->
				<section id="section1" class="content">
     				<div class="row">
	  					<div class="col-md-12 ">
          					<div class="box box-warning">
								<div class="box-body">
									<div id="display_shop">
										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div class="col-md-2">
                                   					<label><b>Shop logo:</b></label>
                            					</div>
												<div class="col-md-8">
													<img src="<?=base_url();?>assets/images/<?=$shop_data[0]->logo;?>" height="55px" width="92px" class="img-responsive">
												</div>
                            					<div class="col-md-2">
                                 					<button id="btn1" onclick="showdiv1()" type="button" class="btn btn-warning">Edit</button>
                           						</div>
					  						</div>
										</div>
										<!------------------------------------------------ -->	
										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Shop Number:</b></label>
												</div>
												<div class="col-md-3" id="sid1">
								 	 				<label><?php echo $shop_data[0]->shop_number; ?></label>
												</div>
							 
												<div  class="col-md-2">
													<label><b>Shop Name:</b></label>
												</div>
												
												<div class="col-md-3" id="sn1">
													<label><?php echo $shop_data[0]->shop_name; ?></label> 
												</div>
					  						</div>
										</div>
										<!------------------------------------------------ -->				

										<div style="padding-top:10px;" class="col-md-12">
											<div class="form-group">
												<div class="col-md-2">
													<label><b>Owner name:</b></label>
												</div>
												<div class="col-md-3" id="on1">
								 					<label><?php echo $shop_data[0]->owner_name; ?></label>
												</div>
							
												<div class="col-md-2">
													<label><b>VAT No:</b></label>
												</div>
												<div class="col-md-3" id="gst1">
													<label><?php echo $shop_data[0]->shop_van; ?></label>
												</div> 
											</div>
										</div>	
										<!------------------------------------------------ -->

										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>GST No:</b></label>
												</div>
												<div class="col-md-3" id="gst1">
													<label><?php echo $shop_data[0]->shop_gstno; ?></label>
												</div>
												
												<div  class="col-md-2">
													<label><b>PAN No:</b></label>
												</div>
												<div class="col-md-3" id="gst1">
													<label><?php echo $shop_data[0]->shop_pan; ?></label>
												</div> 
											</div>
										</div>
										<!------------------------------------------------ -->
				 
										<div style="padding-top:10px;" class="col-md-12">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Mobile No:</b></label>
												</div>
												<div class="col-md-3" id="mn1">
													<label><?php echo $shop_data[0]->shop_contact; ?></label>
												</div>
												
												<div  class="col-md-2">
													<label><b>Mobile No:</b>(alternate)</label>
												</div>
												<div class="col-md-3" id="mn1">
													<label><?php if($shop_data[0]->shop_contact1!=""){ echo $shop_data[0]->shop_contact1; }else{echo "-";}?></label>
												</div>
											</div>
										</div>	
										<!------------------------------------------------ -->

										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Mail id:</b></label>
												</div>
												<div class="col-md-3" id="mid1">
													<label><?php echo $shop_data[0]->shop_email; ?></label>
												</div>
												<div  class="col-md-2">
													<label><b>Mail id:</b>(alternate)</label>
												</div>
												<div class="col-md-3" id="mid1">
													<label><?php if($shop_data[0]->shop_email1!=""){ echo $shop_data[0]->shop_email1; }else{echo "-";}?></label>
												</div>
											</div>
										</div>
											<!------------------------------------------------ -->
										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Address:</b></label>
												</div>
												<div class="col-md-3" id="add1">
												<label ><?php echo $shop_data[0]->shop_address; ?> </label>     
												</div>
												<div  class="col-md-2">
													<label><b>Address:</b>(alternate)</label>
												</div>
												<div class="col-md-3" id="add1">
												
												<label ><?php if($shop_data[0]->shop_address1!=""){echo $shop_data[0]->shop_address1; }else{echo "-";}?> </label>
													
												</div>
											</div>
										</div>
										<!------------------------------------------------ -->

										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Website:</b></label>
												</div>
												<div class="col-md-3" id="vatid1">
												<label ><?php echo $shop_data[0]->shop_website; ?></label>      
												</div>
												</div>
											</div>

										<!------------------------------------------------ --> 
										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Bank:</b></label>
												</div>
												<div class="col-md-3" id="vatid1">
												<label ><?php echo $shop_data[0]->bank_name; ?></label>      
												</div>
												<div  class="col-md-2">
													<label><b>Account Name:</b></label>
												</div>
												<div class="col-md-3" id="terms1">
												<label ><?php echo $shop_data[0]->account_name; ?></label>  
												</div> 
											</div>
										</div>
										<!------------------------------------------------ --> 
						
										<div class="col-md-12" style="padding-top:10px">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Account Number:</b></label>
												</div>
												<div class="col-md-3" id="vatid1">
												<label ><?php echo $shop_data[0]->account_number; ?></label>      
												</div>
												<div  class="col-md-2">
													<label><b>IFSC Code:</b></label>
												</div>
												<div class="col-md-3" id="terms1">
												<label ><?php echo $shop_data[0]->ifsc_code; ?></label>     
												</div>
											</div>
										</div>
										<!------------------------------------------------ --> 	
						
										<div class="col-md-12" style="padding-top:10px; margin-bottom: 1%;">
											<div class="form-group">
												<div  class="col-md-2">
													<label><b>Terms & Conditions:</b></label>
												</div>
												<div class="col-md-8" id="terms1">
												<label ><?php echo $shop_data[0]->shop_terms_conditions; ?></label>
													
											</div>
										</div>
									</div>
									<!------------------------------------------------ -->
							</div>
						</div>
			  		</div>
  					</div>
 					</div>
 					</div>
				</section>
			</div>
		</div>
	<!-- END CONTENT BODY -->
	</div>
		
	<?php	} ?>
<!-- END CONTENT -->
 </div>
</div>
</div>


<?php
	$data ['script'] = "dashboard.js";
	$data ['initialize'] = "pageFunctions.init();";
	$this->load->view ( 'admin/_includes/footer', $data );
?> 
<link href="<?php echo assets_path; ?>css/bootstrapValidator.min.css"rel="stylesheet" type="text/css" />   
<script src="<?php echo assets_path;?>js/bootstrapValidator.min.js"></script>
<script>
	var base_url = "<?php echo base_url(); ?>";
	
	$(document).ready(function() 
	{

		$('#shop_form').bootstrapValidator(
		{
			fields: {
				shop_name: 
				{
					validators: 
					{
						notEmpty: 
						{
							message: 'Please Enter shop Name'
						} 
					}
				}, 
			},
			
		}).on('reset', function (event)
		{
			$('#shop_form').data('bootstrapValidator').resetForm();
		});
	
    });
</script>
<?php $this->load->view('admin/_includes/header');?>
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<style>
.toggle-handle {
    position: relative !important;
    margin: 0 auto !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    height: 100% !important;
    width: 0 !important;
    border-width: 0 1px !important;
     
}
.btn-sm {
    line-height: 2.1 !important;
}
 
</style>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Edit Customer
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/customer'); ?>">Customers</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Edit Customer</span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase">  Edit Customer</span>
						</div>
						<div class="actions">
							
								<a href="<?php echo base_url('admin/customer');?>"
									class="btn btn-circle default fa fa-arrow-left">
									Back</a>
						</div>
					</div>
					<div class="portlet-body">
					
							<?php if($this->session->flashdata("success_message")!=""){?>
			                <div class="Metronic-alerts alert alert-info fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
			                </div>
			              <?php }?>
			              <?php if($this->session->flashdata("error_message")!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
			                </div>
			              <?php }?>
			              
			              <?php if(validation_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
			                </div>
			              <?php }?>
			              
			              <?php if( $this->upload->display_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
			                </div>
			              <?php }?>
			              
			             
		              
						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/update_customer');?>"
							method="post" enctype="multipart/form-data">
							<input type="hidden" name="id" value="<?= $customer->id; ?>">
							<div class="form-body">
								<div class="row">
									<div class="col-md-4 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Customer Name</label><span style="color:red">*</span>
											<input  name="name" class="form-control" type="text" maxlength="25"  value="<?= set_value('name',$customer->name); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-2"></div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Contact</label><span style="color:red">*</span>
											<input id="start_time" name="contact" class="form-control" type="number" required value="<?= set_value('contact',$customer->contact); ?>">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Email / Username</label><span style="color:red">*</span>
											<input id="end_time" name="email" class="form-control" type="Email" value="<?= set_value('email',$customer->email); ?>">
										</div>
									</div>
									<div class="col-md-2"></div>

								</div>
								
								<div class="row">
									<div class="col-md-4 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Birth Date</label>
											<input id="birth" name="birth" class="form-control my-datepicker"  type="text" value="<?= set_value('birth',$customer->birth); ?>">
										</div>
									</div>
									<div class="col-md-2"></div>
									<div class="col-md-4 ">
										<div class="form-group">
											<label class="control-label">Anniversary</label>
											<input id="ani" name="ani" class="form-control my-datepicker" type="text" value="<?= set_value('ani',$customer->ani); ?>">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4 col-md-push-1" >
										<div class="form-group">
											<label class="control-label">Country</label><span style="color:red">*</span>
											<input  name="country" class="form-control" maxlength="25" type="text"  value="<?= set_value('country',$customer->country);?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-2"></div>
									<div class="col-md-4 ">
										<div class="form-group">
											<label class="control-label">State</label><span style="color:red">*</span>
											<input id="state" name="state" class="form-control"  type="text" value="<?= set_value('state',$customer->state);?>">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4 col-md-push-1">
										<div class="form-group">
											<label class="control-label">City</label><span style="color:red">*</span>
											<input  name="city" class="form-control" maxlength="25" type="text"  value="<?= set_value('city',$customer->city);?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-2 "></div>
									<div class="col-md-4 ">
										<div class="form-group">
											<label class="control-label">Pincode</label><span style="color:red">*</span>
											<input id="pin" name="pin" class="form-control"  type="number" value="<?= set_value('pin',$customer->pincode);?>">
										</div>
									</div>
								</div>
									
								<div class="row">	
									<div class="col-md-9 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Address</label><span style="color:red">*</span>
											<textarea id="address1" name="address1"  class="form-control" rows="3"><?= set_value('address1',$customer->address1); ?></textarea>
										</div>
									</div>
									<!--<div class="col-md-2"></div>
									<div class="col-md-4 ">
										<div class="form-group">
											<label class="control-label">Address-2</label>
											<textarea id="address2" name="address2"  class="form-control" rows="3"><?= set_value('address2',$customer->address2);?></textarea>
										</div>
									</div>
									</div>-->
								</div>		
									
													 
							<div class="text-center">
								<button type="submit" class="btn blue">
									<i class="fa fa-check"></i> Update
								</button>
								<a type="button" class="btn default" href="<?php echo base_url('admin/customer');?>">Cancel</a>
							</div>
							<!-- <div class="row">
								<div class="col-md-2">
									<button type="submit" class="btn blue"><i class="fa fa-check"></i> Update</button>
								</div>
								<div class="col-md-2">
									<a type="button" class="btn default" href="<?php echo base_url('admin/dealer');?>">Cancel</a>
								</div>
							</div> -->
							</div>
							 
						</form>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<script>
	var base_url = "<?php echo base_url(); ?>";
</script>

<?php
 
$this->load->view ( 'admin/_includes/footer', $data );
?>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script>
	//CKEDITOR.replace( 'editor1' );
	$(".my-datepicker").datepicker({ 
        minDate: 0,
        format: "yyyy-mm-dd",
        changeMonth: true,
        changeYear: true,
		endDate: new Date(),
        yearRange: '-100:0'
    });
</script>
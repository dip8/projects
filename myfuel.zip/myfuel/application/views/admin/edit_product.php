<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->

<link href="<?php echo theme_assets_path; ?>multi-select.css" rel="stylesheet" type="text/css" />
<link href="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />

<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Edit Product
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/product'); ?>">Product</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Edit Product</span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase"> Edit Product</span>
						</div>
						<div class="actions">
							<a href="<?php echo base_url('admin/product');?>" class="btn btn-circle default"> Back</a>
						</div>
					</div>
					<div class="portlet-body">
					
						<?php if($this->session->flashdata("success_message")!=""){?>
						<div class="Metronic-alerts alert alert-info fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
						</div>
					  <?php }?>
					  <?php if($this->session->flashdata("error_message")!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
						</div>
					  <?php }?>
					  
					  <?php if(validation_errors()!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
						</div>
					  <?php }?>
					  
					  <?php if( $this->upload->display_errors()!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
						</div>
					  <?php }?>
			       
						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/update_product_details');?>"
							method="post" enctype="multipart/form-data">
							<input type="hidden" name="id" value="<?= $product[0]->product_id; ?>">
							<input type="hidden" id="subcat_id" value="<?= $product[0]->sub_category ?>" />
							<div class="form-body">
								<div class="row">
									 
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Product Name</label><span style="color:red">*</span>
											<input id="product_name" name="product_name" class="form-control" type="text" value="<?= set_value('product_name', $product[0]->product_name); ?>">
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Product Code</label><span style="color:red"></span>
											<input id="product_code" name="product_code" class="form-control" type="text" value="<?= set_value('product_code', $product[0]->product_code); ?>">
										</div>
									</div>
							 
									<div class="col-md-1">
										<img id="old" src="<?php echo upload_path.'product_profile/'.$product[0]->image; ?>" width="80" height="80" alt="No Image">
										<img id="blah" src="#" style="display:none;" alt="blog image" />
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Product Image </label><span style="color:red">*</span><br>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="image"  onchange="readURL(this);" accept="image/*">
													</span> 
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput" onclick="removeSingleImg()">X</a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
									</div>
								</div>
								
								<div class="row">
				
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Main Category</label><span style="color:red">*</span>
											
											<select id="main_category" name="main_category" class="form-control" onChange="categorysubcatelist(this.value);">
												<option value="">Select</option>
												<?php for($i=0;$i<count($category);$i++){ 
												
												?>
												<option value="<?= $category[$i]->id ?>" <?= set_select("main_category", ".$category[$i]->id.",$product[0]->main_category==$category[$i]->id?true:'');?>><?php echo $category[$i]->name; ?></option>
												<?php } 
                                                   ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Sub Category</label>
											
											<select id="sub_category" name="sub_category" class="form-control" onChange="categorysubcatechildlist(this.value);">
												<option value="">Select</option>
												<?php for($i=0;$i<count($sub_category);$i++){ ?>
												<option value="<?= $sub_category[$i]->id ?>"  <?= set_select("sub_category", ".$sub_category[$i]->id.",$product[0]->sub_category==$sub_category[$i]->id?true:'');?>><?php echo $sub_category[$i]->name; ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group"> 
											<label class="control-label">Brand</label><span style="color:red">*</span>
											
											<select id="brand_category" name="brand_category" class="form-control" >
												<option value="">Select</option>
												<?php for($i=0;$i<count($brand);$i++){ 
												
												?>
												<option value="<?= $brand[$i]->id ?>" <?= set_select("brand_category", ".$brand[$i]->id.",$product[0]->brand_id==$brand[$i]->id?true:'');?>><?php echo $brand[$i]->name; ?></option>
												<?php } 
                                                   ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Price</label><span style="color:red">*</span>
											<input id="price" name="price" class="form-control" type="text" value="<?= set_value('price', $product[0]->price); ?>">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Offer Price</label>
											<input id="offer_price" name="offer_price" class="form-control" type="text" value="<?= set_value('offer_price', $product[0]->offer_price); ?>">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">GST (%)</label><span style="color:red">*</span>
											<select id="gst" name="gst" class="form-control">
											<option <?= set_select("gst",$product[0]->gst); ?> value="0"  <?php if($product[0]->gst==0){ echo 'selected'; } ?> >0</option>
											<option <?= set_select("gst",$product[0]->gst); ?> value="5" <?php if($product[0]->gst==5){ echo 'selected'; } ?> >5</option>
											<option <?= set_select("gst",$product[0]->gst); ?> value="12" <?php if($product[0]->gst==12){ echo 'selected'; } ?> >12</option>
											<option <?= set_select("gst",$product[0]->gst); ?> value="18" <?php if($product[0]->gst==18){ echo 'selected'; } ?> >18</option>
											<option <?= set_select("gst",$product[0]->gst); ?> value="28" <?php if($product[0]->gst==28){ echo 'selected'; } ?> >28</option>
											</select>
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Weight</label><span style="color:red">*</span>
											<input id="weight" name="weight" class="form-control" type="text" value="<?= set_value('weight', $product[0]->weight); ?>">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group"> 
											<label class="control-label">Flavour</label><span style="color:red"> </span>
											
											<select id="flavour_id" name="flavour_id" class="form-control" >
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($flavour);$i++){ ?>
												<option value="<?= $flavour[$i]->id ?>" <?= set_select("flavour", ".$flavour[$i]->id.",$product[0]->flavour==$flavour[$i]->id?true:'');?>><?php echo $flavour[$i]->name; ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Servings</label>
											<input id="servings" name="servings" class="form-control" type="number" min=0 value="<?= set_value('servings', $product[0]->servings); ?>"  >
										</div>
									</div>
									
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Size</label>
											<input id="size" name="size" class="form-control" type="text"  value="<?= set_value('size', $product[0]->size); ?>">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group"> 
											<label class="control-label">Goals</label><span style="color:red"> </span>
											
											<select id="goals_id" name="goals_id" class="form-control" >
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($goals);$i++){ ?>
												<option value="<?= $goals[$i]->id ?>"  <?= set_select("goals", ".$goals[$i]->id.",$product[0]->goals_id==$goals[$i]->id?true:'');?>><?php echo $goals[$i]->name; ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Product Qty</label><span style="color:red">*</span>
											<input id="product_qty" name="product_qty" class="form-control" type="number" min=0 value="<?= set_value('product_qty', $product[0]->quantity); ?>">
										</div>
									</div>
									
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Set Min Product Qty</label>
											<input id="product_minqty" name="product_minqty" class="form-control" type="number" min=0 value="<?= set_value('product_minqty', $product[0]->min_quantity); ?>">
										</div>
									</div>	
									<div class="col-md-3  ">
									 
										<div class="form-group">
											<label class="control-label">Select You May Like Product</label><span style="color:red">  </span>
											<select id="related_product_id" name="related_product_id[]" class="multiselect-ui form-control" multiple="multiple" value="<?= set_value('related_product_id'); ?>" >
											<!--<option value="">Select Product</option>-->
											<?php 
										 $product[0]->stack_with;
										 $stack_with = explode(',', $product[0]->stack_with);
											for($i=0;$i<count($products);$i++){
											?>
											 <option value="<?=$products[$i]->product_id?>" <?php if(in_array($products[$i]->product_id,$stack_with)){ echo 'selected'; } ?>><?=$products[$i]->product_name?></option>
											<?php } ?>
											</select>
										</div>
									</div>
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Free Product</label>
											<input id="free" name="free" type="checkbox" <?php if($product[0]->free_flag == 1){ echo 'checked'; } ?> value="1">
										</div>
									</div>									
									
								</div>
								
								<div class="row" >
									<div class="col-md-4 col-md-push-1"> 
										<img id="old1" src="<?php echo upload_path.'product/'.$product[0]->ingredients_image; ?>" width="50" height="50" alt="No Image" >
										<img id="blah1" src="#" style="display:none;" alt="blog image" />
									 
										<div class="form-group">
											<label class="control-label">Ingredients Image</label><span style="color:red"> </span><br>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												 
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="ingredients_image" onchange="readURL1(this);" accept="image/*">
													</span> 
													
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput" onclick="removeSingleImg1()">X</a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
									</div>
	
									<div class="col-md-4 col-md-push-3">
										<div class="form-group"> 
											<div id="old_gallery">
											<label class="control-label">Product Images</label><span style="color:red"></span><br>
											<?php //print_r($product_image);
												for($i=0;$i<count($product_image);$i++)
												{ ?>
													<div id="" class="col-md-2 ">
													<img src="<?php echo upload_path.'product/'.$product_image[$i]->image_name;?>" width="50" height="50" > 
													</div>
												<?php }  ?>
											</div>
											
											<div class="gallery">

											</div>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> Select Product Images</span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="pfd[]"  multiple id="gallery-photo-add">
													</span>
												<!--	<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput">X</a> -->
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists"  data-dismiss="fileinput" onclick="removeallImg()" >X</a>
												</div>
											</div>
											<span class="help-block"> Maximum 5 </span>
											<span class="help-block"> Allowed file types .jpg, .png </span>
										</div>
									</div>
							 
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Key Highlights</label>
											<textarea id="key_highlights" name="key_highlights" class="editor1 form-control" rows="7"><?= set_value('key_highlights',$product[0]->key_highlights); ?></textarea>
										</div>
									</div>
									
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Product Description</label>
											<textarea id="product_desc" name="product_desc" class="editor1 form-control" rows="7"><?= set_value('product_desc',$product[0]->description ); ?></textarea>
										</div>
										
										<div class="form-group">
										<img id="old2" src="<?php echo upload_path.'product/'.$product[0]->description_image; ?>" width="50" height="50" alt="No Image" >
										<img id="blah2" src="#" style="display:none;" alt="blog image" />
									 
										<div class="form-group">
											<label class="control-label">Description Image</label><span style="color:red"> </span><br>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												 
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="description_image" onchange="readURL2(this);" accept="image/*">
													</span> 
													
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput" onclick="removeSingleImg2()">X</a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
										</div>
									 
									</div>
									
									<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Benefits</label>
											<textarea id="benefits" name="benefits" class="editor1 form-control" rows="7"><?= set_value('benefits',$product[0]->benefits); ?></textarea>
										</div>
										
										<div class="form-group">
										<img id="old3" src="<?php echo upload_path.'product/'.$product[0]->benefits_image; ?>" width="50" height="50" alt="No Image">
										<img id="blah3" src="#" style="display:none;" alt="blog image" />
									 
										<div class="form-group">
											<label class="control-label">Benefits Image</label><span style="color:red"> </span><br>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												 
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="benefits_image" onchange="readURL3(this);" accept="image/*">
													</span> 
													
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput" onclick="removeSingleImg3()">X</a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
										</div>
									</div>
									
                                  	<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">How To Use</label>
											<textarea id="how_to_use" name="how_to_use" class="editor1 form-control" rows="7"><?= set_value('how_to_use',$product[0]->how_to_use ); ?></textarea>
										</div>
										
										<div class="form-group">
										<img id="old4" src="<?php echo upload_path.'product/'.$product[0]->how_to_use_image; ?>" width="50" height="50" alt="No Image">
										<img id="blah4" src="#" style="display:none;" alt="blog image" />
									 
										<div class="form-group">
											<label class="control-label">How To Use Image</label><span style="color:red"> </span><br>
											<div class="fileinput fileinput-new"
												data-provides="fileinput">
												 
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="how_to_use_image" onchange="readURL4(this);" accept="image/*">
													</span> 
													
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput" onclick="removeSingleImg4()">X</a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
										</div>
									</div>
									
                                  <!--	<div class="col-md-12">
										<div class="form-group">
											<label class="control-label">Stack With</label>
											<textarea id="stack_with" name="stack_with" class="editor1 form-control" rows="5"><?= set_value('stack_with',$product[0]->stack_with); ?></textarea>
										</div>
									</div>
									-->
								</div>
							</div>
					
						<?php 
						if($product[0]->sub_category==1 || $product[0]->sub_category==6){ 
							$class='display:block';
							$classc='display:block';
						}else{
							$class='display:none';
							$classc='display:none';
							
							if($product[0]->sub_category==2){ 
							$classc='display:block';
							}else{
								$classc='display:none';
							}
						}
						
						?>

							<hr>
							<div class="form-actions text-center">
								<button type="submit" class="btn blue">
									<i class="fa fa-check"></i> Update
								</button>
								<a type="button" class="btn default" href="<?php echo base_url('admin/product');?>">Cancel</a>
							</div>
						</form>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<?php
//$data ['script'] = "payments.js";
//$data ['initialize'] = "pageFunctions.init();";
$this->load->view ( 'admin/_includes/footer', $data );
?>
<script src="<?php echo theme_assets_path; ?>multi-select.js" type="text/javascript"></script>
<script src="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/js/bootstrap-select.min.js"></script>

<script>
$(document).ready(function(){
           $('.editor1').wysihtml5();
    });
$(document).ready(function() {
	var selectid=$('#subcat_id').val();
	categorysubcatechildlist(selectid);
	//alert(selectid);
});
	function categorysubcatelist(cat_id){

		var url="<?php echo base_url.'admin/getSubcat/';?>";	
		$("#sub_category").load(url,{'category_id':cat_id},function(res){
			//alert(res);	
		});
		
	}
	
	function categorysubcatechildlist(subcat_id){

		/* var url="<?php echo base_url.'admin/getChildcat/';?>";	
		$("#child_category").load(url,{'subcategory_id':subcat_id},function(res){
			//alert(res);	
		}); */

		if(subcat_id==6){
			$('#product_child_div').show();
			$('#product_type_div').show();
			$('#product_color_div').show();
		}else{
			$('#product_child_div').hide();
			$('#product_type_div').hide();
			$('#product_color_div').hide();
		}
		
		if(subcat_id==2 || subcat_id==3){
			//$('#product_type_div').show();
			$('#product_color_div').show();
			//$('#product_child_div').show();
		}else{
			//$('#product_type_div').hide();
			//$('#product_color_div').hide();
			//$('#product_child_div').hide();
		} 
		
		if(subcat_id==1){
			$('#product_child_div').show();
			$('#product_type_div').hide();
			$('#product_color_div').show();
		}else{
			/* $('#product_child_div').hide();
			$('#product_type_div').show();
			$('#product_color_div').hide(); */
		}
		
	}
	
	function readURL(input) {
		
        if (input.files && input.files[0]) {
			$('#blah').show();
			$('#old').hide();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(78)
                    .height(80);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function removeSingleImg(){
		$('#blah').hide();
		$('#old').show();
	}
	
	function readURL1(input) {
		
        if (input.files && input.files[0]) {
			$('#old1').hide();
			$('#blah1').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah1')
                    .attr('src', e.target.result)
                    .width(58)
                    .height(60);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function removeSingleImg1(){
		$('#blah1').hide();
		$('#old1').show();
	}
		
	function readURL2(input) {
		
        if (input.files && input.files[0]) {
			$('#old2').hide();
			$('#blah2').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah2')
                    .attr('src', e.target.result)
                    .width(58)
                    .height(60);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function removeSingleImg2(){
		$('#blah2').hide();
		$('#old2').show();
	}
		
	function readURL3(input) {
		
        if (input.files && input.files[0]) {
			$('#old3').hide();
			$('#blah3').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah3')
                    .attr('src', e.target.result)
                    .width(58)
                    .height(60);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function removeSingleImg3(){
		$('#blah3').hide();
		$('#old3').show();
	}
		
	function readURL4(input) {
		
        if (input.files && input.files[0]) {
			$('#old4').hide();
			$('#blah4').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah4')
                    .attr('src', e.target.result)
                    .width(58)
                    .height(60);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function removeSingleImg4(){
		$('#blah4').hide();
		$('#old4').show();
	}
	
	$(function() {
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;
			if($("#gallery-photo-add")[0].files.length > 5)
			{
				cnt = 5;
			}else{
				cnt = filesAmount;
			}
            for (i = 0; i < cnt; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {
                    $($.parseHTML('<img width="60" height="50" style="padding: 5px;">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#gallery-photo-add').on('change', function() {
		if ($("#gallery-photo-add")[0].files.length > 5) {
			alert("You can select only 5 images");
			imagesPreview(this, 'div.gallery');
			$('#old_gallery').hide();
		} else {
			imagesPreview(this, 'div.gallery');
			$('#old_gallery').hide();
		}
    });
	});
	
	function removeallImg(){
		$('.gallery').html('');
		//$('#old_gallery').style();
		$('#old_gallery').show();
	}
</script>
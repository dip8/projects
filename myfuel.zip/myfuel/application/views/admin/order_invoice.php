<?php error_reporting(0); ?> 
<style type="text/css" media="print">
@media print {
 .gstclass td{
	padding: 0px; margin: 0px; line-height: 0px;
}

}
 .gstclass td{
	padding: 1px !important;
	 margin: 1px !important; 
	 line-height: 1px !important;
	font-size: 9px !important;
}
</style>
	<div id="printableArea">
	 <table width="100%" >
		<h4 class="myheading" style="text-align:center;"><b>GST INVOICE</b></h4>
	</table>
	<div  id="invoice-template" class="card-body">
	
		<!-- Invoice Company Details -->
	<div style="border:1px solid black; font-size: 12px;">
		<table width="100%" >
		 <tbody style="line-height: 15px;">
			<tr style="border-bottom: 1px solid black;">
				 
				<td style="border-right: 1px solid black; border-bottom: 1px solid black;padding: 15px; width: 50%;">
				<?php echo "<b>".$about_shop->shop_name."</b><br>".$about_shop->shop_number.",".$about_shop->shop_address;?><br>
				  Contact No: <?php echo $about_shop->shop_contact;?><br>
				  Email: <?php echo $about_shop->shop_email;?><br>
				  GST No: <?php echo $about_shop->shop_gstno; ?> 
				</td>
				
				<td style=" border-bottom: 1px solid black; padding: 15px;width: 50%;" >
					Invoive No: <b> #<?php echo $invoice_nom;?></b><br>
					Invoive Date: <b> <?php echo date('d-m-Y');?></b><br><hr style="margin: 5px 0px;border: 1px solid #ecebeb;">
					Order No: <b> #<?php echo $order_no;?></b><br>
					Order Date: <b> <?php echo $tbl_order->order_date;?></b><br><hr style="margin: 5px 0px;border: 1px solid #ecebeb;">
			
					Docket No: <b> <?php echo $docket_no;?></b><br>
					Docket Date: <b> <?php echo $docket_date;?></b><br>
					Trasnsport: <b> <?php echo $medium;?></b><br>
				</td>
				   
			</tr> 
		<!--/ Invoice Company Details -->

		<!-- Invoice Customer Details -->
		 <tr>
		<td style="padding: 15px; width: 40%;">
				<b>Customer Info: </b><br>
				Name : <?php  echo $print_customer->name; ?><br>
				Mobile No: <?php  echo $print_customer->contact;?>
			</td>
			<td style="padding: 15px; width: 60%;">
				Email-Id: <?php  echo $print_customer->email?><br>
				Address:  <?php  echo $print_customer->address1.', '.$print_customer->city.', '.$print_customer->pin_code.', '.$print_customer->state;?><br>
				<?php if($print_customer->gst!=""){ ?>GST No: <?php  echo $print_customer->gst; } ?><br> 
			</td>
            <!--<td style="padding: 15px; width: 20%;">
			   <br>
				Delivered By :  <?php  //echo $print_customer['employee_name'];?> 
			</td>-->                    
			</tr> 
		 </tbody>  
		 </table>     
		<!--/ Invoice Customer Details -->

		<!-- Invoice Items Details -->
		 <table  border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse;" width="100%">
				<thead>
				<tr>
					<th class="text-center" style="border:1px solid black;">Sr</th>
					<th style="border:1px solid black;" class="text-center">Qty</th>
					<th style="border:1px solid black;" class="text-center">Pack</th>
					<th style="border:1px solid black;" class="text-center">Product Name</th>
					<th style="border:1px solid black;" class="text-center">Batch No</th>
					<th style="border:1px solid black;" class="text-center">HSN No</th>
					
					<th style="border:1px solid black;" class="text-center">Rate</th>
					<th style="border:1px solid black;" class="text-center">Discount</th>	
					<!--<th style="border:1px solid black;" class="text-center">Price</th>-->	
					<th style="border:1px solid black;" class="text-center">GST (%)</th>					
					<th style="border:1px solid black;" class="text-center">Amount</th>
				</tr>
				</thead>
				
				<tbody>
					<?php  
					/*$offer_id = $order_total['offer_id'];
					//$product_id = $order_total['product_id'];
					//$launch_offer = $order_total['launch_offer'];
					//$get_delivery = $order_total['get_delivery'];
					$total_qty = $order_total['total_qty'];
					$total_amount = $order_total['total_amount'];
					$total_gst_amount = $order_total['total_gst_amount'];
					$total_disc_amount = $order_total['total_disc_amount'];
					$coupon_discount_amt = $order_total['coupon_discount_amt'];
					$coupon_discount_per = $order_total['coupon_discount_per'];
					$coupon_code = $order_total['coupon_code'];
					$final_total_amount = $order_total['final_total_amount'];
					*/
					$counter=0;	
					$quantity=0;	
					$actual_price=0;	
					$price=0;	
					$total=0;	
					$gst_amount=0;	
					$mrp_total_t =0;
					$mrp_total_amount =0;
					$sell_total_amount =0;
					 $total_qty=0;
					 $mrp_total_amount=0;
						$total_disc_amount=0;
						$total_gst_amount=0;
						$total_total_amt=0;
				 
					foreach ($print_product as $temp_product){
						  
						$product_id = $temp_product['product_id'];
						$product_name = $temp_product['product_name'];
						$batch_no = $temp_product['batch_no'];
						$hsn_no = $temp_product['hsn_no'];
						$product_image = $temp_product['product_image'];
						$quantity = $temp_product['quantity'];
						$actual_price = $temp_product['actual_price'];
						$price = $temp_product['price'];
						$unit_cost = $temp_product['unit_cost'];
						$gst = $temp_product['gst'];
						$gst_amount = $temp_product['gst_amount']; 
						$disc_amount = $temp_product['disc_amount']; 
						$total = $temp_product['total'];
						$taxable_amt = $temp_product['taxable_amt'];
						$hsn_no = $temp_product['hsn_no'];
						$unit = $temp_product['unit'];

						$referee_disc = $temp_product['referee_disc'];
						$class_disc = $temp_product['class_disc'];
						$coupon_disc = $temp_product['coupon_disc'];
						
						$discount=$referee_disc+$class_disc+$coupon_disc;

						$total_qty+=$quantity;
						$mrp_total_amount+=$unit_cost;
						$total_disc_amount+=$discount;
						$total_gst_amount+=$gst_amount;
						$total_total_amt+=$taxable_amt;


						 
						if($product_id1==27 || $product_id1==28){
							$quantity = 10;
							$total_qty = 10;
						}else if($product_id1==29 || $product_id1==30){
							$quantity = 20;
							$total_qty = 20;
						}
					  ?>
					<tr>
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						   <?php echo ++$counter ;?>
						</td>

						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $quantity;?>  
						</td>
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $unit;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black; width: 300px;border-bottom: 1px solid #e8e8e8;">
						 <p><?php echo $product_name; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						 <p><?php echo $batch_no; ?></p>
						</td>
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						 <p><?php echo $hsn_no; ?></p>
						</td>

						
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $unit_cost; ?>
						</td>
						
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $discount; ?>
						</td>
						
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $gst_amount.' ('.$gst.'%)'; ?>
						</td>
						
						<!--<td style="text-align:center; border:1px solid black;">
						  <?php echo $price; ?>
						</td>-->
						
						<td style="text-align:center; border:1px solid black;border-bottom: 1px solid #e8e8e8;">
						  <?php echo $taxable_amt; ?>
						</td>
						
						 		
					</tr> 
				<?php } ?> 
				<tr style="border-top: 1px solid #e8e8e8;">
					<td height="50"style="border-top: 1px solid #e8e8e8; "></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8; "></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
					<td height="50"style="border-top: 1px solid #e8e8e8;"></td>
				</tr>
						 
					<tr style="height:<?php if($counter==1){ echo '80px';}else if($counter==2){ echo '70px';}else if($counter==3){ echo '60px';}else if($counter==4){ echo '50px';}else if($counter==5){ echo '40px';}else if($counter==6){ echo '30px';}else{ echo '20px';} ?>" >                                            
						<td style="text-align:center;border:none;"></td> 
						<td style="text-align:center; border:1px solid black;"><b><?php echo $total_qty; ?></b></td>
						
						<td style="text-align:center;border:none;"></td> 
					    <td style="text-align:center;border:1px solid black;">
					      	<p><b>Total</b></p>
					    </td>  
						<td style="text-align:center;border:none;"></td> 
						<td style="text-align:center;border:none;"></td> 
					    <td style="text-align:center; border:1px solid black;"><b><?php echo $mrp_total_amount; ?></b></td>
					    <td style="text-align:center;border:1px solid black;"><b><?php echo $total_disc_amount;?> </b></td>
						<td style="text-align:center;border:1px solid black;"><b><?php echo $total_gst_amount;?> </b></td>
						<!--<td style="text-align:center;border:1px solid black;"><b><?php echo $sell_total_amount;?> </b></td>-->
					    <td style="text-align:center; border:1px solid black;"><b><?php echo $total_total_amt; ?></b></td>   
					</tr> 
 
			   </tbody>     
			</table>
		   <br>
		    <table class="gstclass" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse;" width="100%">
				<thead style="line-height: 15px;">
				<tr>
					<th class="text-center" style="border:1px solid black;">Class</th>
					<!--<th style="border:1px solid black;border-collapse: collapse;" class="text-center">Total</th> 
					<th style="border:1px solid black;border-collapse: collapse;" class="text-center">Discount</th>-->
					<th style="border:1px solid black;border-collapse: collapse;" class="text-center"><?php if($print_customer->state=="Maharashtra"){ echo "SGST";} else{ echo "IGST";}?> </th>
					<th style="border:1px solid black;border-collapse: collapse;" class="text-center">CGST</th>
					<th style="border:1px solid black;border-collapse: collapse;" class="text-center">Total GST</th>
					<th style="border:1px solid black;border-bottom: solid 1px #FFF;border-collapse: collapse;" class="text-center"> </th> 				
					<th style="border:1px solid black;border-bottom: solid 1px #FFF;border-collapse: collapse;" class="text-center"> </th> 				
				
					 
				</tr>
				</thead>
				<?php
					 

					$gst5=0.0;
					$gst12=0.0;
					$gst18=0.0;
					$gst28=0.0;
					$disc_amount5=0.0;
					$disc_amount12=0.0;
					$disc_amount18=0.0;
					$disc_amount28=0.0;
					 
					for($i=0;$i<$counter;$i++){
						$gst = $print_product[$i]['gst'];
						    
					if($gst==5){
						  $gst5+=$print_product[$i]['gst_amount'];
						$disc_amount5+= $print_product[$i]['coupon_disc']+ $print_product[$i]['referee_disc']+$print_product[$i]['class_disc'];
					}	 if($gst==12){
						  $gst12+=$print_product[$i]['gst_amount'];
						$disc_amount12+= $print_product[$i]['coupon_disc']+ $print_product[$i]['referee_disc']+$print_product[$i]['class_disc'];
					}	 if($gst==18){
						  $gst18+=$print_product[$i]['gst_amount'];
						  $disc_amount18+= $print_product[$i]['coupon_disc']+ $print_product[$i]['referee_disc']+$print_product[$i]['class_disc'];
					}	 if($gst==28){
						  $gst28+=$print_product[$i]['gst_amount'];
						$disc_amount28+= $$print_product[$i]['coupon_disc']+ $print_product[$i]['referee_disc']+$print_product[$i]['class_disc']; 
					}

					$gst_total+=$gst5+$gst12+$gst18+$gst28;
					$total_disc+=$disc_amount5+$disc_amount12+$disc_amount18+$disc_amount28;

					}
					//print_r($print_product[0]['gst']);
				 
					$gstt=$gst5+$gst12+$gst18+$gst28;
				  ?>
				  <tbody  style="line-height: 15px;"> 
					<tr height="12px" >
						<td height="12px" style="text-align:center; border:1px solid black;border-collapse: collapse; padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo "GST 5.00 %" ;?>
						</td>
						<!--<td style="text-align:center; border:1px solid black;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo $gst5+$disc_amount5 ;?>
						</td>

						<td style="text-align:center; border:1px solid black;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $disc_amount5;?>  
						</td>-->
						<td style="text-align:center; border:1px solid black;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $gst5/2;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst5/2; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst5; ?></p>
						</td>
					   	<td style="text-align:center; border:1px solid black;border-bottom: solid 1px #FFF;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 11pxs;"> Total Item : <?=$counter?></td>
						 
							<th style="border:1px solid black;border-bottom: solid 1px #FFF;border-collapse: collapse;padding: 1px; margin: 1px; line-height: 1px;font-size: 12px;" class="text-center">Total    :   <?=$total_total_amt?></th>
						
					 </tr>

					 <tr>
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo "GST 12.00 %" ;?>
						</td>
						<!--<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo $gst12+$disc_amount12 ;?>
						</td>

						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $disc_amount12;?>  
						</td>-->
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $gst12/2;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst12/2; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst12; ?></p>
						</td>
					   	<td style="text-align:center; border:1px solid black;border-bottom: solid 1px #FFF;padding: 1px; margin: 1px; line-height: 1px;font-size: 11px;"> Total Qty : <?=$total_qty?></td> 
					 <td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;"> </td>
						
					 </tr>

					 <tr>
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo "GST 18.00 %" ;?>
						</td>
						<!--<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo $gst18+$disc_amount18 ;?>
						</td>

						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $disc_amount18;?>  
						</td>-->
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $gst18/2;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black; padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst18/2; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst18; ?></p>
						</td>
					   	<td style="text-align:center; border:1px solid black;border-bottom: solid 1px #FFF;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;"> </td>
						  
						 <td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 11px;">SGST : <?=$total_gst_amount/2?> </td>
					 </tr>

					 <tr>
						<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo "GST 28.00 %" ;?>
						</td>
						<!--<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo $gst28+$disc_amount28 ;?>
						</td>

						<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $disc_amount28;?>  
						</td>-->
						<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $gst28/2;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black; padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst28/2; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gst28; ?></p>
						</td>
						<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;"> </td> 
					   	<td style="text-align:center; border:1px solid black;padding: 0px;padding: 1px; margin: 1px; line-height: 1px;font-size: 11px;"> CGST : <?=$total_gst_amount/2?></td>
						
						
					 </tr>
					 <tr>
						<th style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   Total
						</th>
						<!--<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						   <?php echo $gst_total+$total_disc ;?>
						</td>

						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $total_disc;?>  
						</td>-->
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						  <?php echo $gstt/2;?>  
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px; ">
						 <p><?php echo $gstt/2; ?></p>
						</td>
						
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;">
						 <p><?php echo $gstt; ?></p>
						</td> 
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;"> </td> 
						<td style="text-align:center; border:1px solid black;padding: 1px; margin: 1px; line-height: 1px;font-size: 9px;"> </td> 
						
						
					 </tr>
				 
				 </tbody>

			</table>
   
			<table  width="100%">
				<tbody style="line-height: 15px;" >    
					<tr>
					<?php if($launch_offer==1){ ?>
						<td style="padding: 10px;">
						  <?php if($product_id1==27 || $product_id1==28){ ?>
						  <b>FREE 1 Year Premium GYM Membership </b>(for 1 person)  
						  <?php }if($product_id1==29 || $product_id1==30){  ?>	    
						  <b>FREE 1 Year Premium GYM Membership for Couple </b>(or 2 persons)  
						  <?php } ?>	
						</td>
						 
					<?php } ?>	
					<td style="padding: 10px;"></td>					
					<td style="padding: 10px;"></td>					
					</tr>				
					<tr>
						<td style="padding: 10px;">
						 Amount Chargeable &nbsp;(in words):<br>
						<b><?php echo ucfirst(convertNumber($total_total_amt+$total_gst_amount));?>  Rupees only</b>       
						</td>
						 <td style="padding: 10px;"></td>	
						 <td style="padding: 10px;"></td>	
						  
					</tr>
				   <tr>
						<td style="padding: 15px;border-top: 1px solid black;border-right: 1px solid black;">
					 <?php  if($launch_offer==1){ ?>
					 <b>GET Delivery On : </b>
							<?php 
							if($get_delivery==1) { 
							echo $get_delivery = 'Monthly';
							}else if($get_delivery==2) {
							echo $get_delivery = 'Quarterly';
							}else if($get_delivery==3) {	
							echo $get_delivery = 'One Time Delivery';
							}
							?>
					 
					<?php  } ?>	
							<b>Terms & Conditions: </b><br>
							<p><?php $data1=nl2br($about_shop->shop_terms_conditions); echo $data1;?><p>
						</td>
						<td style="padding: 15px;border-top: 1px solid black;border-right: 1px solid black;">
						  <p style="margin-top: 7%;  font-size:12px; text-align: center;" >For <?php echo strtoupper($about_shop->shop_name);?><br> -&nbsp; Authorized Signature</p> 
						</td>
						<td style="text-align: end; padding: 10px;border-top: 1px solid black;background: #e8e8e8;">
								<?php if($coupon_discount_amt > 0){ ?>
								Coupon Discount : <b><?php echo $coupon_discount_amt.' ('.$coupon_discount_per.' %)'; ?> </b>
								<?php } ?>
			             	   <br>
					   			Grand Total : <b><?php echo round($total_total_amt+$total_gst_amount); ?><?php if(($launch_offer==1) &&	 ($product_id1==27 || $product_id1==28|| $product_id1==29|| $product_id1==30)){ echo ' (including all taxes)'; }?></b>
						 </td>	
					</tr> 
				</tbody>          
			</table>
	 
		 

	</div>
   </div>
	<p style="text-align:center;margin-bottom: 0rem;font-size:12px;">This is computer generated Order Receipt </p>
	</div>
		
	
        
	
        
 <?php
function convertNumber($number) {
  $no = round($number);
  $decimal = round($number - ($no = floor($number)), 2) * 100;   
  $digits_length = strlen($no);    
  $i = 0;
  $str = array();
  $words = array(
   0 => '',
   1 => 'One',
   2 => 'Two',
   3 => 'Three',
   4 => 'Four',
   5 => 'Five',
   6 => 'Six',
   7 => 'Seven',
   8 => 'Eight',
   9 => 'Nine',
   10 => 'Ten',
   11 => 'Eleven',
   12 => 'Twelve',
   13 => 'Thirteen',
   14 => 'Fourteen',
   15 => 'Fifteen',
   16 => 'Sixteen',
   17 => 'Seventeen',
   18 => 'Eighteen',
   19 => 'Nineteen',
   20 => 'Twenty',
   30 => 'Thirty',
   40 => 'Forty',
   50 => 'Fifty',
   60 => 'Sixty',
   70 => 'Seventy',
   80 => 'Eighty',
   90 => 'Ninety');
  $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
  while ($i < $digits_length) {
   $divider = ($i == 2) ? 10 : 100;
   $number = floor($no % $divider);
   $no = floor($no / $divider);
   $i += $divider == 10 ? 1 : 2;
   if ($number) {
    $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
    $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
   } else {
    $str [] = null;
   }  
  }
  
  
  $Rupees = implode(' ', array_reverse($str));
  if($decimal>0){
	  $first_dec = substr($decimal, 0, 1);
	  $second_dec = substr($decimal, 1, 1);
	  
	  $paise = ($decimal < 20) ? "And " . ($words[$decimal - $decimal%1]) ." " .($words[$decimal%1])  : "And " . ($words[$decimal - $decimal%10]) ." " .($words[$second_dec]);
	}
  //return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Paise Only";
  return ($Rupees ? $Rupees : '');
 }
?>
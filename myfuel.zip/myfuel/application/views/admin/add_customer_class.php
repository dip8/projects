<?php $this->load->view('admin/_includes/header');?>

<link href="<?php echo theme_assets_path; ?>multi-select.css" rel="stylesheet" type="text/css" />
<link href="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />
<style>
	.multiselect-container{
		height: 300px;
	    overflow: auto;
	    width: 320px;
	}
</style>

<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Customer Class
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/customer'); ?>">Customers</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Add Customer Class</span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase"> Add Customer Class</span>
						</div>
					<div class="actions">
						<a href="<?php echo base_url('admin/customer');?>" class="btn btn-circle default"> Back </a>
						</div> 
					</div>
					<div class="portlet-body">
					
						<?php if($this->session->flashdata("success_message")!=""){?>
						<div class="Metronic-alerts alert alert-info fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
						</div>
					  <?php }?>
					  <?php if($this->session->flashdata("error_message")!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
						</div>
					  <?php }?>
					  
					  <?php if(validation_errors()!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
						</div>
					  <?php }?>
					  
					  <?php if( $this->upload->display_errors()!=""){?>
						<div
							class="Metronic-alerts alert alert-danger fade in">
							<button type="button" class="close" data-dismiss="alert"
								aria-hidden="true"></button>
							<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
						</div>
					  <?php }?>

						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/save_customer_class');?>" method="post" enctype="multipart/form-data">
							<div class="form-body">
								<div class="row">
									<div class="col-md-6 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Class Name</label><span style="color:red">*</span>
											<input id="class_name" name="class_name" class="form-control" autocomplete="off"  type="text" value="<?= set_value('class_name'); ?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-3 col-md-push-1">
										<label class="control-label">Discount On</label><span style="color:red">*</span>
									</div>	
									<div class="col-md-4">
										<label class="radio-inline"> 
											<input type="radio" name="discount_on" onclick="handleClick(this);" checked value="1"> Whole Order
										</label>
									 
										<label class="radio-inline"> 
											<input type="radio" name="discount_on" onclick="handleClick(this);" value="2"> Particular Products
										</label>
									</div>
									<br><br>
								</div>

								<div class="row" id="discount_on_div" style="display: none;">
									<div class="col-md-12">
									<div class="col-md-4 col-md-push-4">
										<div class="form-group">
											<label class="control-label">Select Product</label><span style="color:red">  </span>
											<select id="product" name="product[]" class="multiselect-ui form-control" multiple="multiple" onchange="selectProduct(this.value)" value="<?= set_value('product'); ?>"  >
											<!--<option value="">Select Product</option>-->
											<?php 
											
											for($i=0;$i<count($products);$i++){
											?>
											 <option value="<?=$products[$i]->product_id?>" title="<?=$products[$i]->product_name?>" ><?=$products[$i]->product_name?></option>
											<?php } ?>
											</select>
										</div>
									</div>
									</div>

									<div class="col-md-12">
									<div class="col-md-12 selectproductdiv" id="selectproductdiv">
									<div class="col-md-12 table table-responsive">
										<table class="table table-responsive table-striped table-bordered">
										<thead>
											<tr>
												<td><strong>Sr No.</strong></td>
												<td style="width:50%"><strong>Product Name</strong></td>
												<!--<td><strong>MRP Price</strong></td>-->
												<td><strong>Discount In</strong></td>
												<td><strong>Discount</strong></td>
												<td><strong>Remove</strong></td>
											</tr>
										</thead>
										</table>
									</div>
					 				</div>
									</div>
								</div>	

								<div class="row" id="discount_in_div">
									<div class="col-md-3 col-md-push-1">
										<label class="control-label">Discount In</label><span style="color:red">*</span>
									</div>	
									<div class="col-md-3">
										<label class="radio-inline"> 
											<input type="radio" name="discount_in" onclick="handleClick1(this);" checked value="1"> Percent(%)
										</label>

										<label class="radio-inline"> 
											<input type="radio" name="discount_in" onclick="handleClick1(this);" value="2"> Rupees
										</label>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Discount</label><span style="color:red">*</span>
											<input id="price" name="udist" class="form-control" type="number" min="0" step="0.01" value="<?= set_value('udist'); ?>">
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-10 col-md-push-1">
										<div class="form-group">
											<label class="control-label">Note</label>
											<textarea id="note" name="note" class="editor1 form-control" rows="6"><?= set_value('note'); ?></textarea>
										</div>
									</div>
								</div>

								<div class="form-actions text-center">
									<button type="submit" class="btn blue">
										<i class="fa fa-share-square-o"></i> Submit
									</button>
									<a type="button" class="btn default" href="<?php echo base_url('admin/customer');?>">Cancel</a>
								</div>
							</div>
						</form>
						
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase">Customer Classes</span>
						</div>
						
					</div>
					<div class="portlet-body">
							 
						<table class="table table-striped table-bordered table-hover table-checkable order-column" id="managed_datatable" data-page-length='10'>
							<thead>
								<tr>
									<th>Sr.No.</th>
									<th>Class Name</th>
									<th>Discount On</th>
									<th>Discount In</th>
									<th>Discount</th>
									<th>Customers In Class</th>
									<th>View Details</th>
									<th>Status</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php for($i=0;$i<count($discount);$i++){ 
								$table = 'customer';
								$where = array('class_id'=>$discount[$i]->id);
								$order_cnt = $this->user_model->record_count($table, $where);

								if($discount[$i]->discount_on == 1){
									$discount_on = 'Whole Order';
									$discountp = $discount[$i]->discount;
								}else{
									$discount_on = 'Particular Product';
									$discountp = '-';
								}
								if($discount[$i]->discount_in == 0){
									$discount_in = '-';
								}else if($discount[$i]->discount_in == 1){
									$discount_in = 'Percent (%)';
								}else{
									$discount_in = 'Rupees';
								}
								?>
								
									<tr class="odd gradeX">
										<td><?= $i+1; ?></td>
										<td><?= $discount[$i]->class_name; ?></td>
										<td><?= $discount_on; ?></td>
										<td><?= $discount_in; ?></td>
										<td><?= $discountp; ?></td>
										<td><?php if($order_cnt > 0){ ?><a href="javascript:void(0);" onclick="customer_in_class(<?= $discount[$i]->id; ?>)" class="btn default btn-xs blue-sharp-stripe"> View Customers (<?= $order_cnt; ?>) </a> <?php } ?> </td>
										<td>
					                    	<a href="javascript:void(0);" onclick="view_details(<?= $discount[$i]->id; ?>)" class="btn default btn-xs blue-sharp-stripe"> Details </a>
					                    </td>	
					                    <td> <?php if($discount[$i]->status == 1) { echo 'Active'; }
											else if($discount[$i]->status == 2) {	echo 'Inactive'; } ?></td>
					                    <td>
						                    <?php if($discount[$i]->status == 1){ ?>
				                    			<a href="<?= base_url('admin/update_customer_class/2/'.$discount[$i]->id); ?>" class="btn default btn-xs yellow-gold-stripe"
				                    				onclick="if(!confirm('Are you sure to make inactive?')) return false;"> Inactive </a>
												
											<?php }else if($discount[$i]->status == 2){ ?>
												<a href="<?= base_url('admin/update_customer_class/1/'.$discount[$i]->id); ?>" class="btn default btn-xs green-meadow-stripe"
													onclick="if(!confirm('Are you sure to make active?')) return false;"> Active </a>
											<?php } ?>
												<a href="<?php echo base_url('admin/edit_customer_class/'.$discount[$i]->id) ;?>" class="btn default btn-xs purple-stripe">Edit </a>
												<a href="<?php echo base_url('admin/update_customer_class/0/'.$discount[$i]->id) ;?>" class="btn default btn-xs red-soft-stripe" onclick="if(!confirm('Are you sure to delete ?')) return false;">Delete </a>
										</td>
									</tr>
								<?php } ?>
					        </tbody>
						</table>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<!--view details_popup-->
	<div class="modal modal-flex fade" id="view_details" tabindex="-1" role="dialog" aria-labelledby="flexModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header" style="background-color:#FF9800;color:#fff;">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="flexModalLabel">Class Details</h4>
				</div>
				
				<div class="modal-body">
					<div class="row" id="bind_details">
					</div>
				</div>
				
				<div class="modal-footer" style="background-color:#eeeeee;padding: 10px;">
					 <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!--view coupon applied orders-->
	<div class="modal modal-flex fade" id="view_coupon_order_details" tabindex="-1" role="dialog" aria-labelledby="flexModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header" style="background-color:#FF9800;color:#fff;">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title" id="flexModalLabel">Customers In Class</h4>
				</div>
				
				<div class="modal-body">
					<div class="row" id="bind_coupon_order_details">
					</div>
				</div>
				
				<div class="modal-footer" style="background-color:#eeeeee;padding: 10px;">
					 <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>


<?php
$this->load->view ( 'admin/_includes/footer', $data );
?>

<script src="<?php echo theme_assets_path; ?>multi-select.js" type="text/javascript"></script>
<script src="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/js/bootstrap-select.min.js"></script>

<script>

	$(document).ready(function(){
        $('.editor1').wysihtml5();
    }); 

	function selectProduct(id){ 
 
	var values = $('#product').val();
	var referee_id = 0;
		var url="<?php echo base_url('admin/selectrefereeProductPrice'); ?>";
		$.post(url,{"id":values,"referee_id":referee_id},function(res){
				// alert(res);
			  $("#selectproductdiv").html(res);
		});  
	}
	
	$(function () { 
		$("body").on("click", ".remove", function () {
			$(this).closest("tr").remove();	 
		});
	});	

	function handleClick(myRadio) {
		currentValue = myRadio.value;
		if(currentValue==1){
			document.getElementById('discount_in_div').style.display = "block";
			document.getElementById('discount_on_div').style.display = "none";
		}else if(currentValue==2){
			document.getElementById('discount_on_div').style.display = "block";
			document.getElementById('discount_in_div').style.display = "none";
		}
	}	

	function view_details(id){
		var url="<?php echo base_url('admin/customer_class_details'); ?>";
			$.post(url,{"id":id},function(res){
			$("#bind_details").html(res);
			$('#view_details').modal('show');
		});
	}

	function customer_in_class(id){
		var url="<?php echo base_url('admin/customer_in_class'); ?>";
			$.post(url,{"id":id},function(res){
			$("#bind_coupon_order_details").html(res);
			$('#view_coupon_order_details').modal('show');
		});
	}
	
</script>
<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Edit Dealer
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/dealer'); ?>">Dealer</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Edit Dealer</span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase">  Edit Dealer</span>
						</div>
						<div class="actions">
							
								<a href="<?php echo base_url('admin/dealer');?>"
									class="btn btn-circle default">
									Back</a>
						</div>
					</div>
					<div class="portlet-body">
					
							<?php if($this->session->flashdata("success_message")!=""){?>
			                <div class="Metronic-alerts alert alert-info fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
			                </div>
			              <?php }?>
			              <?php if($this->session->flashdata("error_message")!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
			                </div>
			              <?php }?>
			              
			              <?php if(validation_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
			                </div>
			              <?php }?>
			              
			              <?php if( $this->upload->display_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
			                </div>
			              <?php }?>
			              
			             
		              
						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/update_dealer');?>"
							method="post" enctype="multipart/form-data">
							<input type="hidden" name="id" value="<?= $dealer->id; ?>">
							<div class="form-body">
								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Dealer name</label><span style="color:red">*</span>
											<input  name="name" class="form-control" type="text" maxlength="25"  value="<?= $dealer->owner_name; ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-1"></div>
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Shop name</label><span style="color:red">*</span>
											<input name="shop_name" class="form-control" type="text" maxlength="25"  value="<?= $dealer->shop_name; ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
								</div>
								
								
								
								<div class="row">
									
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Contact</label><span style="color:red">*</span>
											<input id="start_time" name="contact" class="form-control" type="number" required value="<?= $dealer->shop_contact; ?>">
										</div>
									</div>
									<div class="col-md-1"></div>
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Email</label><span style="color:red">*</span>
											<input id="end_time" name="email" class="form-control" type="Email" value="<?= $dealer->shop_email; ?>">
										</div>
									</div>
									 
									<!--<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Upload Image</label><span style="color:red"></span><br>
											<div class="fileinput fileinput-new
												data-provides="fileinput">
												<div class="input-group input-large">
													<div class="form-control uneditable-input input-fixed input-medium" data-trigger="fileinput">
														<i class="fa fa-file fileinput-exists"></i>&nbsp; 
														<span class="fileinput-filename"> </span>
													</div>
													<span class="input-group-addon btn default btn-file"> 
														<span class="fileinput-new"> Select file </span> 
														<span class="fileinput-exists"> Change </span> 
														<input type="file" name="image">
													</span> 
													<a href="javascript:;" class="input-group-addon btn red fileinput-exists" data-dismiss="fileinput"> X </a>
														
												</div>
											</div>
											<span class="help-block"> Allowed file types .jpg, .png</span>
										</div>
									</div>-->
								</div>
								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">GST Number</label><span style="color:red"> </span>
											<input  name="gst" class="form-control" maxlength="25" type="text"  value="<?= set_value('gst',$dealer->shop_gstno);?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-1"></div>
									
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">PAN Number</label> 
											<input id="pan" name="pan" class="form-control"  type="text" value="<?= set_value('pan',$dealer->shop_pan);?>">
										</div>
									</div>
								</div>
								  
								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Address-1</label><span style="color:red">*</span>
											<textarea id="address1" name="address1"  class="form-control" rows="3"><?= $dealer->shop_address; ?></textarea>
										</div>
									</div>
									<div class="col-md-1"></div>
									
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Address-2</label>
											<textarea id="address2" name="address2"  class="form-control" rows="3"><?= set_value('address2',$dealer->shop_address1);?></textarea>
										</div>
									</div>
								</div>

								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">City</label><span style="color:red">*</span>
											<input id="city" name="city" class="form-control"  type="text" value="<?= set_value('city',$dealer->shop_city);?>">
										</div>
									</div>
									<div class="col-md-1"></div>
									
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Area / Location</label>
											<input id="area" name="area" class="form-control"  type="text" value="<?= set_value('area',$dealer->shop_area);?>">
											
										</div>
									</div>
								</div>	
								
								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Pincode</label><span style="color:red">*</span>
											<input id="pincode" name="pincode" class="form-control"  type="text" value="<?= set_value('pincode',$dealer->shop_pincode);?>">
											
										</div>
									</div>
									<div class="col-md-1"></div>
									
									<div class="col-md-5">
										
										
									</div>
								</div>
								
								<?php
									if($dealer->birth=='0000-00-00'){
										$birth=0;
									}else{
										$birth=$dealer->birth;
									}
									if($dealer->ani=='0000-00-00'){
										$ani=0;
									}else{
										$ani=$dealer->ani;
									}
								?>
								<div class="row">
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Birthday</label><span style="color:red">*</span>
											<input id="birth" name="birth" class="form-control datepicker"  type="text" value="<?= set_value('birth',$birth); ?>">
										</div>
									</div>
									<div class="col-md-1"></div>
									
									<div class="col-md-5">
										<div class="form-group">
											<label class="control-label">Anniversary</label>
											<input id="ani" name="ani"  class="form-control datepicker" type="text" value="<?= set_value('ani',$ani); ?>">
										</div>
									</div>
								</div>
								
							 
								
									
								 
							<div class="form-actions right">
								<button type="submit" class="btn blue">
									<i class="fa fa-check"></i> Update
								</button>
								<a type="button" class="btn default" href="<?php echo base_url('admin/dealer');?>">Cancel</a>
							</div>
							<!-- <div class="row">
								<div class="col-md-2">
									<button type="submit" class="btn blue"><i class="fa fa-check"></i> Update</button>
								</div>
								<div class="col-md-2">
									<a type="button" class="btn default" href="<?php echo base_url('admin/dealer');?>">Cancel</a>
								</div>
							</div> -->
							</div>
							 
						</form>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<script>
	var base_url = "<?php echo base_url(); ?>";
</script>

<?php
$this->load->view ( 'admin/_includes/footer', $data );
?>

<script>
	$(".datepicker").datepicker({ 
		minDate: 0,
		format: "yyyy-mm-dd",
		changeMonth: true,
		changeYear: true,
		endDate: new Date(),
		yearRange: '-100:0'
	});
</script>
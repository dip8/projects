<?php $this->load->view('admin/_includes/header');
//load custom helper 
$this->load->helper('custom');
?>
<!-- BEGIN CONTENT -->

<style>
.wrapper{
  width:100%;
}
@media(max-width:992px){
 .wrapper{
  width:100%;
} 
}
.panel{
background-color:#EEEEEE;
margin-bottom:6px;
}
.panel-heading {
  padding: 0;
	border:0;
}
.panel-title>a, .panel-title>a:active{
	display:block;
	padding:15px;
  color:#555;
  font-size:14px;
  font-weight:bold;
	text-transform:uppercase;
	letter-spacing:1px;
  word-spacing:3px;
	text-decoration:none;
}
.panel-heading  a:before {
   font-family: 'FontAwesome';
   content: "\f107";
   float: right;
   transition: all 0.5s;
   font-size: 20px;
    margin-top: -3px;
}
.panel-heading.active a:before {
	-webkit-transform: rotate(180deg);
	-moz-transform: rotate(180deg);
	transform: rotate(180deg);
} 
.panel-body{
background-color:#fff;
border:1px solid #EEEEEE; 
}	
input[type="checkbox"]{
width:auto!important;
}
.checkbox label{
width: 225px;
float:left!important;
}
.cust-check{
text-align: -webkit-left;
    margin-left: 15px;
	}
	
	.modal-body p{
		
		margin:0px 0px;
	}
</style>	
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Place Order
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/order'); ?>">order</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Place Order </span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

<div class="row">
	<div class="col-md-12">
		<!-- BEGIN EXAMPLE TABLE PORTLET-->
		<div class="portlet light ">
			<div class="portlet-title">
				<div class="caption font-dark">
					<i class="icon-settings font-dark"></i> <span
						class="caption-subject bold uppercase"> Place Order </span>
				</div>
				<div class="actions">
					<a href="<?php echo base_url('admin/order');?>" class="btn btn-circle default"> Back</a>
				</div>
			</div>
			<div class="portlet-body">
			
					<?php if($this->session->flashdata("success_message")!=""){?>
					<div class="Metronic-alerts alert alert-info fade in">
						<button type="button" class="close" data-dismiss="alert"
							aria-hidden="true"></button>
						<i class="fa-lg fa fa-check"></i>  <?php echo $tsave_imagehis->session->flashdata("success_message");?>
					</div>
				  <?php }?>
				  <?php if($this->session->flashdata("error_message")!=""){?>
					<div
						class="Metronic-alerts alert alert-danger fade in">
						<button type="button" class="close" data-dismiss="alert"
							aria-hidden="true"></button>
						<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
					</div>
				  <?php }?>
				  
				  <?php if(validation_errors()!=""){?>
					<div
						class="Metronic-alerts alert alert-danger fade in">
						<button type="button" class="close" data-dismiss="alert"
							aria-hidden="true"></button>
						<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
					</div>
				  <?php }?>
				  
				  <?php if( $this->upload->display_errors()!=""){?>
					<div
						class="Metronic-alerts alert alert-danger fade in">
						<button type="button" class="close" data-dismiss="alert"
							aria-hidden="true"></button>
						<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
					</div>
				  <?php }?>
   
			<form id="msform" class="horizontal-form" action="javascript:void(0);"
				method="post" enctype="multipart/form-data">
				<div class="form-body">
					<div class="row">
					 <input class="input-sm form-full" id="cust_id" type="hidden" name="cust_id" value="<?= $orders[0]->customer_id; ?>" >
					 <input class="input-sm form-full" id="order_id" type="hidden" name="order_id" value="<?= $orders[0]->id; ?>" >
						<div class="col-md-4">
							<div class="form-group">
								<label class="control-label">Name</label>
								<input id="cust_name" name="cust_name" class="form-control" type="text" value="<?= $orders[0]->name; ?>" onkeypress="getDealer(event)" onkeyup="getDealer(event)">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label class="control-label">Email</label>
								<input id="cust_email" name="cust_email" class="form-control" type="email" value="<?= $orders[0]->email; ?>">
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label class="control-label">Contact</label>
								<input id="cust_contact" name="cust_contact" class="form-control" type="number" value="<?= $orders[0]->contact; ?>">
							</div>
						</div>
						</div>
									
					 
				<?php 
				for($i=0;$i<count($products);$i++) {
							$product_id=$products[$i]->product_id;	
							$product_name=$products[$i]->product_name;	
					?>
					<input type="checkbox" class="product" id="product" name="product" value="<?= $product_id ?>" checked style="display:none;" ><?= $product_name ?> &nbsp;&nbsp;
				<?php } ?>							
				<div class="row" id="TextBoxContainer">

				<h4 style="color:#a10307;"><strong>Estimation</strong></h4>
				<hr></hr>
				<div class="col-lg-12" id="accessories" style="padding:0px;">
				<div class="table table-responsive">
					<table class="table table-responsive table-striped table-bordered">
					<thead>
						<tr>
							<td><strong>Product Name</strong></td>
							<!--<td><strong>Product Description</strong></td>-->
							<td><strong>Product Img</strong></td>
							<td><strong>Select color</strong></td>
							<td><strong>Quantity</strong></td>
							<td><strong>Unit Cost</strong></td>
							<td><strong>Taxable Value</strong></td>
							<!--<td><strong>HSN</strong></td>-->
							<!--<td><strong>Value/Taxable value(Rs)</strong></td>-->
							<td><strong>GST</strong></td>
							<td><strong>Product Remark</strong></td>
							<!--<td><strong>Total gst</strong></td>-->
							<td><strong>Total Amount</strong></td>
							<td><strong>Remove</strong></td>
						</tr>
						 
					</thead>
					</table>
				</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<div class="form-group">
							<label class="control-label">Total amount (with GST)</label>
							<input class="form-control" type="number">
						</div>
					</div>
					<!--<div class="col-md-4">
						<div class="form-group">
							<label class="control-label">Discount (%)</label>
							<input class="form-control" type="number" >
						</div>
					</div>-->
					<div class="col-md-4">
						<div class="form-group">
							<label class="control-label">Final value</label>
							<input class="form-control" type="number" >
						</div>
					</div>
				</div>	
					
				</div>					 
				</div>
	
				<div class="form-actions right" style=" margin-top: 1%;">
					<div class="row">
					<div class="col-md-3" style="float: right;">
					<!--<button type="submit" name="submit" onclick="save_order()" disabled="disabled" class="btn blue">
						<i class="fa fa-share-square-o"></i> Submit
					</button>-->
					<button type="submit" name="submit" id="submit" class="btn blue" onclick="bill_preview()" name="Print" />
						<i class="fa fa-print"></i> Print & Update
					</button>
					<a type="button" class="btn default" href="<?php echo base_url('admin/order');?>">Cancel</a>
					</div>
					</div>
				</div>
			</form>
			</div>
		</div>
		<!-- END EXAMPLE TABLE PORTLET-->
	</div>
</div>

</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->


<script>
	var base_url = "<?php echo base_url(); ?>";
</script>

	<!-- Modal -->
	  <div class="modal fade" id="bill_preview_model" role="dialog">
		<div  class="modal-dialog modal-lg">
		  <div class="modal-content">
			<div class="model-header">
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			  
			</div>
			<div class="modal-body" id="bill_data" style="padding:0px 20px;">
				
		   </div>
			<div class="modal-footer">
			<input type="submit" name="submit" style="margin-bottom:0px;  background-color: indianred;" onclick="update_order()" class="btn btn-default" value="Print & Update"/>	
			<!--<button style="margin-bottom:0px;    background-color: indianred;" type="button" class="btn btn-default" onclick="save_order()" value="print a div!">Print & Save</button>-->
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		   
			  
		</div>
	  </div>
	  </div>

<?php
//$data ['script'] = "payments.js";
//$data ['initialize'] = "pageFunctions.init();";
$this->load->view ( 'admin/_includes/footer', $data );
?>
 
<script>
 $('.panel-collapse').on('show.bs.collapse', function () {
    $(this).siblings('.panel-heading').addClass('active');
  });

  $('.panel-collapse').on('hide.bs.collapse', function () {
    $(this).siblings('.panel-heading').removeClass('active');
  });
</script>

<script>
	$(function () { 
		$("body").on("click", ".remove", function () {
			$(this).closest("tr").remove();
			
			//recalculate
			var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
		  
			
		var price = row.find('.product_price').val();
		var gst = row.find('.product_gst').val();
		var dist = $('#only_discount').val();
		var dealer_dist = $('#only_dealer_discount').val();
		
		var price = row.find('.product_price').val() * row.find('.product_qty').val();

		var gstamt=(price/100)*gst;
		var total=(price+gstamt).toFixed(2);
		
		var taxable_val=price.toFixed(2);;
		
		var gstamt1=(price/100)*gst;
		var gst_amt=gstamt1.toFixed(2);
		
		isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);

		var total1 = 0;
		$('.total').each(function() {
		total1 += Number($(this).val()) || 0;
		});
		var total1 =total1.toFixed(2);
    
		var tol_tax_val = 0;
		$('.taxable_value').each(function() {
		tol_tax_val += Number($(this).val()) || 0;
		});
		var tol_tax_val =tol_tax_val.toFixed(2);
    
		var tot_gst_amt = 0;
		$('.total_gst').each(function() {
		tot_gst_amt += Number($(this).val()) || 0;
		});
		var tot_gst_amt =tot_gst_amt.toFixed(2);
    
		var tot_quntity = 0;
		$('.product_qty').each(function() {
		tot_quntity += Number($(this).val()) || 0;
		});

		var discount =total1*(dist/100);
		var discount=discount.toFixed(2);
	    var final_value =total1-discount;
		var final_value= final_value.toFixed(2);
	    var dealer_discount=final_value*(dealer_dist/100);
	    var dealer_discount=dealer_discount.toFixed(2);
	    var totol_dist= parseFloat(discount) + parseFloat(dealer_discount);
	    var totol_dist=totol_dist.toFixed(2); 
	    var totdist_final_amt=Math.round(total1-totol_dist);
	    var totdist_final_amt=roundNumber(totdist_final_amt,2);
    
		$(".tol_tax_val").val(tol_tax_val);
		$(".tot_gst").val(total1);
		$(".discount").val(totol_dist);
		$(".tot_gst_amt").val(tot_gst_amt);
		$(".final_value").val(totdist_final_amt);
		$(".total_quntity").val(tot_quntity);
 
		 
		
		});
		
var nextbtn = document.getElementById('submit');
    $("input.product").click(function () {
		var checkedNum=0;
		$("input.product:checked").each(function(){
            checkedNum=checkedNum+1;
        });
		//alert(checkedNum);
		if (checkedNum>0) {
			nextbtn.disabled = false;
		}else{
			nextbtn.disabled = true;
		}
        
    })
});
</script>

<script>	
function getDealer(e){	
	 //alert(e);
	$("#cust_name").autocomplete({
		source:"<?php echo base_url('admin/get_dealer');?>",
		select:function(event,ui){
			//alert(ui.item.id);
			$("#cust_id").val(ui.item.id);
			$("#cust_email").val(ui.item.email);
			$("#cust_contact").val(ui.item.contact);
		}
	});
}
  
$(function () { 
	var checkboxes = document.querySelectorAll('input[name="product"]:checked'), values = [];
    Array.prototype.forEach.call(checkboxes, function(el) {
       values.push(el.value);
    });
	//var values=[1,2,3];
	//alert(values);
	var cust_name = document.getElementById("cust_name").value;
	var email = document.getElementById("cust_email").value;
	var contact = document.getElementById("cust_contact").value;
	var cust_id = document.getElementById("cust_id").value;		
	var order_id = document.getElementById("order_id").value;
	
	if(values.length > 0){
	$.ajax({
	url : '<?php echo base_url('admin/select_order_product_edit');?>',
    type : "post", 
    data :({'id' : values,'cust_name' : cust_name,'email' :email,'contact':contact,'cust_id' :cust_id,'order_id' :order_id}),
	success : function(data){
		//alert(data);
	 $('#TextBoxContainer').html(data);
	},
	
	error : function(data) {
          alert("error");
	    }
	});
	}else{
		$('#TextBoxContainer').html('<h4 style="color:#a10307;"><strong>Estimation</strong></h4> <hr></hr> <div class="col-lg-12" id="accessories" style="padding:0px;"> <div class="table table-responsive"> <table class="table table-responsive table-striped table-bordered"> <thead> <tr> <td><strong>Product Name</strong></td><td><strong>Product Img</strong></td> <td><strong>Select color</strong></td> <td><strong>Quantity</strong></td> <td><strong>Unit Cost</strong></td> <td><strong>Taxable Value</strong></td><td><strong>GST</strong></td> <td><strong>Product Remark</strong></td> <td><strong>Total Amount</strong></td> <td><strong>Remove</strong></td> </tr> </thead> </table> </div> </div> <div class="row"> <div class="col-md-4"> <div class="form-group"> <label class="control-label">Total amount (with GST)</label> <input class="form-control" type="number"> </div> </div> <div class="col-md-4"> <div class="form-group"> <label class="control-label">Discount (%)</label> <input class="form-control" type="number" > </div> </div> <div class="col-md-4"> <div class="form-group"> <label class="control-label">Final value</label> <input class="form-control" type="number" > </div> </div> </div>');
	}
});
	
</script>

<script>
	$('document').ready(function() {
		 //alert("hi1");
	$(document).on("focus", "[class*='item-row']", function() {	
	 //alert("hi2");
	$('.product_qty').on("blur", function(){
		
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
		
		$.ajax({
			 url:'<?php echo base_url('frontend/check_qty');?>',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			
			 success: function(data)
			 {
				var pqty=parseInt(data);
				 if(qty>pqty)
				 {
	                 //alert(data+"not availble");
					 alert('Quantity not available!');
				     row.find('.product_qty').val(pqty);
				 }
	            else{
	                //alert(data+"availble");
	                row.find('.product_qty').val(pqty);
	              }
			 }
			}); 
			
		setTimeout(function(){
				
		var price = row.find('.product_price').val();
		var gst = row.find('.product_gst').val();
		var dist = $('#only_discount').val();
		var dealer_dist = $('#only_dealer_discount').val();
		//alert(dist);
			
		//alert("hi"+qty+"hii"+price+"-"+gst);
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		//var price = row.find('.product_price').val() * 1;
		
		var gstamt=(price/100)*gst;
		var total=(price+gstamt).toFixed(2);
    
		var taxable_val=price.toFixed(2);
		
		var gstamt1=(price/100)*gst;
		var gst_amt=gstamt1.toFixed(2);
		
		isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);
		
		var total1 = 0;
		$('.total').each(function() {
		total1 += Number($(this).val()) || 0;
		});
		var total1 =total1.toFixed(2);
    
		var tol_tax_val = 0;
		$('.taxable_value').each(function() {
		tol_tax_val += Number($(this).val()) || 0;
		});
		var tol_tax_val =tol_tax_val.toFixed(2);
    
		var tot_gst_amt = 0;
		$('.total_gst').each(function() {
		tot_gst_amt += Number($(this).val()) || 0;
		});
		var tot_gst_amt =tot_gst_amt.toFixed(2);
		
		var tot_quntity = 0;
		$('.product_qty').each(function() {
		tot_quntity += Number($(this).val()) || 0;
		});
		
		var discount =total1*(dist/100);
		var discount=discount.toFixed(2);
		var final_value =total1-discount;
		var final_value= final_value.toFixed(2);
		var dealer_discount=final_value*(dealer_dist/100);
		var dealer_discount=dealer_discount.toFixed(2);
		var totol_dist= parseFloat(discount) + parseFloat(dealer_discount);
		var totol_dist=totol_dist.toFixed(2); 
		var totdist_final_amt=Math.round(total1-totol_dist);
		var totdist_final_amt=roundNumber(totdist_final_amt,2);
	
		
		$(".tol_tax_val").val(tol_tax_val);
		$(".tot_gst").val(total1);
		$(".discount").val(totol_dist);
		$(".tot_gst_amt").val(tot_gst_amt);
		$(".final_value").val(totdist_final_amt);
		$(".total_quntity").val(tot_quntity);
	   //	$(".unit_price").val($tot_qty);
		
		}, 500);
	});
	
	$('.product_qty').on("click", function(){
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
		$.ajax({
			 url:'<?php echo base_url('frontend/check_qty');?>',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			
			 success: function(data)
			 {
				 var pqty=parseInt(data);
				 if(qty>pqty)
				 {
	                 row.find('.product_qty').val(pqty);
					 alert('Quantity not available!');
				     
				 }
	            else{
	                //alert(data+"availble");
	                row.find('.product_qty').val(pqty);
	              }
			 }
			}); 
		 
		setTimeout(function(){
			
		var price = row.find('.product_price').val();
		var gst = row.find('.product_gst').val();
		var dist = $('#only_discount').val();
		var dealer_dist = $('#only_dealer_discount').val();
		
		var price = row.find('.product_price').val() * row.find('.product_qty').val();

		var gstamt=(price/100)*gst;
		var total=(price+gstamt).toFixed(2);
		
		var taxable_val=price.toFixed(2);;
		
		var gstamt1=(price/100)*gst;
		var gst_amt=gstamt1.toFixed(2);
		
		isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);

		var total1 = 0;
		$('.total').each(function() {
		total1 += Number($(this).val()) || 0;
		});
		var total1 =total1.toFixed(2);
    
		var tol_tax_val = 0;
		$('.taxable_value').each(function() {
		tol_tax_val += Number($(this).val()) || 0;
		});
		var tol_tax_val =tol_tax_val.toFixed(2);
    
		var tot_gst_amt = 0;
		$('.total_gst').each(function() {
		tot_gst_amt += Number($(this).val()) || 0;
		});
		var tot_gst_amt =tot_gst_amt.toFixed(2);
    
		var tot_quntity = 0;
		$('.product_qty').each(function() {
		tot_quntity += Number($(this).val()) || 0;
		});

		var discount =total1*(dist/100);
		var discount=discount.toFixed(2);
	    var final_value =total1-discount;
		var final_value= final_value.toFixed(2);
	    var dealer_discount=final_value*(dealer_dist/100);
	    var dealer_discount=dealer_discount.toFixed(2);
	    var totol_dist= parseFloat(discount) + parseFloat(dealer_discount);
	    var totol_dist=totol_dist.toFixed(2); 
	    var totdist_final_amt=Math.round(total1-totol_dist);
	    var totdist_final_amt=roundNumber(totdist_final_amt,2);
    
		$(".tol_tax_val").val(tol_tax_val);
		$(".tot_gst").val(total1);
		$(".discount").val(totol_dist);
		$(".tot_gst_amt").val(tot_gst_amt);
		$(".final_value").val(totdist_final_amt);
		$(".total_quntity").val(tot_quntity);
 
		}, 500);
	});
    
   $('.product_color').on("change", function(){
	    var row = $(this).parents('.item-row');
	    var product_id = row.find('.hid_product_id').val();
	    var product_color_id = row.find('.product_color').val();
		var qty = row.find('.product_qty').val();
		//alert(product_color_id);
		//alert(product_color_id);
		$.ajax({
			 url:'<?php echo base_url('frontend/change_color');?>',
			 type:'POST',
	         dataType:'json',
			 data:{'product_color_id':product_color_id,'qty':qty},
			 
			 success: function(data)
			 {
	          //alert(data);
	          //alert(data[4]);
	           row.find('.hid_product_id').val(data[3]);
	           row.find('.product_name').val(data[0]);
	           row.find('.product_img').val(data[1]);
	           row.find('.product_price').val(data[2]);
			   //row.find('.product_qty').val(data[4]); 
			   
			   var product_id = row.find('.hid_product_id').val();
				var qty = row.find('.product_qty').val();
				var name = row.find('.product_name').val();
				var image = row.find('.product_img').val();
				//var price = row.find('.product_price').val();
				var gst = row.find('.product_gst').val();
				var dist = $('#only_discount').val();
				var dealer_dist = $('#only_dealer_discount').val();
				var price = row.find('.product_price').val() * row.find('.product_qty').val();
				//alert(price);
				var gstamt=(price/100)*gst;
				var total=(price+gstamt).toFixed(2);
				
				var taxable_val=price.toFixed(2);;
				
				var gstamt1=(price/100)*gst;
				var gst_amt=gstamt1.toFixed(2);
				
				//$(".unit_price").val($tot_qty);
				isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
				isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
				isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);
				
				var total1 = 0;
				$('.total').each(function() {
				total1 += Number($(this).val()) || 0;
				});
				var total1 =total1.toFixed(2);
				//var total1=roundNumber(total1,2);
				
				var tol_tax_val = 0;
				$('.taxable_value').each(function() {
				tol_tax_val += Number($(this).val()) || 0;
				});
				var tol_tax_val =tol_tax_val.toFixed(2);
				//var tol_tax_val=rproduct_imgoundNumber(tol_tax_val,2);
				
				var tot_gst_amt = 0;
				$('.total_gst').each(function() {
				tot_gst_amt += Number($(this).val()) || 0;
				});
				var tot_gst_amt =tot_gst_amt.toFixed(2);
				//var tot_gst_amt=roundNumber(tot_gst_amt,2);
				
				var tot_quntity = 0;
				$('.product_qty').each(function() {
				tot_quntity += Number($(this).val()) || 0;
				});
				
				var discount =total1*(dist/100);
				var discount=discount.toFixed(2);
			   
				var final_value =total1-discount;
				var final_value= final_value.toFixed(2);
				var dealer_discount=final_value*(dealer_dist/100);
				var dealer_discount=dealer_discount.toFixed(2);
				var totol_dist= parseFloat(discount) + parseFloat(dealer_discount);
			   
				var totol_dist=totol_dist.toFixed(2); 
				var totdist_final_amt=Math.round(total1-totol_dist);
				var totdist_final_amt=roundNumber(totdist_final_amt,2);
			
			   
				$(".tol_tax_val").val(tol_tax_val);
				$(".tot_gst").val(total1);
				$(".discount").val(totol_dist);
				$(".tot_gst_amt").val(tot_gst_amt);
				$(".final_value").val(totdist_final_amt);
				$(".total_quntity").val(tot_quntity);
				//alert(total2);
				
				
	          }
			}); 
 
	});

	$('.btn').on("keyup", function(){
		
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
		
		/*$.ajax({
			 url:'<?php echo base_url('frontend/check_qty');?>',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			
			 success: function(data)
			 {
				 var pqty=parseInt(data);
				 //alert(data);
				 if(pqty==1)
				 {
					 alert('Quantity not available!');
					 row.find('.product_qty').val(pqty);
				 }
			 }
			}); */
		var price = row.find('.product_price').val();
		var gst = row.find('.product_gst').val();
		var dist = $('#only_discount').val();
		//alert(dist);
			
		//alert("hi"+qty+"hii"+price+"-"+gst);
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		//var price = row.find('.product_price').val() * 1;
		
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		
		var taxable_val=Math.round(price);
		var taxable_val=roundNumber(taxable_val,2);
		
		var gstamt1=(price/100)*gst;
		var gst_amt=Math.round(gstamt1);
		var gst_amt=roundNumber(gst_amt,2);
		
		//$(".unit_price").val($tot_qty);
		isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);
		
		var total1 = 0;
		$('.total').each(function() {
		total1 += Number($(this).val()) || 0;
		});
		
		var tol_tax_val = 0;
		$('.taxable_value').each(function() {
		tol_tax_val += Number($(this).val()) || 0;
		});
		
		var tot_gst_amt = 0;
		$('.total_gst').each(function() {
		tot_gst_amt += Number($(this).val()) || 0;
		});
		
		
		var tot_quntity = 0;
		$('.product_qty').each(function() {
		tot_quntity += Number($(this).val()) || 0;
		});
		
		var discount =Math.round(total1*(dist/100));
		var discount=roundNumber(discount,2);
		var final_value =Math.round((total1)-(discount));
		var final_value= roundNumber(final_value,2);
		//var total2=total1;
		//alert(total2);
		$(".tol_tax_val").val(tol_tax_val);
		$(".tot_gst").val(total1);
		$(".discount").val(discount);
		$(".tot_gst_amt").val(tot_gst_amt);
		$(".final_value").val(final_value);
		$(".total_quntity").val(tot_quntity);

	});
	
	$('.btn').on("click", function(){
		var row = $(this).parents('.item-row');
		var product_id = row.find('.hid_product_id').val();
		var qty = row.find('.product_qty').val();
		/*$.ajax({
			 url:'<?php echo base_url('frontend/check_qty');?>',
			 type:'POST',
			 data:{'product_id':product_id,'qty':qty},
			
			 success: function(data)
			 {
				 var pqty=parseInt(data);
				 if(pqty!=0)
				 {
					 alert('Quantity not available!');
					 row.find('.product_qty').val(pqty);
				 }
			 }
			}); */
		
		var price = row.find('.product_price').val();
		var gst = row.find('.product_gst').val();
		var dist = $('#only_discount').val();
		//var dist = row.find('.only_discount').val();alert(dist);
			
		//alert("hi"+qty+"hii"+price+"-"+gst);
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		//var price = row.find('.product_price').val() * 1;
		
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		
		var taxable_val=Math.round(price);
		var taxable_val=roundNumber(taxable_val,2);
		
		var gstamt1=(price/100)*gst;
		var gst_amt=Math.round(gstamt1);
		var gst_amt=roundNumber(gst_amt,2);
		
		//$(".unit_price").val($tot_qty);
		isNaN(taxable_val) ? row.find('.taxable_value').val("N/A") : row.find('.taxable_value').val(taxable_val);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		isNaN(gst_amt) ? row.find('.total_gst').val("N/A") : row.find('.total_gst').val(gst_amt);
		
		var total1 = 0;
		$('.total').each(function() {
		total1 += Number($(this).val()) || 0;
		});
		
		var tol_tax_val = 0;
		$('.taxable_value').each(function() {
		tol_tax_val += Number($(this).val()) || 0;
		});
		
		var tot_gst_amt = 0;
		$('.total_gst').each(function() {
		tot_gst_amt += Number($(this).val()) || 0;
		});
		
		var tot_quntity = 0;
		$('.product_qty').eqtyach(function() {
		tot_quntity += Number($(this).val()) || 0;
		});
		
		
		var discount =Math.round(total1*(dist/100));
		var discount=roundNumber(discount,2);
		var final_value =Math.round((total1)-(discount));
		var final_value= roundNumber(final_value,2);
		//var total2=total1;
		//alert(total2);
		$(".tol_tax_val").val(tol_tax_val);
		$(".tot_gst").val(total1);
		$(".discount").val(discount);
		$(".tot_gst_amt").val(tot_gst_amt);
		$(".final_value").val(final_value);
		$(".total_quntity").val(tot_quntity);

	});
	 
    
	
	$('.product_price').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		
			//alert("asd");
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		 
	});
	$('.product_price').on("click", function(){
		var row = $(this).parents('.item-row');
		var minprice = row.find('.min_sale_cost').val() * row.find('.product_qty').val();
		
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		 
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
		 
	});
	
	$('.product_gst').on("change", function(){
		var row = $(this).parents('.item-row');
		var price = row.find('.product_price').val() * row.find('.product_qty').val();
		//var price = row.find('.product_price').val() * 1;
		var gst = row.find('.product_gst').val();
		var gstamt=(price/100)*gst;
		var total=Math.round(price+gstamt);
		var total=roundNumber(total,2);
		isNaN(total) ? row.find('.total').val("N/A") : row.find('.total').val(total);
	});
	
	$('.total').on("keyup", function(){
		var row = $(this).parents('.item-row');
		var total = row.find('.total').val();
		var qty = row.find('.product_qty').val();
		//var qty = 1;
		var gst = row.find('.product_gst').val();
		var gstext =parseInt(100)+parseInt(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		isNaN(net_price) ? row.find('.product_price').val("N/A") : row.find('.product_price').val(net_price);
	});
	
	/*$('.total').on("click", function(){
		var row = $(this).parents(bill_preview'.item-row');
		var total = row.find('.total').val();
		var qty = row.find('.product_qty').val();
		//var qty = 1;
		var gst = row.find('.product_gst').val();
		var gstext =parseInt(100)+parseInt(gst);
		var gstamt=(total*100)/gstext;
		var price=total-gstamt;
		var net_price=gstamt/qty;
		var net_price=roundNumber(net_price,2);
		isNaN(net_price) ? row.find('.product_price').val("N/A") : row.find('.product_price').val(net_price);
	});*/
	
	
	
	});
			}); 
	
	
	
	
function roundNumber(number,decimals) {
  var newString;// The new rounded number
  decimals = Number(decimals);
  if (decimals < 1) {
    newString = (Math.round(number)).toString();
  } else {
    var numString = number.toString();
    if (numString.lastIndexOf(".") == -1) {// If there is no decimal point
      numString += ".";// give it one at the end
    }
    var cutoff = numString.lastIndexOf(".") + decimals;// The point at which to truncate the number
    var d1 = Number(numString.substring(cutoff,cutoff+1));// The value of the last decimal place that we'll end up with
    var d2 = Number(numString.substring(cutoff+1,cutoff+2));// The next decimal, after the last one we want
    if (d2 >= 5) {// Do we need to round up at all? If not, the string will just be truncated
      if (d1 == 9 && cutoff > 0) {// If the last digit is 9, find a new cutoff point
        while (cutoff > 0 && (d1 == 9 || isNaN(d1))) {
          if (d1 != ".") {
            cutoff -= 1;
            d1 = Number(numString.substring(cutoff,cutoff+1));
          } else {
            cutoff -= 1;
          }
        }
      }
      d1 += 1;
    } 
    if (d1 == 10) {
      numString = numString.substring(0, numString.lastIndexOf("."));
      var roundedNum = Number(numString) + 1;
      newString = roundedNum.toString() + '.';
    } else {
      newString = numString.substring(0,cutoff) + d1.toString();
    }
  }
  if (newString.lastIndexOf(".") == -1) {// Do this again, to the new string
    newString += ".";
  }
  var decs = (newString.substring(newString.lastIndexOf(".")+1)).length;
  for(var i=0;i<decimals-decs;i++) newString += "0";
  //var newNumber = Number(newString);// make it a number if you like
  return newString; // Output the result to the form field (change for your purposes)
}


</script>

<script>

	function update_order()
	{ 	 
	//document.getElementById("btnproduct").readonly = true;
	    var myform = document.getElementById("msform");
		var fd = new FormData(myform);
		//alert(fd);
		$.ajax({
		  url:'<?php echo base_url('admin/update_order');?>',
		  type: "POST",
		  data: fd,
		  cache: false,
		  processData: false,  // tell jQuery not to process the data
		  contentType: false,   // tell jQuery not to set contentType
			success: function (data) {
				//alert(data);
				if(data){
				alert("Order Update Successfully..");
				printDiv('printableArea');
				//location.reload();
				window.location.href = '<?php echo base_url('admin/order'); ?>'; 
					//var baseurl = "<?php print base_url(); ?>";
				}
				else{
					alert("Order Not Placed! Please try again..");
					location.reload();
				}
			}
		});  
	}


</script>
 
<script>
function bill_preview()
	{ 
		var cust_name=$('#cust_name').val();
		var cust_email=$('#cust_email').val();
		var cust_contact=$('#cust_contact').val();
		var checkedNum=0;
		$("input.product:checked").each(function(){
            checkedNum=checkedNum+1;
        });
		
		if(cust_name && cust_email && cust_contact && checkedNum>0){
			
			var myform = document.getElementById("msform");
			var fd = new FormData(myform);
			//alert(fd);
			$.ajax({
			  url: '<?php echo base_url('admin/bill_print_edit');?>',
			  type: "POST",
			  data: fd,
			  cache: false,
			  processData: false,  // tell jQuery not to process the data
			  contentType: false,   // tell jQuery not to set contentType
				success: function (data) {
					//alert(data);
					$("#bill_preview_model").modal("show");
					$("#bill_data").html('');
					$("#bill_data").html(data);
					 
				}
			});
		}else if(cust_name==''){
			alert('Please enter dealer name.');
			$('#cust_name').focus();
		}else if(cust_email==''){
			alert('Please enter dealer email-id.');
			$('#cust_email').focus();
		}else if(cust_contact==''){
			alert('Please enter dealer contact number.');
			$('#cust_contact').focus();
		}else if(checkedNum<=0){
			alert('Please select product.');
			//$('#cust_contact').focus();
		}
	}
	
 function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}

</script>
<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Add Quotation
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/dealer'); ?>">Add Quotation</a>
					</li>
				<li><span></span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase"> Add Quotation</span>
						</div>
						<div class="actions">
							
								<a href="<?php echo base_url('admin/dealer');?>"
									class="btn btn-circle default">
									Back</a>
						</div>
					</div>
					<div class="portlet-body">
					
							<?php if($this->session->flashdata("success_message")!=""){?>
			                <div class="Metronic-alerts alert alert-info fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
			                </div>
			              <?php }?>
			              <?php if($this->session->flashdata("error_message")!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
			                </div>
			              <?php }?>
			              
			              <?php if(validation_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
			                </div>
			              <?php }?>
			              
			              <?php if( $this->upload->display_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
			                </div>
			              <?php }?>
			              
			             
		              
						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/save_dealer');?>"  method="post" enctype="multipart/form-data" autocomplete="Off">
							<div class="form-body">
							
                            <div class="row">
							
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Client Id</label><span style="color:red">*</span>
											<input name="client_id" class="form-control" maxlength="25" type="text" value="<?= set_value('client_id'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Request Quntity(By Customer)</label><span style="color:red">*</span>
											<input name="req_qun" class="form-control" maxlength="25" type="text" value="<?= set_value('request_quntity'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									
									<div class="col-md-4">
								
										<div class="form-group">
											<label class="control-label">Client Name</label><span style="color:red">*</span>
											<input name="client_name" class="form-control" maxlength="25" type="text" value="<?= set_value('client_name'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									
								</div>

								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Avalable quantity (in your branch)</label><span style="color:red">*</span>
											<input name="cun_quntity" class="form-control" maxlength="25" type="text" value="<?= set_value('current_quntity'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Bar Code</label> 
											<input name="bar_code" class="form-control" maxlength="25" type="text" value="<?= set_value('bar_code'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Total Quntity</label> 
											<input name="quntity" class="form-control" maxlength="25" type="text" value="<?= set_value('total_quntity'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
								</div>
								
								
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Brand</label><span style="color:red">*</span>
											<input name="brand" class="form-control" maxlength="25" type="text"  value="<?= set_value('brand'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Discount %</label><span style="color:red">*</span>
											<input name="discount" class="form-control" maxlength="25" type="text"  value="<?= set_value('discount'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Unit</label><span style="color:red">*</span>
											<input name="unit" class="form-control" maxlength="25" type="text"  value="<?= set_value('unit'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Discount Amount</label>
											<input name="dis_amt" class="form-control" maxlength="25" type="text"  value="<?= set_value('discount_amount'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Sale Price</label>
											<input name="sale_price" class="form-control" maxlength="25" type="text"  value="<?= set_value('sale_price'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Total Amount</label>
											<input name="total_amount" class="form-control" maxlength="25" type="text"  value="<?= set_value('total_amount'); ?>" alt="Only 25 Character Allowed">
										</div>
									</div>
									
								</div>
								
							</div>
					
	
							</div>
							<div class="row">
							<div class="col-md-1">
								<button type="submit" class="btn blue"><i class="fa fa-check"></i> Add</button>
							</div>
						</form>
</div>

<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/save_quotation');?>"  method="post" enctype="multipart/form-data" autocomplete="Off">
				<div class="table-responsive" id="bind_products">
				
							<div class="form-body">
						<table class="table table-striped table-bordered table-hover table-checkable order-column" id="managed_datatable" data-page-length='10'>
							<thead>
								<tr>
									<th>Sr.No.</th>
									<th>Client Id</th>
									<th>Client Name</th>
									<th>Current Quntity</th>
									<th>Bar Code</th>
									<th>Total Quntity</th>
									<th>Discount</th>
									<th>Discount Amount</th>
									<th>Total Amount</th>
								</tr>
							</thead>
							<tbody >
								<?php for($i=0;$i<count($product);$i++){ 
										//print_r($product);exit;
									

								?>
							
									<tr class="odd gradeX">
										<td><?= $i+1; ?></td>
										<td><input id="client_id" name="client_id"class="form-control"  type="text" readonly value="<?= set_value('total_amount',$product[$i]->client_id);?>"></td>
										<td><input id="client_name" name="client_name" class="form-control"  type="text" readonly value="<?= set_value('client_name', $product[$i]->client_name);?>"></td>
										<td><input id="current_quntity" name="current_quntity" class="form-control"  type="text" readonly value="<?= set_value('current_quntity', $product[$i]->current_quntity);?>"></td>
										<td><input id="bar_code" name="bar_code" class="form-control"  type="text" readonly value="<?= set_value('bar_code', $product[$i]->bar_code);?>"></td>
										<td><input id="total_quntity" name="total_quntity" class="form-control"  type="text" readonly value="<?= set_value('total_quntity', $product[$i]->total_quntity);?>"></td>
										<td><input id="discount" name="discount" class="form-control"  type="text" readonly value="<?= set_value('discount', $product[$i]->discount);?>"></td>
									    <td><input id="discount_amount" name="discount_amount" class="form-control"  type="text" readonly value="<?= set_value('discount_amount', $product[$i]->discount_amount);?>"></td>
					                    <td><input id="total_amount" name="total_amount" class="form-control"  type="text" readonly value="<?= set_value('total_amount', $product[$i]->total_amount);?>"></td>
									</tr>
								<?php } ?>
					        </tbody>
						</table>
						</div>
					
					<div class="row">
										<div class="form-group">
										<center><label class="control-label">Remark</label>
											<textarea id="data_text" name="data_text"  class="form-control" rows="2" style=" width : 80%"></textarea></center>
										</div>
									</div>
									</form>
									<div class="row">
								<center><button type="submit" class="btn blue"><i class="fa fa-check"></i> Submit</button></center>
						</div>			
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>
		</div>
			</div>
			</div>	
						</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<script>
	var base_url = "<?php echo base_url(); ?>";
</script>

<?php
$this->load->view ( 'admin/_includes/footer', $data );
?>

<script>

	$(".datepicker").datepicker({ 
		minDate: 0,
		format: "yyyy-mm-dd",
		changeMonth: true,
		changeYear: true,
		endDate: new Date(),
		yearRange: '-100:0'
	});

</script>
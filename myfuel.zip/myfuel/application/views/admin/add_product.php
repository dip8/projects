<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->

<link href="<?php echo theme_assets_path; ?>multi-select.css" rel="stylesheet" type="text/css" />
<link href="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" />

<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Add Product 
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/product'); ?>">Product</a>
					<i class="fa fa-angle-right"></i></li>
				<li><span> Add Product </span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase"> Add Product </span>
						</div>
						<div class="actions">
							
								<a href="<?php echo base_url('admin/product');?>"
									class="btn btn-circle default">
									Back</a>
						</div>
					</div>
					<div class="portlet-body">
				
			              <?php if($this->session->flashdata("error_message")!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
			                </div>
			              <?php }?>
			              
			              <?php if(validation_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
			                </div>
			              <?php }?>
			              
			              <?php if( $this->upload->display_errors()!=""){?>
			                <div
								class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert"
									aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
			                </div>
			              <?php }?>
			              
						<form id="add_student_form" class="horizontal-form" action="<?php echo base_url('admin/save_product');?>"
							method="post" enctype="multipart/form-data">
							<div class="form-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Product Name</label><span style="color:red">*</span>
											<input id="product_name" name="product_name" class="form-control" type="text" value="<?= set_value('product_name'); ?>">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Product Code</label><span style="color:red"></span>
											<input id="product_code" name="product_code" class="form-control" type="text" value="<?= set_value('product_code'); ?>">
										</div>
									</div>
									<div class="col-md-4">
									<div class="form-group"> 
											<label class="control-label">Flavour</label><span style="color:red"> </span>
											<select id="flavour_id" name="flavour_id" class="form-control" >
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($flavour);$i++){ ?>
												<option value="<?= $flavour[$i]->id ?>"><?php echo $flavour[$i]->name; ?></option>
												<?php } ?>
											</select>
										</div>
									</div>
						     	</div>
									
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Main Category</label><span style="color:red">*</span>
											
											<select id="main_category" name="main_category" class="form-control" onChange="categorysubcatelist(this.value);" >
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($category);$i++){ ?>
												<option value="<?= $category[$i]->id ?>"><?php echo $category[$i]->name; ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Sub Category</label>
											
											<select id="sub_category" name="sub_category" class="form-control" onChange="categorysubcatechildlist(this.value);">
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($sub_category);$i++){ ?>
												<option value="<?= $sub_category[$i]->id ?>"><?php echo $sub_category[$i]->name; ?></option>
												<?php } ?>
											</select>
											
										</div>
									</div>
									
									<div class="col-md-4">
									<div class="form-group"> 
										<label class="control-label">Brand</label><span style="color:red">*</span>
										
										<select id="brand_category" name="brand_category" class="form-control" >
											<option value="">--Select--</option>
											<?php for($i=0;$i<count($brand);$i++){ ?>
											<option value="<?= $brand[$i]->id ?>"><?php echo $brand[$i]->name; ?></option>
											<?php } ?>
										</select>
										
									</div>
									</div>
	
									<div class="col-md-4" >
										<div class="form-group">
											<label class="control-label">Price</label><span style="color:red">*</span>
											<input id="price" name="price" class="form-control" type="text"  >
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Offer Price</label>
											<input id="offer_price" name="offer_price" class="form-control" type="text" value="<?= set_value('offer_price'); ?>">
										</div>
									</div> 
									<div class="col-md-4">
										<div class="form-group"  >
											<label class="control-label">GST (%)</label><span style="color:red">*</span>
											<select id="gst" name="gst" class="form-control" >
											<option <?= set_select("gst",0); ?> value="0" >0</option>
											<option <?= set_select("gst",5); ?> value="5" h>5</option>
											<option <?= set_select("gst",12); ?> value="12" >12</option>
											<option <?= set_select("gst",18); ?> value="18" >18</option>
											<option <?= set_select("gst",28); ?> value="28" >28</option>
											</select>
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Weight</label><span style="color:red">*</span>
											<input id="weight" name="weight" class="form-control" type="text" value="<?= set_value('weight'); ?>">
										</div>
									</div>
									
									
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Barcode</label>
											<input id="servings" name="servings" class="form-control" type="text"  value="<?= set_value('servings'); ?>"  >
										</div>
									</div>
									
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Size</label>
											<input id="size" name="size" class="form-control" type="text"  value="<?= set_value('size'); ?>">
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group"> 
											<label class="control-label">Goals</label><span style="color:red"> </span>
											
											<select id="goals_id" name="goals_id" class="form-control" >
												<option value="">--Select--</option>
												<?php for($i=0;$i<count($goals);$i++){ ?>
												<option value="<?= $goals[$i]->id ?>"><?php echo $goals[$i]->name; ?></option>
												<?php } ?>
											</select>
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="form-group">
											<label class="control-label">Product Qty</label><span style="color:red">*</span>
											<input id="product_qty" name="product_qty" class="form-control" type="number" min=0 value="1">
										</div>
									</div>
									<div class="col-md-3" >
										<div class="form-group">
											<label class="control-label">Set Min Product Qty</label>
											<input id="product_minqty" name="product_minqty" class="form-control" type="number" min=0 value="1">
										</div>
									</div>
									
									
								</div>
								</div>
								
							</div>
							<hr>
							<div class="form-actions text-center">
								<button type="submit" class="btn blue">
									<i class="fa fa-upload"></i> Upload
								</button>
								<a type="button" class="btn default" href="<?php echo base_url('admin/product');?>">Cancel</a>
							</div>
						</form>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<?php
//$data ['script'] = "payments.js";
//$data ['initialize'] = "pageFunctions.init();";
$this->load->view ( 'admin/_includes/footer', $data );
?>
<script src="<?php echo theme_assets_path; ?>multi-select.js" type="text/javascript"></script>
<script src="<?php echo theme_assets_path; ?>global/plugins/bootstrap-select/js/bootstrap-select.min.js"></script>

<script>
	$(document).ready(function(){
        $('.editor1').wysihtml5();
    });
	
	function categorysubcatelist(cat_id){

		var url="<?php echo base_url.'admin/getSubcat/';?>";	
		$("#sub_category").load(url,{'category_id':cat_id},function(res){
			//alert(res);	
		});	
	}
	
	function categorysubcatechildlist(subcat_id){

		/* var url="<?php echo base_url.'admin/getChildcat/';?>";	
		$("#child_category").load(url,{'subcategory_id':subcat_id},function(res){
			//alert(res);	
		}); */

		if(subcat_id==6){
			$('#product_child_div').show();
			$('#product_type_div').show();
			$('#product_color_div').show();
		}else{
			$('#product_child_div').hide();
			$('#product_type_div').hide();
			$('#product_color_div').hide();
		}
		
		if(subcat_id==2 || subcat_id==3){
			//$('#product_type_div').show();
			$('#product_color_div').show();
			//$('#product_child_div').show();
		}else{
			//$('#product_type_div').hide();
			//$('#product_color_div').hide();
			//$('#product_child_div').hide();
		} 
		
		if(subcat_id==1){
			$('#product_child_div').show();
			$('#product_type_div').hide();
			$('#product_color_div').show();
		}else{
			/* $('#product_child_div').hide();
			$('#product_type_div').show();
			$('#product_color_div').hide(); */
		}
	
	}
	
	function readURL(input) {
		
        if (input.files && input.files[0]) {
			$('#blah').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(98)
                    .height(90);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function removeSingleImg(){
		$('#blah').hide();
	}
	
	function readURL1(input) {
		
        if (input.files && input.files[0]) {
			$('#blah1').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah1')
                    .attr('src', e.target.result)
                    .width(98)
                    .height(90);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function removeSingleImg1(){
		$('#blah1').hide();
	}
	
	function readURL2(input) {
		
        if (input.files && input.files[0]) {
			$('#blah2').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah2')
                    .attr('src', e.target.result)
                    .width(98)
                    .height(90);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function removeSingleImg2(){
		$('#blah2').hide();
	}
	
	function readURL3(input) {
		
        if (input.files && input.files[0]) {
			$('#blah3').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah3')
                    .attr('src', e.target.result)
                    .width(98)
                    .height(90);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function removeSingleImg3(){
		$('#blah3').hide();
	}
	
	function readURL4(input) {
		
        if (input.files && input.files[0]) {
			$('#blah4').show();
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah4')
                    .attr('src', e.target.result)
                    .width(98)
                    .height(90);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function removeSingleImg4(){
		$('#blah4').hide();
	}
	
	$(function() {
		// Multiple images preview in browser
		var imagesPreview = function(input, placeToInsertImagePreview) {
			if (input.files) {
				var filesAmount = input.files.length;
				if($("#gallery-photo-add")[0].files.length > 5)
				{
					cnt = 5;
				}else{
					cnt = filesAmount;
				}
				for (i = 0; i < cnt; i++) {
					var reader = new FileReader();

					reader.onload = function(event) {
						$($.parseHTML('<img width="60" height="60" style="padding: 5px;">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
					}

					reader.readAsDataURL(input.files[i]);
				}
			}

		};

		$('#gallery-photo-add').on('change', function() {
			if ($("#gallery-photo-add")[0].files.length > 5) {
				alert("You can select only 5 images");
				imagesPreview(this, 'div.gallery');
			} else {
				imagesPreview(this, 'div.gallery');
			}
		});
	});
	
	function removeallImg(){
		$('.gallery').html('');
	}

</script>
<?php $this->load->view('admin/_includes/header');?>
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper">
	<!-- BEGIN CONTENT BODY -->
	<div class="page-content">
		<!-- BEGIN PAGE HEADER-->

		<h3 class="page-title">
			Add Customer
		</h3>
		<div class="page-bar">
			<ul class="page-breadcrumb">
				<li><i class="icon-home"></i> <a
					href="<?php echo base_url('admin'); ?>">Home</a> <i
					class="fa fa-angle-right"></i></li>
				<li><a href="<?php echo base_url('admin/customer'); ?>">Customer</a> </li> <i class="fa fa-angle-right"></i>
				<li><a> Add Customer</a> </li>
				<li><span></span>	
			</ul>
		</div>
		<!-- END PAGE HEADER-->

		<div class="row">
			<div class="col-md-12">
				<!-- BEGIN EXAMPLE TABLE PORTLET-->
				<div class="portlet light ">
					<div class="portlet-title">
						<div class="caption font-dark">
							<i class="icon-settings font-dark"></i> <span
								class="caption-subject bold uppercase "> Add Customer</span>
						</div>
						<div class="actions">
								<a href="<?php echo base_url('admin/customer');?>" class="btn btn-circle default fa fa-arrow-left">Back
								</a>
						</div>
					</div>
					<div class="portlet-body">
							<?php if($this->session->flashdata("success_message")!="")
							{
							?>
			        <div class="Metronic-alerts alert alert-info fade in">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
								<i class="fa-lg fa fa-check"></i>  <?php echo $this->session->flashdata("success_message");?>
			        </div>
							<?php 
							}
							if($this->session->flashdata("error_message")!="")
							{
							?>
			        <div class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo $this->session->flashdata("error_message");?>
			        </div>
							<?php 
							}
							if(validation_errors()!="")
							{
							?>
			        <div class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo validation_errors();?>
			        </div>
							<?php 
							}
							if( $this->upload->display_errors()!="")
							{
								?>
			        <div class="Metronic-alerts alert alert-danger fade in">
								<button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
								<i class="fa-lg fa fa-warning"></i>  <?php echo  $this->upload->display_errors();?>
			        </div>
							<?php 
							}
							?>
			              
						<form id="add_student_form" class="horizontal-form" autocomplete="off" action="<?php echo base_url('admin/save_customer');?>"  method="post" enctype="multipart/form-data" autocomplete="Off">
							<div class="form-body">
							
								<h4 style="background-color:#68838B;color:#fff;padding:10px;">PERSONAL DETAILS</h4>
						
								<div class="row">
								
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Customer Name</label><span style="color:red">*</span>
											<input  name="name" class="form-control" maxlength="25" type="text"  value="<?= set_value('name'); ?>" alt="Only 25 Character Allowed" placeholder="Enter full name">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Contact</label><span style="color:red">*</span>
											<input id="start_time" name="contact" class="form-control" type="tel"  value="<?= set_value('contact'); ?>" placeholder="Contact Number">
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Email</label><span style="color:red">*</span>
											<input id="end_time" name="email" class="form-control"  type="Email" value="<?= set_value('email'); ?>" required placeholder="Email Address">
											<span style="color:gray">Email Id is considered as Username</span>
										</div>
									</div>
									
								</div>
							
								<div class="row">

									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Password</label><span style="color:red">*</span>
											<input name="password" class="form-control" type="password"  value="<?= set_value('password'); ?>" required placeholder="Password">
											<span style="color:gray">Password should contain minimum 6 Characters</span>
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Conf. Password</label><span style="color:red">*</span>
											<input name="cpassword" class="form-control" type="password"  value="<?= set_value('cpassword'); ?>" required placeholder="Confirm Password">
										</div>
									</div>

									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Birth Date</label><span style="color:gray">(optional)</span>
											<input id="birth" name="birth" placeholder="Birth Date" class="form-control datepicker"  type="text" value="<?= set_value('birth'); ?>">
										</div>
									
									</div>	
									</div>
										
								</div>

								<h4 style="background-color:#68838B;color:#fff;padding:10px;">Addressing Details</h4>


								<div class="row">

									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Address 1</label><span style="color:red">*</span>
											<textarea id="address1" name="address1" placeholder="Billing Address " class="form-control" rows="3"><?= set_value('address1'); ?></textarea>
											<span style="color:gray">Enter Address lines without Country,State,City,Pincode</span>
										</div>
									</div>

									<div class="col-md-6">
										<div class="form-group">
											<label class="control-label">Address 2</label><span style="color:gray">(optional)</span>
											<textarea id="address2" name="address2" placeholder="Optional billing Address " class="form-control" rows="3"><?= set_value('address2'); ?></textarea>
											<span style="color:gray">Please enter full address</span>
										</div>
									</div>

								</div>

								<div class="row">

									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">Country</label><span style="color:red">*</span>
											<input  name="country" class="form-control" maxlength="25" type="text"  value="India" alt="Only 25 Character Allowed">
										</div>
									</div>
							
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label">State</label><span style="color:red">*</span>
											<input id="state" name="state" class="form-control" placeholder="State" type="text" value="<?= set_value('state'); ?>">
										</div>
									</div>
							
									<div class="row">

										<div class="col-md-4">
											<div class="form-group">
											<label class="control-label">City</label><span style="color:red">*</span>
											<input  name="city" class="form-control" maxlength="25" type="text" placeholder="City" value="<?= set_value('city'); ?>" alt="Only 25 Character Allowed">
											</div>
										</div>
									</div>
									
								</div>
									
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
											<label class="control-label">Pincode</label><span style="color:red">*</span>
											<input id="pin" name="pin" class="form-control" placeholder="Pincode" type="number" value="<?= set_value('pin'); ?>">
											</div>
										</div>
								</div>

							</div>
						
							</div>
								<div class="row"></div>

								<div class="row">
									<div class="col-md-1">
										<button type="submit" class="btn blue"><i class="fa fa-check"></i> Submit</button>
									</div>	
									<div class="col-md-1">
										<a type="button" class="btn default" href="<?php echo base_url('admin/Customer');?>">Cancel</a>
									</div>
							</div>
							
						</form>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>

	</div>
	<!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->

<script>
	var base_url = "<?php echo base_url(); ?>";
</script>

<?php
/*$data ['script'] = "";
$data ['initialize'] = "pageFunctions.init();";*/
$this->load->view ( 'admin/_includes/footer', $data );
?>

<script>
//$("#date").datepicker("setDate", new Date());
//$("#edate").datepicker("setDate", new Date());
	 

	$(".datepicker").datepicker({ 
        minDate: 0,
        format: "yyyy-mm-dd",
        changeMonth: true,
        changeYear: true,
		endDate: new Date(),
        yearRange: '-100:0'
    });

</script>